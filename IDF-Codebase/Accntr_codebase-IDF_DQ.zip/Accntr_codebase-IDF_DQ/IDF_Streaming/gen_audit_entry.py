import datetime

job_end_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
class AuditEntry:
    def __init__(self):
        self.PRCS_NAME='NA'
        self.FILE_NAME='NA'
        self.BATCH_DATE='NA'
        self.SOURCE_NAME='NA'
        self.PRCS_EXECUTION_ID='NA'
        self.PIPELINE_NAME='NA'
        self.TRIG_NAME='NA'
        self.STATUS='NA'
        self.STATUS_DESC='NA'
        self.TECH_STATUS_DESC='NA'
        self.BUSS_STATUS_DESC='NA'
        self.JOB_START_TIME=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.JOB_END_TIME=job_end_time
        self.SOURCE_PATH='NA'
        self.SOURCE_ROW_COUNT='0'
        self.SOURCE_COL_COUNT='0'
        self.SOURCE_AMOUNT='0'
        self.SOURCE_FILE_SIZE='0'
        self.DEST_PATH='NA'
        self.DEST_ROW_COUNT='0'
        self.DEST_COL_COUNT='0'
        self.DEST_AMOUNT='0'
        self.DEST_FILE_SIZE='0'
        self.REJECTED_ROW_COUNT='0'
        self.REJECTED_FILE_NAME='NA'
        self.LOG_PATH='NA'
        self.EXPECTED_PERIOD_KEY='NA'
        self.VALIDATION_FLAG=False

class SuccessStatusMessage:
    def __init__(self,status_desc,validation_exception):
        self.status_desc=status_desc
        if validation_exception is None or validation_exception==0:
            self.tech_message=status_desc
            self.buss_message=status_desc
        else:
            self.tech_message=validation_exception.tech_message
            self.buss_message=validation_exception.buss_message    

class DriverEntry(AuditEntry):
    def __init__(self,prcs_name,batch_date,sourceName,prcs_runid,pipelineName,triggerName,status,exception,job_start_time):
        super().__init__()
        self.PRCS_NAME=prcs_name
        self.FILE_NAME='NA'
        self.BATCH_DATE=batch_date
        self.SOURCE_NAME=sourceName
        self.PRCS_EXECUTION_ID=prcs_runid
        self.PIPELINE_NAME=pipelineName
        self.TRIG_NAME=triggerName
        self.STATUS=status
        self.TECH_STATUS_DESC=exception.tech_message
        self.BUSS_STATUS_DESC=exception.buss_message
        self.JOB_START_TIME=job_start_time


class BeforeSourceRead(AuditEntry):
    def __init__(self,obj,batch_date,status,exception,job_start_time,invalid_val=None):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_val)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=obj["prcs-name"]
        self.FILE_NAME=obj["target-dir"]
        self.BATCH_DATE=batch_date
        self.SOURCE_NAME=obj["sourceName"]
        self.PRCS_EXECUTION_ID=obj["prcs_runid"]
        self.PIPELINE_NAME=obj["pipelineName"]
        self.TRIG_NAME=obj["triggerName"]
        self.STATUS=status
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.STATUS_DESC=self.exception.status_desc
        self.JOB_START_TIME=job_start_time

class BeforeDestinationRead(BeforeSourceRead):
    def __init__(self,obj,batch_date,status,exception,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,invalid_val=None):
        super().__init__(obj,batch_date,status,exception,job_start_time,invalid_val)
        self.SOURCE_PATH=dynamicInputPath
        self.SOURCE_ROW_COUNT=str(inputRowCount)
        self.SOURCE_COL_COUNT=str(inputColumnCount)
        self.SOURCE_FILE_SIZE=str(src_file_size)

class AfterDestinationWrite(BeforeDestinationRead):
    def __init__(self,obj,batch_date,status,exception,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,dest_path,dest_row_cnt,dest_col_cnt,dest_file_size,rejected_row_cnt,rejected_file_path,log_filename,validation_flag=False,invalid_val=None):
        super().__init__(obj,batch_date,status,exception,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,invalid_val)
        self.DEST_PATH=dest_path
        self.DEST_ROW_COUNT=str(dest_row_cnt)
        self.DEST_COL_COUNT=str(dest_col_cnt)
        self.DEST_AMOUNT='0'
        self.DEST_FILE_SIZE=str(dest_file_size)
        self.REJECTED_ROW_COUNT=str(rejected_row_cnt)
        self.REJECTED_FILE_NAME=rejected_file_path
        self.LOG_PATH=log_filename
        self.VALIDATION_FLAG=validation_flag

class CuratedBeforeSourceRead(AuditEntry):
    def __init__(self,obj,batch_date,PRC_EXECUTION_ID,status,exception):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,None)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=obj["prcs-name"]
        self.FILE_NAME=obj["fileName"]
        self.BATCH_DATE=str(batch_date)
        self.SOURCE_NAME=obj['fileName'] 
        self.PRCS_EXECUTION_ID=PRC_EXECUTION_ID
        self.PIPELINE_NAME=obj["pipelineName"]
        self.TRIG_NAME=obj["triggerName"]
        self.STATUS=status
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.STATUS_DESC=self.exception.status_desc

class CuratedAfterDestinationwrite(CuratedBeforeSourceRead):
    def __init__(self,obj,batch_date,PRC_EXECUTION_ID,status,exception,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,dest_row_cnt,dest_col_cnt,log_filename,validation_flag):
        super().__init__(obj,batch_date,PRC_EXECUTION_ID,status,exception)
        self.SOURCE_PATH=dynamicInputPath
        self.SOURCE_ROW_COUNT=str(inputRowCount)
        self.SOURCE_COL_COUNT=str(inputColumnCount)
        self.SOURCE_AMOUNT='0'
        self.SOURCE_FILE_SIZE=str(src_file_size)
        self.DEST_ROW_COUNT=str(dest_row_cnt)
        self.DEST_COL_COUNT=str(dest_col_cnt)
        self.DEST_AMOUNT='0'
        self.LOG_PATH=log_filename
        self.VALIDATION_FLAG=validation_flag

class StreamingAuditEntry(AuditEntry):
    def __init__(self,exit_doc,obj,sourceName,status,exception,job_start_time,invalid_dim=None):
        if type(exception)==str:
            print(exception)
            self.exception=SuccessStatusMessage(exception,invalid_dim)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__(super)
        self.PRCS_NAME=obj["prcs-name"]
        self.SOURCE_NAME=sourceName
        self.PRCS_EXECUTION_ID=obj["prcs_runid"]
        self.STATUS=status
        self.STATUS_DESC = exception
        self.TECH_STATUS_DESC=exception
        self.BUSS_STATUS_DESC=exception
        self.JOB_START_TIME=job_start_time
        self.JOB_END_TIME=job_end_time
        self.ID=exit_doc['ID']
        self.STAGE=exit_doc['STAGE']
        self.RUNID=exit_doc['RUNID']
        self.NAME=exit_doc['NAME']
        self.STREAM_TIMESTAMP=exit_doc['STREAM_TIMESTAMP']
        self.BATCHID=exit_doc['BATCHID']
        self.PRCS_NAME=exit_doc['PRCS_NAME']
        self.STATUS=exit_doc['STATUS']
        self.TRIGGER_TYPE=exit_doc['TRIGGER_TYPE']
        self.LOG_PATH=exit_doc['LOG_PATH']
        self.SOURCE_TYPE=exit_doc['SOURCE_TYPE']
        self.RAW_PATH=exit_doc['RAW_PATH']
        self.RAW_ROW_COUNT = exit_doc['RAW_ROW_COUNT']
        self.RAW_COL_COUNT = exit_doc['RAW_COL_COUNT']
        self.CURATED_PATH=exit_doc['CURATED_PATH']
        self.CURATED_ROW_COUNT = exit_doc['CURATED_ROW_COUNT']
        self.CURATED_COL_COUNT = exit_doc['CURATED_COL_COUNT']
        self.ENRICH_PATH=exit_doc['ENRICH_PATH']
        self.ENRICH_ROW_COUNT = exit_doc['ENRICH_ROW_COUNT']
        self.ENRICH_COL_COUNT = exit_doc['ENRICH_COL_COUNT']
        self.NUMINPUTROWS = exit_doc['NUMINPUTROWS']
        self.INPUTROWSPERSECOND = exit_doc['INPUTROWSPERSECOND'] 
        self.PROCESSEDROWSPERSECOND = exit_doc['PROCESSEDROWSPERSECOND']
        self.GETOFFSET = exit_doc['GETOFFSET'] 
        self.TRIGGEREXECUTION = exit_doc['TRIGGEREXECUTION'] 
        self.SOURCE_DESCRIPTION = exit_doc['SOURCE_DESCRIPTION'] 
        self.START_OFFSET_NAME = exit_doc['START_OFFSET_NAME'] 
        self.START_OFFSET_0 = exit_doc['START_OFFSET_0'] 
        self.START_OFFSET_1 = exit_doc['START_OFFSET_1']
        self.END_OFFSET_NAME = exit_doc['END_OFFSET_NAME'] 
        self.END_OFFSET_0 = exit_doc['END_OFFSET_0'] 
        self.END_OFFSET_1 = exit_doc['END_OFFSET_1'] 
        self.SOURCE_NUM_INPUT_ROWS = exit_doc['SOURCE_NUM_INPUT_ROWS'] 
        self.SOURCE_INPUT_ROWS_PER_SECOND = exit_doc['SOURCE_INPUT_ROWS_PER_SECOND'] 
        self.SINK_DESCRIPTION = exit_doc['SINK_DESCRIPTION'] 
        self.SINK_NUM_OF_OUTPUT_ROWS = exit_doc['SINK_NUM_OF_OUTPUT_ROWS'] 


class TransformLoadDataVault:
    def __init__(self,exit_doc,stg,exception,status,dest_rw_cnt,dest_col_cnt,rej_rw_cnt,expected_period_key,tgt_table='NA',invalid_dim=None):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_dim)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        self.PRCS_NAME=exit_doc["PRCS_NAME"]
        self.FILE_NAME=exit_doc["FILE_NAME"] if tgt_table== 'NA' else tgt_table
        self.BATCH_DATE=exit_doc["BATCH_DATE"]
        self.SOURCE_NAME=exit_doc["SOURCE_NAME"]
        self.PRCS_EXECUTION_ID=exit_doc["PRCS_EXECUTION_ID"]
        self.PIPELINE_NAME=exit_doc["PIPELINE_NAME"]
        self.TRIG_NAME=exit_doc["TRIG_NAME"]
        self.STATUS=status
        self.STAGE=stg
        self.STATUS_DESC=self.exception.status_desc
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.JOB_START_TIME=exit_doc["JOB_START_TIME"]
        self.JOB_END_TIME=job_end_time
        self.SOURCE_PATH=exit_doc["SOURCE"]["SOURCE_PATH"]
        self.SOURCE_ROW_COUNT=exit_doc["SOURCE"]["SOURCE_ROW_COUNT"]
        self.SOURCE_COL_COUNT=exit_doc["SOURCE"]["SOURCE_COL_COUNT"]
        self.SOURCE_AMOUNT=exit_doc["SOURCE"]["SOURCE_AMOUNT"]
        self.SOURCE_FILE_SIZE=exit_doc["SOURCE"]["SOURCE_FILE_SIZE"]
        self.DEST_PATH=exit_doc["DESTINATION"]["DEST_PATH"]
        self.DEST_ROW_COUNT=str(dest_rw_cnt)
        self.DEST_COL_COUNT=str(dest_col_cnt)
        self.DEST_AMOUNT="0"
        self.DEST_FILE_SIZE=exit_doc["DESTINATION"]["DEST_FILE_SIZE"]
        self.REJECTED_ROW_COUNT=str(rej_rw_cnt)
        self.REJECTED_FILE_NAME='NA'
        self.LOG_PATH=exit_doc["LOG_PATH"]
        self.EXPECTED_PERIOD_KEY=str(expected_period_key)
        self.VALIDATION_FLAG=exit_doc["VALIDATION_FLAG"]

class ValidationEntry(AuditEntry):
    def __init__(self,obj,batch_date,status,validation_flag,exception):
        super().__init__()
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,None)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        self.PRCS_NAME=obj["prcs-name"]
        self.PIPELINE_NAME=obj["pipelineName"]
        self.TRIG_NAME=obj["triggerName"]
        self.BATCH_DATE=str(batch_date)
        self.STATUS=status
        self.VALIDATION_FLAG=validation_flag
        self.STATUS_DESC=self.exception.status_desc
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message

class StreamingDriverEntry(AuditEntry):
    def __init__(self,exit_doc,prcs_name,status,status_desc,exception,job_start_time,sourceName,prcs_runid):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_dim)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=prcs_name
        self.SOURCE_NAME=sourceName
        self.PRCS_EXECUTION_ID=prcs_runid
        self.STATUS=status
        self.STATUS_DESC = status_desc
        self.TECH_STATUS_DESC=exception.tech_message
        self.BUSS_STATUS_DESC=exception.buss_message
        self.JOB_START_TIME=job_start_time
        self.JOB_END_TIME=job_end_time
        self.ID=exit_doc['ID']
        self.STAGE=exit_doc['STAGE']
        self.RUNID=exit_doc['RUNID']
        self.NAME=exit_doc['NAME']
        self.STREAM_TIMESTAMP=exit_doc['STREAM_TIMESTAMP']
        self.BATCHID=exit_doc['BATCHID']
        self.PRCS_NAME=exit_doc['PRCS_NAME']
        self.STATUS=exit_doc['STATUS']
        self.TRIGGER_TYPE=exit_doc['TRIGGER_TYPE']
        self.LOG_PATH=exit_doc['LOG_PATH']
        self.SOURCE_TYPE=exit_doc['SOURCE_TYPE']
        self.RAW_PATH=exit_doc['RAW_PATH']
        self.RAW_ROW_COUNT = exit_doc['RAW_ROW_COUNT']
        self.RAW_COL_COUNT = exit_doc['RAW_COL_COUNT']
        self.CURATED_PATH=exit_doc['CURATED_PATH']
        self.CURATED_ROW_COUNT = exit_doc['CURATED_ROW_COUNT']
        self.CURATED_COL_COUNT = exit_doc['CURATED_COL_COUNT']
        self.ENRICH_PATH=exit_doc['ENRICH_PATH']
        self.ENRICH_ROW_COUNT = exit_doc['ENRICH_ROW_COUNT']
        self.ENRICH_COL_COUNT = exit_doc['ENRICH_COL_COUNT']
        self.NUMINPUTROWS = exit_doc['NUMINPUTROWS']
        self.INPUTROWSPERSECOND = exit_doc['INPUTROWSPERSECOND'] 
        self.PROCESSEDROWSPERSECOND = exit_doc['PROCESSEDROWSPERSECOND']
        self.GETOFFSET = exit_doc['GETOFFSET'] 
        self.TRIGGEREXECUTION = exit_doc['TRIGGEREXECUTION'] 
        self.SOURCE_DESCRIPTION = exit_doc['SOURCE_DESCRIPTION'] 
        self.START_OFFSET_NAME = exit_doc['START_OFFSET_NAME'] 
        self.START_OFFSET_0 = exit_doc['START_OFFSET_0'] 
        self.START_OFFSET_1 = exit_doc['START_OFFSET_1']
        self.END_OFFSET_NAME = exit_doc['END_OFFSET_NAME'] 
        self.END_OFFSET_0 = exit_doc['END_OFFSET_0'] 
        self.END_OFFSET_1 = exit_doc['END_OFFSET_1'] 
        self.SOURCE_NUM_INPUT_ROWS = exit_doc['SOURCE_NUM_INPUT_ROWS'] 
        self.SOURCE_INPUT_ROWS_PER_SECOND = exit_doc['SOURCE_INPUT_ROWS_PER_SECOND'] 
        self.SINK_DESCRIPTION = exit_doc['SINK_DESCRIPTION'] 
        self.SINK_NUM_OF_OUTPUT_ROWS = exit_doc['SINK_NUM_OF_OUTPUT_ROWS'] 

class readStreamException(AuditEntry):
    def __init__(self,exit_doc,obj,sourceName,status,exception,job_start_time):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_val)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=obj["prcs-name"]
        self.SOURCE_NAME=sourceName
        self.PRCS_EXECUTION_ID=obj["prcs_runid"]
        self.STATUS=status
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.STATUS_DESC=self.exception.status_desc
        self.JOB_START_TIME=job_start_time
        self.JOB_END_TIME=job_end_time
        self.ID=exit_doc['ID']
        self.STAGE=exit_doc['STAGE']
        self.RUNID=exit_doc['RUNID']
        self.NAME=exit_doc['NAME']
        self.STREAM_TIMESTAMP=exit_doc['STREAM_TIMESTAMP']
        self.BATCHID=exit_doc['BATCHID']
        self.PRCS_NAME=exit_doc['PRCS_NAME']
        self.STATUS=exit_doc['STATUS']
        self.TRIGGER_TYPE=exit_doc['TRIGGER_TYPE']
        self.LOG_PATH=exit_doc['LOG_PATH']
        self.SOURCE_TYPE=exit_doc['SOURCE_TYPE']
        self.RAW_PATH=exit_doc['RAW_PATH']
        self.RAW_ROW_COUNT = exit_doc['RAW_ROW_COUNT']
        self.RAW_COL_COUNT = exit_doc['RAW_COL_COUNT']
        self.CURATED_PATH=exit_doc['CURATED_PATH']
        self.CURATED_ROW_COUNT = exit_doc['CURATED_ROW_COUNT']
        self.CURATED_COL_COUNT = exit_doc['CURATED_COL_COUNT']
        self.ENRICH_PATH=exit_doc['ENRICH_PATH']
        self.ENRICH_ROW_COUNT = exit_doc['ENRICH_ROW_COUNT']
        self.ENRICH_COL_COUNT = exit_doc['ENRICH_COL_COUNT']
        self.NUMINPUTROWS = exit_doc['NUMINPUTROWS']
        self.INPUTROWSPERSECOND = exit_doc['INPUTROWSPERSECOND'] 
        self.PROCESSEDROWSPERSECOND = exit_doc['PROCESSEDROWSPERSECOND']
        self.GETOFFSET = exit_doc['GETOFFSET'] 
        self.TRIGGEREXECUTION = exit_doc['TRIGGEREXECUTION'] 
        self.SOURCE_DESCRIPTION = exit_doc['SOURCE_DESCRIPTION'] 
        self.START_OFFSET_NAME = exit_doc['START_OFFSET_NAME'] 
        self.START_OFFSET_0 = exit_doc['START_OFFSET_0'] 
        self.START_OFFSET_1 = exit_doc['START_OFFSET_1']
        self.END_OFFSET_NAME = exit_doc['END_OFFSET_NAME'] 
        self.END_OFFSET_0 = exit_doc['END_OFFSET_0'] 
        self.END_OFFSET_1 = exit_doc['END_OFFSET_1'] 
        self.SOURCE_NUM_INPUT_ROWS = exit_doc['SOURCE_NUM_INPUT_ROWS'] 
        self.SOURCE_INPUT_ROWS_PER_SECOND = exit_doc['SOURCE_INPUT_ROWS_PER_SECOND'] 
        self.SINK_DESCRIPTION = exit_doc['SINK_DESCRIPTION'] 
        self.SINK_NUM_OF_OUTPUT_ROWS = exit_doc['SINK_NUM_OF_OUTPUT_ROWS']

class WriteForEachException(AuditEntry):
    def __init__(self,exit_doc,obj,sourceName,status,exception,sourceType,sourceRowCount,sourceColCount,job_start_time):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_val)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=obj["prcs-name"]
        self.SOURCE_NAME=sourceName
        self.PRCS_EXECUTION_ID=obj["prcs_runid"]
        self.STATUS=status
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.STATUS_DESC=self.exception.status_desc
        self.JOB_START_TIME=job_start_time
        self.JOB_END_TIME=job_end_time
        self.LOG_PATH=obj['log_file_name']
        self.TRIGGER_TYPE='NA'
        self.SOURCE_TYPE=sourceType
        self.SOURCE_ROW_COUNT = sourceRowCount
        self.SOURCE_COL_COUNT = sourceColCount
        self.RAW_PATH='NA'
        self.RAW_ROW_COUNT = "0"
        self.RAW_COL_COUNT = "0"
        self.CURATED_PATH= "NA" 
        self.CURATED_ROW_COUNT = "0"
        self.CURATED_COL_COUNT = "0"
        self.ENRICH_PATH= "NA"
        self.ENRICH_ROW_COUNT = "0"
        self.ENRICH_COL_COUNT = "0"

#Default audit entries for streaming
class AuditEntryStreaming:
    def __init__(self):
        self.ID='NA'
        self.RUNID='NA'
        self.NAME='NA'
        self.STREAM_TIMESTAMP=''
        self.BATCHID='0'
        self.FOREACHBATCH='0'
        self.STAGE='NA'
        self.STATUS_DESC='NA'
        self.TECH_STATUS_DESC='NA'
        self.BUSS_STATUS_DESC='NA'
        self.JOB_END_TIME=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.TRIGGER_TYPE='NA'
        self.SOURCE_TYPE='NA'
        self.SOURCE_NAME='NA'
        self.START_OFFSET='NA'
        self.SOURCE_DESCRIPTION='NA'
        self.END_OFFSET='NA'
        self.SINK_DESCRIPTION='NA'
        self.CHECKPOINT_PATH='NA'
        self.RAW_PATH='NA'
        self.RAW_ROW_COUNT='0'
        self.RAW_COL_COUNT='0'
        self.CURATED_PATH='NA'
        self.CURATED_ROW_COUNT='0'
        self.CURATED_COL_COUNT='0'
        self.ENRICH_PATH='NA'
        self.ENRICH_ROW_COUNT='0'
        self.ENRICH_COL_COUNT='0'

#Audit entries added in case of exceptions encountered in Driver code
class DriverEntryStreaming(AuditEntryStreaming):
    def __init__(self,prcs_name,sourceName,prcs_runid,status,exception,job_start_time,json,logpath):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_dim)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.PRCS_NAME=prcs_name
        self.SOURCE_NAME=sourceName
        self.STATUS=status
        self.TECH_STATUS_DESC=exception.tech_message
        self.BUSS_STATUS_DESC=exception.buss_message
        self.JOB_START_TIME=job_start_time
        self.JSON=json
        self.LOG_PATH=logpath
        self.STATUS_DESC=self.exception.status_desc

#Audit entry for readStream
class BeforeStreamRead(AuditEntryStreaming):
    def __init__(self,exit_doc,obj,status,exception,job_start_time,invalid_val=None):
        if type(exception)==str:
            self.exception=SuccessStatusMessage(exception,invalid_val)
        else:
            self.exception=exception
            self.exception.status_desc=exception.tech_message
        super().__init__()
        self.JSON=exit_doc["JSON"]
        self.PRCS_NAME=obj["prcs-name"]              
        self.SOURCE_NAME=obj["sourceName"]
        self.STATUS=status
        self.TECH_STATUS_DESC=self.exception.tech_message
        self.BUSS_STATUS_DESC=self.exception.buss_message
        self.STATUS_DESC=self.exception.status_desc
        self.JOB_START_TIME=job_start_time
        self.JSON=exit_doc['JSON']
        self.LOG_PATH=exit_doc['LOG_PATH']

#Foreachbatch audit entry
class WriteStreamForEachBatch(BeforeStreamRead):
    def __init__(self,exit_doc,obj,status,exception,job_start_time,invalid_val=None):
        super().__init__(exit_doc,obj,status,exception,job_start_time,invalid_val=None)
        self.JSON=exit_doc["JSON"]
        self.PRCS_NAME=obj["prcs-name"]
        self.TRIGGER_TYPE=exit_doc['TRIGGER_TYPE']
        self.SOURCE_TYPE=exit_doc['SOURCE_TYPE']
        self.CHECKPOINT_PATH = exit_doc['CHECKPOINT_PATH']
        self.RAW_PATH=exit_doc['RAW_PATH']
        self.RAW_ROW_COUNT = exit_doc['RAW_ROW_COUNT']
        self.RAW_COL_COUNT = exit_doc['RAW_COL_COUNT']
        self.CURATED_PATH= exit_doc['CURATED_PATH']
        self.CURATED_ROW_COUNT = exit_doc['CURATED_ROW_COUNT']
        self.CURATED_COL_COUNT = exit_doc['CURATED_COL_COUNT']
        self.ENRICH_PATH= exit_doc['ENRICH_PATH']
        self.ENRICH_ROW_COUNT = exit_doc['ENRICH_ROW_COUNT']
        self.ENRICH_COL_COUNT = exit_doc['ENRICH_COL_COUNT']

class StreamRawData(WriteStreamForEachBatch):
    def __init__(self,exit_doc,obj,status,exception,job_start_time,invalid_val=None):
        super().__init__(exit_doc,obj,status,exception,job_start_time,invalid_val=None)
        self.ID=exit_doc['ID']
        self.RUNID=exit_doc['RUNID']
        self.NAME=exit_doc['NAME']
        self.STREAM_TIMESTAMP=exit_doc['STREAM_TIMESTAMP']
        self.BATCHID=exit_doc['BATCHID']
        self.START_OFFSET=exit_doc['START_OFFSET']
        self.END_OFFSET=exit_doc['END_OFFSET']
        self.SINK_DESCRIPTION=exit_doc['SINK_DESCRIPTION']
        self.SOURCE_DESCRIPTION=exit_doc['SOURCE_DESCRIPTION']
        
class StreamForeachbatch(StreamRawData):
    def __init__(self,exit_doc,obj,status,exception,job_start_time,invalid_val=None):
        super().__init__(exit_doc,obj,status,exception,job_start_time,invalid_val=None)
        self.ID=exit_doc['ID']
        self.RUNID=exit_doc['RUNID']
        self.NAME=exit_doc['NAME']
        self.STREAM_TIMESTAMP=exit_doc['NAME']
        self.BATCHID=exit_doc['BATCHID']
        self.FOREACHBATCH=exit_doc['FOREACHBATCH']
        self.STAGE=exit_doc['STAGE']
        self.JOB_END_TIME=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        self.START_OFFSET=exit_doc['START_OFFSET']
        self.END_OFFSET=exit_doc['END_OFFSET']


