# -*- coding: utf-8 -*-

import time
import os
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType

# from elasticsearch import Elasticsearch

from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import lit, col, lower, trim, coalesce,upper, when,substring
import hashlib
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import *

class UtilsIO:

	def __init__(self):
		pass

	def get_max_batchdate(src_path):
		date_col=os.listdir("/dbfs"+src_path)
		return str(max(date_col))

	def read_db_pushdown(spark,query,obj,sourceDict=0):

		connectionProperties = {"driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
		pushdown_query = query
		source_df1 = spark.read.jdbc(url=(obj["sqlserver"]["connection-string"]), table=pushdown_query, properties=connectionProperties)
	
		return source_df1

	def read_enrich(spark,tableName,obj,sourceDict=0):

		# Check if the additional filter is provided
		if isinstance(sourceDict, dict) and 'read-type' in sourceDict:
			readType = str(sourceDict['read-type'])
			#sourceName = str(sourceDict['source-filter'])
		elif 'read-type' in obj and 'source-filter' in obj:
			readType = str(obj['read-type'])
			#sourceName = str(obj['source-filter'])
		else:
			readType = 'full'

		if readType == 'rec-source-filtered':
			source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load().where(col('SRC_ID') == str(obj['srcId']))
		if readType == 'rec-batchdate-filtered':
			batch_date=str(datetime.strptime(obj["batchDate"], '%Y%m%d'))[:10]
			source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load()
			source_df1.show()
			print(batch_date)
			source_df1=source_df1.where(col("BATCH_DATE")== batch_date)
			source_df1.show()
		else:
			# Full load
			source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load()
		return source_df1

	def postAction_query(obj,lookupType,tgt_table,table_name):
		dwhTargetTable = obj['target-table']
		dwhStagingTable = tgt_table
		lookupColumns = obj[lookupType]['lookup-columns']
		deltaName = obj[lookupType]['natural-key']
		postActions = ""

		#STEP1: Delete existing records
		whereClause=""
		for col in lookupColumns:
			whereClause= whereClause + dwhTargetTable  +"."+ col  + "="+ dwhStagingTable +"." + col + " and "
		
		if deltaName is not None and  len(deltaName) >0:
				
			whereClause= whereClause + dwhTargetTable  +"."+ deltaName  + "= "+ dwhStagingTable +"." + deltaName + " and " + dwhTargetTable + ".CURR_IND = 1"
		else:
			#remove last "and"
			remove="and"
			reverse_remove=remove[::-1]
			whereClause = whereClause[::-1].replace(reverse_remove,"",1)[::-1]
	
		deleteOutdatedSQL = "delete from " + dwhStagingTable + " where exists (select 1 from " + dwhTargetTable + " where " + whereClause + " );"
		#print("deleteOutdatedSQL={}".format(deleteOutdatedSQL))

		#STEP2: Insert new records staging
		insertSQL ="Insert Into " + dwhStagingTable + " select * from " + table_name +";"
		#print("insertSQL={}".format(insertSQL))
		
		if lookupType == "postAction-lookup":
			#consolidate post actions SQL
			postActions = insertSQL + deleteOutdatedSQL
		else:
			postActions = deleteOutdatedSQL

		print(postActions)
		return postActions
	   


	def write_enrich(dbutils, HASH_TABLE, spark, obj,v_mode,tgt_table,logger):
	#  Write data to table
		account_name = obj["azure"]["storage_account_name"]
		stg_account_name = "fs.azure.account.key."+ account_name +".dfs.core.windows.net"
		stg_account_key = obj["azure"]["storage_account_access_key"]
		spark.conf.set(stg_account_name,stg_account_key)
		spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
		spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")
		tempDir=obj["sqlserver"]["tempDir"]

		table_split = tgt_table.split(".")
		table_name = "#" + table_split[1]
		preAction = "TRUNCATE TABLE " + tgt_table

		if 'postAction-lookup' in obj and str(obj['postAction-lookup']['enable-type2']) == "true": 
			#consolidate post actions SQL
			postActions = UtilsIO.postAction_query(obj,'postAction-lookup',tgt_table,table_name) 
			logger.info("postActionsSQL={}".format(postActions))
		
		else:	
			postActions = "INSERT INTO "+ tgt_table + " SELECT * FROM "+ table_name +";"
		
		HASH_TABLE.write.format("com.databricks.spark.sqldw").option("url", str(obj["sqlserver"]["connection-string"])).option("useAzureMSI","true").mode('append').option("dbTable", table_name).option('preActions',preAction).option('postActions', postActions).option("tempDir", tempDir).save()
		query = "(select count(*) as destRowCount from " + tgt_table + " ) AS CNT"
		print(query)
		(destRowCount) = (UtilsIO.read_db_pushdown(spark,query,obj,sourceDict=0).first()['destRowCount'])

		destRowCount = int(destRowCount)

		return destRowCount


	def write_enrich_old(dbutils, HASH_TABLE, spark, obj,v_mode,tgt_table):
		#  Write data to table
		HASH_TABLE.write.format("jdbc").option("url", str(obj["sqlserver"]["connection-string"])).mode(v_mode).option("dbTable", tgt_table ).save()



	def ref_look_up_list(spark, obj, ref):

		# Read Atomic Table from phoenix for REF_LOOK_UP
		REF_TABLE = spark.read.format('org.apache.phoenix.spark').option('table',str(ref['ref-table-name'])).option('zkUrl', str(obj['hdi']['zkurl'])).load()

		for refColName in ref['ref-look-up-values'].keys():
			REF_TABLE = REF_TABLE.filter(lower(col(refColName))
					== str(ref['ref-look-up-values'][refColName]).lower())

		# return REF_TABLE
		# Obtain the list of values from the return look up col

		returnList1 = REF_TABLE.select(ref['return-look-up-col']).collect()

		if "return-look-up-col-const" in ref:
			lenConst = int(ref['return-look-up-col-const']['length'])
			padValue = str(ref['return-look-up-col-const']['rpad'])
			returnList = [str(row[ref['return-look-up-col'
						]]).strip().rjust(lenConst, str(padValue))
						for row in returnList1]
		else:
			returnList = [str(row[ref['return-look-up-col']]) for row in returnList1]

		return returnList


	def has_column(df, col):
		try:
			df[col]
			return True
		except AnalysisException:
			return False


	# TO extract the columns from the Dataframe with rename and explode if the coltype is array

	def get_col_with_alias(inputDF,listofCols,sourceDict,listDictofAlias=0,flatten=1):

		# Add col if not preset
		for (ind, colName) in enumerate(listofCols):
			if not UtilsIO.has_column(inputDF, colName):
				if '.' in colName:
					colName = colName.replace('.', '_')
					listofCols[ind] = colName
				inputDF = inputDF.withColumn(colName,
						lit(None).cast('string'))
		# Check if the alias list is passed and whether if its dict or list
		if isinstance(listDictofAlias, list):
			for (colName, colAlias) in zip(listofCols, listDictofAlias):
				inputDF = inputDF.withColumn(colAlias, col(colName))
		elif isinstance(listDictofAlias, dict):

		# Add the column from the dict with new name and then update the list
			listDictofAliasTemp = listDictofAlias
			for colName in listDictofAliasTemp.keys():
				inputDF = inputDF.withColumn(listDictofAliasTemp[colName],col(colName))
				listDictofAlias = [listDictofAliasTemp.get(n, n) for n in listofCols]
		elif listDictofAlias == 0:

		# Generate the names if the alias names not provided
			listDictofAlias = []
			for colName in listofCols:
				if '.' in colName:
					colAlias = colName.replace('.', '_')
					inputDF = inputDF.withColumn(colAlias, col(colName))
				else:
					colAlias = colName
				listDictofAlias.append(colAlias)

		# select the required cols
		resDF = inputDF.select(listDictofAlias)
		

		# Explode the arrays or struct
		if flatten == 1:
			for (colName, typeCol) in resDF.dtypes:
				if typeCol[0:5] == 'array':
					resDF = resDF.withColumn(colName, explode(colName))
				if typeCol[0:6] == 'struct':
					for c in resDF.select(colName + '.*').columns:
						resDF = resDF.withColumn(colName + '_' + c,col(colName + '.' + c))
					resDF = resDF.drop(colName)

		# get the distinct rows
		if "drop-duplicates" in sourceDict and sourceDict["drop-duplicates"]==True:
			resDF = resDF.dropDuplicates()


		# Return the resultant Dataframe
		return resDF

	def get_df_with_renamed(HASHDF,src_list,trgt_list):
		HASHDF = HASHDF.select(src_list)

		for x,y in zip(src_list,trgt_list):
			HASHDF=HASHDF.withColumnRenamed(x, y)

		return HASHDF


	# write the dataframe into a sql table
	def write_data_sql(HASH_TABLE, obj,v_mode,tgt_table):
		if HASH_TABLE.count() > 0:
			database = str(obj['sqlserver']['jdbcDatabase'])
			port = str(obj['sqlserver']['jdbcPort'])
			hostname = str(obj['sqlserver']['jdbcHostname'])
			HASH_TABLE.write \
				.format("jdbc") \
				.option("url",f"jdbc:sqlserver://{hostname}:{port};database={database};") \
				.option("dbtable",tgt_table) \
				.option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver") \
				.option("user",str(obj["sqlserver"]["username"])) \
				.option("password",str(obj["sqlserver"]["password"])) \
				.mode(v_mode) \
				.save()

	# read data from sql table
	def read_data_sql_table(spark,obj,tableName,logger):
		"""
			@params: spark, envConfig, table Name, logger
			@returns: spark dataframe from dq Master table
		"""
		try:
			if "sqlserver" in obj.keys():
				jdbcHostname = obj['sqlserver']['jdbcHostname']
				jdbcDatabase = obj['sqlserver']['jdbcDatabase']
				jdbcPort = obj['sqlserver']['jdbcPort']
				username = obj['sqlserver']['username']
				password = obj['sqlserver']['password']
				hostNameInCertificate = obj['sqlserver']['hostNameInCertificate']
				jdbcUrl = obj['sqlserver']['jdbc-connection-string']
				jdbcUrl = jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)
				connectionProperties = {"user": username, "password": password,
										"driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
				# query = '(select * from dbo.dqMaster where TABLE_NAME = {0} and IsActive = 1) as t1'.format(tableName)
				query = '(select * from dbo.dqMaster order by RULE_ID desc OFFSET 0 ROWS) as t1'
				print(jdbcUrl)
				print(query)
				# read sql table and create spark dataframe on top of it
				df = spark.read.jdbc(url=jdbcUrl, table=query, properties=connectionProperties)

				if df.count() > 0:
					print('returning df of dq Master')
					return df
		except:
			logger.info("Sql server properties are missing")
			raise ValueError("Sql server properties are missing ")


	# Read data based on format from multiple source
	def read_data_based_on_format(spark,obj, format, path, tableName, logger, delimiter=','):
		"""
		@params: spark, envConfig, file format, file path, filename/tableName, delimiter (in case of file)
		@returns: spark dataframe from table or file location provided
		"""
		try:
			format = format.lower()
			if format == 'csv' | format == 'txt':
				filePath = path+tableName+'.'+format
				outputDF = spark.read.option(header = True) \
									.option(inferSchema='True') \
									.option(delimiter = delimiter) \
									.csv(filePath)
			if format == 'parquet':
				filePath = path + tableName + '.' + format
				outputDF = spark.read.parquet(filePath)

			if format == 'sqltable':
				query = '(select * from {}) as t1'.format(tableName)
				outputDF = read_data_sql_table(spark,obj,query)

			return outputDF
		except:
			logger.info("Sql server properties are missing")
			raise ValueError("Sql server properties are missing ")