import traceback
import sys,os
import logging
import re
import hashlib
import time
import glob
from pyspark.sql.functions import udf,lit,split,input_file_name,reverse,split,monotonically_increasing_id,col,collect_list
from pyspark.sql.types import StringType, DateType, IntegerType,TimestampType
from pyspark.sql import SparkSession
import Utils
from metadataManager import metadataManager
import datetime
from collections import OrderedDict
from pyspark.sql import DataFrame as SparkDataFrame


sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
from customException import *
from gen_audit_entry import *

millis = int(round(time.time() * 1000))
###################################################################################################
def process(spark,obj,inputDF,dbutils, exit_doc):
    job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")) 
    loc = str(obj['varbatchdate'])
    stage='txt-batch-ingestion-process'
    log_filename =  obj['local_log_file_name']
    logger = utilsShared.getFormattedLogger(stage,log_filename)
    validation_flag=False
    null_cnt=0
    #spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
    spark = SparkSession.builder.appName(obj["use-case"]).getOrCreate()
    spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    metadataObject = metadataManager()

    try:
        logger.info("Inside try of txt-batch-ingestion")
        file_ext=obj["fileExt"]
        audit_doc=OrderedDict()

        # creating dynamic input path
        dynamicInputPath =str(obj['azure']['raw-base-path']) + str(obj['raw-location']) + "." + str(file_ext)
        logger.info("Dynamic Input Path: " + dynamicInputPath)
        # generate dynamic input path for multiple files in raw (based on if all required or latest only)
        try:
            dynamicInputPath= Utils.gen_dynamic_input_path(obj,dynamicInputPath,dbutils,logger)
        except Exception as e:
            try:
                logger.error(traceback.print_exc())
                raise issueWhileFindinglatestFileError(dynamicInputPath)
            except issueWhileFindinglatestFileError as lfe:
                audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',lfe,job_start_time)
                audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,lfe)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0
                return 0, exit_doc                  

        if "sla_check" in obj:
            dynamicInputPath_p =str(obj['azure']['raw-base-path']) + str(obj['raw-location']) + loc + "*." + str(file_ext) + '*' 
            sla_status=Utils.sla_check(obj, dynamicInputPath_p)
            
            if (sla_status == '1st' or sla_status == '2nd'):
                try:
                    raise SLABreachError(obj['fileName'], sla_status)
                except SLABreachError as fnf:
                    audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',fnf,job_start_time)
                    audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,fnf)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0, exit_doc
            else:
                pass
                
        # if dynamic input path is None , no new file came from the source -- succeed only for forecast files
        if dynamicInputPath is not None:
            # Generating source file size and Actual path for generating fin_mth 
            src_file_size=0
            src_file_size,act_path=Utils.gen_src_file_size(dynamicInputPath,dbutils)

            #Initiating Exception DF to 0
            exception_df=0

            file_cnt_chk_flag,expected_file_count,actual_files_count=Utils.get_file_cnt_check(obj,dynamicInputPath)
            if file_cnt_chk_flag:
                pass
            else:
                try:
                    raise fileCountNotMatchedError(actual_files_count,expected_file_count)
                except fileCountNotMatchedError as fe:
                    audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',fe,job_start_time)
                    audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,fe)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0, exit_doc

            if (file_ext == 'csv' or  file_ext == 'txt'):
                return_value = Utils.file_delimit_validation(obj, dynamicInputPath, dbutils, logger)
                if (return_value is False):
                    try:
                        raise delimitterMismatchError(obj['delimiter'])
                    except delimitterMismatchError as dme:
                        audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',dme,job_start_time)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,dme)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc
            
            if "file_schema" in obj:
                parsed_df=None
                logger.debug("Parsing the file with schema given explicitly in config")

                try:
                    file_schema_broadcast=spark.sparkContext.broadcast(obj["file_schema"])
                    nullValue=obj["nullValue"] if "nullValue" in obj else ""
                    if ((file_ext == 'csv' or  file_ext == 'txt' or file_ext == 'dat') and "src_filename" in obj and obj["src_filename"]!="yes"):      
                        logger.info("Reading CSV file")
                        parsed_df = spark.read.format("csv").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(dynamicInputPath,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                        logger.debug("Reading file from ADLS")
                        print("__________________________")
                        print("Records read "+str(parsed_df.count()))
                        parsed_df.show(50,False)
                    elif ((file_ext == 'csv' or  file_ext == 'txt' or file_ext == 'dat' ) and "src_filename" in obj and  obj["src_filename"]=="yes"):
                        
                        parsed_df = spark.read.format("csv").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(dynamicInputPath,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("SRC_FILENAME",input_file_name()).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                        logger.info("Records read from CSV ######################")
                        print(parsed_df.count())
                        parsed_df=parsed_df.withColumn("SRC_FILENAME",reverse(split(col("SRC_FILENAME"),'/'))[0])

                    elif file_ext == 'parquet':
                        logger.info("Reading parquet file")
                        parsed_df = spark.read.format("parquet").option("header",obj["header"]).option("comment",obj["comment"]).option("nullValue",nullValue).load(dynamicInputPath,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()

                    elif file_ext in ('xlsx','xlsm'):
                        absolutefilepath=glob.glob('/dbfs'+dynamicInputPath)
                        filepath=' '.join(absolutefilepath)[5:]
                        infer_schema=obj["infer_schema"] if "infer_schema" in obj else "false"
                        if obj["data-address"]!="":
                            parsed_df = spark.read.format("com.crealytics.spark.excel").option("dataAddress",obj["data-address"]).option("useHeader", obj["header"]).option("inferSchema", infer_schema).load(filepath)
                        else:
                            parsed_df = spark.read.format("com.crealytics.spark.excel").option("useHeader", obj["header"]).option("inferSchema",infer_schema).load(filepath)
                        parsed_df = parsed_df.na.drop(how="all")
                    inputrowcnt=parsed_df.count()
                    logger.info(str(inputrowcnt))
                    inputcolcnt=len(parsed_df.columns)
                    
                except Exception as e:
                    try:
                        logger.error(traceback.print_exc())
                        raise fileNotFoundError(dynamicInputPath)
                    except fileNotFoundError as fnf:
                        audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',fnf,job_start_time)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,fnf)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc
                try:
                    inputDF,exception_df,null_cnt=Utils.schema_validation(obj,parsed_df,file_schema_broadcast.value,file_ext)
                except Exception as e:
                    try:
                        logger.error(traceback.print_exc())
                        raise schemaValidationError(dynamicInputPath)
                    except schemaValidationError as sve:
                        audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',sve,job_start_time,dynamicInputPath,inputrowcnt,inputcolcnt,src_file_size)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,sve)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc
                logger.debug("Schema is exposed to the data and Dataframe is created")
                logger.info(str(inputDF.count()))

            else:
                parsed_df=None
                logger.debug("Parsing the file with inferring the schema from file itself")
                if ((file_ext == 'csv' or  file_ext == 'txt') and "src_filename" in obj and  obj["src_filename"]!="yes"):
                    # Storage read from Blob storage
                    parsed_df = spark.read.format("csv").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(dynamicInputPath).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
                elif ((file_ext == 'csv' or  file_ext == 'txt') and "src_filename" in obj and obj["src_filename"]=="yes"):
                    parsed_df = spark.read.format("csv").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(dynamicInputPath).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
                    parsed_df=parsed_df.withColumn("SRC_FILENAME",input_file_name())
                    split_source_filename=reverse(split(parsed_df['SRC_FILENAME'],'/'))
                    parsed_df=parsed_df.withColumn("SRC_FILENAME",lit(split_source_filename.getItem(0)))
                elif file_ext in ('xlsx','xlsm'):
                    absolutefilepath=glob.glob('/dbfs'+dynamicInputPath)
                    filepath=' '.join(absolutefilepath)[5:]
                    if obj["data-address"]!="":

                        parsed_df = spark.read.format("com.crealytics.spark.excel").option("dataAddress",obj["data-address"]).option("useHeader", obj["header"]).option("inferSchema", "true").load(filepath)
                    else:
                        parsed_df = spark.read.format("com.crealytics.spark.excel").option("useHeader", obj["header"]).option("inferSchema", "true").load(filepath)
                    parsed_df = parsed_df.na.drop(how="all")
                inputDF=parsed_df.withColumn("ERROR_CODE",lit(2)).withColumn("ERROR_DESC",lit(None).cast(StringType()))


            output =  str(obj['azure']['clean-base-path']) + str(obj['clean-location']) + "/"    
            exception_path=str(obj['azure']['exception-base-path']) + str(obj['exception-layer-location']) + "/"
            logger.info("Output path is:"+str(output))


            # Updating the Column names to remove special character not allowed in parquet
            inputDF = inputDF.toDF(*(re.sub(r'[\,\s;\n\t\={}():]+', '_', c) for c in inputDF.columns))
            
            # Adjustment period data validation against 0 or None values
            if "adjustment-data-flag" in obj:
                ret,period = Utils.adjustment_validation(spark,inputDF, obj, logger)
                if (ret is False):
                    try:
                        raise InvalidAdjustmentData(period)
                    except InvalidAdjustmentData as iad:
                        audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',iad,job_start_time)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,iad)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc

            # if Any transformation is required
            if "transformation" in obj:
                transformationtype=obj["transformation"]
                try:
                    inputDF,transformationtype=Utils.get_transformation(inputDF,obj)
                except Exception as ex:
                    try:
                        logger.error(traceback.print_exc())
                        raise transformationError(transformationtype)
                    except transformationError as tfe:
                        audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',tfe,job_start_time,dynamicInputPath,inputrowcnt,inputcolcnt,src_file_size)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,tfe)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc


            destination_path=output
            if "forecast-plan-flag" in obj:
                try:
                    inputDF,destination_path=Utils.add_fin_yr_mth_ptn(obj,dynamicInputPath,output,inputDF,act_path)
                except Exception as ex:
                    try:
                        logger.error(traceback.print_exc())
                        raise addingfinYearAndMonthError(destination_path)
                    except addingfinYearAndMonthError as afe:
                        audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',afe,job_start_time,dynamicInputPath,inputrowcnt,inputcolcnt,src_file_size)
                        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,afe)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0, exit_doc

            inputRowCount = inputDF.count()+null_cnt
            inputColumnCount=str(len(inputDF.columns))


            #Adding Metadata columns
            inputDF=Utils.add_metadata_columns(inputDF,obj)

            target_df=0
            dest_file_size=0
            if inputRowCount > 0:
                if obj["data-profile"] == "true" : # removed advance profiling from option
                    document={}
                    profile_file_name= str(obj['azure']['raw-base-path']) + '/profile_' + str(obj["target-dir"]) + '_' + loc + '.csv'
                    document['profile'] = Utils.profile(inputDF)

                    metadataObject.insert_profileRecord(document['profile'],profile_file_name)

                logger.debug("output path for csv ingestion is :" + output)

                #comapring source and Target DF for current Financial year
                src_vs_tgt_diff=1
            
                if "forecast-plan-flag" in obj:
                    # Comparing Source and Target Dataframe
                    try:
                        src_vs_tgt_diff=Utils.gen_src_tgt_comparison_flag(obj,destination_path,src_vs_tgt_diff,inputDF,spark)
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise sourceVsTargetComparisonError()
                        except sourceVsTargetComparisonError as sve:
                            audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',sve,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size)
                            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,sve)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0, exit_doc


                if src_vs_tgt_diff!=0: 
                    # Writing final Dataframe to curated layer
                    try:
                        Utils.write_df(obj,inputDF,output)
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise writeDataframeError(output)
                        except writeDataframeError as wde:
                            audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',wde,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size)
                            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,wde)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0, exit_doc
                    try:
                        target_df=spark.read.parquet(destination_path)

                        if "filter-by-src_filename" in obj:
                            DF = inputDF
                            DF = DF.select("src_filename").distinct()
                            file_list=DF.select(collect_list("src_filename")).collect()[0][0]
                            target_df= target_df.where(col("src_filename").isin(file_list))
                            
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise readingTargetDFError(destination_path)
                        except readingTargetDFError as wde:
                            audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',wde,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,destination_path,0,0,0,0,'NA',log_filename)
                            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,wde)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0, exit_doc
                    # Extracting Destination File Size
                    dest_file_size=Utils.gen_tgt_file_sz(dbutils,destination_path)

                    # checking sum and sum of length of numeric and String column respectively
                    if "column_level_validation" in obj:
                        objdict=obj["column_level_validation"]
                        check_sum_flag=Utils.check_colsum(inputDF,target_df,objdict,logger)
                    else:
                        check_sum_flag=True
                else:

                    #Renaming file to processed 
                    if(file_ext not in ('xlsx','xlsm')):
                        Utils.rename_files('/dbfs'+dynamicInputPath)
                   
                    # Appending Audit entry record in process execution file/Table
                    
                    audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Succeeded','Completed Successfully! No change in source',job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,destination_path,0,0,0,0,'NA',log_filename)
                    audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc['EXIT_CODE']=0
                    return inputDF, exit_doc
                   
                    logger.info("Audit record saved successfully for txt-batch-ingestion-process")
            else:
                check_sum_flag=True
            
            exception_df_cnt=0
            if isinstance(exception_df,SparkDataFrame) and exception_df is not None and  exception_df.count()>0:
                #exception_df=exception_df.toDF(*(re.sub(r'[\,\s;\n\t\={}():]+', '_', c) for c in exception_df.columns))
                #exception_df.write.partitionBy("ec").mode('overwrite').save(exception_path,format=str(obj['target-format']))
                #exception_df_cnt=exception_df.count()

                exception_df = Utils.get_exception_data(spark, obj, exception_df, dbutils, logger)
                tableName = str(obj["sqlserver"]["R2C_exception_table"])
                if isinstance(exception_df,SparkDataFrame) and len(exception_df.head(1))>0 :
                    validation_flag=True
                    try:
                        logger.info("Writing data to the Synapse table: " + tableName)
                        utilsShared.write_enrich(dbutils,exception_df , spark, obj, 'append',tableName)
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise dbInsertError(str(traceback.format_exc()))
                        except dbInsertError as dbe:
                            audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',dbe,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size)
                            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return exit_doc    

            # Insert the success record in Audit Table, change audit information
            target_cnt=target_df.count()  if isinstance(target_df,SparkDataFrame) else 0
            tgt_col_cnt=len(target_df.columns)  if isinstance(target_df,SparkDataFrame) else 0
            row_count_validation=str(target_cnt+null_cnt)==str(inputRowCount)

            #Appending p as suffix signify file is processed
            # if(file_ext not in ('xlsx','xlsm')):
            #     Utils.rename_files('/dbfs'+dynamicInputPath)
            # logger.info("Files renamed successfully")


            if check_sum_flag:
                pass
            else:
                try:
                    raise checkSumMismatchError()
                except recordCountMismatchError as rec:
                    audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',rec,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,destination_path,target_cnt,tgt_col_cnt,dest_file_size,null_cnt,exception_path,log_filename)
                    audit_doc,exit_doc=Utilsgen_audit_dict(audit_doc,exit_doc,audit_rec,rec)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc
            
            if row_count_validation:
                pass
            else:
                try:
                    raise recordCountMismatchError(inputRowCount,str(target_cnt+null_cnt))
                except recordCountMismatchError as rec:
                    audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',rec,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,destination_path,target_cnt,tgt_col_cnt,dest_file_size,null_cnt,exception_path,log_filename)
                    audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,rec)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc

            if validation_flag:
                invalid_val=InvalidValue()
            else:
                invalid_val=0 
            audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Succeeded','Completed Successfully!',job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,destination_path,target_cnt,tgt_col_cnt,dest_file_size,null_cnt,exception_path,log_filename,validation_flag,invalid_val)
            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,invalid_val)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=1
            logger.info("Audit record saved successfully for txt-batch-ingestion-process")
            return inputDF,exit_doc
            

        else:
            audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Succeeded','Completed Successfully! No New File',job_start_time)
            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)

            # Appending Audit entry record in process execution file/Table
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            logger.info("Audit record saved successfully for txt-batch-ingestion-process")
            exit_doc['EXIT_CODE'] = '0'
            return inputDF,exit_doc
    #try
    except:
        logger.error(str(traceback.print_exc()))
        err_desc = str(traceback.format_exc())
        try :
            raise uncatchException(err_desc)
        except uncatchException as ue:
            audit_rec=BeforeSourceRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',ue,job_start_time)
            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
            return 0,exit_doc
            
    #except
    finally:
        logger.info("End of "+ __name__+ " process...")
        #sqlContext.clearCache()
        #context.stop()
    #finally
  ###################################################################################################
