# Databricks notebook source
# MAGIC %fs unmount /mnt/mountdatalake

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "6a7b7707-74c7-42d3-887d-f374bf063a60",
           "fs.azure.account.oauth2.client.secret": dbutils.secrets.get(scope="Idfrgscope1",key="idfrgkvadb-01"),
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/dcc5be65-5889-4ef9-be02-4352e92c9f98/oauth2/token"}

# COMMAND ----------

dbutils.fs.mount(
  source = "abfss://idfappdata@idfadbworkspace.dfs.core.windows.net",
  mount_point = "/mnt/mountdatalake/",
  extra_configs = configs)

# COMMAND ----------

dbutils.fs.refreshMounts()
dbutils.fs.ls("/mnt/mountdatalake/")

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/schemaMatching/Hello.txt","Hello World", True)

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/Hello.txt","Hello World", True)

# COMMAND ----------

# MAGIC %sh
# MAGIC cat /dbfs/mnt/mountdatalake/mount.err

# COMMAND ----------

f= open("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching/schemaMatchingInput/HP_Main.csv", 'rb')
var=r.read()
print(var)

# COMMAND ----------

# dbutils.fs.mkdirs("/mnt/mountdatalake")

# COMMAND ----------

# filepath = "/mnt/datalakemount/schemaMatching/schemaMatchingInput/HP_Main.csv"
filepath = "abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching/schemaMatchingInput/HP_Main.csv"
import pyspark
from pyspark.sql import SparkSession
from pyspark.sql import SQLContext, Window
from pyspark import SparkConf, SparkContext
import pyspark.sql.functions as f 
spark = SparkSession.builder.master("local").appName("SchemaMatchingApplication").getOrCreate()
spark.conf.set("fs.azure.account.auth.type.idfadbworkspace.dfs.core.windows.net", "OAuth")
spark.conf.set("fs.azure.account.oauth.provider.type.idfadbworkspace.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
spark.conf.set("fs.azure.account.oauth2.client.id.idfadbworkspace.dfs.core.windows.net", "6a7b7707-74c7-42d3-887d-f374bf063a60")
spark.conf.set("fs.azure.account.oauth2.client.secret", "idfrgkvadb-01")
# spark.conf.set("fs.azure.account.oauth2.client.secret.idfadbworkspace.dfs.core.windows.net", dbutils.secrets.get(scope="Idfrgscope1",key="idfrgkvadb-01"))
spark.conf.set("fs.azure.account.oauth2.client.endpoint.idfadbworkspace.dfs.core.windows.net", "https://login.microsoftonline.com/dcc5be65-5889-4ef9-be02-4352e92c9f98/oauth2/token")

dnb_data_healthcare = spark.read.option("header", "true").option("inferSchema", "true").csv(filepath)
#to see distinct states abbreviation
#dnb_data_healthcare.select("`duns.state_province_abbreviation`").distinct().collect()
# dnb_data_healthcare.write.partitionBy("duns.state_province_abbreviation").format("csv").save(r'/mnt/intelligent-data-foundation/raw/dnb_data/partitions',header = 'true')
# dnb_data_healthcare.show(10)

# COMMAND ----------

dbutils.fs.ls("/mnt/mountdatalake")

# COMMAND ----------

dbutils.fs.put("/mnt/mountdatalake/Hello.txt","Hello World", True)

# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://dedupe@idfadbworkspace.dfs.core.windows.net",
  mount_point = "/mnt/dedupemount/",
  extra_configs = configs)

# COMMAND ----------



# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net/")

# COMMAND ----------



# COMMAND ----------

# MAGIC %fs unmount /mnt/dedupe/datastage

# COMMAND ----------

# MAGIC %fs unmount /mnt/adlsdedupe

# COMMAND ----------

# MAGIC %fs unmount /mnt/dedupe/testdata

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdata

# COMMAND ----------

# MAGIC %fs unmount /mnt/idfadlsmount

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdatamount

# COMMAND ----------

# MAGIC %fs unmount /mnt/idfdatamount

# COMMAND ----------

# MAGIC %fs unmount /mnt/testdatamount1

# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net/azure")

# COMMAND ----------

# MAGIC %fs ls /mnt/idfmount/

# COMMAND ----------

spark.conf.set("fs.azure.account.key.idfadbworkspace.dfs.core.windows.net","U51BTllKR3MLuXDjfu5GcRuBPnTbsWRlauhP+Oa3SGWLQzaAxvP8+isDBYdaeJ24IDKzZeqpGKZw864Yw7kBTA==")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
dbutils.fs.ls("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/")
spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")

# COMMAND ----------

dbutils.fs.ls("abfss://idfappdata@idfadbworkspace.dfs.core.windows.net/schemaMatching")

# COMMAND ----------

dbutils.fs.ls("abfss://dedupe@idfadbworkspace.dfs.core.windows.net")