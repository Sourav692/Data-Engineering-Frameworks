import os
import itertools
import time
import logging
import optparse
import locale
import json
import pyspark
from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, SparkSession
from random import random
import pickle
from pyspark.sql.types import IntegerType
#from Util import debug,log
import pandas as pd
import re
import numpy as np
import scipy
from scipy import stats
import pyspark.sql.functions as f
import SchemaMatchEngine
import UIMeasures
import sys
sys.path.insert(0, os.path.abspath("/dbfs/mnt/mountdatalake/AZ_schemaMatchcodebase"))

#COMMON
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

def inputToDf(inputP):
    spark = SparkSession.builder.master("local[*]").appName("SchemaMatchingApp").config("spark.debug.maxToStringFields", "100").getOrCreate()
    logger.debug("Reading file from path :"+str(inputP))
    dataSetIN = spark.read.option("header", "true").csv(inputP)
    return dataSetIN

features = ['type', 'length', 'key', 'unique', 'not_null', 'avgUsedLength', 'VarofLength', 'VarCoeffLength', 'average',
            'variance', 'Coeff', 'min', 'max', 'whitespace', 'specialchar', 'num2all', 'char2all', 'backslash',
            'brackets', 'hyphen']


def averageusedlength(charAtt, n, fixed_length):
    charAttribute = "".join(str(elm) for elm in charAtt)
    used_length = len(charAttribute)
    ratio = (used_length * 1.0) / (n * fixed_length)
    # print 'ratio--', ratio
    # print 'used_length--', used_length
    return round(ratio, 4)

def varianceoflength(passList, fixed_length):
    lengtharray = []
    for values in passList:
        lengtharray.append(len(str(values)))
    return round(np.var(lengtharray) / fixed_length, 4)
  
def varianceCoefflength(passList):
    lengtharray = []
    for values in passList:
        lengtharray.append(len(str(values)))
    return round(scipy.stats.variation(lengtharray, axis=0), 4)

def Numberofbackslash(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_space = 0
    i = len(charAttribute)
    for val in range(0, i):
        if (charAttribute[val] == "/"):
            count_space = count_space + 1
    ratio = (count_space * 1.0) / i
    return round(ratio, 4)


def Numberofbrackets(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_space = 0
    i = len(charAttribute)
    for val in range(0, i):
        if (charAttribute[val] == "("):
            count_space = count_space + 1
    ratio = (count_space * 1.0) / i
    return round(ratio, 4)


def Numberofhyphen(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_space = 0
    i = len(charAttribute)
    for val in range(0, i):
        if (charAttribute[val] == "-"):
            count_space = count_space + 1
    ratio = (count_space * 1.0) / i
    return round(ratio, 4)


def NumbertoAll(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_integer = 0
    i = len(charAttribute)
    for val in range(0, i):
        try:
            va = int(charAttribute[val])
            count_integer = count_integer + 1
        except ValueError:
            continue
        val = val + 1
    ratio = (count_integer * 1.0) / i
    return round(ratio, 4)


def ChartoAll(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_char = 0
    i = len(charAttribute)
    for val in range(0, i):
        try:
            va = int(charAttribute[val])
        except ValueError:
            count_char = count_char + 1
        val = val + 1
    ratio = (count_char * 1.0) / i
    return round(ratio, 4)


def WhiteSpaceFeature(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    count_space = 0
    i = len(charAttribute)
    for val in range(0, i):
        if (charAttribute[val] == " "):
            count_space = count_space + 1
    ratio = (count_space * 1.0) / i
    return round(ratio, 4)
  
def specialChars(charAtt):
    charAttribute = "".join(str(elm) for elm in charAtt)
    i = len(charAttribute)
    count_special = 0
    for char in charAttribute:
        if (re.match("^[a-zA-Z0-9_]*$", char)):
            continue
        else:
            count_special = count_special + 1
    ratio = (count_special * 1.0) / i
    return round(ratio, 4)

def numFeatures(numArray, fixed_length, n):
    sum = 0
    n = len(numArray)
    for i in range(0, len(numArray)):
        if numArray[i] is None:
            numArray[i] = 0
    for values in numArray:
        sum = sum + values
    # print sum,"zhjhdfgdfjhgdhg"
    avg = sum / n
    var = np.var(numArray) / (n)
    coeff = scipy.stats.variation(numArray, axis=0)
    mini = min(numArray)
    maxi = max(numArray)
    return float(avg), float(var), round(coeff, 4), round(mini, 4), round(maxi, 4)
      
def typeFinder(NumberString):
  type=""
  if NumberString.isdigit():
    type='int'
  elif NumberString.lower()=='true' or NumberString.lower()=='false':
    type='boolean'
  elif NumberString.replace('.', '', 1).isdigit():
    type='float'
  else:
    type='string'
  return type

# COMMAND ----------

# FLOATISH_TYPES # float8 - 0
# INT_TYPES # bigint, int, smallint - 1
# CHAR_TYPES# text, char, varchar   - 2
# BOOLEAN_TYPES # bool - 3
def columnDescrip(df,colName,rowCount):
  colDict=dict()
  valuesList=[]
  colDict[colName]=valuesList
  n_data=rowCount
  sampleCValue=df.select([f.first(colName, ignorenulls=True).alias(colName)]).first().asDict()[colName]
  logger.debug(str(colName)+" Samplevalue: "+str(sampleCValue))
  typeOfValue=typeFinder(sampleCValue)
  logger.debug(str(colName)+" Type : "+str(typeOfValue))
  if typeOfValue=='int':
    valuesList.append(1)# feature ['type'] value 1 for integer types
    df=df.fillna('0')
    df=df.withColumn(colName,df[colName].cast('integer'))
  elif typeOfValue=='boolean':
    valuesList.append(3)# feature ['type'] value 3 for boolean types
    df=df.fillna('false')
    df=df.withColumn(colName,df[colName].cast('boolean'))
  elif typeOfValue=='float':
    valuesList.append(0)# feature ['type'] value 0 for float types
    df=df.fillna('0.0')
    df=df.withColumn(colName,df[colName].cast('float'))
  else:
    valuesList.append(2)# feature ['type'] value 2 for string, char types
    df=df.fillna(' ')
    df=df.withColumn(colName,df[colName].cast('string'))
    
  colLen="{cname}_length".format(cname=colName)
  dfWithLen=df.withColumn(colLen,f.length(colName))
  dfWithLen=dfWithLen.sort(f.desc(colLen))
  maxCLength=dfWithLen.select(colLen).collect()[0].asDict()[colLen]
  valuesList.append(maxCLength) # feature ['length'] value
  logger.debug(str(colName)+" Length : "+str(maxCLength))
  numOfClDistinct=df.select(f.countDistinct(colName).alias("distinctCount")).collect()[0].asDict()['distinctCount']
  if(rowCount==numOfClDistinct):
    logger.debug(str(colName)+" is in {key, unique and not_null}")
    valuesList.append(1)# feature ['key'] value
    valuesList.append(1)# feature ['unique'] value
    valuesList.append(1)# feature ['not_null'] value
  else:
    logger.debug(str(colName)+" is not in {key, unique and not_null}")
    valuesList.append(0)# feature ['key'] value
    valuesList.append(0)# feature ['unique'] value
    valuesList.append(0)# feature ['not_null'] value
  
  dataAslist=[ele.asDict()[colName] for ele in df.collect()]
  avgL=averageusedlength(dataAslist,n_data,maxCLength)
  valuesList.append(avgL)# feature ['avgUsedLength'] value
  logger.debug(str(colName)+" avgUsedLength : "+str(avgL))
  varL=varianceoflength(dataAslist, maxCLength)
  valuesList.append(varL)# feature ['VarofLength'] value
  logger.debug(str(colName)+" VarofLength : "+str(varL))
  varcoL=varianceCoefflength(dataAslist)
  valuesList.append(varcoL)# feature ['VarCoeffLength'] value
  logger.debug(str(colName)+" VarCoeffLength : "+str(varcoL))
  if typeOfValue=='int' or typeOfValue=='float':
    numFuncall=numFeatures(dataAslist,maxCLength,n_data)
    valuesList.append(numFuncall[0])# feature ['average'] value
    logger.debug(str(colName)+" average : "+str(numFuncall[0]))
    valuesList.append(numFuncall[1])# feature ['variance'] value
    logger.debug(str(colName)+"  variance : "+str(numFuncall[1]))
    valuesList.append(numFuncall[2])# feature ['Coeff'] value
    logger.debug(str(colName)+" Coeff : "+str(numFuncall[2]))
    valuesList.append(numFuncall[3])# feature ['min'] value
    logger.debug(str(colName)+" min : "+str(numFuncall[3]))
    valuesList.append(numFuncall[4])# feature ['max'] value
    logger.debug(str(colName)+"  max : "+str(numFuncall[4]))
    valuesList.append(0.0)# feature ['whitespace'] value
    logger.debug(str(colName)+" whitespace : "+str(0.0))
    valuesList.append(0.0)# feature ['specialchar'] value
    logger.debug(str(colName)+" specialchar : "+str(0.0))
    valuesList.append(0.0)# feature ['num2all'] value
    logger.debug(str(colName)+" num2all : "+str(0.0))
    valuesList.append(0.0)# feature ['char2all'] value
    logger.debug(str(colName)+" char2all : "+str(0.0))
    valuesList.append(0.0)# feature ['backslash'] value
    logger.debug(str(colName)+" backslash : "+str(0.0))
    valuesList.append(0.0)# feature ['brackets'] value
    logger.debug(str(colName)+"  brackets: "+str(0.0))
    valuesList.append(0.0)# feature ['hyphen'] value
    logger.debug(str(colName)+" hyphen : "+str(0.0))
  else:
    valuesList.append(0.0)# feature ['average'] value
    logger.debug(str(colName)+" average : "+str(0.0))
    valuesList.append(0.0)# feature ['variance'] value
    logger.debug(str(colName)+" variance : "+str(0.0))
    valuesList.append(0.0)# feature ['Coeff'] value
    logger.debug(str(colName)+" Coeff : "+str(0.0))
    valuesList.append(0.0)# feature ['min'] value
    logger.debug(str(colName)+" min : "+str(0.0))
    valuesList.append(0.0)# feature ['max'] value
    logger.debug(str(colName)+" max : "+str(0.0))
    whites=WhiteSpaceFeature(dataAslist)
    valuesList.append(whites)# feature ['whitespace'] value
    logger.debug(str(colName)+" whitespace : "+str(whites))
    specialc=specialChars(dataAslist)
    valuesList.append(specialc)# feature ['specialchar'] value
    logger.debug(str(colName)+" specialchar : "+str(specialc))
    num2a=NumbertoAll(dataAslist)
    valuesList.append(num2a)# feature ['num2all'] value
    logger.debug(str(colName)+" num2all : "+str(num2a))
    char2a=ChartoAll(dataAslist)
    valuesList.append(char2a)# feature ['char2all'] value
    logger.debug(str(colName)+" char2a : "+str(char2a))
    backs=Numberofbackslash(dataAslist)
    valuesList.append(backs)# feature ['backslash'] value
    logger.debug(str(colName)+" backslash : "+str(backs))
    brack=Numberofbrackets(dataAslist)
    valuesList.append(brack)# feature ['brackets'] value
    logger.debug(str(colName)+" brackets : "+str(brack))
    hyp=Numberofhyphen(dataAslist)
    valuesList.append(hyp)# feature ['hyphen'] value
    logger.debug(str(colName)+" hyphen : "+str(hyp))
  return colDict


def metaDataProcess(dataset):
  logger.setLevel(logging.DEBUG)
  colmnList=dataset.columns
  logger.debug("Columns list for the dataset"+str(colmnList))
  totalRows=dataset.count()
  logger.debug("Number of total records available in dataset is :"+str(totalRows))
  columnMetadata={}
  for column in colmnList:
      logger.debug("Finding column level information on column :"+str(column))
      tempDf=dataset.select(str(column))
      for colName, values in columnDescrip(tempDf,str(column),totalRows).items():
        cleanList=[0.0 if np.isnan(x) else x for x in values]
        columnMetadata[colName]=cleanList
  return columnMetadata

def writeOut(columnMetadata,pathToWrite):
    pickle.dump(columnMetadata,open(pathToWrite,'wb'))


def pickleDumpTrainingFiles(filename,typef):
    logger.info("Pickle file generation process started for: "+str(typef)+" data")
    inputBasePathtrain="/mnt/mountdatalake/AZ_schemaData/TrainingData/"
    inputBasePathtest="/mnt/mountdatalake/AZ_schemaData/TestData/"
    outbasePathtrain="/dbfs/mnt/mountdatalake/AZ_schemaData/TrainPickleData/"
    outputbasePathtest="/dbfs/mnt/mountdatalake/AZ_schemaData/TestPickleData/"
    rawFile=filename.split(".")[0]
    if(typef=="train"):
        inputTrainFile=str(inputBasePathtrain)+str(filename)
        pickleTrainpath=str(outbasePathtrain)+str(rawFile)+"_train_file.pickle"
        inputD=inputToDf(inputTrainFile)
        logger.info("Finding column metadata information for training file")
        fData=metaDataProcess(inputD)
        logger.debug("Writing training pickle file to :"+str(pickleTrainpath))
        writeOut(fData,pickleTrainpath)
        return pickleTrainpath
    else:
        inputTestFile=str(inputBasePathtest)+str(filename)
        pickleTestpath=outputbasePathtest+str(rawFile)+"_test_file.pickle"
        inputD=inputToDf(inputTestFile)
        fData=metaDataProcess(inputD)
        logger.debug("Writing test pickle file to :"+str(pickleTestpath))
        writeOut(fData,pickleTestpath)
        return pickleTestpath
  
def process(testfile,trainfile):
    inputBasePathtest="/mnt/mountdatalake/AZ_schemaData/TestData/"
    testURL=str(inputBasePathtest)+testfile
    trainPickleFile = pickleDumpTrainingFiles(trainfile,"train")
    logger.debug("Generating picklefile for training data: "+str(trainPickleFile))
    testPickleFile = pickleDumpTrainingFiles(testfile,"test")
    logger.debug("Generating picklefile for test data: "+str(testPickleFile))
    logger.info("--------------------Pickle File Generation Completed for test and training data---------------------------")
    return testURL, trainPickleFile, testPickleFile
