"""utilsDq.py- Consists various fuctions to perform data quality checks
"""
import os
import logging
from collections import OrderedDict
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sys
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
import utilsIO
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, FloatType
import numpy as np
from regexLibrary import mapping_dict,regex_pattern
import pyspark.sql.functions as F
from pyspark.sql import functions as f
from pyspark.sql.functions import array, col, lit, when
import pyspark.sql.types as sparktypes
from jsonschema import validate
from pyspark.sql.functions import monotonically_increasing_id,row_number
#from shutil import copyfile

#ML_mod
from pyspark.ml.feature import Bucketizer
from itertools import chain
from pyspark.sql import *
from scipy.stats.distributions import chi2
from scipy.stats import ksone
import scipy.stats
from pyspark.sql.functions import mean as _mean, stddev as _stddev, variance as _variance
from pyspark import ml
import ast
import dask.array as da
from pyspark.sql import DataFrameStatFunctions as statFunc

#for anomaly detection
from pyspark.sql.window import Window
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
#from sklearn.model_selection import GridSearchCV
from spark_sklearn import GridSearchCV
#emptyRDD = spark.sparkContext.emptyRDD()

def getFormattedLogger(script_name,file_name=None):
	"""[summary]

	Args:
		script_name ([type]): [description]
		file_name ([type], optional): [description]. Defaults to None.

	Returns:
		[type]: [description]
	"""
	logger = logging.getLogger(script_name)
	#logger = logging.getLogger() #Enabling root logger
	logger.setLevel(logging.DEBUG)
	file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	if file_name:
		file_handler = logging.FileHandler(file_name)
		file_handler.setFormatter(file_format)
		logger.addHandler(file_handler)
	ch=logging.StreamHandler()
	ch.setLevel(logging.DEBUG)
	ch.setFormatter(file_format)
	logger.addHandler(ch)
	logging.getLogger("py4j").setLevel(logging.ERROR)
	return logger

def is_convertible(spark,hash_table,rule_col,rule_val,rule_id,logger):
	"""
	This function checks if a column can be converted to another datatype.
  
	Args:
		hash_table : DataFrame to be checked
		rule_col : Name of the column whose fields has to be checked
		rule_val : Target data Type 

	Returns:
		Original DataFrame with extra column 'ERR_CD' denoting failed records
	"""	
	try:
		casted_table = hash_table.withColumn(rule_col,col(rule_col).cast(rule_val))
		validated_res = casted_table.withColumn("ERR_CD", when(col(rule_col).isNull(),lit(rule_id)).otherwise(lit("")))
		validated_res_count=validated_res.select().where((validated_res.ERR_CD!='')).count()
		return validated_res,validated_res_count
	except:
		logger.error('Failed to convert Data Type')	
		return None,0

def getEnvConf(logger=0,dbutils=0,storageflag=0,onlyYaml=0):
	"""Read the environment Config file from the static path
	@param:logger,dbutils,storageflag,onlyYaml
	@return:envConfig
	"""
	if logger ==0 :
		logger = getFormattedLogger(__name__)

	envConfPath= "/dbfs/mnt/gdpdq/AZ_GDP_DQ/GDP_DQ_Codebase/conf/envConfig.yaml"
	logger.info("Reading Env Config from: " + envConfPath)
	if onlyYaml==1:
		envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
	else:
		if os.path.isfile(envConfPath):
			envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
			"""
			#stg_acct_name = dbutils.secrets.get(scope = 'keyvault',key = '')
			envConfig["azure"]["storage_account_name"]	= "xxxxx"
			envConfig["azure"]["storage_account_access_key"]	=	"xxxxxxxx"
			temp_dir_path = envConfig["sqlserver"]["temp_dir_path"]
			envConfig["sqlserver"]["tempDir"] = 'abfss://' + str(envConfig["azure"]["storage_container_name"]) +'@'+ str(envConfig["azure"]["storage_account_name"]) +'.dfs.core.windows.net'+ str(envConfig["sqlserver"]["temp_dir_path"])
			sql_server_name = str(envConfig["sqlserver"]["sql_server_name"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_db = str(envConfig["sqlserver"]["sql_server_db"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_user = str(envConfig["sqlserver"]["sql_server_user"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_pass = str(envConfig["sqlserver"]["sql_server_pass"]) #dbutils.secrets.get(scope = 'keyvault',key = '')

			conn_string = 'jdbc:sqlserver://' + str(sql_server_name) + ';database=' + str(sql_server_db) +';user='+ str(sql_server_user) +';password='+ str(sql_server_pass) +';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
			envConfig["sqlserver"]["connection-string"]	=	conn_string
			"""
		else:
			logger.info("Env Config is not available " + str(envConfPath) + ", Please place the config file in order to execute the job")
			return 0

	return envConfig

def gen_audit_dict(audit_doc,exit_doc,audit_rec,exception):
	"""Get default initialised audit_doc
	@params: audit_doc,exit_doc,audit_rec,exception
	@returns: audit_doc,exit_doc
	"""
	audit_doc=OrderedDict()
	audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
	audit_doc['FILE_NAME'], exit_doc['FILE_NAME'] = audit_rec.FILE_NAME,audit_rec.FILE_NAME
	audit_doc['BATCH_DATE'],exit_doc['BATCH_DATE'] = audit_rec.BATCH_DATE,audit_rec.BATCH_DATE
	audit_doc['SOURCE_NAME'],exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
	audit_doc['PRCS_EXECUTION_ID'], exit_doc['PRCS_EXECUTION_ID'] = audit_rec.PRCS_EXECUTION_ID,audit_rec.PRCS_EXECUTION_ID
	audit_doc['PIPELINE_NAME'],exit_doc['PIPELINE_NAME']=audit_rec.PIPELINE_NAME,audit_rec.PIPELINE_NAME
	audit_doc['TRIG_NAME'],exit_doc['TRIG_NAME']=audit_rec.TRIG_NAME,audit_rec.TRIG_NAME
	audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
	audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC,audit_rec.TECH_STATUS_DESC
	exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
	audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
	exit_doc["VALIDATION_FLAG"]="Failed" if audit_rec.VALIDATION_FLAG else "Succeeded"

	audit_doc['SOURCE_PATH'], exit_doc['SOURCE']['SOURCE_PATH'] = audit_rec.SOURCE_PATH,audit_rec.SOURCE_PATH
	audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = audit_rec.SOURCE_ROW_COUNT,audit_rec.SOURCE_ROW_COUNT
	audit_doc['SOURCE_COL_COUNT'], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = audit_rec.SOURCE_COL_COUNT,audit_rec.SOURCE_COL_COUNT
	audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT']=audit_rec.SOURCE_AMOUNT,audit_rec.SOURCE_AMOUNT
	audit_doc['SOURCE_FILE_SIZE'], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = audit_rec.SOURCE_FILE_SIZE,audit_rec.SOURCE_FILE_SIZE
	exit_doc["EXPECTED_PERIOD_KEY"]=audit_rec.EXPECTED_PERIOD_KEY
	audit_doc['DEST_PATH'], exit_doc['DESTINATION']['DEST_PATH'] = audit_rec.DEST_PATH,audit_rec.DEST_PATH
	audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = audit_rec.DEST_ROW_COUNT,audit_rec.DEST_ROW_COUNT
	audit_doc['DEST_COL_COUNT'], exit_doc['DESTINATION']['DEST_COL_COUNT'] = audit_rec.DEST_COL_COUNT,audit_rec.DEST_COL_COUNT
	audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT']=audit_rec.DEST_AMOUNT,audit_rec.DEST_AMOUNT
	audit_doc['DEST_FILE_SIZE'], exit_doc['DESTINATION']['DEST_FILE_SIZE'] =audit_rec.DEST_FILE_SIZE,audit_rec.DEST_FILE_SIZE
	audit_doc['REJECTED_ROW_COUNT'], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = audit_rec.REJECTED_ROW_COUNT,audit_rec.REJECTED_ROW_COUNT
	audit_doc['REJECTED_FILE_NAME'], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = audit_rec.REJECTED_FILE_NAME,audit_rec.REJECTED_FILE_NAME
	audit_doc["LOG_PATH"]=audit_rec.LOG_PATH
	exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
	return audit_doc,exit_doc


# Function to join the dataframes
def df_join(left_df,left_col_list,right_df,right_col_list,logger,join_type="inner"):
	"""
	@params: left_df,left_col_list,right_df,right_col_list,logger,join_type=inner
	@returns: left_df
	"""
	logger.info("In JOin")
	for (col_name_left, col_name_right) in zip(left_col_list,right_col_list) :
		logger.debug("Casting	"+ col_name_right + " with datatype of	" + col_name_left)
		right_df = right_df.withColumn(col_name_right, col(col_name_right).cast(left_df.schema[str(col_name_left)].dataType))

	for col_name in right_col_list:
		col_name_2 = "tempJoin_"+ col_name
		logger.debug("Renaming column "+ col_name + " with " + col_name_2 )
		right_df = right_df.withColumnRenamed(col_name,col_name_2)

	left_df= left_df.join(broadcast(right_df),[trim(col(f)).eqNullSafe(trim(col("tempJoin_" + s))) for (f, s) in zip(left_col_list,right_col_list)], how = join_type)

	# Dropping the columns which are renamed after joining
	for col_name in right_col_list:
		col_name_2 = "tempJoin_"+ col_name
		logger.debug("Dropping column "+ col_name_2)
		left_df = left_df.drop(col_name_2)

	if "CURR_IND" in left_df.columns:
		left_df = left_df.drop("CURR_IND")
	return left_df

#Reading input data
def data_quality_read_input_data01(spark,tableName, data_type, data_path, logger):
	"""
	@params: spark dataframe,envConfig,tableName, data_type, data_path, logger_str
	@returns: hash_table dataframe
	"""
	hash_table = None
	if data_type == 'csv':
		logger.info("Trying to read data for table: " + tableName + " from file at "+ data_path)
		#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path
		hash_table = spark.read.option("header",True).csv(data_path, header = True)
	elif data_type == 'delta':
		logger.info("Trying to read data for table: " + tableName + " from delta file at "+ data_path)
		#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from delta table at "+ data_path
		hash_table = spark.read.format("delta").load(data_path).select('*')

	else:
		logger.error("Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported")
		#logger_str =logger_str+"\nError: "+"Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported"
		raise Exception("Provided file format "+data_type+" not supported yet to read. Currently supported formats: csv, delta ")
	return hash_table

#Reading input data
def data_quality_read_input_data(spark,tableName, data_type, data_path, logger):
	"""
	@params: spark dataframe,envConfig,tableName, data_type, data_path, logger_str
	@returns: hash_table dataframe
	"""
	hash_table = None
	if data_type == 'csv':
		logger.info("Trying to read data for table: " + tableName + " from file at "+ data_path)
		#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path
		hash_table = spark.read.option("header",True).csv(data_path, header = True)
	elif (data_type == 'delta' or data_type == 'parquet'):
		logger.info("Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path)
		#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from delta table at "+ data_path
		hash_table = spark.read.format(data_type).load(data_path)

	else:
			#	logger.error("Failed to read data for table: " + tableName + " from "+data_type+" table at "+ data_path+" as the input file format "+ data_type+" not supported")
			#logger_str =logger_str+"\nError: "+"Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported"
			raise Exception("Provided file format "+data_type+" not supported yet to read. Currently supported formats: csv, delta ")
	return hash_table


#Missing data Valdiation

def data_quality_null_validation(spark,hash_table,rule_col,rule_id,logger):
	"""
	@params: envConfig,hash_table,rule_col,rule_id,logger
	@returns: null validation record, null validation record count
	"""
	rulecolms_lst=rule_col.split(',')
	# hash_table=hash_table.select('*',"data.*")
	null_filter_str =""
	for rulecol in rulecolms_lst:
		null_filter_str=null_filter_str + "(trim(cast("+rulecol+" as string))='') or ("+rulecol+" is Null) or"
	rule_expr=null_filter_str[:-2]
	validated_res = hash_table.withColumn("ERR_CD", when(expr(rule_expr), lit(rule_id)).otherwise(lit(""))).where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )")
	return validated_res, validated_res.count()




# Duplicate records count
def data_quality_duplicates_valdation(spark,hash_table,rule_col,rule_id,logger):
	"""
	@params: envConfig,hash_table,rule_col,rule_id,logger
	@returns: duplicates valdation record, duplicates valdation record count
	"""
	rulecolms_lst=rule_col.split(',')
#	 hash_table=hash_table.select('*',"data.*")
	duplicates_data=hash_table.groupBy(rulecolms_lst).count().where(col("count") > 1)
	new_rulecolms_lst =[]
	new_columns_to_drop=[]
	for clm_name in rulecolms_lst:
		new_clm_name = clm_name
		if '.' in clm_name:
			current_clm_name = clm_name.split('.')[-1]
			new_clm_name=clm_name.replace('.','_')
			duplicates_data = duplicates_data.withColumnRenamed(current_clm_name, new_clm_name)
			hash_table = hash_table.withColumn(new_clm_name, col(clm_name) )
			new_columns_to_drop=new_columns_to_drop+[new_clm_name]
			new_rulecolms_lst=new_rulecolms_lst+[new_clm_name]
	validated_res=duplicates_data.join(hash_table,new_rulecolms_lst, "inner" ).select(hash_table.columns).drop(col("count")).withColumn("ERR_CD", lit(rule_id))
	#logger.info("Trying to load duplicates data: " + validated_res)
	validated_res=validated_res.drop(*new_columns_to_drop)
	return validated_res, validated_res.count()


# Row Counts validation
# Will Need To Update The Nmaing Convention and Complete the expressions after getting sample recon file and modify
def data_quality_counts_valdation(spark,hash_table, ref_path,ref_path_type,rule_id,logger):
	"""
	@params: spark dataframe,envConfig,hash_table, ref_path, rule_id,logger
	@returns: counts valdation dataframe
	"""
	#source_side_df=spark.read.format(recon_file_format).load(ref_path)
	sample_recon_df= data_quality_read_input_data01(spark,'ReconFile', ref_path_type, ref_path, logger)
	job_sesn_strt_ts=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['strm_sesn_strt_ts']
	job_sesn_end_ts=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['strm_sesn_end_ts']
	source_count=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['total_rec_sent']
	#delta_count=hash_table.where( (col("load_ts")> to_timestamp(job_sesn_strt_ts))	& (col("load_ts")< to_timestamp(job_sesn_end_ts))).count()
	delta_count = hash_table.orderBy("timestamp", ascending=False).first()['numOutputRows']
	count_diff= int(source_count)-int(delta_count)
	counts_vldtn_scma= StructType([
	StructField("RULE_ID", StringType()),
	StructField("FAILED_ROW_COUNT", IntegerType()),
	StructField("TOTAL_ROW_CNT", IntegerType()),
	StructField("PASSED_ROW_CNT", IntegerType())])
	counts_vldtn_data = spark.createDataFrame([(rule_id, int(count_diff), int(source_count), int(delta_count) )], counts_vldtn_scma )
	return counts_vldtn_data

# Methods to get subject and email body details for Counts validation mismatch Alerting
def dq_counts_validation_alert_details(envConfig,dq_statistics_res, tbale_name,logger):
	"""
	@params: envConfig,dq_statistics_res, tbale_name,logger
	@returns: subject,message_dict ,records count
	"""
	records_count_res = dq_statistics_res.where(lower(col("RULE_TYPE")) == 'count_validation').withColumn("EXEC_DATE", col("EXEC_DATE").cast(StringType())).first().asDict()
	records_count_diff = records_count_res['FAILED_ROW_COUNT']
	source_count = records_count_res['TOTAL_ROW_CNT']
	current_count = records_count_res['PASSED_ROW_CNT']
	message=""
	if records_count_diff != 0:
	# recipient = "santhosh_killi@gap.com"#dbutils.secrets.get(scope = "key-vault-secrets", key = "") # insert secret name
	#recipient="aluguri_koushik@gap.com"
	#"\033[1m" + a_string + "\033[0m"
		subject = "DQ ALERT: Records Count Mismatch for Table: "+tbale_name.upper()
		message00="Hi Team,"
		message01 = "This is a system generated alert to inform that there is record count mismatch between recon and raw table <b>"+tbale_name.upper()+"</b> below are the details for the same:"
		message02="<b>Count_Difference: "+str(records_count_diff)+"</b>"
		message03 = "<b>Source_Count: "+str(source_count)+"</b>"
		message04 = "<b>Current_Count: "+str(current_count)+"</b>"
		message05 = "More DQ validation details below: "
		message06 = str(records_count_res).replace(", '",",'")
		message07 = "Regards,"
		message08 = "DQ Validation."
		message_dict = {"message00":message00,"message01":message01,"message02":message02,"message03":message03,"message04":message04,"message05":message05,"message06":message06,"message07":message07,"message08":message08}
		return subject,message_dict,records_count_res
	else:
		return 0


# Send an Email
def SendEmail(recipient, subject, message_dict, dq_val_res_dict, logger):
	"""
	@params: recipient, subject, message_dict, dq_val_res_dict, logger
	@returns: sendmail to mail Address
	"""
	table = "<table>\n"
	table += "	<tr>\n"
	for key in dq_val_res_dict:
		table += "	<th>{0}</th>\n".format(key.strip())
	table += "	</tr>\n"
	table += "	<tr>\n"
	for key in dq_val_res_dict:
		table += "	<td>{0}</td>\n".format(dq_val_res_dict[key])
	table += "	</tr>\n"
	table += "</table>"
	html = f'''\
	<html>
	<head>
		<style>
		table, th, td {{ border: 1px solid black; border-collapse: collapse; }}
		th, td {{ padding: 5px; }}
		</style>
	</head>
	<body>
		<div>{message_dict["message00"]}</div><br><br>
		<div>{message_dict["message01"]}</div><br>
		<div>{message_dict["message02"]}</div><br>
		<div>{message_dict["message03"]}</div><br>
		<div>{message_dict["message04"]}</div><br>
		<div>{message_dict["message05"]}</div><br>
		<br>{table}<br>
		<div>{message_dict["message07"]}</div><br>
		<div>{message_dict["message08"]}</div><br>
	</body>
	</html>
	'''
	server = smtplib.SMTP ('Mailhub.gap.com', 25)
	server.ehlo()
	server.starttls()
	#sender = 'aparna_roy@gap.com'
	sender = 'santhosh_killi@gap.com'
	msg = MIMEMultipart()
	msg['Subject'] = subject
	msg['From'] = sender
	msg['To'] = recipient
	msg.attach(MIMEText(html, 'html'))
	server.sendmail(sender, recipient, msg.as_string())
	logger.info("Email Send to: " + recipient)
	server.close()


## method to validate custom expression validation on spark dataframe
def data_quality_expression_validation(envConfig,hash_table,rule_id,rule,logger):
	"""
	@params: envConfig,hash_table,rule_id,rule,logger
	@returns: hash_table dataframe
	"""
	rule_val = rule['RULE_VAL']
	rule_col = "DQ_CUST_EXPR_CHECK"
#	 hash_table=hash_table.select('*',"data.*")
	logger.info("Trying to load data for rule value: " + rule_val)
	# logger.debug("Hash Table count is",str(hash_table.count()))
	rule_expr = expr(rule_val)
	hash_table = hash_table.withColumn(rule_col, rule_expr) \
		.withColumn('ERR_CD',
					when((trim(col(str(rule_col))) == lit("")) | (
						isnull(col("`" + str(rule_col) + "`"))) | (
								 trim(col(str(rule_col))) == lit("false")),
						 lit(rule_id)) \
					.otherwise(lit("")))
	# logger.debug("Hash Table count with column is",str(hash_table.count()))
	validated_res = hash_table.where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )").drop(rule_col)
	return validated_res, validated_res.count()



## method to do straight lookup between to two dataframes

def data_quality_straight_lookup_validation(spark, envConfig, hash_table, rule_val, rule_id, lookup_path, format, logger):
	"""
	@params: inputDF- spark dataframe, envConfig, hash_table, rule_val, rule_id, lookup_path, format, logger
	@returns: hash_table dataframe
	"""
	try:
		rule_val_lkup = json.loads(rule_val)
		# hash_table=hash_table.select('*',"data.*")
		logger.info("Trying to load data for rule value: " + rule_val)
		hash_col_list = list(rule_val_lkup['RULE_COL_TO_MATCH'].keys())
		ref_col_list = list(rule_val_lkup['RULE_COL_TO_MATCH'].values())
		ret_col_name = rule_val_lkup['REF_DEPENDENT_COL']
		#ret_col_name = rule_val_lkup['REF_RET_COL']
		lookup_table = rule_val_lkup['REF_TABLE_NAME']
		logger.info("Parameters fetched")
		ref_df = utilsIO.read_data_based_on_format(spark,envConfig,format,lookup_path,lookup_table,logger)
		hash_table = df_join(hash_table,hash_col_list,ref_df,ref_col_list)
		hash_table = hash_table.withColumn('ERR_CD',
											when( ( (trim(col(str(ret_col_name))) == lit("")) | (
												isnull(col("`" + str(ret_col_name) + "`"))) ),lit(rule_id)) \
											.otherwise(""))
		validated_res = hash_table.where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )").drop(ret_col_name)
		return validated_res, validated_res.count()
	except:
		logger.error("Failed to apply straight lookup for rule value: " + rule_val)
		return 0


# write the dataframe into a sql table
def write_data_sql(hash_table, obj,v_mode,tgt_table):
	"""[write the dataframe into a sql table]

	Args:
		hash_table (bool): [description]
		obj ([type]): [description]
		v_mode ([type]): [description]
		tgt_table ([type]): [description]
	"""


	if hash_table.count() > 0:
		database = str(obj['sqlserver']['jdbcDatabase'])
		port = str(obj['sqlserver']['jdbcPort'])
		hostname = str(obj['sqlserver']['jdbcHostname'])
		hash_table.write \
			.format("jdbc") \
			.option("url",f"jdbc:sqlserver://{hostname}:{port};database={database};") \
			.option("dbtable",tgt_table) \
			.option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver") \
			.option("user",str(obj["sqlserver"]["username"])) \
			.option("password",str(obj["sqlserver"]["password"])) \
			.mode(v_mode) \
			.save()

# read data from sql table
def read_data_sql_table(spark,obj,tableName,logger):
	"""
		@params: spark, envConfig, table Name, logger
		@returns: spark dataframe from dq Master table
	"""
	try:
		if "sqlserver" in obj.keys():
			jdbc_hostname = obj['sqlserver']['jdbcHostname']
			jdbc_database = obj['sqlserver']['jdbcDatabase']
			jdbc_port = obj['sqlserver']['jdbcPort']
			username = obj['sqlserver']['username']
			password = obj['sqlserver']['password']
			hostNameInCertificate = obj['sqlserver']['hostNameInCertificate']
			jdbc_url = obj['sqlserver']['jdbc-connection-string']
			jdbc_url = jdbc_url.format(jdbc_hostname, jdbc_port, jdbc_database, username, password, hostNameInCertificate)
			connection_properties = {"user": username, "password": password,
									"driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
			#query = '(select * from dbo.dqMaster where TABLE_NAME = {} and IsActive = 1) as t1'.format(tableName)
			query = '(select * from dbo.dqMaster order by RULE_ID desc OFFSET 0 ROWS) as t1'
			jdbc_url= conn_string = 'jdbc:sqlserver://' + str(jdbc_hostname) + ':' + str(jdbc_port) + ';database=' + str(jdbc_database) +';user='+ str(username) +';password='+ str(password) +';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
			# read sql table and create spark dataframe on top of it
			data_frame = spark.read.jdbc(url=jdbc_url, table=query, properties=connection_properties)

			if data_frame.count() > 0:
				return data_frame
	except:
		logger.info("Sql server properties are missing")
		raise ValueError("Sql server properties are missing ")

def data_quality_regex_expr_validation(hash_table,rule_col,rule_id,rule_val,logger):
	"""
	@params: envConfig,hash_table,rule_col,rule_id,logger
	@returns: regex validation record, regex validation record count
	"""
	map_dict = {}
	regex_pat = regex_pattern()
	map_dict = mapping_dict()
	logger.info("Trying to load data for rule value: " + rule_val)
	key = map_dict[rule_val]
	reg = regex_pat[key]
	if reg:
		validated_res = hash_table.withColumn("ERR_CD", when(regexp_extract(rule_col, reg, 0) == lit(""), lit(rule_id)).otherwise(lit("")))
	else:
		logger.error("Regular Expression not found" + reg)
	# logger.debug("Hash Table count with column is",str(hash_table.count()))
	return validated_res, validated_res.count()


def data_quality_ks_test_distribution(spark, hash_table, rule_col, rule_id, rule_val, logger):
	"""[Uses Kolmogorov-Smirnov test statistics to explain if the given dataframe has normal distribution or not]
	Args:
		spark ([pyspark.sql.session.SparkSession]): [Instance of spark session]
		hash_table (pyspark.sql.dataframe.DataFrame): [Input dataframe]
		rule_col ([str]): [Column name to test for]
		rule_id ([str]): [Passed automatically as primary key]
		rule_val ([str]): [Concatenated parameters]
		logger ([module]): [Instance of logger class]
	Returns:
		[pyspark.sql.dataframe.DataFrame]: [Output dataframe with ERR_CD column added]
		[int]: [Number of failed records]
	"""
	try:
		rule_val = ast.literal_eval(rule_val)
		p_value = float(rule_val['p_value'])
		distribution = rule_val['dist']
		print(f'Parameters extracted succesfully - > p_value: {p_value} | distribution: {distribution}')
		if p_value <= 0 or p_value >= 1:
			logger.error("P_value must be between 0 and 1 exclusive")
	except:
		logger.error('Parameters extraction failed')

	try:
		df_spark = hash_table[[rule_col]]
		df_spark = df_spark.filter((~isnan(rule_col)) & (df_spark[rule_col].isNotNull()))
		null_count = hash_table.count() - df_spark.count()
		logger.info('Column found in the dataset')
		logger.info(f'Number of null values found in the column -> {null_count}')
	except:
		logger.error('Column not found in the dataset')

	if distribution.lower() == "norm":
		try:
			df_stats = df_spark.select(
				_mean(df_spark[rule_col]).alias('mean'),
				_variance(df_spark[rule_col]).alias('variance')
			).collect()
			mean = df_stats[0]['mean']
			variance = df_stats[0]['variance']
			logger.info(f'Dataframe stats calculated succesfully - > mean: {mean} | variance: {variance}')
		except:
			logger.error('Failed to calculate dataframe stats')
		try:
			try:
				emptyRDD = spark.sparkContext.emptyRDD()
				dq_table = spark.createDataFrame(emptyRDD,hash_table.schema)
				dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
				logger.info('Creation of dq_table is successful')
			except:
				logger.error('Creation of dq_table failed')

			results = ml.stat.KolmogorovSmirnovTest.test(df_spark, rule_col, distribution, mean, variance)
			significance_val = results.collect()[0][0]
			logger.info(f'Significance value caculated successfully -> {significance_val}')
			if significance_val > p_value:
				logger.info("Success -> Can't reject the null hypothesis")
				return dq_table, 0, f'Significance value (Success) -> {significance_val}'
			logger.info("Fail -> Null hypothesis rejected")
			return dq_table, hash_table.count(), f'Significance value (Fail)-> {significance_val}'
		except:
			logger.info(f'Failed to calculate significance value')
			return None, -1, None
	else:
		logger.error("Only normal distribution is supported")
		return None, -1, None


def data_quality_chisquare_test(spark, hash_table, rule_col, rule_id, rule_val, logger):
	"""[Uses Chisquare test statistics to explain if the two dataframes have common distributions or not]
	Args:
		spark ([pyspark.sql.session.SparkSession]): [Instance of spark session]
		hash_table (pyspark.sql.dataframe.DataFrame): [Input dataframe]
		rule_col ([str]): [Column name to test for]
		rule_id ([str]): [Passed automatically as primary key]
		rule_val ([str]): [Concatenated parameters]
		logger ([module]): [Instance of logger class]
	Returns:
		[pyspark.sql.dataframe.DataFrame]: [Output dataframe with ERR_CD column added]
		[int]: [Number of failed records]
	"""
	#Creation of parameters from a rule_val
	try:
		rule_val = ast.literal_eval(rule_val)
		p_value = float(rule_val['p_value'])
		partition = rule_val['partition']
		logger.info(f'Parameters extracted succesfully - > p_value: {p_value} | partiton: {partition}')
		if len(partition['values']) != len(partition['weights']):
			logger.error("Length of values list and weights list in partion object should be equal")
		if np.array(partition['weights']).sum() != 1.0:
			logger.error("Weights should add up to 1")
		if p_value <= 0 or p_value >= 1:
			logger.error("P_value must be between 0 and 1 exclusive")
	except:
		logger.error('Parameters extraction failed')
	try:
		df_spark = hash_table[[rule_col]]
		df_spark = df_spark.filter((~isnan(rule_col)) & (df_spark[rule_col].isNotNull()))
		null_count = hash_table.count() - df_spark.count()
		logger.info('Column found in the dataset')
		logger.info(f'Number of null values found in the column -> {null_count}')
	except:
		logger.error('Column not found in the dataset')
	try:
		df_spark = df_spark.groupBy(rule_col).count().withColumnRenamed('count', 'actual')
		values_found = df_spark.select(collect_list(rule_col)).first()[0]
		values_not_found = list(set(partition['values'])-set(values_found))
		if len(values_not_found)>0:
			nf_df = spark.createDataFrame(values_not_found, StringType())
			nf_df = nf_df.withColumnRenamed('value', rule_col)
			nf_df = nf_df.withColumn('actual', lit(0))
			df_spark = df_spark.union(nf_df)
		mapping = dict(zip(partition['values'],partition['weights']))
		mapping_expr = create_map([lit(x) for x in chain(*mapping.items())])
		df_spark = df_spark.withColumn("weights", mapping_expr.getItem(col(rule_col)))
		sum_actual = df_spark.rdd.map(lambda x: (1,x[-2])).reduceByKey(lambda x,y: x + y).collect()[0][1]
		df_spark = df_spark.withColumn('sum', lit(sum_actual)).withColumn('expected', col('sum')*col('weights')).withColumn('(actual-expected)^2', pow(col('actual')-col('expected'), 2)).withColumn('(actual-expected)^2/expected',col('(actual-expected)^2')/col('expected'))
		try:
			chi_square_score = df_spark.rdd.map(lambda x: (1,x[-1])).reduceByKey(lambda x,y: x + y).collect()[0][1]
			logger.info("For all the sub-categories weights are provided")
			logger.info(f"Chi square score calculation succeded -> {chi_square_score}")
		except:
			logger.error("Make sure all the sub-categories and weights for them are defined")
	except:
		logger.error("Chi square score calculation failed")
	try:
		try:
			emptyRDD = spark.sparkContext.emptyRDD()
			dq_table = spark.createDataFrame(emptyRDD,hash_table.schema)
			dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
			logger.info('Creation of dq_table is successful')
		except:
			logger.error('Creation of dq_table failed')
		degree_freedom = df_spark.count()-1
		significance_val = chi2.sf(chi_square_score, degree_freedom)
		logger.info(f'Calculation of significance value succeded -> {significance_val}')
		if significance_val > p_value:
			logger.info("Success -> Can't reject the null hypothesis")
			return dq_table, 0, f'Significance value (Success)-> {significance_val}'
		logger.info("Fail -> Null hypothesis rejected")
		return dq_table, hash_table.count(), f'Significance value (Fail)-> {significance_val}'
	except:
		logger.error("Calculation of significance value failed")
		return None, -1, None 


def data_quality_create_partition_continuous(hash_table, column, bins, n_bins = 10):
	"""[Helper function for craetion of data_quality_ks_test - partition]
	Args:
		hash_table (pyspark.sql.dataframe.DataFrame): [Input dataframe]
		column ([str]): [Column name to test for]
		bins ([str]): [Method of bin creation - ntile, uniform]
		n_bins ([int]): [Number of bins to be created for the contineous variable]
	Returns:
		[dict]: [Partition dictionary, stating weights and bins]
	"""
	#Helper function for creation of buckets and return counts
	def bucket_count_ord(spark_df, bins, column):
		bucketizer = Bucketizer()
		bucketizer.setSplits(bins)
		bucketizer.setInputCol(column)
		bucketizer.setOutputCol("buckets")
		bucketed = bucketizer.setHandleInvalid("skip").transform(spark_df.select(column))
		group_bucketed = bucketed.groupBy("buckets").count()
		group_bucketed_ord = group_bucketed.orderBy(col("buckets"))
		count_lst = group_bucketed_ord.select(collect_list('count')).first()[0]
		buckets_lst = group_bucketed_ord.select(collect_list('buckets')).first()[0]
		return count_lst, buckets_lst

	spark_df = hash_table[[column]].na.drop()
	count_ = spark_df.count()

	if bins.lower() == 'ntile':
		percentiles = da.linspace(start=0, stop=1, num=n_bins + 1).compute().tolist()
		bins = statFunc(spark_df).approxQuantile(column,percentiles, 0)
	elif bins.lower() == 'uniform':
		min_max_vals = statFunc(spark_df).approxQuantile(column,[0.0,1.0], 0)
		min_ = min_max_vals[0]
		max_ = min_max_vals[1]
		bins = da.linspace(start=float(min_), stop=float(max_), num=n_bins + 1).compute().tolist()
	else:
		print("Make a vaild choice for creation of bins")
	mapping = {}
	mapping1 = {}
	for i in range(0, len(bins)-1):
		mapping[i] = bins[i]
		mapping1[i] = bins[i+1]
	bins = list(set(bins))
	bins.sort()
	count_lst, buckets_lst = bucket_count_ord(spark_df, bins, column)
	while len(bins)-1 > len(count_lst):
		bins = [mapping[i] for i in buckets_lst] + [mapping1[buckets_lst[-1]]]
		bins = list(set(bins))
		bins.sort()
		count_lst, buckets_lst = bucket_count_ord(spark_df, bins, column)
	output = {'bins': bins, 'weights': [x / count_ for x in count_lst]}
	return output


def data_quality_ks_test(spark, hash_table, rule_col ,rule_id ,rule_val, logger, hash_table_1 = None):
	"""[Uses Kolmogorov-Smirnov test statistics to explain if the two dataframes have common distributions or not]
	Args:
		spark ([pyspark.sql.session.SparkSession]): [Instance of spark session]
		hash_table (pyspark.sql.dataframe.DataFrame): [Input dataframe]
		rule_col ([str]): [Column name to test for]
		rule_id ([str]): [Passed automatically as primary key]
		rule_val ([str]): [Concatenated parameters]
		logger ([module]): [Instance of logger class]
		hash_table_1 (pyspark.sql.dataframe.DataFrame): [Secondary table for distribution creation]
	Returns:
		[pyspark.sql.dataframe.DataFrame]: [Output dataframe with ERR_CD column added]
		[int]: [Number of failed records]
	"""

	try:
		rule_val = ast.literal_eval(rule_val)
		if hash_table_1 is not None:
			alpha = float(rule_val['alpha'])
			bins = rule_val['bins']
			n_bins = rule_val['n_bins']
			partition = data_quality_create_partition_continuous(hash_table_1, rule_col , bins, n_bins)
			logger.info(f'Parameters extracted succesfully - > alpha: {alpha} | bins: {bins} | n_bins: {n_bins}')
		else:
			alpha = float(rule_val['alpha'])
			partition = rule_val['partition']
			logger.info(f'Parameters extracted succesfully - > alpha: {alpha} | partiton: {partition}')
			logger.info(f'Partition info -> {partition}')
			if len(partition['bins'])-1 != len(partition['weights']):
				logger.error("Bins list and weights list is not defined properly")
			if np.array(partition['weights']).sum() != 1.0:
				logger.error("Weights should add up to 1")
			if alpha <= 0 or alpha >= 1:
				logger.error("alpha value must be between 0 and 1 exclusive")
	except:
		logger.error('Parameters extraction failed')
	try:
		df_spark = hash_table[[rule_col]]
		df_spark = df_spark.filter((~isnan(rule_col)) & (df_spark[rule_col].isNotNull()))
		null_count = hash_table.count() - df_spark.count()
		logger.info('Column found in the dataset')
		logger.info(f'Number of null values found in the column -> {null_count}')
	except:
		logger.error('Column not found in the dataset')
	try:
		bins = list(set(partition['bins']))
		bins.sort()
		bins[0] = float('-inf')
		bins[-1] = float('inf')
		bucketizer_ = Bucketizer()
		bucketizer_.setSplits(bins)
		bucketizer_.setInputCol(rule_col)
		bucketizer_.setOutputCol("buckets")
		bucketed = bucketizer_.setHandleInvalid("skip").transform(df_spark.select(rule_col))
		group_bucketed = bucketed.groupBy("buckets").count()
		buckets_found = group_bucketed.select(collect_list('buckets')).first()[0]
		buckets = [float(i) for i in range(0, len(partition['weights']))]
		buckets_not_found = list(set(buckets)-set(buckets_found))
		if len(buckets_not_found)>0:
			nf_df = spark.createDataFrame(buckets_not_found, FloatType())
			nf_df = nf_df.withColumnRenamed('value', 'buckets')
			nf_df = nf_df.withColumn('count', lit(0))
			group_bucketed = group_bucketed.union(nf_df)
		logger.info('Creation of buckets was successful')
		try:
			emptyRDD = spark.sparkContext.emptyRDD()
			dq_table = spark.createDataFrame(emptyRDD,hash_table.schema)
			dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
			logger.info('Creation of dq_table is successful')
		except:
			logger.info('Creation of dq_table failed')
		group_bucketed_w  = group_bucketed.rdd.map(lambda x: (x.buckets, partition['weights'][int(x.buckets)])).toDF(["buckets_1","weights"])
		df_spark = group_bucketed.join(group_bucketed_w, group_bucketed.buckets == group_bucketed_w.buckets_1, 'left').drop('buckets_1')
		sum_actual = df_spark.rdd.map(lambda x: (1,x[-2])).reduceByKey(lambda x,y: x + y).collect()[0][1]
		df_spark = df_spark.withColumn('sum', lit(sum_actual)).withColumn('expected', col('sum')*col('weights'))
		df_spark = df_spark.selectExpr(
			"buckets", "count", "weights", "sum","expected",
			"sum(count) over (order by row_number() over (order by buckets asc)) as count_cum_sum",
			"sum(expected) over (order by row_number() over (order by buckets asc)) as expected_cum_sum"
		)
		df_spark = df_spark.withColumn("Fo(X)", col('count_cum_sum')/sum_actual).withColumn("Ft(X)", col('expected_cum_sum')/sum_actual).withColumn("Fo(X)-Ft(X)", abs(col('Fo(X)') - col('Ft(X)')))
		test_stats_val = df_spark.agg({"Fo(X)-Ft(X)": "max"}).collect()[0][0]
		critical_value = ksone.ppf(1 - alpha/2,sum_actual)
		logger.info('Critical and test stats values calculated successfully')
		logger.info(f'test_stats_val -> {test_stats_val} | critical_value -> {critical_value}')
		if test_stats_val < critical_value:
			logger.info("Success -> Can't reject the null hypothesis")
			return dq_table, 0, f'Success - Test stats value ({test_stats_val}) < Critical value ({critical_value})'
		logger.info("Fail -> Null hypothesis rejected")
		return dq_table, hash_table.count(), f'Fail - Test stats value ({test_stats_val}) > Critical value ({critical_value})'
	except:
		logger.error('Critical and test stats values calculation failed')
		return None, -1, None


#cramers_phi_value
def data_quality_cramers_phi_value(spark, hash_table, ruleCol, ruleID, ruleVal, logger):
    """[summary] :
    [Cramer's phi gives us a value between 0 and 1, which indicates the strength of the correlation.
     -> The Higher the value, the stronger the relationship.
     -> In this function we are expecting the Cramer's phi value to be less than the threshold
        value we specify.
     -> The function returns the observed Cramer's phi value and If the observed value is less than
        the specified threshold value, It returns "Success" else it returns "Fail".]

	Args:
		spark ([pyspark.sql.session.SparkSession]): [description]
		hash_table (pyspark.sql.dataframe.DataFrame): [input dataframe]
		ruleCol ([str]): [list of two categorical columns]
		rule_id ([str]): [description]
		ruleVal ([str]): [threshold value]
		logger ([module]): [description]
	Returns:
		[pyspark.sql.dataframe.DataFrame]: [dq table with error code]
		[int]: [0 if the function succeeds (or)
		        the total dataframe count if the function fails to meet the required condition]
	"""
    ruleCol = ruleCol.split(',')
    try:
        threshold = float(ruleVal)
    except:
        logger.error('Threshold value should not be lis string')
    try:
        if len(ruleCol)!=2:
            logger.error('Cramers phi must always have two columns as the input for calculation')
        else:
            #dropping null values from the columns
            df_spark = hash_table[[ruleCol]].na.drop()
    except:
        logger.error('Either one or both the columns are not found in the dataset')
    try:
        cross_tab = df_spark.crosstab(ruleCol[0],ruleCol[1])
        #replacing '.' with '_' in the column names as pyspark wouldn't fetch a column name with '.'
        crosstable = cross_tab.toDF(*(col_len.replace('.', '_') for col_len in cross_tab.columns))
        rdd = crosstable.rdd
        lis = rdd.map(list)
        #calculating sum of each row
        row_totals = []
        for i in lis.collect():
            row_totals.append(np.array(i[1:]).sum())
        #calculating sum of each column
        colsum = crosstable.groupBy().sum()
        for i in colsum.collect():
            dic = i.asDict()
        col_totals = list(dic.values())
        total_sum = df_spark.count()
        chi_val = 0
        for i in range(len(row_totals)):
            for j in range(len(col_totals)):
                expected_val = row_totals[i] * col_totals[j] / total_sum
                observed_val = crosstable.collect()[i][j+1]
                #calculating chi-square
                chi_val = chi_val + (observed_val - expected_val)**2 / expected_val
        if chi_val == 0:
            logger.info('Cramers phi is applicable only for categorical columns with atleast two distinct values')
        else:
            pass
        row_len = len(row_totals)
        col_len = len(col_totals)
        total = df_spark.count()
        minimum = np.min(np.array([row_len,col_len]))
        #calculating cramers phi
        cramers_phi = (chi_val / (total*(minimum-1)))**0.5
        logger.info(f'observed Cramers phi --> {cramers_phi}')
        try:
            empty_rdd = spark.sparkContext.emptyRDD()
            dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
            dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
        except:
            logger.error('dq_table creation failed')
        if cramers_phi < threshold:
            logger.info("Success - Observed cramers phi value is less than threshold value")
            return dq_table, 0
        else:
            logger.info("Fail - Observed cramers phi value is not less than threshold value")
            return dq_table, hash_table.count()
    except:
        logger.error('cramers phi value calculation failed')
        return None, -1

#compound_columns_to_be_unique
def data_quality_compound_columns_to_be_unique(spark, hash_table, ruleCol, ruleID, ruleVal, logger):
    """[summary]
    [Expect that the columns are unique together
     -> In this function we are expecting a list of columns to be unique together
     -> example : A B C
                  1 1 2 - Fail
                  1 2 3 - Pass
                  1 1 2 - Fail
                  2 2 2 - Pass
                  3 2 3 - Pass
     -> The above mentioned example is not unique as '112' is repeating]

	Args:
		spark ([pyspark.sql.session.SparkSession]): [description]
		hash_table (pyspark.sql.dataframe.DataFrame): [input dataset]
		ruleCol ([str]): [list of columns that we are expecting to be unique together]
		rule_id ([str]): [description]
		ruleVal ([str]): [specify ruleVal as
						  'all_values_are_missing' to ignore a row if all values in a row are null (or)
						  'any_value_is_missing' to ignore a row if any value in a row is null (or)
						  'never' to never ignore a row]
		logger ([module]): [description]
	Returns:
		[pyspark.sql.dataframe.DataFrame]: [dq table with error code]
		[int]: [0 if the function succeeds (or)
		        the total dataframe count if the function fails to meet the required condition]
	"""
    ruleCol = ruleCol.split(',')
    ignore_row_if = ruleVal
    try:
        df = hash_table.select(ruleCol)
    except:
        logger.error('Either one or more columns in the col_list are not present in the dataset')
    try:
        empty_rdd = spark.sparkContext.emptyRDD()
        dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
        dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
    except:
        logger.info('dq_table creation failed')
    try:
        if ignore_row_if == 'all_values_are_missing':
            dataframe = df[ruleCol].na.drop(how='all')
            distinct_count = dataframe.select(ruleCol).distinct().count()
            if distinct_count != dataframe.count():
                status = 'fail'
                logger.info('Status - Fail -> columns are not unique together')
                # return dq_table, hash_table.count()
            else:
                status = 'success'
                logger.info('Status - Success -> columns are unique together')
                # return dq_table, 0
        elif ignore_row_if == 'any_value_is_missing':
            dataframe = df[ruleCol].na.drop(how='any')
            distinct_count = dataframe.select(ruleCol).distinct().count()
            if distinct_count != dataframe.count():
                status = 'fail'
                logger.info('Status - Fail -> columns are not unique together')
                # return dq_table, hash_table.count()
            else:
                status = 'success'
                logger.info('Status - Success -> columns are unique together')
                # return dq_table, 0
        elif ignore_row_if == 'never':
            distinct_count = df.select(ruleCol).distinct().count()
            if distinct_count != df.count():
                status = 'fail'
                logger.info('Status - Fail -> columns are not unique together')
                # return dq_table, hash_table.count()
            else:
                status = 'success'
                logger.info('Status - Success -> columns are unique together')
                # return dq_table, 0
        else:
            logger.error('ruleVal should be all_values_are_misssing/any_value_is_missing/never')
        if status == 'success':
            return dq_table, 0
        elif status == 'fail':
            return dq_table, hash_table.count()
    except:
        logger.error('Function failed as ruleVal is not specified properly')
        return None, -1

#anomaly detection
def data_anomaly_detection(spark,hash_table,path,rule_col,rule_id,rule_val,logger):
    """
        Perfroms a data anomaly detection run on the given column of a dataset. Depending on the parameter passed (KS or IF) it performs a KS test for a sniff test of anomalies in data or a builds an isolation forest for more thorough detection.
        @params: envConfig,hash_table,ruleColms,ruleID,logger
        @returns: dqtable,total_failed
    """
    #function for building if dqtable
    def build_dqtable(hashtable,outlier,rule_col,rule_id):
        """
        Builds dqtable for return.
        """
        window = Window.orderBy(rule_col)
        result = hashtable.withColumn("index", row_number().over(window))
        df_spark = result.filter((~isnan(rule_col)) & (result[rule_col].isNotNull()))
        window = Window.orderBy(rule_col)
        result_2 = df_spark.withColumn("index_new_1", row_number().over(window))
        temp_df = spark.createDataFrame(outlier.tolist(), IntegerType())
        window = Window.orderBy("value")
        result_new = temp_df.withColumn("index_new", row_number().over(window))
        final_df = result_2.join(result_new, result_2.index_new_1 == result_new.index_new, how='inner').drop('index_new', 'index_new_1')
        d_frame = result.join(final_df[['index', 'value']], result.index == final_df.index, how='left')
        dqtable = d_frame.withColumn('ERR_CD', when((col('value')==-1) | (isnan('value')) | (~d_frame['value'].isNotNull()), rule_id).otherwise(None))[hashtable.columns + ['ERR_CD']]
        return dqtable    
    #Function for performing ks test
    def ks_test(hash_table, rule_colms,std_threshhold,mean_value=0, std_value=1):
        """
            Performs KSTest
            Returns Boolean value
            True if pvalue less than threshold
            False if pvalue greater than threshold
            @params:hash_table, ruleColms,std_threshhold,mean_Value, std_Value
            @returns: Boolean
        """
        print(hash_table.show())
        print(rule_colms)
        ks_result=ml.stat.KolmogorovSmirnovTest.test(hash_table, rule_colms, 'norm',mean_value, std_value).first()
        print(ks_result.pValue)
        return ks_result.pValue<std_threshhold
    #function for building isolation forest
    def i_forest(spark,hashtable,rule_colms,contamination_value,null_count):
        """
            Builds an isolation forest model for detecting anomalies
            Returns Percentage of anomalies in a given column
            @params:hashtable,ruleColms,null_count,contamination_value
            @returns:total_row,total_failed,per
        """
        
        colm = da.from_array(hashtable.select(rule_colms).collect(),chunks=(1000,1000)).reshape(-1,1) #converting column of spark df to array
        # grid_search=GridSearchCV(sc=spark.sparkContext,estimator=IsolationForest(n_estimators=100,n_jobs=-1,random_state=0),
		# param_grid={'contamination':contamination_value},scoring=scorer_f,n_jobs=-1)  #buildin the IF model with GS optimisation
        # grid_search.fit(colm)
        # outlier=grid_search.predict(colm) #predicting the outliers
        m=0
        outlier=[]
        for i in range(1,len(colm),10):
            for j in range(1,4):
                model=LocalOutlierFactor(n_neighbors=i,p=j,n_jobs=-1)
                r=model.fit_predict(colm)
                c=len(r<0)
                if c>m:
                    m=c
                    outlier=r
        print(outlier)
        print(m)
        # print(contamination_value)
        total_failed=np.sum(np.where(outlier==-1,1,0))+null_count
        total_failed=int(total_failed) #total failed rows
        return total_failed,outlier
    logger.info("Initiating drift detection on  : " + rule_col)
    conf=spark.read.option("multiline","true").json(path)
    cont=conf.select('DRIFT_DETECTION .i_forest.contamination').collect()[0][0]
    parm=rule_val.split(',')
#for KS Test
    if parm[0]=="KS":
        hashtable=hash_table.na.drop(subset=[rule_col])#dropping the null values
        if hashtable.rdd.isEmpty():
            logger.error('Column contains only null Values. KS Test cant be performed.')
            return None,-1
        try:
            mean_v=float(parm[2])
            if mean_v=='None':
                mean_v=hashtable.select(_mean(hashtable[rule_col])).collect()[0][0]	
        except:
            mean_v=hashtable.select(_mean(hashtable[rule_col])).collect()[0][0]
        try:
            std_v=float(parm[3])
            if std_v=='None':
                std_v=hashtable.select(_stddev(hashtable[rule_col])).collect()[0][0]	
        except:    
            std_v=hashtable.select(_stddev(hashtable[rule_col])).collect()[0][0]
        try:
            threshold_ks=float(parm[1])
            if threshold_ks== 'None':
                threshold_ks=0.7
        except:
            threshold_ks=0.7
        try:
            ks_val=ks_test(hashtable,rule_col,threshold_ks,mean_v, std_v)
            logger.info('KS test successful')
            try:
                empty_rdd = spark.sparkContext.emptyRDD()
                dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
                dq_table = dq_table.withColumn("ERR_CD", lit(None).cast(StringType()))
                logger.info('Creation of dq_table is successful')
            except:
                logger.error('Creation of dqtable failed')
                return None,-1
            if ks_val:
                return dq_table, hash_table.count()
            else:
                return dq_table,0
        except:
            logger.error("KS test failed")
            return None,-1

#for Isolation Forest model
    elif parm[0]=="IF":
        temp_df = hash_table.filter((~isnan(rule_col)) & (hash_table[rule_col].isNotNull()))
        null_count = hash_table.count() - temp_df.count()
        df=hash_table.na.drop(subset=[rule_col]) #dropping the null values
        if df.rdd.isEmpty():
            logger.error('Column contains all null values. IF Model could not be built.')
            return None,-1
        try:
            failed_row_cnt,outlier=i_forest(spark,df,rule_col,cont,null_count)
            logger.info('Isolation Forest Build successful')
            try:
                dqtable=build_dqtable(hash_table,outlier,rule_col,rule_id)
                logger.info('Creation of dq table successful.')
                return dqtable,failed_row_cnt
            except:
                logger.error('Creation of dqtable failed')
                return None,-1  
        except:
            logger.error('Isolation Forest failed!')
            return None,-1


def condition(number,mini,maxi,hash_table):
	"""Checks for the value n to be between minimum and maximum.

	Args:
		number ([integer]): [Value to be compared]
		mini ([integer]): [Lower limit]
		maxi ([integer]): [Upper limit]
		hash_table (dataframe): [Table to return the number of rows in case condition fails]

	Returns:
		[integer]: [0 or Number of rows in given dataframe]
	"""
	if number>mini and number<maxi:
		return 0
	return hash_table.count()

def get_dtype(data_frame,colname):

	"""[Get datatype of column]

	Args:
		data_frame ([Dataframe]): [Dataframe which contains the column]
		colname ([string]): [Column name to perform data type check]

	Returns:
		[string]: [data type of specified column]
	"""
	return [dtype for name, dtype in data_frame.dtypes if name == colname][0]

def data_quality_aggregate_validation(spark, hash_table, rule_col, rule_val, rule_id, logger):

	"""Function checks whether or not, aggregate value lies between given thresholds.

	Raises:
		ValueError: [if column specified is not having numerical values]

	Args:
		hash_table ([dataframe]): [Table with values]
		rule_col ([string]): [Column name]
		rule_val ([string]): [Aggregate type and threshold values]
		rule_id ([string]): [rule_id to append in case of condition failure]
		logger ([type]): [description]

	Returns:
		[dataframe]: [Rows failed]
		[integer]: [Number of rows failed]
	"""
	rule_val=json.loads(rule_val)
	rule = rule_val['aggregate']
	mini = float(rule_val['min_val'])
	maxi = float(rule_val['max_val'])
	validated_res = hash_table.withColumn("ERR_CD",lit(rule_id))
	emptyRDD = spark.sparkContext.emptyRDD()
	dq_table = spark.createDataFrame(emptyRDD,hash_table.schema)
	df_output = hash_table.withColumn(rule_col,hash_table[rule_col].cast(FloatType()))
	dt_type = get_dtype(df_output,rule_col)


	try:
		if rule.lower() == 'sum':
			if dt_type.lower() == 'int' or dt_type.lower() == 'float' or dt_type.lower() == 'double':
				df_stats = df_output.select(sum(col(rule_col)).alias('sum')).collect()
				df_sum = df_stats[0]['sum']
				sum_val = float(df_sum)
				validated_res_count = condition(sum_val,mini,maxi,hash_table)
			else:
				logger.error(f"Column {rule_col} is not a numerical column")

		elif rule.lower() == 'max':
			if dt_type.lower() == 'int' or dt_type.lower() == 'float' or dt_type.lower() == 'double':
				df_stats = df_output.select(max(col(rule_col)).alias('maxi')).collect()
				df_max = df_stats[0]['maxi']
				max_val = float(df_max)
				validated_res_count = condition(max_val,mini,maxi,hash_table)
			else:
				logger.error(f"Column {rule_col} is not a numerical column")
    
		elif rule.lower() == 'min':
			if dt_type.lower() == 'int' or dt_type.lower() == 'float' or dt_type.lower() == 'double':
				df_stats = df_output.select(min(col(rule_col)).alias('mini')).collect()
				df_min = df_stats[0]['mini']
				min_val = float(df_min)
				validated_res_count=condition(min_val,mini,maxi,hash_table)
			else:
				logger.error(f"Column {rule_col} is not a numerical column")

		elif rule.lower() == 'mean':
			if dt_type.lower() == 'int' or dt_type.lower() == 'float' or dt_type.lower() == 'double':
				df_stats = df_output.select(mean(col(rule_col)).alias('meani')).collect()
				df_mean = df_stats[0]['meani']
				mean_val = float(df_mean)
				validated_res_count = condition(mean_val,mini,maxi,hash_table)
			else:
				logger.error(f"Column {rule_col} is not a numerical column")

		elif rule.lower() == 'median':
			if dt_type.lower() == 'int' or dt_type.lower() == 'float' or dt_type.lower() == 'double':
				output_df = df_output.where(col(rule_col).isNotNull())
				col_count = output_df.select(col(rule_col)).count()
				if col_count%2 == 0:
					median = (output_df.approxQuantile(rule_col,[0.50],0.001)[0]+output_df.approxQuantile(rule_col,[0.51],0.001)[0])/2
				else:
					median = output_df.approxQuantile(rule_col,[0.50],0.001)[0]
				validated_res_count=condition(median,mini,maxi,hash_table)
			else:
				logger.error(f"Column {rule_col} is not a numerical column")
		else:
			logger.error("Please select a valid aggregate rule.")

		if validated_res_count != 0:
			return validated_res,validated_res_count

		return dq_table,0

	except:
		logger.info("Column does not have numerical values")
		raise ValueError("Column does not have numerical values")

def data_quality_unique_validation(hash_table, rule_col, rule_id, logger):
	"""[Checks for unique values in the given column(where count==1 and after removing null values )]

	Args:
		hash_table ([dataframe]): [Table with values]
		rule_col ([string]): [Column name]
		rule_id ([string]): [rule_id to append in case of condition failure]
		logger ([type]): [description]

	Returns:
		[dataframe]: [Rows failed]
		[integer]: [Number of rows failed]
	"""
	try:
		newdf = (hash_table.groupBy(rule_col).count()).filter("count==1").filter(hash_table[rule_col].isNotNull())
		if newdf.count() == 0:
			logger.info("Unique values are not present in the column")
			return hash_table.withColumn("ERR_CD",lit(rule_id)),hash_table.count()

		unq_list = newdf.select(rule_col).rdd.flatMap(lambda x: x).collect()
		data_frame = hash_table.filter(~hash_table[rule_col].isin(unq_list)|hash_table[rule_col].isNull())
		logger.info("Unique Values identified sucessfully")
		return data_frame.withColumn("ERR_CD",lit(rule_id)), hash_table.count()-newdf.count()
	except:
		logger.info("Unique Validation failed.")
  
def data_quality_column_unique_count_to_be_between(spark, hash_table, column, rule_val, rule_id, logger):
	"""check the number of unique values in a column"""
	try:
		rule_val = json.loads(rule_val)
		min_value = rule_val["min_val"]
		max_value = rule_val["max_val"]
		validated_res = hash_table.withColumn("ERR_CD", lit(rule_id))
		empty_rdd = spark.sparkContext.emptyRDD()
		dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
		unique_value_df = (hash_table.groupBy(column).count()).filter("count==1")\
			.filter(hash_table[column].isNotNull())
		unique_value_count = unique_value_df.count()

		if unique_value_count is None:
			logger.info("Unique values are not present in the column")
			return validated_res, hash_table.count()
		try:
			if ((unique_value_count >= int(min_value)) and (unique_value_count <= int(max_value))):
				return dq_table, 0
			else:
				return validated_res, hash_table.count()
		except:
			logger.error("min_value or max_value are none")
			return None,0
	except:
		logger.error("Error while validating unique values to be between")
		return None,0

def data_quality_proportion_of_unique_values_to_be_between(spark, hash_table, column, rule_val,\
	rule_id, logger, strict_min="false", strict_max="false"):
	"""Not including Null value while calculating the number of unique values"""
	try:
		rule_val = json.loads(rule_val)
		min_value = rule_val["min_val"]
		max_value = rule_val["max_val"]
		validated_res = hash_table.withColumn("ERR_CD",lit(rule_id))
		empty_rdd = spark.sparkContext.emptyRDD()
		dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
		unique_value_df = (hash_table.groupBy(column).count()).filter("count==1")\
			.filter(hash_table[column].isNotNull())
		unique_value_count = unique_value_df.count()
		row_cnt =hash_table.count()
		proportion = unique_value_count/row_cnt
		if proportion is None:
			return validated_res, row_cnt
		if strict_min == 'true':
			if min_value is not None:
				above_min = min_value<proportion
			else:
				above_min = True
			if max_value is not None:
				below_max = proportion <= max_value
			else:
				below_max = True
			success = above_min and below_max
			if success:
				return dq_table, 0
			else:
				return validated_res,row_cnt
		if strict_max == 'true':
			if min_value is not None:
				above_min = proportion >= min_value
			else:
				above_min = True
			if max_value is not None:
				below_max = proportion < max_value
			else:
				below_max = True
			success = above_min and below_max
			if success:
				return dq_table, 0
			else:
				return validated_res,row_cnt
		else:
			if min_value is not None:
				above_min = proportion >= min_value
			else:
				above_min = True
			if max_value is not None:
				below_max = proportion <= max_value
			else:
				below_max = True
			success = above_min and below_max
			if success:
				return dq_table, 0
			else:
				return validated_res, row_cnt
	except:
		logger.error("Error while validating proportion of unique values to be between")
		return None,0

def data_quality_multicolumn_sum_to_equal(spark, hash_table, column_list, rule_val, rule_id, logger):
    """Expects that the sum of row values is the same for each row,
    summing only values in columns specified in
    column_list, and equal to the specific value, sum_total."""
    column_list= column_list.split(',')
    rule_val = json.loads(rule_val)
    sum_total = int(rule_val["sum_total"])
    expression = '+'.join(column_list)
    df_ = hash_table.withColumn('sum_cols', F.expr(expression))
    df_new = df_.select('sum_cols')
    coun = df_new.count()
    validated_res = hash_table.withColumn("ERR_CD", lit(rule_id))
    empty_rdd = spark.sparkContext.emptyRDD()
    dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
    unexpected_value=[]
    try:
        for i in range(coun):
            temp = df_new.collect()[i][0]
            if temp == sum_total:
                continue
            else:
                unexpected_value.append(temp)
        if unexpected_value:
            return validated_res, len(unexpected_value)
        else:
            return dq_table,0
    except:
        logger.error("Error while validating multicolumn sum to equal")
        return None,0


def data_quality_most_common_value_to_be_in_set(spark, hash_table, column, rule_val, rule_id, logger):
	"""Expect the most common value to be within the designated value set"""
	try:
		df_new = hash_table.groupby(column).count()
		rule_val = ast.literal_eval(rule_val)
		ordered_df = df_new.orderBy(desc('count')).take(1)
		temp_a = ordered_df[0]["count"]
		col_len = df_new.select(column).count()
		lst = []
		validated_res = hash_table.withColumn("ERR_CD", lit(rule_id))
		empty_rdd = spark.sparkContext.emptyRDD()
		dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
		lst_expec = list(rule_val["Value_set"])
		if temp_a != 1 :
			for i in range(col_len):
				temp_b = df_new.collect()[i][1]
				if temp_a==temp_b :
					lst.append(df_new.collect()[i][0])
			if all(elem in lst_expec for elem in lst):
				return dq_table, 0
			else:
				return validated_res, hash_table.count()
		else:
			logger.error("max_count = 1 or null")
			return None, 0
	except:
		logger.error("error while validating expect most common value to be in set rule")
		return None, 0

def data_quality_expect_column_values_to_be_increasing(spark, hash_table, rule_col, rule_val, rule_id, logger, strictly=False):
	"""Expect column values to be increasing."""
	try:
		column = hash_table.select(rule_col)
		# string column name
		column_name = column.schema.names[0]
		# check if column is any type that could have na (numeric types)
		na_types = [isinstance(column.schema[column_name].dataType, typ) for typ in \
			[sparktypes.LongType,sparktypes.DoubleType,sparktypes.IntegerType,]]
		# if column is any type that could have NA values, remove them (not filtered by .isNotNull())
		if any(na_types):
			hash_table = hash_table.filter(~isnan(column[0]))
		
		hash_table = (hash_table.withColumn("row_idx",row_number().over(Window.orderBy(monotonically_increasing_id())))\
				.withColumn("lag",lag(column[0]).over(Window.orderBy(F.col("row_idx")))).withColumn("diff", column[0] - col("lag"))) 
			# replace lag first row null with 1 so that it is not flagged as fail
		hash_table = hash_table.withColumn("diff", when(F.col("diff").isNull(), 1).otherwise(F.col("diff")))
		if strictly:
			hash_table = hash_table.withColumn("ERR_CD", when(F.col("diff") >= 1, lit(""))\
				.otherwise(lit(rule_id)))
		else:
			hash_table = hash_table.withColumn("ERR_CD", when(F.col("diff") >= 0, lit(""))\
				.otherwise(lit(rule_id)))
		return hash_table.drop("diff","row_idx","lag"), hash_table.where(F.col("ERR_CD") == rule_id).count()
	except:
		logger.error("error while validating expect column values to be increasing rule")
		return None, 0

"""great expectations"""
def data_quality_expect_column_values_to_be_decreasing(spark, hash_table, rule_col, rule_val,\
													rule_id, logger, strictly=False):
	"""check the values in a column are decreasing or not"""
	try:    
		column = hash_table.select(rule_col)
		# string column name
		column_name = column.schema.names[0]
		# check if column is any type that could have na (numeric types)
		na_types = [isinstance(column.schema[column_name].dataType, typ) \
			for typ in [sparktypes.LongType,sparktypes.DoubleType,sparktypes.IntegerType,]]
		# if column is any type that could have NA values, remove them (not filtered by .isNotNull())
		if any(na_types):
			hash_table = hash_table.filter(~isnan(column[0]))
		hash_table = (hash_table.withColumn("row_idx",row_number().over(Window.orderBy(monotonically_increasing_id())))\
				.withColumn("lag",lag(column[0]).over(Window.orderBy(F.col("row_idx")))).withColumn("diff", column[0] - col("lag")))
	# replace lag first row null with 1 so that it is not flagged as fail
		hash_table = hash_table.withColumn("diff", when(F.col("diff").isNull(), -1).otherwise(F.col("diff")))
		if strictly:
			hash_table = hash_table.withColumn("ERR_CD", when(F.col("diff") <= -1, lit(""))\
				.otherwise(lit(rule_id)))
		else:
			hash_table = hash_table.withColumn("ERR_CD", when(F.col("diff") <= 0, lit(""))\
				.otherwise(lit(rule_id)))
		return hash_table.drop("diff","row_idx","lag"), hash_table.where(F.col("ERR_CD") == rule_id).count()
	except:
		logger.error("error while validating expect column values to be decreasing rule")
		return None, 0

def data_quality_column_is_json_parsable(spark, hash_table, column, rule_val, rule_id, logger):
    """Expect column entries to be data written in JavaScript Object Notation."""
    try:
        df_ = hash_table.select(column)
        count=0
        validated_res = hash_table.withColumn("ERR_CD",lit(rule_id))
        empty_rdd = spark.sparkContext.emptyRDD()
        dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
        for i in range(df_.count()):
            val = df_.collect()[i][0]
            try:
                json.loads(val)
            except:
                count+=1
        if count == 0:
            return dq_table, 0
        else:
            return validated_res, hash_table.count()
    except:
        logger.error("error while validating column is json parsable rule")
        return None, 0
		

def data_quality_column_values_to_match_json_schema(spark, hash_table, rule_col, rule_val, rule_id, logger):
	"""Expect column entries to be JSON objects matching a given JSON schema."""
	try:
		rule_val = ast.literal_eval(rule_val)
		json_schema = rule_val["schema"]
		df_ = hash_table.select(rule_col)
		count=0
		validated_res = hash_table.withColumn("ERR_CD",lit(rule_id))
		empty_rdd = spark.sparkContext.emptyRDD()
		dq_table = spark.createDataFrame(empty_rdd,hash_table.schema)
		for i in range(df_.count()):
			val = df_.collect()[i][0]
			try:
				val_json = json.loads(val)
				validate(val_json, json_schema)
			except:
				count+=1
		if count == 0:
			return dq_table, 0
		else:
			return validated_res, hash_table.count()
	except:
		logger.error("error while validating column values to match json schema rule")
		return None, 0

#values to be date parseable
def values_to_be_date_parseable(spark,hash_table,col_name,rule_val,ruleID,logger):
    """[summary]
      ""checks whether the values are in given format""
      @Args:
          hash_table: spark dataframe
          col_name: column name to check
          rule_val: Date format
      @Returns:
          Dataframe with ERR_CD
    """
    try:
        get_dtype=[dtype for name, dtype in hash_table.dtypes if name == col_name][0]
        if get_dtype == 'string':
            final_df = hash_table.withColumn("ERR_CD",f.when
                        (f.from_unixtime(f.unix_timestamp(f.col(col_name),rule_val))
                        .cast("timestamp").isNotNull() &f.col(col_name).isNotNull(),
                        f.lit("") ).otherwise(f.lit(ruleID)))
        else:
            logger.error("Datatype of column must be String")
        return final_df,final_df.count()
    except:
        logger.error("Error while validating values to be date format")
        return None,0

#quantiles to be between
def quantiles_to_be_between(spark,hash_table,col_name,rule_val,ruleID,logger):
    """[summary]
    ["checks whether quantiles are between the given values"]
    @Args:
      input_df - spark dataframe
      col_name - column to check
      rule_val - value range
    @Returns:
      final_df - Output dataframe with ERR_CD column added
    """
    rule_val = json.loads(rule_val)
    min_val = rule_val["min_val"]
    max_val = rule_val["max_val"]
    try:
        if col_name in (name for name in hash_table.columns):
            get_dtype=[dtype for name, dtype in hash_table.dtypes if name == col_name][0]
            if get_dtype == 'string':
                logger.error("Columns of type string is not supported")
                return None,0
            else:
                col_list=(hash_table.select(col_name).rdd.flatMap(lambda x: x).collect())
                maximum=col_list[0]
                for k in col_list:
                    if isinstance(k,float or int):
                        if maximum<k:
                            maximum = k
                min_percentile = (min_val*maximum)/100
                max_percentile = (max_val*maximum)/100
                final_df = hash_table.withColumn('ERR_CD', when(hash_table[col_name]
                        .between(min_percentile,max_percentile),
                        lit("")).otherwise(lit(ruleID)))
            return final_df,final_df.count()
        else:
            logger.error("Enter valid column name")
            return None,0
    except: 
        logger.error("error while validating quantiles to be between rule")
        return None,0

def count_to_be_between(input_df,rule_val,rule_id,logger):
	""" counts the no.of rows in a dataframe and checks if it is between 2 given values

	Args:
		input_df (pyspark dataframe): dataframe used to calculate count
		rule_val (json): min and max values given by user in a json format
		rule_id (string): rule id to add in error code column
		logger (logger): logger used to generate logs

	Returns:
		final_df (pyspark dataframe): dataframe appended with error code column
		final_df.count() (integer): row count of dataframe
	"""
	try:
		rule_val = json.loads(rule_val)
		min_val = rule_val["min_val"]
		max_val = rule_val["max_val"]
		if input_df.count() >= min_val and input_df.count() <= max_val:
			final_df = input_df.withColumn("ERR_CD",lit(''))
		else:
			final_df = input_df.withColumn("ERR_CD",lit(rule_id))
		return final_df,final_df.count()
	except:
		logger.error("Error while validating count_to_be_between")
		return None,0

def count_to_be_equal(input_df,rule_val,rule_id,logger):
	""" counts the no.of rows in a dataframe and checks if it is equal to the value given by user

	Args:
		input_df (pyspark dataframe): dataframe used to calculate count
		rule_val (integer): value given by user
		rule_id (string): rule id to add in error code column
		logger (logger): logger used to generate logs

	Returns:
		final_df (pyspark dataframe): dataframe appended with error code column
		final_df.count() (integer): row count of dataframe
	"""
	try:
		if input_df.count() != int(rule_val):
			final_df = input_df.withColumn("ERR_CD",lit(rule_id))
		else:
			final_df = input_df.withColumn("ERR_CD",lit(''))
		return final_df,final_df.count()
	except:
		logger.error("Error while validating count_to_be_equal")
		return None,0

def count_to_be_equal_table(spark,obj,input_df,lookup_path,ref_path_type,rule_id,logger):
	""" counts the no.of rows in a dataframe and checks if it is equal to the count of another dataframe

	Args:
		spark (spark): spark used to create empty dataframe
		obj (variabel): environment config variable
		input_df (pyspark dataframe): dataframe used to calculate count
		lookup_path (string): path of the file
		ref_path_type (string): format of the file
		rule_id (string): rule id to add in error code column
		logger (logger): logger used to generate logs

	Returns:
		final_df (pyspark dataframe): dataframe appended with error code column
		final_df.count() (integer): row count of dataframe
	"""
	try:
		lookup_path=str(lookup_path)
		logger.info("The lookup path is: "+str(lookup_path))
		table_df = spark.read.option("header", True).format(ref_path_type).load(lookup_path)
	except:
		logger.error("Error while creating the second dataframe")
		return None,0
	try:
		if input_df.count() != table_df.count():
			final_df = input_df.withColumn("ERR_CD",lit(rule_id))
		else:
			final_df = input_df.withColumn("ERR_CD",lit(''))
		return final_df,final_df.count()
	except:
		logger.error("Error while validating count_to_be_equal_table")
		return None,0
def col_to_dist_set(data_frame,col_name):
    """[Converts the column into a distict set]

    Args:
        data_frame ([Dataframe]): [Dataframe which contains the column]
        col_name ([string]): [Column name to perform data type check]
    Returns:
        distinct_set[set]: [returns a distinct set of values in the column]
        """
    dist_list= data_frame.select(col_name).na.drop().distinct().collect()
    dist_list= ([str(i[col_name]) for i in dist_list])
    dist_set=[]
    i= None
    for i in dist_list:
        if i in('null','NAN','NULL','Null'):
            continue
        check = i.replace('.','')
    if check.isnumeric():
        dist_set.append(float(i))
    else:
        dist_set.append(i)
    return set(dist_set)

def user_list_to_dist_set(user_list):
  """[Converts the user given string value into a distict set]
  Args:
		user_list[string]: [string contains user list values]

	Returns:
		distinct_set[set]: [returns a distinct set of values]
  """
  user_list= user_list.split(',')
  dist_set=[]
  i= None
  for i in user_list:
    if i in('null','NAN','NULL',"Null"):
      continue
    p= i.replace('.','')
    p=p.strip()
    if p.isnumeric():
      dist_set.append(float(i.strip()))
    else:
      dist_set.append(i.strip())
  return set(dist_set)

def distinct_values_to_equal_set(spark,hash_table,rule_col,rule_val,rule_id,logger):
  """[Check if all the distinct values provided by the user are present in the distinct column data frame(where count==1 and after removing null values )]

	Args:
		hash_table ([dataframe]): [Table with values]
		rule_col ([string]): [Column name]
		rule_id ([string]): [rule_id to append in case of condition failure]
		logger ([type]): [description]
		rule_val([string]): [user provided string value ]

	Returns:
		[dataframe]: [Rows failed]
		[integer]: [Number of rows failed]

	"""
  dist_list= col_to_dist_set(hash_table, rule_col)
  user_list= user_list_to_dist_set(rule_val)
  try:
    if len(set(dist_list)-set(user_list)) ==0 and len(set(user_list)-set(dist_list))==0:
      hash_table = hash_table.withColumn("ERR_CD",lit(""))
    else:
      hash_table = hash_table.withColumn("ERR_CD",lit(rule_id))
    return hash_table, hash_table.count()
  except:
    logger.error("Error while validating distinct_values_to_equal_set")
    return None, -1


def distinct_values_to_contain_set(spark,hash_table,rule_col,rule_val, rule_id,logger):
  """ all the distinct values provided by the user are present in the distinct column data frame
   @Args:
		hash_table ([dataframe]): [Table with values]
		rule_col ([string]): [Column name]
		rule_id ([string]): [rule_id to append in case of condition failure]
		logger ([type]): [description]
		rule_val([string]): [user provided string value ]
	@Returns:
		[dataframe]: [Rows failed]
		[integer]: [Number of rows failed]"""
  dist_list= col_to_dist_set(hash_table, rule_col)
  user_list= user_list_to_dist_set(rule_val)
  try:
    if len(set(user_list)-set(dist_list))!=0:
      hash_table = hash_table.withColumn("ERR_CD",lit(rule_id))
    else:
      hash_table = hash_table.withColumn("ERR_CD",lit(""))
    return hash_table, hash_table.count()
  except:
    logger.error('error while validating distinct_values_to_contain_set')
    return None,-1

def distinct_values_to_be_in_set(spark,hash_table,rule_col,rule_val,rule_id,logger):
  """[Check if all the distinct values provided by the user are in the column(where count==1 and after removing null values )]

	Args:
		hash_table ([dataframe]): [Table with values]
		rule_col ([string]): [Column name]
		rule_id ([string]): [rule_id to append in case of condition failure]
		logger ([type]): [description]
		rule_val([string]): [user provided string value ]

	Returns:
		[dataframe]: [Rows failed]
		[integer]: [Number of rows failed]

	"""
  dist_list= col_to_dist_set(hash_table, rule_col)
  user_list= user_list_to_dist_set(rule_val)
  try:
    if len(set(dist_list)-set(user_list)) !=0:
      hash_table=hash_table.withColumn("ERR_CD",lit(rule_id))  
    else:
      hash_table=hash_table.withColumn("ERR_CD",lit(""))
    return hash_table,hash_table.count()
  except:
    logger.error('error in validating distinct_values_to_be_in_set')
    return None, -1

#column_to_exist
def column_to_exist(spark,input_df,col_name,ruleID,df_dq_master,rule_exe_ts,batchDate,logger):
    """[summary]:
    [Check whether column exists in data frame]
    @Args:
        input_df - spark dataframe
        col_name - column name to check
    @returns: a boolean
    """
    try:
        if col_name in (name for name in input_df.columns):
            val_res = "column exists"
        else:
            val_res = "column does not exists"
    except:
        logger.error("Error while validating column_to_exist")
        return 0
    dq_statistics = stats_gen(spark, df_dq_master, val_res, ruleID,rule_exe_ts,batchDate)
    return dq_statistics

#column_to_match_ordered_list
def columns_to_match_ordered_list(spark,input_df,col_names,ruleID,df_dq_master,rule_exe_ts,batchDate,logger):
    """
      "check whether the columns exactly match a specified list"
      @Args:
        input_df - spark dataframe
        col_names - column name list
      @returns: a boolean

    """
    try:
        col_list = input_df.columns
        order_list = col_names.split(',')
        flag=0
        val_res = "columns does not match ordered list"
        for j in range(0,len(col_list)):
            if((order_list[0]==col_list[j]) and (len(col_list)-j>=len(order_list))):
                for i in range(0,len(order_list)):
                    if str(order_list[i])!=str(col_list[j+i]):
                        val_res = "columns does not match the ordered list"
                        flag = 1
                        break
                if flag == 0:
                    val_res = "columns match ordered list"
    except:
        logger.error("Error while validating column_to_match_ordered list")
        return 0
    dq_statistics = stats_gen(spark, df_dq_master, val_res, ruleID,rule_exe_ts,batchDate)
    return dq_statistics

#column to match set
def columns_to_match_set(spark,input_df,col_names,ruleID,df_dq_master,rule_exe_ts,batchDate,logger):
    """[summary]:
    [Check whether set of columns provided by user matches with column unordered]
    @Args:
        input_df - spark dataframe
        col_names - column name
    @returns: a boolean
    """
    try:
        col_list = input_df.columns
        order_list = col_names.split(',')
        flag=0
        if set(order_list).issubset(set(col_list)):
            flag = 1
        if flag == 1:
            val_res = "column match the set"
        else:
            val_res = "column does not match set"
    except:
        logger.error("Error while validating column_to_match_ordered list")
        return 0
    dq_statistics = stats_gen(spark, df_dq_master, val_res, ruleID,rule_exe_ts,batchDate)
    return dq_statistics

#has datatype
def has_datatype(spark,input_df,col_name,rule_val,ruleID,df_dq_master,rule_exe_ts,batchDate,logger):
    """[summary]:
    [checks whether the column has the given datatype]
    @Args:
        input_df - spark dataframe
        col_name - column name to check
        rule_val - datatype to check
    @returns: a boolean
    """
    try:
        if col_name in (name for name in input_df.columns):
            get_dtype = [dtype for name, dtype in input_df.dtypes if name == col_name][0]
            if get_dtype == rule_val:
                val_res = "Datatype matches with column datatype"
            else:
                val_res = "Datatype does not match with column datatype"
        else:
            logger.error("Enter valid column name")
            return 0
    except:
        logger.error("Error while validating column_to_exist")
        return 0
    dq_statistics = stats_gen(spark, df_dq_master, val_res, ruleID,rule_exe_ts,batchDate)
    return dq_statistics



def stats_gen(spark,df_dq_master,stats,ruleID,rule_exe_ts,batchDate):
        """
        @description: Generates the dq statistics table 
        @params: df_dq_master,stats,ruleID,rule_exe_ts,batchDate
        @returns: dq_statistics -> a dataframe  
        """
        empty_rdd = spark.sparkContext.emptyRDD()
        dq_file_stats_schema = StructType([StructField("RULE_ID", StringType()), StructField("STATS_DESC", StringType())])
        dq_file_stats = spark.createDataFrame(empty_rdd, dq_file_stats_schema)
        dq_file_stats = dq_file_stats.union(spark.createDataFrame([(ruleID, stats)], dq_file_stats_schema))
        dq_stats= dq_file_stats
        dq_stats2 = dq_stats.withColumn("TOTAL_ROW_CNT", lit("0")).withColumn("FAILED_ROW_COUNT", lit("0")).withColumn("RULE_FAIL_PC", lit("0")).withColumn("EXEC_DATE",lit(rule_exe_ts)).withColumn("BATCH_DATE", lit(batchDate))
        dq_statistics = dq_stats2.join(df_dq_master.select(['RULE_ID','RULE_TYPE','RULE_DIMENSION','FILE_OR_TABLE_NAME', 'COL_NAME']),'RULE_ID','inner')\
        .select( "RULE_ID","RULE_TYPE","RULE_DIMENSION","FILE_OR_TABLE_NAME","COL_NAME","BATCH_DATE","TOTAL_ROW_CNT","FAILED_ROW_COUNT","RULE_FAIL_PC","EXEC_DATE","STATS_DESC")
        return dq_statistics  
def hasforeignkey(spark,envConfig,hash_table,rul_col,rule_val,rule_id,lookup_path,ref_path_type,logger):
    """
    Args:
        spark ([pyspark.sql.session.SparkSession]): [Instance of spark session]
        hash_table (pyspark.sql.dataframe.DataFrame): [Input dataframe]
        rul_col ([str]): [Column name to test for]
        rule_val ([str]): [contains secondary table column name and threshold_score(user input)]
        rule_id ([str]): [Passed automatically as primary key]
        lookup_path (pyspark.sql.dataframe.DataFrame): [Secondary table]
        ref_path_type([str]): [Format of dataframe]
        logger ([module]): [Instance of logger class]
    Returns:
        [pyspark.sql.dataframe.DataFrame]: [Output dataframe with ERR_CD column added]
        [int]: [Number of failed records]
    """
    try:
        percentage=0
        default_score=99
        #lookup_path=str(envConfig['azure']['raw-base-path'])+lookup_path
        rule_val = json.loads(rule_val)   
        hash_value=hash_table.select(collect_set(rul_col).alias("data")).collect()
        hash_df=hash_value[0]['data']
        ref_col_name = rule_val['column']
        threshold_score = rule_val['threshold_score']
        secondary_df= spark.read.option("header", True).format(ref_path_type).load(lookup_path)
        secondary_df=secondary_df.withColumn(ref_col_name, col(ref_col_name).cast(IntegerType()))
        ref_data=secondary_df.select(collect_set(ref_col_name).alias("data")).collect()
        reference_df=ref_data[0]['data']
        df_diff=[int(df_diff) for df_diff in np.setdiff1d(hash_df,reference_df)]
        percentage = len(set(hash_df).intersection(set(reference_df)))\
        / len(set(reference_df)) * 100
        threshold_score = threshold_score if threshold_score > 0 else default_score
        if percentage >= threshold_score:
            dq_table = hash_table.withColumn('ERR_CD', when(col(rul_col).isin(df_diff), lit(rule_id)).otherwise(lit("")))
            validated_res_count=dq_table.select().where((dq_table.ERR_CD!='')).count()  
        else:
            dq_table = hash_table.withColumn('ERR_CD', lit(rule_id))
            validated_res_count=dq_table.select().where((dq_table.ERR_CD!='')).count()
        return dq_table,validated_res_count
    except:
        logger.debug("Failed to find foreign key")
        return None, 0


    
#Value_pairs_to_be_in_set
def data_quality_value_pairs_to_be_in_set(hash_table, rule_col, ref_df, rule_val, rule_id, logger):
    """[Value pairs of a given no. of columns present in hash_table or not ]
        Args:
        hash_table (dataframe): [Dataframe in which value pairs to be checked]
        ruleCol (list): [List of columns which needs to be checked from hashtable]
        ref_input_path (path): [path of the 2nd dataframe from which particular columns to be checked from hashtable]
        ruleID (integer): [ruleID of dqMaster table]
        logger (logs): [logs]

        Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    try:
        rule_colms_lst = rule_col.split(',')
        rule_val_lst = rule_val.split(',')
        vdf = ref_df.withColumn("set_columns", array(rule_val_lst))
        join_df = hash_table.withColumn("input_columns", array(rule_colms_lst))
        final_df = join_df.join(vdf[['set_columns']], join_df['input_columns'] == vdf['set_columns'], how = "left") \
                    .withColumn("ERR_CD", when(col('set_columns').isNull(), lit(rule_id)).otherwise(lit("")))
        final_df = final_df.select(*hash_table.columns, final_df['ERR_CD'])
        return final_df, final_df.count()

    except:
        logger.info("Value pairs check Failed")
        return None, -1

#value_pairs_to_be_equal
"""Function to check whether two columns have same value or not"""
def data_quality_value_pairs_to_be_equal(hash_table, rule_col, rule_id, rule_val, logger):
    """[Two columns of a dataframe has same value or not
            eg: student_id	class	total_fees	fees_paid
                1	6th	800	800
                2	8th	700	700
                3	2th	1000 600
        ]

        hash_table (dataframe): [Dataframe in which value pairs to be checked]
        ruleCol (list): [List of columns which needs to be checked from hashtable]
        ruleID (integer): [ruleID of dqMaster table]
        rule_col (list): [List of columns which needs to be checked from hashtable]
		rule_val(json): [rule_val contains the boolean value of data_type_enforcement_flag]
        rule_id (integer): [ruleID of dqMaster table to be used as error code]
        logger (logs): [logs]

        Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    try:
        rule_val = json.loads(rule_val)
        data_type_enforce_flag = rule_val["data_type_enforcement_flag"]
        rule_colms_lst	= rule_col.split(',')
        col_1 = rule_colms_lst[0]
        col_2 = rule_colms_lst[1]
        if data_type_enforce_flag == True:
            if dict(hash_table.dtypes)[col_1] == dict(hash_table.dtypes)[col_2]:
                final_df = hash_table.withColumn("ERR_CD", when(hash_table[col_1] == hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
            else:
                logger.info("Data Type mismatched")
        else:
            if (dict(hash_table.dtypes)[col_1] == 'date') | (dict(hash_table.dtypes)[col_2] == 'date'):
                if dict(hash_table.dtypes)[col_1] == 'date':
                    hash_table = hash_table.withColumn(col_2, to_date(hash_table[col_2], 'dd-MM-yyy'))
                else:
                    hash_table = hash_table.withColumn(col_1, to_date(hash_table[col_1], 'dd-MM-yyy'))
                final_df = hash_table.withColumn("ERR_CD", when(hash_table[col_1] == hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
            else:
                final_df = hash_table.withColumn("ERR_CD", when(hash_table[col_1] == hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
    except:
        logger.info("Value pairs check Failed")
        return None, -1

#value_pairs_A_to_be_greater_than_B
"""Function to check whether value of column A greater than B or not"""
def data_quality_pair_values_a_to_be_greater_than_b(hash_table, rule_col, rule_id, rule_val, logger):
    """[value of column A greater than B or not
            eg: Emp_id	int_1	int_2
                1	800	800
                2	700	700
                3	1000 600
        ]

    Args:
        hash_table (dataframe): [Dataframe in which value pairs to be checked]
        rule_col (list): [List of columns which needs to be checked from hashtable]
        rule_val(json): [rule_val contains the boolean value of data_type_enforcement_flag]
        rule_id (integer): [ruleID of dqMaster table to be used as error code]
        logger (logs): [logs]

    Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    try:
        rule_val = json.loads(rule_val)
        data_type_enforce_flag = rule_val["data_type_enforcement_flag"]
        date_type = rule_val["date_type"]
        rule_colms_lst = rule_col.split(',')
        col_1 = rule_colms_lst[0]
        col_2 = rule_colms_lst[1]
        if data_type_enforce_flag == True:
            if dict(hash_table.dtypes)[col_1] == dict(hash_table.dtypes)[col_2]:
                logger.info("Data Type matched")
                try:
                    if date_type == True:
                        if (dict(hash_table.dtypes)[col_1] != 'date') & (dict(hash_table.dtypes)[col_2] != 'date'):
                            hash_table = hash_table.withColumn(col_1, to_date(hash_table[col_1], 'dd-MM-yyy')).withColumn(
								col_2, to_date(hash_table[col_2], 'dd-MM-yyy'))
                except:
                    logger.info("Data Type under data_type_enforcement can't changed")
                final_df = hash_table.withColumn('ERR_CD', when(hash_table[col_1] > hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
            else:
                logger.info("Data Type mismatched")
        else:
            if date_type == True:
                if (dict(hash_table.dtypes)[col_1] != 'date') & (dict(hash_table.dtypes)[col_2] != 'date'):
                    hash_table = hash_table.withColumn(col_1, to_date(hash_table[col_1], 'dd-MM-yyy')).withColumn(
						col_2, to_date(hash_table[col_2], 'dd-MM-yyy'))
                elif (dict(hash_table.dtypes)[col_1] == 'date') | (dict(hash_table.dtypes)[col_2] == 'date'):
                    if dict(hash_table.dtypes)[col_1] == 'date':
                        hash_table = hash_table.withColumn(col_2, to_date(hash_table[col_2], 'dd-MM-yyy'))
                    else:
                        hash_table = hash_table.withColumn(col_1, to_date(hash_table[col_1], 'dd-MM-yyy'))
                final_df = hash_table.withColumn('ERR_CD', when(hash_table[col_1] > hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
            else:
                final_df = hash_table.withColumn('ERR_CD', when(hash_table[col_1] > hash_table[col_2], lit("")).otherwise(lit(rule_id)))
                return final_df, final_df.count()
    except:
        logger.info("Value pairs check Failed")
        return None, -1

#hasNumRowsGreaterThan
def data_quality_has_num_rows_greater_than(spark, hash_table, rule_val, rule_id, logger):
    """[Funtion to check whether total number of rows of dataframe is greater than particular number or not]

    Args:
        spark ([type]): [spark functionalities]
        hash_table ([dataframe]): [Dataframe in which total number of rows to be checked]
        rule_val ([string]): [Number which to be checked]
        rule_id ([integer]): [ruleID of dqMaster table to be used as error code]
        logger ([logs]): [logs]

    Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    try:
        if hash_table.count() > int(rule_val):
            final_hash_table = spark.createDataFrame([], hash_table.schema)
        else:
            final_hash_table = hash_table.withColumn("ERR_CD", lit(rule_id))
        return final_hash_table, final_hash_table.count()
    except:
        logger.error("Error while validating hasNumRowsGreaterThan")
        return None,-1


#hasNumRowsLessThan
def data_quality_has_num_rows_less_than(spark, hash_table, rule_val, rule_id, logger):
    """[Funtion to check whether total number of rows of dataframe is less than particular number or not]

    Args:
        spark ([type]): [spark functionalities]
        hash_table ([dataframe]): [Dataframe in which total number of rows to be checked]
        rule_val ([string]): [Number which to be checked]
        rule_id ([integer]): [ruleID of dqMaster table to be used as error code]
        logger ([logs]): [logs]

    Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    try:
        if hash_table.count() < int(rule_val):
            final_hash_table = spark.createDataFrame([], hash_table.schema)
        else:
            final_hash_table = hash_table.withColumn("ERR_CD", lit(rule_id))
        return final_hash_table, final_hash_table.count()
    except:
        logger.error("Error while validating hasNumRowsLessThan")
        return None,-1

#hasFunctionalDependency
def data_quality_has_functional_dependency(hash_table, rule_col, rule_val, rule_id, logger):
    """[Function to check whether given columns of a dataframe is functionally dependent on other columns of the same dataframe]

    Args:
        spark (type): [spark functionalities]
        hash_table (dataframe): [Dataframe in which columns to be checked whether functionally dependent or not]
        rule_col (list): [List of determinant columns which needs to be checked from hashtable]
        rule_val ([type]): [List of dependent columns which needs to be checked from hashtable]
        rule_id (integer): [ruleID of dqMaster table to be used as error code]
        logger (logs): [logs]

    Returns:
        [dataframe]: [dataframe with error code]
        [interger]: [total no. of columns]
    """
    determinant_col = rule_col.split(',')
    dependent_col = rule_val.split(',')
    try:
        final_df = hash_table.withColumn('determinantCols', concat(*determinant_col)).withColumn('dependentCols', concat(*dependent_col))
        if (final_df[['determinantCols']].distinct().count()) == (final_df[['determinantCols']].count()):
            hash_table = hash_table.withColumn('ERR_CD', lit(''))
            return hash_table, hash_table.count()
        else:
            duplicate_df = final_df.groupBy("determinantCols").count().filter("count > 1").withColumnRenamed('determinantCols','duplicate')
            final_df = final_df.join(duplicate_df[['duplicate']],
                                     final_df['determinantCols']==duplicate_df['duplicate'], how='left').withColumn(
										 "ERR_CD", when(col('duplicate').isNull(), lit('')).otherwise(lit(rule_id)))
            final_df = final_df.select(*hash_table.columns, final_df['ERR_CD'])
            logger.info(final_df.count())
            return final_df, final_df.count()
    except:
        logger.info("has_functional_dependency failed")
        return None, -1

def has_primary_key(spark, hash_table, rule_col, rule_id, logger):
	"""[Primary Key Check for given set of columns(non-null and unique)]

	Args:
	hash_table ([dataframe]): [Table with values]
	rule_col ([string]): [Column names separated with commas]
	rule_id ([string]): [rule_id to append in case of condition failure]
	logger ([type]): [description]

	Returns:
	[dataframe]: [Rows failed]
	[integer]: [Number of rows failed]
	"""
	try:
		rule_col=rule_col.split(",")
		dq_table = spark.createDataFrame([],hash_table.schema)
		newdf =hash_table[rule_col].na.drop(how='any')
		distinct_count = newdf.select(rule_col).distinct().count()
		if distinct_count != hash_table.count():
			return hash_table.withColumn("ERR_CD",lit(rule_id)),hash_table.count()
		return dq_table,0
	except:
		logger.error("Invalid Column names")
