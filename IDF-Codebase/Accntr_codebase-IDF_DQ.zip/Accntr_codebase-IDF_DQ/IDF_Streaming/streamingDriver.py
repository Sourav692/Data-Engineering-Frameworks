import json
import sys
import traceback
import os
import datetime
from collections import OrderedDict
import time
import json
from shutil import copyfile
import logging
from pyspark.sql.functions import *
from pyspark.sql.types import *

from streaming.utilsShared import UtilsShared
from streaming.customException import configNotFoundError,uncatchException
from streaming.gen_audit_entry import *
from streaming.streamingMetadataManager import streamingMetadataManager


def process(sourceName, tableName, batchDate, loadDate, load_userid, prcs_runid, dbutils):


    start_time = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    envConfig = UtilsShared.getEnvConf(0, dbutils)

    envConfig['sourceName'] = sourceName
    envConfig['tableName'] = tableName
    envConfig["batchDate"]= batchDate
    envConfig['loadDate'] = loadDate
    envConfig['load_userid'] = load_userid
    envConfig['prcs_runid'] =  prcs_runid

    metadata_obj = streamingMetadataManager()

    local_log_file_name = envConfig["local_log_path"] + envConfig['sourceName']  + "_" + str(envConfig["tableName"]).replace("/","_") + "_" +str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d_%H%M%S')) + '.log'
    envConfig['local_log_file_name'] = local_log_file_name     
    log_file_name = local_log_file_name.replace(envConfig["local_log_path"], envConfig["log_path"] + "/"  + envConfig['sourceName']+ "/"  + str(envConfig["tableName"]) + "/"+ str(datetime.datetime.strftime(datetime.datetime.now(), '%Y-%m-%d')) + "/")
    envConfig['log_file_name'] = log_file_name
    log_file_folder = "/".join(log_file_name.split("/")[:-1])
    os.makedirs(envConfig["local_log_path"], exist_ok=True)
    logger = UtilsShared.getFormattedLogger("smart_ingestion_driver", local_log_file_name)
    logger.info('Performing Stream Ingestion Activity')

    exit_doc = {
      "JSON": "NA",
      "PRCS_NAME": "NA",
      "ID":"NA",
      "RUNID":"NA",
      "NAME":"NA",
      "STREAM_TIMESTAMP":"",
      "BATCHID":"NA",
      "FOREACHBATCH":"NA",
      "STAGE":"NA",
      "STATUS":"NA",
      "STATUS_DESC":"NA",      
      "JOB_START_TIME":start_time,
      "JOB_END_TIME":"",
      "TRIGGER_TYPE":"NA",
      "LOG_PATH":log_file_name,
      "SOURCE_TYPE":"NA",
      "SOURCE_NAME":"NA",
      "SOURCE_DESCRIPTION":"NA",
      "START_OFFSET":"NA",
      "END_OFFSET":"NA",
      "SINK_DESCRIPTION":"NA",
      "CHECKPOINT_PATH":"NA",
      "RAW_PATH":"NA",
      "RAW_ROW_COUNT":"0",
      "RAW_COL_COUNT":"0",
      "CURATED_PATH":"NA",
      "CURATED_ROW_COUNT":"0",
      "CURATED_COL_COUNT":"0",
      "ENRICH_PATH":"NA",
      "ENRICH_ROW_COUNT":"0",
      "ENRICH_COL_COUNT":"0"
	}



    try:
        if envConfig["loadDate"].strip() == "" :
            envConfig["loadDate"] = str(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
            logger.info("Since load date is not provided, considering load datetime as current/Execution timestamp")
        else:
            loadDate_object = datetime.datetime.strptime(envConfig["loadDate"], "%Y%m%d")
            if date.today() == loadDate_object.date():
                envConfig["loadDate"] = str(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))
                logger.info("Since load date & execution date is same , load date/time considered as : " + envConfig["loadDate"])
            else:
                envConfig["loadDate"] = loadDate_object.strftime("%Y%m%d%H%M%S")
                logger.info("Since load date & execution date is different , load date/time used as provided : " + envConfig["loadDate"]) 

        suffixConf = "streaming"
        jsonFileName = str(envConfig["sourceName"])+ "_" + str(envConfig["tableName"]) + "_" + suffixConf + ".json"
        dataProcessSourceConfig = envConfig["data_config_stream_path"] + jsonFileName
        logger.info(dataProcessSourceConfig)
        exit_doc['JSON'] = jsonFileName
        dataprocess_config_file=None
        if os.path.isfile(dataProcessSourceConfig):
            dataprocess_config_file = open(str(dataProcessSourceConfig),'r').read()
            config = json.loads(dataprocess_config_file)
            logger.info('Reading config from: ' + str(dataProcessSourceConfig))

        else:
            logger.info('Source Config is not available '+ str(dataProcessSourceConfig) + ', Please place the config file in order to execute the job')
            try:
                raise configNotFoundError(dataProcessSourceConfig)        
            except configNotFoundError as cfe:
                audit_doc = OrderedDict()
                audit_rec=DriverEntryStreaming('streaming',envConfig['sourceName'],envConfig['prcs_runid'],'Failed',cfe,start_time,exit_doc['JSON'],log_file_name)
                audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,cfe)
                metadata_obj.insert_StreamingauditRecord(dbutils,envConfig,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0

            os.makedirs(log_file_folder, exist_ok=True)
            copyfile(local_log_file_name, log_file_name)
            dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc})

        conf = 0

        # Adding Common data conf process to envConfig
        if 'S0-common-conf' in config:  # config.has_key("M0-common-conf"):
            envConfig.update(config['S0-common-conf'])
            config.pop('S0-common-conf')
        TABLE_DF = 0
        for key in sorted(config.keys()):
            logger.info('Processing ' + key)
            val = envConfig.copy()
            val.update(config[key])
            typeValue = val['type']

            if 'NONE' != typeValue and 'D999-alert-monitor-process'!= key:
                logger.debug(typeValue)
                moduleName = 'streaming.' + typeValue
                module = __import__(moduleName)
                file = getattr(module, typeValue)
                classVar = getattr(file, 'MultipleStreamsDataProcess')
                function = getattr(classVar, 'process')
                TABLE_DF = function(conf,val, TABLE_DF,dbutils,exit_doc)
                if TABLE_DF == 0:
                    break

        try:
            logger.info("Exit dict: " + str({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']}))
            os.makedirs(log_file_folder, exist_ok=True)
            copyfile(local_log_file_name, log_file_name)
        except:
            pass

    except:
        try:
            err_desc = str(traceback.format_exc())
            raise uncatchException(err_desc)
        except uncatchException as cfe:
            audit_doc = OrderedDict()
            audit_rec=DriverEntryStreaming('streaming',envConfig['sourceName'],envConfig['prcs_runid'],'Failed',cfe,start_time,exit_doc['JSON'],log_file_name)
            audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,cfe)
            metadata_obj.insert_StreamingauditRecord(dbutils,envConfig,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
            logger.info('ERROR in  Processing file '+ str(envConfig['sourceName']) + '.'+ str(envConfig['tableName']) + '  for date '+ str(envConfig['batchDate']) + str(traceback.format_exc()))
            logger.info('Streaming - Failure Audit Process Completed')
            os.makedirs(log_file_folder, exist_ok=True)
            copyfile(local_log_file_name, log_file_name)
	     



