__author__ = 'vn50lsg'
import traceback
import sys
import json
import logging
import re
import datetime
import hashlib
import pyspark
from pyspark.sql import SparkSession
from metadataManager import metadataManager

from collections import OrderedDict
import time
import os

# Custom Libs
#from metadataManagerDV import metadataManagerDV
import utilsTrans
import utilsIO

millis = int(round(time.time() * 1000))
start_time =str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
#M1
def process(obj,hashDF):

	log_filename = obj['log_path'] + obj['pipelineName'] +"_"+ obj['sourceName'] + "_"+str(datetime.datetime.strftime(datetime.datetime.now(),'%Y%m%d')) + '.log'
	logger = logging.getLogger("data-profile-rules-business-process")
	logger.setLevel(logging.DEBUG)
	file_handler = logging.FileHandler(log_filename)
	file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	file_handler.setFormatter(file_format)
	logger.addHandler(file_handler)
	logging.getLogger("py4j").setLevel(logging.ERROR)

	conf = pyspark.SparkConf()
	spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()

	metadataObject = metadataManager()

	try:
		for source in obj["sourceList"]:
			sourceDict = obj[source]
			if "type" in sourceDict:
				sourceType = sourceDict["type"]
			else:
				sourceType = "curated-zone"


			# Read from the source - curated zone or ADV
			if sourceType == "curated-zone":
				if "read-type" in sourceDict:
					readType = str(sourceDict["read-type"])
				else:
					readType = "batch-date-single"
				logger.debug("Processing readType as  " + readType)

				if readType == "batch-date-single":
					#change path once path is changed in raw zone
					if "path" in sourceDict:
						if "max_batchdate_flag" in sourceDict and sourceDict["max_batchdate_flag"]=="True" :
							batch_date=utilsIO.get_max_batchdate(str(obj['azure']["clean-base-path"])  + str(sourceDict["path"]))
						else:
							batch_date=str(datetime.datetime.strptime(obj["batchDate"], '%Y%m%d'))[:10]
						inputPath = str(obj['azure']["clean-base-path"])  + str(sourceDict["path"]) + batch_date+ "/"+ str(sourceDict["fileName"])
					else:
						inputPath = str(obj['azure']["clean-base-path"]) +"/" + str(obj['curated-location']) +"/"+obj["fileName"]

				target_basepath="/dbfs/mnt/fcp/test_fcp/data_profiling/"+str(sourceDict["path"]).replace("/","")+"_"+batch_date+".csv"
				#Reading Curated Data
				withReplacement=False
				sampleDF = spark.read.parquet(inputPath).sample(withReplacement,sourceDict["fraction"],sourceDict["seed"])
				col_dq_rules=[]
				if "DQ_RULES" in sourceDict:
					objDict=sourceDict["DQ_RULES"].copy()

					#Apply DQ Rules and generate a report
					col_dq_rules=utilsTrans.data_quality_rules(sampleDF,objDict,sourceDict["fraction"])

					utilsTrans.insert_profiling_rec(col_dq_rules,target_basepath)
					if len(col_dq_rules)==len(objDict.keys()):
						staus="Succeeded"
					else:
						staus="Failed"

					#Generating Audit Entry with status
					audit_doc=OrderedDict()
					audit_doc["FILE_NAME"] = obj["fileName"]
					if "prcs-name" in obj:
						audit_doc['PRCS_NAME'] = obj["prcs-name"]
					else:
						audit_doc['PRCS_NAME'] = "data_profiling"

					audit_doc["PIPELINE_NAME"] = obj["pipelineName"]
					audit_doc["PRCS_EXECUTION_ID"] = None
					audit_doc["TRG_NAME"] = obj["triggerName"]
					audit_doc["STATUS"] = staus
					audit_doc["STATUS_DESC"] = "Completed Successfully!" if staus=="Succeeded" else "Report is not generated for all DQ Rules"
					audit_doc["JOB_START_TIME"] = start_time
					audit_doc["SOURCE_PATH"] = str(inputPath)
					audit_doc["SOURCE_ROW_COUNT"] = ""
					audit_doc["SOURCE_COL_COUNT"] = ""
					audit_doc["SOURCE_AMOUNT"] = ""
					audit_doc["SOURCE_FILE_SIZE"] = ""
					audit_doc["DEST_PATH"] = ""
					audit_doc["DEST_ROW_COUNT"] = "NA"
					audit_doc["DEST_COL_COUNT"] = "NA"
					audit_doc["DEST_AMOUNT"] = ""
					audit_doc["DEST_FILE_SIZE"] = ""
					audit_doc["REJECTED_ROW_COUNT"] = ""
					audit_doc["REJECTED_FILE_NAME"] = ""
					audit_doc["LOG_PATH"] = log_filename
					audit_doc["JOB_END_TIME"]=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
					logger.debug(str(audit_doc))

					#inserted Audit entry in process execution file
					metadataObject.insert_auditRecord(audit_doc)
					logger.debug("Inserted Audit Entry - Job Failure")

	except:
		logger.debug("Inserted Audit Entry - Job Failure")
		traceback.print_exc()
		raise ValueError("ERROR in "+ __name__+ " for type "+ str(obj['type']) + " >>" + str(traceback.format_exc()))
	finally:
		logger.info("End of "+ __name__+ " process...")
			#sqlContext.clearCache()
			#context.stop()
		#finally
###################################################################################################
