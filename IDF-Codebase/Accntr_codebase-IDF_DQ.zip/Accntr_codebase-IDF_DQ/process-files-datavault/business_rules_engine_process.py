#!/usr/bin/python
# -*- coding: utf-8 -*-
import traceback
import sys
import json
import logging
import re
import hashlib
import time
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType
from pyspark.sql.functions import udf
from pyspark.sql import SparkSession
from datetime import datetime
from pyspark.sql.functions import lit, col, trim
from metadataManager import metadataManager
import utilsIO
from collections import OrderedDict
import datetime
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

from metadataManager import metadataManager
import utilsShared
from pyspark.sql.functions import when, isnull

millis = int(round(time.time() * 1000))
start_time =str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

###################################################################################################
# M1

def process(obj, HASH_TABLE, dbutils):

    # setting up the logs
    log_filename = obj['log_path'] + obj['pipelineName'] +"_"+ obj['sourceName'] + "_"+str(datetime.datetime.strftime(datetime.datetime.now(),'%Y%m%d')) + '.log'
    logger = logging.getLogger('business-rules-engine-process')
    logger.setLevel(logging.DEBUG)
    file_handler = logging.FileHandler(log_filename)
    file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_format)
    logger.addHandler(file_handler)
    logging.getLogger('py4j').setLevel(logging.ERROR)

    conf = pyspark.SparkConf()
    # Azure conf setting for ADLS
    conf.set('fs.azure.account.key.' + str(obj['azure']['storage_account_name']) + '.dfs.core.windows.net',str(obj['azure']['storage_account_access_key']))
    spark = SparkSession.builder.appName(obj['use-case' ]).config(conf=conf).getOrCreate()

    metadataObject = metadataManager()

    #  Function to append error code
    def error_code_append(curr_str, error_code):
        if len(curr_str) == 0:
            curr_str = error_code
        elif error_code in curr_str:
            curr_str = error_code
        elif len(error_code) > 0:
            curr_str = curr_str + '|' + error_code
        return curr_str

    #  UDF from error code append function
    error_code_append_UDF = udf(error_code_append, StringType())

    try:
        # Default Error Code column
        logger.info('Inside try of business-rules-engine-process')
        logger.info('obj data' + str(obj))

        # Generate the audit record of Success
        audit_doc = OrderedDict()
        audit_doc['FILE_NAME'] = obj['fileName']
        if 'prcs-name' in obj:
            audit_doc['PRCS_NAME'] = obj['prcs-name']
        else:
            audit_doc['PRCS_NAME'] = 'curated_to_enriched'
        audit_doc['PRCS_EXECUTION_ID'] = HASH_TABLE.select("BATCH_ID").distinct().first()[0]
        audit_doc['PIPELINE_NAME'] = obj['pipelineName']
        audit_doc['TRIG_NAME'] = obj['triggerName']
        audit_doc['STATUS'] = None
        audit_doc['STATUS_DESC'] = None
        audit_doc['JOB_START_TIME'] = start_time
        audit_doc['JOB_END_TIME'] = None
        inputRowCount = HASH_TABLE.count()
        audit_doc['SOURCE_PATH'] = ''
        audit_doc['SOURCE_ROW_COUNT'] = str(inputRowCount)
        audit_doc['SOURCE_COL_COUNT'] = str(len(HASH_TABLE.columns))
        audit_doc['SOURCE_AMOUNT'] = 0
        audit_doc['SOURCE_FILE_SIZE'] = 0

        HASH_TABLE = HASH_TABLE.withColumn('ERR_CD', lit(''))

        if 'business-rules' not in obj:
            logger.debug("NO business rules provided in config.So no business rules will be applied")
            return HASH_TABLE
        # Loop to run error codes
        if 'business-rules' in obj:
            for ruleID in sorted(obj['business-rules'].keys()):
                logger.debug('Applying Business rule ID : '+ str(ruleID))
                ruleCol = str(obj['business-rules'][ruleID]['rule-col'])
                ruleType = str(obj['business-rules'][ruleID]['rule-type'])
                logger.debug('Applying Business rule type ' + ruleType+ ' on Column ' + ruleCol)

                if ruleType == 'isgreater':
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',
                            when(col('`' + ruleCol + '`') >= col('`'+ obj['business-rules'][ruleID]['rule-col2' ] + '`'), error_code_append_UDF(col('ERR_CD'), lit(ruleID))).otherwise(col('ERR_CD')))

                if ruleType == 'isnull':
                    logger.debug('applying isnull business rule')
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',
                            when((trim(col(str(ruleCol))) == lit('')) | isnull(col('`' + str(ruleCol) + '`')),error_code_append_UDF(col('ERR_CD'),lit(ruleID))).otherwise(col('ERR_CD')))

                if ruleType == 'isnull-conditional':
                    logger.debug('applying isnullDerived business rule')
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',
                            when((trim(col('`' + obj['business-rules'][ruleID]['rule-col2'] + '`')) == lit('1')) & ((trim(col(str(ruleCol))) == lit('')) | isnull(col('`' + str(ruleCol) + '`'))),error_code_append_UDF(col('ERR_CD'),
                            lit(ruleID))).otherwise(col('ERR_CD')))

                if ruleType == 'isdate':
                    logger.debug('applying isdate business rule')
                    newColName = 'tempCol_' + ruleCol
                    HASH_TABLE = HASH_TABLE.withColumn(newColName,col(ruleCol).cast('date'))
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',when(isnull(col(str(newColName))),error_code_append_UDF(col('ERR_CD'),lit(ruleID))).otherwise(col('ERR_CD')))

                if ruleType == 'isnumeric':
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',
                            when(col('`' + str(ruleCol) + '`').rlike('^[-0-9\.]*$'), col('ERR_CD')).otherwise(error_code_append_UDF(col('ERR_CD'), lit(str(ruleID)))))

                    # df1 = df1.withColumn("test", col("Survived").rlike('^[0-9\.]*$'))

                if ruleType == 'isequal':
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',
                            when(trim(col('`' + str(ruleCol) + '`'))!= str(obj['business-rules'][ruleID]['colValue']),error_code_append_UDF(col('ERR_CD'),
                            lit(str(ruleID)))).otherwise(col('ERR_CD')))

                if ruleType == 'inrange':
                    refDict = obj['business-rules'][ruleID]['list-look-up']
                    refList = utilsIO.ref_look_up_list(spark, obj,refDict)
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',when(col(ruleCol).isin(refList),col('ERR_CD')).otherwise(error_code_append_UDF(col('ERR_CD'), lit(str(ruleID)))))

                    # REF_TABLE = utilsDV.ref_look_up_list(spark,obj,refDict)
                    # HASH_TABLE = HASH_TABLE.withColumn('ERROR_CODE', when(col(ruleCol).isin(REF_TABLE[str(refDict["return-look-up-col"])]),
                    # ............col("ERROR_CODE")).otherwise(error_code_append_UDF(col("ERROR_CODE"), lit(str(ruleID)))))........................................

                if ruleType == 'inlist':
                    refList = obj['business-rules'][ruleID]['list-value']
                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',when(col(ruleCol).isin(refList),col('ERR_CD')).otherwise(error_code_append_UDF(col('ERR_CD'), lit(str(ruleID)))))

                if ruleType == 'inrange-date':
                    if obj['business-rules'][ruleID] in obj('date_format'):
                        newColName = obj['business-rules'][ruleID]['newColName']
                        dateForamt = str(obj['business-rules'][ruleID]['date-format'])
                        HASH_TABLE = HASH_TABLE.withColumn(newColName,to_date(col(ruleCol), dateForamt))
                        ruleCol = newColName

                    HASH_TABLE = HASH_TABLE.withColumn('ERR_CD',when((col(ruleCol) >= obj['business-rules'][ruleID]['upper-limit']) | (col(ruleCol)<= obj['business-rules'][ruleID]['lower-limit']),
                            error_code_append_UDF(col('ERR_CD'),
                            lit(str(ruleID)))).otherwise(col('ERR_CD')))

        # Generate ERROR flag
        HASH_TABLE = HASH_TABLE.withColumn('ERR_FLG', when(col('ERR_CD') != '', lit(1)).otherwise(lit(0))).cache()
        HASH_TABLE = HASH_TABLE.withColumn('ERR_CD', when(col('ERR_CD') != '', col('ERR_CD')).otherwise(lit('0')))

        # Insert the success record in Audit Table, change audit information
        inputRowCount = HASH_TABLE.count()
        audit_doc['JOB_END_TIME'] = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        audit_doc['DEST_PATH'] = ''
        audit_doc['DEST_ROW_COUNT'] = str(inputRowCount)
        audit_doc['DEST_COL_COUNT'] = str(len(HASH_TABLE.columns))
        audit_doc['DEST_AMOUNT'] = ""
        audit_doc['DEST_FILE_SIZE'] = ""
        audit_doc['STATUS'] = 'Succeeded'
        audit_doc['STATUS_DESC'] = 'Completed Successfully!'
        audit_doc['REJECTED_ROW_COUNT'] = ""
        audit_doc['REJECTED_FILE_NAME'] = ""
        audit_doc['LOG_PATH'] = log_filename
        logger.info('final audit:' + str(audit_doc))
        #metadataObject.insert_auditRecord(audit_doc)

        return HASH_TABLE
    except:
        logger.error(str(traceback.print_exc()))

        # Insert the Failure record in Audit Table
        inputRowCount = HASH_TABLE.count()
        audit_doc['SOURCE_PATH'] = ''
        audit_doc['SOURCE_ROW_COUNT'] = str(inputRowCount)
        audit_doc['SOURCE_COL_COUNT'] = str(len(HASH_TABLE.columns))
        audit_doc['SOURCE_AMOUNT'] = ''
        audit_doc['SOURCE_FILE_SIZE'] = ''
        audit_doc['JOB_END_TIME'] = str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        audit_doc['DEST_PATH'] = ''
        audit_doc['DEST_ROW_COUNT'] = ''
        audit_doc['DEST_COL_COUNT'] = ''
        audit_doc['DEST_FILE_SIZE'] = ''
        audit_doc['STATUS'] = 'Failure'
        audit_doc['STATUS_DESC'] = str(traceback.format_exc())
        audit_doc['REJECTED_ROW_COUNT'] = ''
        audit_doc['REJECTED_FILE_NAME'] = ''
        audit_doc['LOG_PATH'] = log_filename
        #metadataObject.insert_auditRecord(audit_doc)
        logger.debug('Inserted Audit Entry - Job Failure ')
        traceback.print_exc()
        raise ValueError('ERROR in ' + __name__ + ' for type '+ str(obj['type']) + ' >>' + str(traceback.format_exc()))
    finally:
        logger.info('End of ' + __name__ + ' process...')

        # sqlContext.clearCache()
        # context.stop()
    # finally
###################################################################################################
