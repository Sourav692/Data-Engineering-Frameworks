import json
from datetime import datetime
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pandas as pd
import os
import sys
from delta.tables import *
import  pyspark.sql.functions as F

class streamingMetadataManager:

	def __init__(self):
		pass	


	def insert_StreamingauditRecord(self,dbutils,obj,spark,audit_doc):		
		audit_df = pd.DataFrame([audit_doc])
		df=spark.createDataFrame(audit_df)
		df = df.filter("SOURCE_NAME != 'NA'")
		if int(df.count()) > 0:
			timestamp_cols = ['JOB_START_TIME','JOB_END_TIME','STREAM_TIMESTAMP']
			for time_col in timestamp_cols:
				df = df.withColumn(time_col,F.col(time_col).cast(TimestampType()))

			integer_cols = ['RAW_ROW_COUNT','RAW_COL_COUNT','CURATED_ROW_COUNT','CURATED_COL_COUNT','ENRICH_ROW_COUNT','ENRICH_COL_COUNT']
			for cols in integer_cols:
				df = df.withColumn(cols,F.col(cols).cast(IntegerType()))

			df.show()
			deltaTable = DeltaTable.forName(spark, 'PRCS_EXECUTION')  
			spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 
			mergeColumns = ['JSON','SOURCE_NAME']
			query = ""
			for col in mergeColumns:
				query = query +" s."+ col + "=" +" t." + col + " and "
			#remove last "and"
			remove="and"
			reverse_remove=remove[::-1]
			query = query[::-1].replace(reverse_remove,"",1)[::-1]
			print("Audit merge: " + query)
			deltaTable.alias("t").merge(df.alias("s"), query).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

		



	def insert_auditRecord(self,dbutils,obj,spark,audit_doc):		
		audit_df = pd.DataFrame([audit_doc])
		df=spark.createDataFrame(audit_df)

		#Build Audit table path
		#dynamicauditPath = obj['azure']['clean-base-path'] + 'PRCS_EXECUTION'
		
		#Cast Datatypes of Audit record
		timestamp_cols = ['JOB_START_TIME','JOB_END_TIME','STREAM_TIMESTAMP']
		for time_col in timestamp_cols:
			df = df.withColumn(time_col,F.col(time_col).cast(TimestampType()))
		integer_cols = ['NUMINPUTROWS','INPUTROWSPERSECOND','PROCESSEDROWSPERSECOND','SINK_NUM_OF_OUTPUT_ROWS','SOURCE_INPUT_ROWS_PER_SECOND','SOURCE_NUM_INPUT_ROWS','END_OFFSET_1','END_OFFSET_0','START_OFFSET_1','START_OFFSET_0','TRIGGEREXECUTION','GETOFFSET','RAW_ROW_COUNT','RAW_COL_COUNT','CURATED_ROW_COUNT','CURATED_COL_COUNT','ENRICH_ROW_COUNT','ENRICH_COL_COUNT']
		for cols in integer_cols:
			df = df.withColumn(cols,F.col(cols).cast(IntegerType()))
		
		df.show()
		deltaTable = DeltaTable.forName(spark, 'PRCS_EXECUTION')  
		spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 
		mergeColumns = ['SOURCE_NAME']
		query = ""
		for col in mergeColumns:
			query = query +" s."+ col + "=" +" t." + col + " and "
			#remove last "and"
			remove="and"
			reverse_remove=remove[::-1]
			query = query[::-1].replace(reverse_remove,"",1)[::-1]
			print("Audit merge: " + query)
			deltaTable.alias("t").merge(df.alias("s"), query).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
		#else:
			#df.write.format("delta").option("mergeSchema", "true").mode("append").saveAsTable("PRCS_EXECUTION")
