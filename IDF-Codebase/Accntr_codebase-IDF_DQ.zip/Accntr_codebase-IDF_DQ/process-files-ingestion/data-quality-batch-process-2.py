import traceback
import sys, os
import logging
import hashlib
import json
import time
import pandas as pd
from pyspark.sql.functions import *
from pyspark.sql.types import DateType
from metadataManager import metadataManager
from collections import OrderedDict
import datetime
import Utils
from file_validation import *
from utils_file_validation import *
from  utilsDq import *
from customException import *
from gen_audit_entry import *

sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared

sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
import utilsIO

start_time = datetime.datetime.now()
dynamicInputPath = None



###################################################################################################






###################################################################################################


def process(spark, obj, hash_table, dbutils, exit_doc, pyspark=None):
  log_filename =  obj['local_log_file_name']
  batchDate_formatted=datetime.datetime.strptime(obj['batchDate'], '%Y%m%d')
  batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')
  emptyRDD = spark.sparkContext.emptyRDD()
  metadataObject = metadataManager()
  stage = obj['type']
  table_name = obj['dataset_name']
  rule_exe_ts = datetime.datetime.now()
  # job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
  logger = getFormattedLogger(stage, log_filename)
  logger.info("Started executing "+str(stage)+" module")
  # Data Quality Validation for Each DQ Rule for the selected Table
  skipped_dq_rules="SKIPPED VAILDATING THE BELOW DQ RULES: \n FILE_OR_TABLE_NAME || RULE_ID || RULE_TYPE "
  skipped_tables="SKIPPED VAILDATING THE TABLES: \n FILE_OR_TABLE_NAME : "
  flg=0
  fv=0
  eflg=0
  try:
    logger.info("Inside try of data-quality-delta-process")
    audit_doc = OrderedDict()
    try:
      if table_name:
          logger.debug("Performing data quality on table: " + table_name)
          df_dq_master = read_data_sql_table(spark, obj, table_name,logger)
      else:
          logger.error("Failed to get valid dq master table name or no data found in input dataframe")
          raise invalidInputParams ("Failed to get valid dq master table name or no data found in input dataframe")
    except Exception as iip:
      # audit_doc = OrderedDict()
      audit_rec=DriverEntry('data_quality_batch',batchDate_formatted,obj['sourceName'],obj['prcs_runid'],obj['pipelineName'],obj['triggerName'],'Failed',iip,start_time)
      audit_doc,exit_doc=gen_audit_dict(audit_doc,exit_doc,audit_rec,iip)
      metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
      exit_doc["EXIT_CODE"]=0
      dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
      return 0, exit_doc

    TablesInDqMaster=df_dq_master.select(col('FILE_OR_TABLE_NAME')).distinct().rdd.map(lambda x: x[0].lower()).collect()
    Input_tableNames=[]
    if (str(trim(obj['dataset_name'])) == '' or obj['dataset_name'] is None):
      logger.error("Invalid input table list, please provide valid comma seperated tables names")
      try:
          logger.info("Invalid input table list, please provide valid comma seperated tables names")
          raise invalidInputParams ("Invalid input table list, please provide valid comma seperated tables names for tableNames")
      except invalidInputParams as iip:
          # audit_doc = OrderedDict()
          audit_rec=DriverEntry('data_quality_batch',batchDate_formatted,obj['sourceName'],obj['prcs_runid'],obj['pipelineName'],obj['triggerName'],'Failed',iip,start_time)
          audit_doc,exit_doc=gen_audit_dict(audit_doc,exit_doc,audit_rec,iip)
          metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
          exit_doc["EXIT_CODE"]=0
          dbutils.notebook.exit({'AUDIT_RECORDS': exit_doc, 'EXIT_CODE': exit_doc['EXIT_CODE'], 'ERROR_CODE': exit_doc['ERROR_CODE']})
          return 0, exit_doc

    Input_tableNames = obj['dataset_name'].lower().split(',')
    tableList= list(set(Input_tableNames).intersection(TablesInDqMaster))
    batchDate = obj['batchDate']
    # recipient = obj['recipient']
    tablesNotInDqMaster=list(set(Input_tableNames)-set(TablesInDqMaster))
    if (len(tableList) > 0) :
      for tableName in tableList :
          df_path = df_dq_master.select('DATA_PATH_OR_TOPIC').where((col('FILE_OR_TABLE_NAME') == tableName ) & (col('IsActive') == '1'))
          df_format = df_dq_master.select('FORMAT').where((col('FILE_OR_TABLE_NAME') == tableName ) & (col('IsActive') == '1'))
          Count_path = df_path.distinct().count()
          Count_format = df_format.distinct().count()
          if (Count_path == 1) & (Count_format == 1):
            file_format = df_format.collect()[0][0]
            path = df_path.collect()[0][0]
            filePath = path
            try:
              hash_table = utilsIO.get_data_frame(spark,obj,logger,filePath,file_format)
              # logger.info('Count of records in dataset for DQ: {0}'.format(hash_table.count()))
              inputDF = hash_table
              logger.info(inputDF.display())
              logger.debug("get_dataframe ran")
            except:
              logger.error("Not able to read data from path --> "+filePath)
              return None, 0
          else:
            logger.error("Table does not have a distinct path")
          # metrics_table = None
          dqStatistics=None
          vldtd_hash_tbl_res=None
          counts_vldtn_df = None
          logger.info("Performing data quality on table: " + tableName)
        #   data_path_details = df_dq_master.where( lower(col('TABLE_NAME')) == tableName).where(lower(col('RULE_TYPE')) != 'count_validation')
        #   metrics_path_details = df_dq_master.where( lower(col('TABLE_NAME')) == tableName).where(lower(col('RULE_TYPE')) == 'count_validation')
          dqStats_schema = StructType([StructField("RULE_ID", StringType()), StructField("FAILED_ROW_COUNT", IntegerType())])
          dqStats0=spark.createDataFrame(emptyRDD, dqStats_schema)
          dq_ml_stats_schema = StructType([StructField("RULE_ID", StringType()), StructField("STATS_DESC", StringType())])
          dq_ml_stats = spark.createDataFrame(emptyRDD, dq_ml_stats_schema)
          dq_file_stats_schema = StructType([StructField("RULE_ID", StringType()),StructField("RULE_TYPE", StringType()),StructField("RULE_DIMENSION", StringType()),StructField("FILE_OR_TABLE_NAME", StringType()),StructField("COL_NAME", StringType()),StructField("BATCH_DATE", StringType()),StructField("TOTAL_ROW_CNT", IntegerType()),StructField("FAILED_ROW_COUNT", IntegerType()),StructField("RULE_FAIL_PC", FloatType()),StructField("EXEC_DATE", DateType()), StructField("STATS_DESC", StringType())])
          dq_file_stats = spark.createDataFrame(emptyRDD, dq_file_stats_schema) 
          dq_schema_validation=spark.createDataFrame(emptyRDD, dq_file_stats_schema) 

          if hash_table is not None:
            vldtd_hash_tbl_res = hash_table.select('*').limit(1).withColumn('ERR_CD', lit(""))
            hash_table_cnt = hash_table.count()
            df_dq_master2 = df_dq_master.filter((lower(col('FILE_OR_TABLE_NAME')) == tableName) & (col('IsActive') == '1'))
            dq_master = df_dq_master2.toPandas().transpose().to_dict()

            for ruleKey in dq_master:
                rule = dq_master[ruleKey]
                ruleType = dq_master[ruleKey]['RULE_TYPE'].lower()
                ruleCol = rule['COL_NAME']
                ruleID = rule['RULE_ID']
                ruleVal = rule['RULE_VAL']
                dynamicInputPath = rule['DATA_PATH_OR_TOPIC']
                # refPath = rule['REF_PATH']
                lookup_path= rule['REF_PATH']
                refPathType = rule['FORMAT']
                email=rule['EMAIL']
                if email == True:
                  eflg=1
                logger.info('RULE_TYPE is' + ruleType)
                # Applying rules on data
                dq_table = None
                dqStats0_df = None
                if ruleType == 'isnull':
                    dq_table, dq_rule_count = data_quality_null_validation(spark, hash_table, ruleCol, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("NULL-CHECK rule type executed successfully for table "+tableName)
                elif ruleType == 'anomaly':
                    ml_config_path = obj['ML_Config_path']
                    logger.info('dsfhuas'+ruleCol+ruleVal)
                    dq_table, dq_rule_count = data_anomaly_detection(spark,hash_table,ml_config_path,ruleCol,ruleID,ruleVal,logger)
                    if dq_rule_count == -1:
                       logger.error(" ANOMALY-DETECTION rule type execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" ANOMALY-DETECTION rule type executed successfully for table "+tableName)
                elif ruleType == 'duplicate-check':
                    dq_table, dq_rule_count = data_quality_duplicates_valdation(spark, hash_table, ruleCol, ruleID, logger )
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("DUPLICATE-CHECK rule type executed successfully for table "+tableName)
                elif ruleType == 'custom-expr':
                    dq_table, dq_rule_count = data_quality_expression_validation(obj, hash_table, ruleID, rule, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("COUNT-VALIDATION rule type executed successfully for table "+tableName)
                elif ruleType == 'straight-look-up':
                    dq_table, dq_rule_count = data_quality_straight_lookup_validation(spark, obj, hash_table, ruleVal, ruleID, lookup_path, refPathType, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("STRAIGHT_LOOKUP rule type executed successfully for table "+tableName)
                elif ruleType == 'is-convertible':
                    dq_table, dq_rule_count = is_convertible(spark, hash_table, ruleCol, ruleVal , ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("CONVERSION-CHECK rule type executed successfully for table "+tableName)
                elif ruleType == 'regex-expr':
                    dq_table, dq_rule_count = data_quality_regex_expr_validation(hash_table, ruleCol, ruleID, ruleVal, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("REGEX-VALIDATION rule type executed successfully for table "+tableName)
                elif ruleType == 'count_to_be_between':
                    dq_table, dq_rule_count = count_to_be_between(hash_table, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("COUNT-BETWEEN-VALIDATION rule type executed successfully for table "+tableName)
                    dq_table.display()

                elif ruleType == 'count_to_be_equal':
                    dq_table, dq_rule_count = count_to_be_equal(hash_table, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("COUNT-EQUAL-VALIDATION rule type executed successfully for table "+tableName)
                    
                elif ruleType == 'count_to_be_equal_table':
                    dq_table, dq_rule_count = count_to_be_equal_table(spark,obj,hash_table, lookup_path, refPathType, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("COUNT-EQUAL-TABLE-VALIDATION rule type executed successfully for table "+tableName)
                    
                elif ruleType == 'aggregate':
                    dq_table, dq_rule_count = data_quality_aggregate_validation(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("AGGREGATE rule type executed successfully for table "+tableName) 
                elif ruleType == 'unique':
                    dq_table, dq_rule_count = data_quality_unique_validation(hash_table, ruleCol, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("UNIQUE rule type executed successfully for table "+tableName)
                elif ruleType == 'foreignkey':
                    dq_table, dq_rule_count = hasforeignkey(spark,obj,hash_table,ruleCol,ruleVal,ruleID,lookup_path,refPathType,logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("Foreignkey rule type executed successfully for table "+tableName)
                elif ruleType == 'primary_key':
                    dq_table, dq_rule_count = has_primary_key(spark, hash_table, ruleCol, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                elif ruleType == 'chisquare':
                    dq_table, dq_rule_count, stats = data_quality_chisquare_test(spark, hash_table, ruleCol, ruleID, ruleVal, logger)
                    if dq_rule_count == -1:
                      logger.error(" Chisquare test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" Chisquare test executed successfully for table "+tableName)
                elif ruleType == 'ksdistribution':
                    dq_table, dq_rule_count, stats = data_quality_ks_test_distribution(spark, hash_table, ruleCol, ruleID, ruleVal, logger)
                    if dq_rule_count == -1:
                      logger.error(" KS distribution test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" KS distribution test executed successfully for table "+tableName)
                elif ruleType == 'ks':
                  logger.info(lookup_path)
                  try:
                    if lookup_path == None:
                      dq_table, dq_rule_count, stats = data_quality_ks_test(spark, hash_table, ruleCol, ruleID, ruleVal, logger)
                    else:
                      path = lookup_path
                      file_format = path.split('.',-1)[-1].lower()
                      if file_format == 'csv':
                        ref_df = spark.read.format(file_format).load(path,header=True, inferSchema=True)
                      elif file_format == 'json':
                        ref_df = spark.read.format(file_format).load(path, inferSchema=True)
                      elif file_format == 'parquet':
                        ref_df =  spark.read.format(file_format).load(path)
                      else:
                        logger.error('File format not supported')
                      logger.info(ref_df.show())
                      dq_table, dq_rule_count, stats = data_quality_ks_test(spark, hash_table, ruleCol, ruleID, ruleVal, logger, ref_df)
                  except:
                    dq_table, dq_rule_count , stats = None, -1, None

                  if dq_rule_count == -1:
                    logger.error(" KS test execution failed for table "+tableName)
                  else:
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count)], dqStats_schema)
                    logger.debug(" KS test executed successfully for table "+tableName)
                elif ruleType == 'cramers_phi':
                    dq_table, dq_rule_count = data_quality_cramers_phi_value(spark, hash_table, ruleCol, ruleID, ruleVal, logger)
                    if dq_rule_count == -1:
                      logger.error(" Cramers phi value test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" Cramers phi value test executed successfully for table "+tableName)             
                elif ruleType == 'compound_columns_to_be_unique':
                    dq_table, dq_rule_count = data_quality_compound_columns_to_be_unique(spark, hash_table, ruleCol, ruleID, ruleVal, logger)
                    if dq_rule_count == -1:
                      logger.error(" Compound columns to be unique function failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count)], dqStats_schema)
                      logger.debug(" Compound columns to be unique function is executed successfully for table "+tableName)
                elif ruleType == 'unique_to_be_between':
                    dq_table, dq_rule_count = data_quality_column_unique_count_to_be_between(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("unique_to_be_between rule type executed successfully for table "+tableName)
                elif ruleType == 'proportion_of_unique_values_to_be_between':
                    dq_table, dq_rule_count = data_quality_proportion_of_unique_values_to_be_between(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("proportion_of_unique_values_to_be_between rule type executed successfully for table "+tableName)
                elif ruleType == 'multicolumn_sum_to_equal':
                    dq_table, dq_rule_count = data_quality_multicolumn_sum_to_equal(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("multicolumn_sum_to_equal rule type executed successfully for table "+tableName)
                elif ruleType == 'most_common_value_to_be_in_set' :
                    dq_table, dq_rule_count = data_quality_most_common_value_to_be_in_set(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("multicolumn_sum_to_equal rule type executed successfully for table "+tableName)
                elif ruleType == 'expect_column_values_to_be_increasing':
                    dq_table, dq_rule_count = data_quality_expect_column_values_to_be_increasing(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("expect_column_values_to_be_increasing rule type executed successfully for table "+tableName)
                elif ruleType == 'expect_column_values_to_be_decreasing':
                    dq_table, dq_rule_count = data_quality_expect_column_values_to_be_decreasing(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("expect_column_values_to_be_decreasing rule type executed successfully for table "+tableName)
                elif ruleType == 'column_is_json_parsable':
                    dq_table, dq_rule_count = data_quality_column_is_json_parsable(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("column_is_json_parsable rule type executed successfully for table "+tableName)
                elif ruleType == 'column_values_to_match_json_schema':
                    dq_table, dq_rule_count = data_quality_column_values_to_match_json_schema(spark, hash_table, ruleCol, ruleVal, ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("column_Values_To_Match_Json_Schema rule type executed successfully for table "+tableName)
                elif ruleType == 'values_to_be_date_parseable':
                    dq_table, dq_rule_count = values_to_be_date_parseable(spark,hash_table,ruleCol,ruleVal,ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("values_to_be_date_parseable rule type executed successfully for table ")
                elif ruleType == 'quantiles_to_be_between':
                    dq_table, dq_rule_count = quantiles_to_be_between(spark,hash_table,ruleCol,ruleVal,ruleID, logger)
                    dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                    logger.debug("quantiles_to_be_between rule type executed successfully for table ")
                elif ruleType == 'distinct_values_to_be_in_set':
                    dq_table, dq_rule_count = distinct_values_to_be_in_set(spark,hash_table,ruleCol,ruleVal, ruleID,logger)
                    if dq_rule_count == -1:
                      logger.error(" distinct_values_to_be_in_set test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" distinct_values_to_be_in_set test executed successfully for table "+tableName)
                elif ruleType == 'distinct_values_to_contain_set':
                    dq_table, dq_rule_count = distinct_values_to_contain_set(spark,hash_table,ruleCol,ruleVal, ruleID,logger)
                    if dq_rule_count == -1:
                      logger.error(" distinct_values_to_contain_set test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" distinct_values_to_contain_set test executed successfully for table "+tableName)
                elif ruleType == 'distinct_values_to_equal_set':
                    dq_table, dq_rule_count = distinct_values_to_equal_set(spark,hash_table,ruleCol,ruleVal, ruleID,logger)
                    if dq_rule_count == -1:
                      logger.error(" distinct_values_to_equal_set test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" distinct_values_to_equal_set test executed successfully for table "+tableName)
                elif ruleType == 'file_validation':
                    file_obj=FileValidation()
                    dqStatistics_file_val = file_obj.data_quality_file_validation(spark, dynamicInputPath, lookup_path, ruleVal, ruleID, df_dq_master,rule_exe_ts,batchDate, logger)
                    #dqStats0_df = spark.createDataFrame([(ruleID)], dqStats_schema)
                    logger.debug(" File Validation test executed successfully "+tableName)
                    fv = 1
                elif ruleType == 'value_pairs_to_be_in_set':
                  try:
                      #ref_input_path = str(obj['azure']['raw-base-path']) + lookup_path
                      data_type = lookup_path.split('.', -1)[-1]
                      ref_df = data_quality_read_input_data(spark, tableName, data_type, lookup_path, logger)       
                      dq_table, dq_rule_count = data_quality_value_pairs_to_be_in_set(hash_table, 
                                                                          ruleCol, ref_df, ruleVal, ruleID, logger)                                                    
                  except:
                      dq_table, dq_rule_count = None, -1
                  if dq_rule_count == -1:
                      logger.error("Value-Pairs_to_be_in_set-check rule type failed for table" + tableName)
                  else:        
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count)], dqStats_schema)
                      logger.debug("Value-Pairs_to_be_in_set-check rule type executed successfully for table" + tableName)
                elif ruleType == 'value_pairs_to_be_equal':
                    dq_table, dq_rule_count = data_quality_value_pairs_to_be_equal(hash_table,ruleCol,ruleID,ruleVal,logger)
                    if dq_rule_count == -1:
                      logger.error(" value_pairs_to_be_equal test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" value_pairs_to_be_equal test executed successfully for table "+tableName)
                elif ruleType == 'pair_values_a_to_be_greater_than_b':
                    dq_table, dq_rule_count = data_quality_pair_values_a_to_be_greater_than_b(hash_table,ruleCol,ruleID,ruleVal,logger)
                    if dq_rule_count == -1:
                      logger.error(" pair_values_A_to_be_greater_than_B test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" pair_values_A_to_be_greater_than_B test executed successfully for table "+tableName)
                elif ruleType == 'has_num_rows_less_than':
                    dq_table, dq_rule_count = data_quality_has_num_rows_less_than(spark, hash_table, ruleVal, ruleID, logger)
                    if dq_rule_count == -1:
                      logger.error(" has_num_rows_less_than test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" has_num_rows_less_than test executed successfully for table "+tableName)
                elif ruleType == 'has_num_rows_greater_than':
                    dq_table, dq_rule_count = data_quality_has_num_rows_greater_than(spark, hash_table, ruleVal, ruleID, logger)
                    if dq_rule_count == -1:
                      logger.error(" has_num_rows_greater_than test execution failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                      logger.debug(" has_num_rows_greater_than test executed successfully for table "+tableName)
                elif ruleType == 'has_functional_dependency':
                    dq_table, dq_rule_count = data_quality_has_functional_dependency(hash_table, ruleCol, ruleVal, ruleID, logger)
                    if dq_rule_count == -1:
                      logger.error("has_functional_dependency function failed for table "+tableName)
                    else:
                      dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count)], dqStats_schema)
                      logger.debug("has_functional_dependency function is executed successfully for table "+tableName)
                elif ruleType == 'column_to_exist':
                    dqStatistics_column_exist = column_to_exist(spark,hash_table,ruleCol,ruleID,df_dq_master,rule_exe_ts,batchDate,logger)
                    logger.debug(" schema validation executed successfully ")
                    flg=1
                elif ruleType == 'column_to_match_ordered_list':
                    dqStatistics_column_match = columns_to_match_ordered_list(spark,hash_table,ruleCol,ruleID,df_dq_master,rule_exe_ts,batchDate,logger)
                    logger.debug(" schema validation executed successfully ")
                    flg=1
                elif ruleType == 'column_to_match_set':
                    dqStatistics_column_set = columns_to_match_set(spark,hash_table,ruleCol,ruleID,df_dq_master,rule_exe_ts,batchDate,logger)
                    logger.debug(" schema validation executed successfully ")
                    flg=1
                elif ruleType == 'has_data_type':
                    dqStatistics_has_datatype = has_datatype(spark,hash_table,ruleCol,ruleVal,ruleID,df_dq_master,rule_exe_ts,batchDate,logger)
                    logger.debug(" hasDataType executed successfully ")
                    flg=1
                else:
                  try:
                    raise invalidInputParams("Provided DQ Rule"+ruleID+"("+ruleType+") for table"+ tableName+" not supported yet!!!")
                  except invalidInputParams as iip:
                    logger.error(str(iip))
                    logger.error("Skipped DQ validation for DQ Rule "+ruleID+" ("+ruleType+") for table"+ tableName)
                    skipped_dq_rules = skipped_dq_rules+"\n >>> "+tableName+" || "+ruleID+" || "+ruleType
                    # audit_doc = OrderedDict()
                    audit_rec=DriverEntry('data_quality_batch',batchDate_formatted,obj['sourceName'],obj['prcs_runid'],obj['pipelineName'],obj['triggerName'],'Failed',iip,start_time)
                    audit_doc,exit_doc=gen_audit_dict(audit_doc,exit_doc,audit_rec,iip)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0, exit_doc





    

                ################################################### remediation #################

                remRuleType = rule['REM_RULE_TYPE']
                remFlag = rule['REMEDIATE_FLG']
                remMethod = rule['REM_METHOD']
                remRuleVal = rule['REM_RULE_VAL']
                remDefValue = rule['REM_DEFAULT_VAL']

                if remFlag == True:

                    if remRuleType == 'interpolate':
                      hash_table = Utils.get_impute_interpolate_col(hash_table, ruleCol, leEnc, remMethod, logger)
                      logger.debug("interpolation was executed successfully")

                    if remRuleType == 'default-value':
                      hash_table = Utils.replace_default_value(hash_table, ruleCol, remDefValue, logger)
                      logger.debug("null values updated with default-value successfully")
                    
                    if remRuleType == 'mean':
                      hash_table = Utils.get_mean(hash_table, ruleCol, logger)
                      logger.debug("null values updated with mean values successfully")
                    
                    if remRuleType == 'regression':
                      hash_table = Utils.linear_regression(hash_table, ruleCol, logger)
                      logger.debug("null values imputed with linear regression successfully")
                    
                    if remRuleType == 'lookup':
                      hash_table, flag = Utils.straight_lookup_remediation(spark, obj, hash_table, ruleCol, remRuleVal, lookup_path, logger)
                      if flag == 1:
                        logger.debug("Null values imputed with lookup remediation successfully")
                      else:
                        logger.error("Null values imputed with lookup remediation has been failed")
                    
                    if remRuleType == 'mostRecurringValue':
                      hash_table = Utils.most_recurring_value(hash_table, ruleCol, logger)
                      logger.debug("null values updated with most_recurring_values  successfully")
                    
                    if remRuleType == 'median':
                      hash_table = Utils.median(hash_table, ruleCol, logger)
                      logger.debug("null values updated with median successfully")
                    
                    if remRuleType == 'trimmed_mean':
                      hash_table = Utils.trimmed_mean(hash_table, ruleCol, remRuleVal, logger)
                      logger.debug("null values imputed with trimmed mean successfully")
                    
                    rem_path= "/mnt/mountdatalake/idfdata/idfPOC/Remediation/" + str(tableName)
                    hash_table.repartition(1).write.format(refPathType).mode("overwrite").option("header",True).save(rem_path)
                    #hash_table.repartition(1).write.mode("overwrite").option("header",True).csv(rem_path)                    
                ############################ end of Remediation #############################

                if dq_table is not None:
                  if dq_table.count()>0:
                    vldtd_hash_tbl_res=vldtd_hash_tbl_res.union(dq_table)
                  else:
                    dqStats0 = dqStats0.union(dqStats0_df)
                
                
                if ruleType in ['ks','chisquare','ksdistribution']:
                  if stats is not None:
                    dq_ml_stats = dq_ml_stats.union(spark.createDataFrame([(ruleID, stats)], dq_ml_stats_schema))
                if ruleType =='file_validation':
                  dq_file_stats=dq_file_stats.union(dqStatistics_file_val)
                if ruleType == 'column_to_exist':
                  dq_schema_validation=dq_schema_validation.union(dqStatistics_column_exist)
                if ruleType == 'column_to_match_ordered_list':
                  dq_schema_validation=dq_schema_validation.union(dqStatistics_column_match)
                if ruleType == 'column_to_match_set':
                  dq_schema_validation=dq_schema_validation.union(dqStatistics_column_set)
                if ruleType == 'has_data_type':
                  dq_schema_validation=dq_schema_validation.union(dqStatistics_has_datatype)	
            #Aggrigating the final results
            FailedData = vldtd_hash_tbl_res.where("Not(ERR_CD is Null or trim(ERR_CD) = '')")
            FailedDataFinal = FailedData.join( df_dq_master.select("RULE_ID","RULE_TYPE").alias("df_dq_master"), FailedData.ERR_CD ==  df_dq_master.RULE_ID  , "left").select(FailedData.columns + ["RULE_TYPE"])
            FailedDataFinal = FailedDataFinal.withColumn('ec',lit("3"))
            
            # write error df to exception table in synapse
            if FailedDataFinal.count() > 0:
                exception_df = Utils.get_exception_data(spark, obj, FailedDataFinal, dbutils, logger)
                exception_tableName = obj['sqlserver']['DQ_exception_table']
                if len(exception_df.head(1)) > 0:
                    validation_flag = True
                    logger.info("Writing erroneous data to the Synapse table: " + exception_tableName)
                    write_data_sql(exception_df, obj, 'append', exception_tableName)
                    #utilsShared.write_enrich(dbutils, exception_df, spark, obj, 'append', exception_tableName)
            else:
                logger.debug("Erroneous data not available for the applied DQ rules")
            dqStats = FailedData.groupby("ERR_CD").count().withColumnRenamed("count", "FAILED_ROW_COUNT" ).selectExpr("ERR_CD as RULE_ID","FAILED_ROW_COUNT")
            dqStats= dqStats.union(dqStats0)
            dqStats1 = dqStats.withColumn("TOTAL_ROW_CNT", lit(hash_table_cnt)).withColumn("PASSED_ROW_CNT" , (col("TOTAL_ROW_CNT")-col("FAILED_ROW_COUNT")))

            # if counts_vldtn_df is not None:
            #   dqStats1=dqStats1.union(counts_vldtn_df)

            dqStats2 = dqStats1.withColumn("RULE_FAIL_PC", lit(100*col("FAILED_ROW_COUNT")/col("TOTAL_ROW_CNT")) ).withColumn("EXEC_DATE",lit(rule_exe_ts)).withColumn("BATCH_DATE", lit(batchDate))
            dqStats2 = dqStats2.join(dq_ml_stats, 'RULE_ID', 'outer')
            dqStatistics = dqStats2.join(df_dq_master.select(['RULE_ID','RULE_TYPE','RULE_DIMENSION','FILE_OR_TABLE_NAME', 'COL_NAME']),'RULE_ID','inner')\
            .select( "RULE_ID","RULE_TYPE","RULE_DIMENSION","FILE_OR_TABLE_NAME","COL_NAME","BATCH_DATE","TOTAL_ROW_CNT","FAILED_ROW_COUNT","RULE_FAIL_PC","EXEC_DATE","STATS_DESC")
            if fv==1:
              dqStatistics= dqStatistics.union(dq_file_stats)
            if flg == 1:
              dqStatistics = dqStatistics.union(dq_schema_validation)
            dqStatistics2 = dqStatistics.join(df_dq_master.select(['RULE_ID','EMAIL','EMAIL_ADDRESS']),'RULE_ID','inner')\
            .select( 'RULE_ID','RULE_TYPE','RULE_DIMENSION','FILE_OR_TABLE_NAME','COL_NAME','EMAIL','EMAIL_ADDRESS','BATCH_DATE','TOTAL_ROW_CNT','FAILED_ROW_COUNT','RULE_FAIL_PC','EXEC_DATE','STATS_DESC')
            if eflg==1:
              DQSTATS_JSON = dqStatistics2
            else:
              DQSTATS_JSON = 0
            DQSTATS_JSON = dqStatistics2
            #Write dqStatistics results for the tabel
            logger.info("Writing dq stats results to DQ stats SQL DB table for: " + tableName)
            write_data_sql(dqStatistics, obj, 'append', 'dbo.dqStatistics')
            logger.debug("DQ Stats table updated successfully with {} records".format(dqStatistics.count()))
            inputRowCount = int(inputDF.count())
            inputColumnCount = 0
            src_file_size = 0
            destination_path = 'NA'
            audit_rec=BeforeSourceRead(obj,batchDate_formatted,'Succeeded','DQ Completed Successfully!',start_time)
            # def __init__(self,obj,batch_date,status,exception,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,dest_path,dest_row_cnt,dest_col_cnt,dest_file_size,rejected_row_cnt,rejected_file_path,log_filename,validation_flag=False,invalid_val=None)
            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=1
            return inputDF,DQSTATS_JSON, exit_doc
            
    if len(tablesNotInDqMaster)>0:
      try:
        tables_str=','.join(tablesNotInDqMaster)
        raise Exception("Some of the provided input tables "+ tables_str +" for dq validation not present dq master!!!")
      except Exception as e:
        logger.error(str(e)+"Please provide currently supported file format  among 'csv' or 'delta' for input source table")
        logger.error(str(e)+ "Skipped DQ validation for tables: "+tables_str)
        skipped_tables=skipped_tables+"\n>>> "+ '\n'.join(tablesNotInDqMaster)
        return 0, exit_doc

  except Exception as e:
        logger.error("DQ Stats validation job failed with exception "+str(e)+"/n"+str(traceback.format_exc()) )
        try:
            err_desc = str(traceback.format_exc())
            logger.error(str(err_desc))
            raise uncatchException(err_desc)
        except uncatchException as cfe:
            print(cfe)
            # audit_doc = OrderedDict()
            audit_rec=DriverEntry('data_quality_batch',batchDate_formatted,obj['sourceName'],obj['prcs_runid'],obj['pipelineName'],obj['triggerName'],'Failed',cfe,start_time)
            audit_doc,exit_doc=gen_audit_dict(audit_doc,exit_doc,audit_rec,cfe)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
            logger.info('ERROR in  Processing file '+ str(obj['sourceName']) + '.'+ str(obj['tableName']) + '  for date '+ str(obj['batchDate']) + str(traceback.format_exc()))
            logger.debug('Inserted Audit Entry - Job Failure ')
            #os.makedirs(log_file_folder, exist_ok=True)
            #copyfile(local_log_file_name, log_file_name)
            return 0, exit_doc

  finally :
    logger.info("\n----------------------------\n"+skipped_tables+"\n----------------------------\n"+skipped_dq_rules)
    logger.info("\n\nInfo: "+"End of DQ Stats Validation Process...")