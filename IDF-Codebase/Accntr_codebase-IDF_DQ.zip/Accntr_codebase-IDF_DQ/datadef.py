import os
import csv
import re
import pandas as pd
import json
import os
import sys
from pyspark.sql import SparkSession
import traceback
import logging
from datetime import datetime,date

#COMMON
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.setLevel(logging.INFO)
logging.getLogger("py4j").setLevel(logging.ERROR)

def dataDefFinder(fileURL):
  logger.setLevel(logging.DEBUG)
  spark = SparkSession.builder.master("local").appName("DadaDefination").getOrCreate()
  logger.info("Sparksession started with DadaDefination as App Name")
  firstpos=fileURL.rfind("/")
  lastpos=len(fileURL)
  try:
    fileExt=fileURL[firstpos+1:lastpos].split(".")[1]
    logger.debug("The format of input file is detected as : "+str(fileExt))
  except:
    fileExt='delta'
  
  if fileExt=="csv":
    logger.info("Reading csv file to find the data defination")
    readDF = spark.read.format('csv').option("header", "true").option("inferSchema", "true").csv(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definations of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=="xml":
    logger.info("Reading xml file to find the data defination")
    readRDD = spark.sparkContext.textFile(fileURL)
    rootTobj = readRDD.take(1)[0].strip().split(" ")
    rootTLen = len(rootTobj)
    rootT=""
    if rootTLen == 1:
      rootT = rootTobj[0][1:-1]
    else:
      rootT = rootTobj[0][1:]
    rowTobj = readRDD.take(2)[1].strip().split(" ")
    rowTLen = len(rowTobj)
    rowT=""
    if rowTLen == 1:
      rowT = rowTobj[0][1:-1]
    else:
      rowT = rowTobj[0][1:]
      
    readRDD = spark.sparkContext.textFile(fileURL)
    readDF = spark.read.format('com.databricks.spark.xml').option("rootTag", rootT).option("rowTag", rowT).load(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definations of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=="json":
    logger.info("Reading json file to find the data defination")
    readDF = spark.read.format('json').option('multiline', True).load(fileURL)
    typedict = dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definations of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=="txt":
    logger.info("Reading txt file to find the data defination")
    readRDD = spark.sparkContext.textFile(fileURL)
    readRDD_1 = readRDD.map(lambda x: re.split(r'[ ,|;"]+', x))
    readDF = readRDD_1.toDF()
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definations of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=='parquet':
    logger.info('Reading parquet file to find data definition')
    readDF=spark.read.parquet(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definitions of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=='delta':
    logger.info('Reading delta lake folder to find data definition')
    readDF=spark.read.format('delta').load(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definitions of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=='orc':
    logger.info('Reading orc folder to find data definition')
    readDF=spark.read.orc(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definitions of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  elif fileExt=='avro':
    logger.info('Reading avro folder to find data definition')
    readDF=spark.read.format('avro').load(fileURL)
    typedict=dict(readDF.dtypes)
    list_keys = [{k:"string"} if str(v)=="object" else {k:str(v)} for k,v in typedict.items()]
    logger.debug("Data definitions of the input dataset : "+str(list_keys))
    return json.dumps({"DataDef": list_keys})
  else:
    return json.dumps({"DataDef": "file format {ext} not supported".format(ext=fileExt)})