#from elasticsearch import Elasticsearch
import json
from datetime import datetime
import pandas as pd
import os
import sys

class metadataManager:
	global logger
	def __init__(self):
		sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/codebase/')
		import utilsShared

		log_file_name="/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/data/logs/db_data_vault_" + str(datetime.strftime(datetime.now(), '%Y%m%d')) + '.log'

		logger = utilsShared.getFormattedLogger(__name__,log_file_name)
		
		
	def insert_auditRecord(self,dbutils,obj,spark,audit_doc):		
		audit_df = pd.DataFrame([audit_doc])
		df=spark.createDataFrame(audit_df)
		df.show(1,False)
		df.write.format("jdbc").option("url", str(obj["sqlserver"]["connection-string"])).option("useAzureMSI","true").mode("append").option("dbTable", str(obj["sqlserver"]["prc_excution_table"])).save()
		
	def insert_profileRecord(self, profile_doc, file_name):
		profile_df = pd.DataFrame([profile_doc])
		profile_data =profile_df.to_csv(sep=',',index=False,header=False)
				
		with open(file_name,"a") as f:
			f.write(str(profile_data))
			f.write("\n")
		#logger.logging_info("Profile Data written in the file:"+str(profile_doc))
