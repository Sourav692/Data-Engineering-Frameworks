import logging
import os
import yaml
from collections import OrderedDict
from pyspark.sql.functions import lit

def getFormattedLogger(scriptName,fileName=None):
	logger = logging.getLogger(scriptName)
	#logger = logging.getLogger() #Enabling root logger
	logger.setLevel(logging.DEBUG)
	file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	if fileName:
		file_handler = logging.FileHandler(fileName)
		file_handler.setFormatter(file_format)
		logger.addHandler(file_handler)
	ch=logging.StreamHandler()
	ch.setLevel(logging.DEBUG)
	ch.setFormatter(file_format)
	logger.addHandler(ch)
	logging.getLogger("py4j").setLevel(logging.ERROR)  
	return logger

def getdbutils():
	# Get the details of dbutils
	return dbutils

def getEnvConf(logger=0,dbutils=0,storageFlag=0,onlyYaml=0):
	# Read the environment Config file from the static path 
	if logger ==0 :
		logger = getFormattedLogger(__name__)
	
	envConfPath= "/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/envConfig.yaml"
	logger.info("Reading Env Config from: " + envConfPath)
	if onlyYaml==1:
		envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
	else:
		if os.path.isfile(envConfPath):
			envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
			#stg_acct_name = dbutils.secrets.get(scope = 'keyvault',key = '')
			envConfig["azure"]["storage_account_name"]  = "idfrgworkspace"	
			envConfig["azure"]["storage_account_access_key"]  =	"AlosfSp1joLOxn0kRTaobLWxQHaaETsZTI8wgZTvMKorWgNJzWxmoth5RRQ9Fl4FxV2hzj1MPy1ZmnjqCZOW4g=="
			temp_dir_path = envConfig["sqlserver"]["temp_dir_path"]
			envConfig["sqlserver"]["tempDir"] = 'abfss://' + str(envConfig["azure"]["storage_container_name"]) +'@'+ str(envConfig["azure"]["storage_account_name"]) +'.dfs.core.windows.net'+ str(envConfig["sqlserver"]["temp_dir_path"])
			sql_server_name = str(envConfig["sqlserver"]["sql_server_name"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_db = str(envConfig["sqlserver"]["sql_server_db"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_user = str(envConfig["sqlserver"]["sql_server_user"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
			sql_server_pass = str(envConfig["sqlserver"]["sql_server_pass"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
		
			conn_string = 'jdbc:sqlserver://' + str(sql_server_name) + ';database=' + str(sql_server_db) +';user='+ str(sql_server_user) +';password='+ str(sql_server_pass) +';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'	
			envConfig["sqlserver"]["connection-string"]  =	conn_string
			
		else:
			logger.info("Env Config is not available " + str(envConfPath) + ", Please place the config file in order to execute the job")
			return 0

	return envConfig

def gen_audit_dict(audit_doc,exit_doc,audit_rec,exception):
	audit_doc=OrderedDict()
	audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
	audit_doc['FILE_NAME'], exit_doc['FILE_NAME'] = audit_rec.FILE_NAME,audit_rec.FILE_NAME
	audit_doc['BATCH_DATE'],exit_doc['BATCH_DATE'] = audit_rec.BATCH_DATE,audit_rec.BATCH_DATE
	audit_doc['SOURCE_NAME'],exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
	audit_doc['PRCS_EXECUTION_ID'], exit_doc['PRCS_EXECUTION_ID'] = audit_rec.PRCS_EXECUTION_ID,audit_rec.PRCS_EXECUTION_ID
	audit_doc['PIPELINE_NAME'],exit_doc['PIPELINE_NAME']=audit_rec.PIPELINE_NAME,audit_rec.PIPELINE_NAME
	audit_doc['TRIG_NAME'],exit_doc['TRIG_NAME']=audit_rec.TRIG_NAME,audit_rec.TRIG_NAME
	audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
	audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC, audit_rec.TECH_STATUS_DESC
	exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
	audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
	exit_doc["EXPECTED_PERIOD_KEY"]=audit_rec.EXPECTED_PERIOD_KEY
	audit_doc['SOURCE_PATH'], exit_doc['SOURCE']['SOURCE_PATH'] = audit_rec.SOURCE_PATH,audit_rec.SOURCE_PATH
	audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = audit_rec.SOURCE_ROW_COUNT,audit_rec.SOURCE_ROW_COUNT
	audit_doc['SOURCE_COL_COUNT'], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = audit_rec.SOURCE_COL_COUNT,audit_rec.SOURCE_COL_COUNT
	audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT']=audit_rec.SOURCE_AMOUNT,audit_rec.SOURCE_AMOUNT
	audit_doc['SOURCE_FILE_SIZE'], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = audit_rec.SOURCE_FILE_SIZE,audit_rec.SOURCE_FILE_SIZE
	exit_doc["VALIDATION_FLAG"]="Failed" if audit_rec.VALIDATION_FLAG else "Succeeded"
	
	audit_doc['DEST_PATH'], exit_doc['DESTINATION']['DEST_PATH'] = audit_rec.DEST_PATH,audit_rec.DEST_PATH
	audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = audit_rec.DEST_ROW_COUNT,audit_rec.DEST_ROW_COUNT
	audit_doc['DEST_COL_COUNT'], exit_doc['DESTINATION']['DEST_COL_COUNT'] = audit_rec.DEST_COL_COUNT,audit_rec.DEST_COL_COUNT
	audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT']=audit_rec.DEST_AMOUNT,audit_rec.DEST_AMOUNT
	audit_doc['DEST_FILE_SIZE'], exit_doc['DESTINATION']['DEST_FILE_SIZE'] =audit_rec.DEST_FILE_SIZE,audit_rec.DEST_FILE_SIZE
	audit_doc['REJECTED_ROW_COUNT'], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = audit_rec.REJECTED_ROW_COUNT,audit_rec.REJECTED_ROW_COUNT
	audit_doc['REJECTED_FILE_NAME'], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = audit_rec.REJECTED_FILE_NAME,audit_rec.REJECTED_FILE_NAME
	audit_doc["LOG_PATH"]=audit_rec.LOG_PATH
	exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
	return audit_doc,exit_doc

def gen_stream_audit_dict(audit_doc,exit_doc,audit_rec,exception):
	audit_doc=OrderedDict()
	audit_doc['ID'], exit_doc['ID'] = audit_rec.ID,audit_rec.ID
	audit_doc['RUNID'], exit_doc['RUNID'] = audit_rec.RUNID,audit_rec.RUNID
	audit_doc['STAGE'], exit_doc['STAGE'] = audit_rec.STAGE,audit_rec.STAGE
	audit_doc['NAME'], exit_doc['NAME'] = audit_rec.NAME,audit_rec.NAME
	audit_doc['STREAM_TIMESTAMP'], exit_doc['STREAM_TIMESTAMP'] = audit_rec.STREAM_TIMESTAMP,audit_rec.STREAM_TIMESTAMP
	audit_doc['BATCHID'], exit_doc['BATCHID'] = audit_rec.BATCHID,audit_rec.BATCHID
	audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
	audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
	audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC, audit_rec.TECH_STATUS_DESC
	exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
	audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
	audit_doc['TRIGGER_TYPE'],exit_doc['TRIGGER_TYPE']=audit_rec.TRIGGER_TYPE,audit_rec.TRIGGER_TYPE
	audit_doc["LOG_PATH"],exit_doc["LOG_PATH"]=audit_rec.LOG_PATH,audit_rec.LOG_PATH
	audit_doc['SOURCE_TYPE'], exit_doc['SOURCE_TYPE'] = audit_rec.SOURCE_TYPE,audit_rec.SOURCE_TYPE
	audit_doc['SOURCE_NAME'], exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
	audit_doc["NUMINPUTROWS"], exit_doc['NUMINPUTROWS'] = audit_rec.NUMINPUTROWS,audit_rec.NUMINPUTROWS
	audit_doc['INPUTROWSPERSECOND'], exit_doc['INPUTROWSPERSECOND'] = audit_rec.INPUTROWSPERSECOND,audit_rec.INPUTROWSPERSECOND
	audit_doc['PROCESSEDROWSPERSECOND'], exit_doc['PROCESSEDROWSPERSECOND'] = audit_rec.PROCESSEDROWSPERSECOND,audit_rec.PROCESSEDROWSPERSECOND
	audit_doc['GETOFFSET'], exit_doc['GETOFFSET'] = audit_rec.GETOFFSET,audit_rec.GETOFFSET
	audit_doc['TRIGGEREXECUTION'], exit_doc['TRIGGEREXECUTION'] = audit_rec.TRIGGEREXECUTION,audit_rec.TRIGGEREXECUTION
	audit_doc['SOURCE_DESCRIPTION'], exit_doc['SOURCE_DESCRIPTION'] = audit_rec.SOURCE_DESCRIPTION,audit_rec.SOURCE_DESCRIPTION
	audit_doc['START_OFFSET_NAME'], exit_doc['START_OFFSET_NAME'] = audit_rec.START_OFFSET_NAME,audit_rec.START_OFFSET_NAME
	audit_doc['START_OFFSET_0'], exit_doc['START_OFFSET_0'] = audit_rec.START_OFFSET_0,audit_rec.START_OFFSET_0
	audit_doc['START_OFFSET_1'], exit_doc['START_OFFSET_1'] = audit_rec.START_OFFSET_1,audit_rec.START_OFFSET_1
	audit_doc['END_OFFSET_NAME'], exit_doc['END_OFFSET_NAME'] = audit_rec.END_OFFSET_NAME,audit_rec.END_OFFSET_NAME
	audit_doc['END_OFFSET_0'], exit_doc['END_OFFSET_0'] = audit_rec.END_OFFSET_0,audit_rec.END_OFFSET_0
	audit_doc['END_OFFSET_1'], exit_doc['END_OFFSET_1'] = audit_rec.END_OFFSET_1,audit_rec.END_OFFSET_1
	audit_doc['SOURCE_NUM_INPUT_ROWS'], exit_doc['SOURCE_NUM_INPUT_ROWS'] = audit_rec.SOURCE_NUM_INPUT_ROWS,audit_rec.SOURCE_NUM_INPUT_ROWS
	audit_doc['SOURCE_INPUT_ROWS_PER_SECOND'], exit_doc['SOURCE_INPUT_ROWS_PER_SECOND'] = audit_rec.SOURCE_INPUT_ROWS_PER_SECOND,audit_rec.SOURCE_INPUT_ROWS_PER_SECOND
	audit_doc['SINK_DESCRIPTION'], exit_doc['SINK_DESCRIPTION'] = audit_rec.SINK_DESCRIPTION,audit_rec.SINK_DESCRIPTION
	audit_doc['SINK_NUM_OF_OUTPUT_ROWS'], exit_doc['SINK_NUM_OF_OUTPUT_ROWS'] = audit_rec.SINK_NUM_OF_OUTPUT_ROWS,audit_rec.SINK_NUM_OF_OUTPUT_ROWS
	audit_doc['RAW_PATH'], exit_doc['RAW_PATH'] = audit_rec.RAW_PATH,audit_rec.RAW_PATH
	audit_doc["RAW_ROW_COUNT"], exit_doc['RAW_ROW_COUNT'] = audit_rec.RAW_ROW_COUNT,audit_rec.RAW_ROW_COUNT
	audit_doc['RAW_COL_COUNT'], exit_doc['RAW_COL_COUNT'] = audit_rec.RAW_COL_COUNT,audit_rec.RAW_COL_COUNT
	audit_doc['CURATED_PATH'], exit_doc['CURATED_PATH'] = audit_rec.CURATED_PATH,audit_rec.CURATED_PATH
	audit_doc["CURATED_ROW_COUNT"], exit_doc['CURATED_ROW_COUNT'] = audit_rec.CURATED_ROW_COUNT,audit_rec.CURATED_ROW_COUNT
	audit_doc['CURATED_COL_COUNT'], exit_doc['CURATED_COL_COUNT'] = audit_rec.CURATED_COL_COUNT,audit_rec.CURATED_COL_COUNT
	audit_doc['ENRICH_PATH'], exit_doc['ENRICH_PATH'] = audit_rec.ENRICH_PATH,audit_rec.ENRICH_PATH
	audit_doc["ENRICH_ROW_COUNT"], exit_doc['ENRICH_ROW_COUNT'] = audit_rec.ENRICH_ROW_COUNT,audit_rec.ENRICH_ROW_COUNT
	audit_doc['ENRICH_COL_COUNT'], exit_doc['ENRICH_COL_COUNT'] = audit_rec.ENRICH_COL_COUNT,audit_rec.ENRICH_COL_COUNT
	exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
	return audit_doc,exit_doc

def gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,exception):
	audit_doc=OrderedDict()
	audit_doc['JSON'], exit_doc['JSON'] = audit_rec.JSON,audit_rec.JSON
	audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
	audit_doc['ID'], exit_doc['ID'] = audit_rec.ID,audit_rec.ID
	audit_doc['RUNID'], exit_doc['RUNID'] = audit_rec.RUNID,audit_rec.RUNID
	audit_doc['STAGE'], exit_doc['STAGE'] = audit_rec.STAGE,audit_rec.STAGE
	audit_doc['NAME'], exit_doc['NAME'] = audit_rec.NAME,audit_rec.NAME
	audit_doc['STREAM_TIMESTAMP'], exit_doc['STREAM_TIMESTAMP'] = audit_rec.STREAM_TIMESTAMP,audit_rec.STREAM_TIMESTAMP
	audit_doc['BATCHID'], exit_doc['BATCHID'] = audit_rec.BATCHID,audit_rec.BATCHID
	audit_doc['FOREACHBATCH'], exit_doc['FOREACHBATCH'] = audit_rec.FOREACHBATCH,audit_rec.FOREACHBATCH
	audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
	audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC, audit_rec.TECH_STATUS_DESC
	exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
	audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
	audit_doc['TRIGGER_TYPE'],exit_doc['TRIGGER_TYPE']=audit_rec.TRIGGER_TYPE,audit_rec.TRIGGER_TYPE
	audit_doc["LOG_PATH"],exit_doc["LOG_PATH"]=audit_rec.LOG_PATH,audit_rec.LOG_PATH
	audit_doc['SOURCE_TYPE'], exit_doc['SOURCE_TYPE'] = audit_rec.SOURCE_TYPE,audit_rec.SOURCE_TYPE
	audit_doc['SOURCE_NAME'], exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
	audit_doc['START_OFFSET'], exit_doc['START_OFFSET'] = audit_rec.START_OFFSET,audit_rec.START_OFFSET
	audit_doc['END_OFFSET'], exit_doc['END_OFFSET'] = audit_rec.END_OFFSET,audit_rec.END_OFFSET
	audit_doc['SINK_DESCRIPTION'], exit_doc['SINK_DESCRIPTION'] = audit_rec.SINK_DESCRIPTION,audit_rec.SINK_DESCRIPTION
	audit_doc['CHECKPOINT_PATH'], exit_doc['CHECKPOINT_PATH'] = audit_rec.CHECKPOINT_PATH,audit_rec.CHECKPOINT_PATH
	audit_doc['RAW_PATH'], exit_doc['RAW_PATH'] = audit_rec.RAW_PATH,audit_rec.RAW_PATH
	audit_doc["RAW_ROW_COUNT"], exit_doc['RAW_ROW_COUNT'] = audit_rec.RAW_ROW_COUNT,audit_rec.RAW_ROW_COUNT
	audit_doc['RAW_COL_COUNT'], exit_doc['RAW_COL_COUNT'] = audit_rec.RAW_COL_COUNT,audit_rec.RAW_COL_COUNT
	audit_doc['CURATED_PATH'], exit_doc['CURATED_PATH'] = audit_rec.CURATED_PATH,audit_rec.CURATED_PATH
	audit_doc["CURATED_ROW_COUNT"], exit_doc['CURATED_ROW_COUNT'] = audit_rec.CURATED_ROW_COUNT,audit_rec.CURATED_ROW_COUNT
	audit_doc['CURATED_COL_COUNT'], exit_doc['CURATED_COL_COUNT'] = audit_rec.CURATED_COL_COUNT,audit_rec.CURATED_COL_COUNT
	audit_doc['ENRICH_PATH'], exit_doc['ENRICH_PATH'] = audit_rec.ENRICH_PATH,audit_rec.ENRICH_PATH
	audit_doc["ENRICH_ROW_COUNT"], exit_doc['ENRICH_ROW_COUNT'] = audit_rec.ENRICH_ROW_COUNT,audit_rec.ENRICH_ROW_COUNT
	audit_doc['ENRICH_COL_COUNT'], exit_doc['ENRICH_COL_COUNT'] = audit_rec.ENRICH_COL_COUNT,audit_rec.ENRICH_COL_COUNT
	exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
	return audit_doc,exit_doc

def write_enrich(dbutils, HASH_TABLE, spark, obj,v_mode,tgt_table):
	#  Write data to table
	#HASH_TABLE.write.format("jdbc").option("url", str(obj["sqlserver"]["connection-string"])).mode(v_mode).option("dbTable", tgt_table).save()
	logger = getFormattedLogger("UtilsShared",obj['local_log_file_name'])
	HASH_TABLE.show()
	#HASH_TABLE.write.format("jdbc").option("url", str(obj["sqlserver"]["connection-string"])).option("useAzureMSI","true").mode(v_mode).option("dbTable",tgt_table).save()
	logger.info("Write Synapse table: " + tgt_table + "completed")