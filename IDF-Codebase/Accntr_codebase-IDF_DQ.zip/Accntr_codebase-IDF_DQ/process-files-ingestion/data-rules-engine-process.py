import sys
import json
import traceback
import re
import unicodedata
import logging
from elasticsearch import Elasticsearch
import pyspark
from elasticsearch import Elasticsearch
from pyspark.sql import SQLContext, Row
from pyspark.sql.types import *
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, lit, trim, concat_ws, when, isnull, col, isnan, array, regexp_replace, sha1, sha2, hex, base64, lower, upper, substring, concat, lpad, rpad, ltrim, rtrim, split, mean
import Utils
import time
import datetime
from collections import OrderedDict
from metadataManager import metadataManager

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
from customException import *
from gen_audit_entry import *
                                                
###################################################################################################
#M1
def process(config_prop,inputDF,dbutils, exit_doc):   
    job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    loc = str(config_prop['varbatchdate'])
    stage='data-rules-engine-process'
    log_filename =  config_prop['local_log_file_name']
    logger = utilsShared.getFormattedLogger(stage,log_filename)
    validation_flag=False

    #spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
    spark = SparkSession.builder.appName(config_prop["use-case"]).getOrCreate()
    spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    metadataObject = metadataManager()
    document={}
    document['applicationid']= str(spark.sparkContext.applicationId)
    document['doc-type']= str(config_prop['use-case'])    
    try:
        logger.info("Inside try of data-rules-engine-process")
        audit_doc=OrderedDict()
        #if config_prop.has_key('multi-folder') and 'FALSE' == str(config_prop['multi-folder']):
        if '1':
            logger.info("Reading the curated file from blobstore")
            if inputDF == 0:
                inputDF = spark.read.parquet(str(config_prop['azure']["clean-base-path"]) + str(config_prop['clean-location'])+"/*")
                       
            output = str(config_prop['azure']['clean-base-path']) + str(config_prop['clean-location']) + "/" #+loc # + loc +"_output"
            
            columnList = inputDF.columns
            document['name']=config_prop['raw-location']+"/"+loc
            #document['curated-location']=config_prop['curated-location'
            #aliesMap = metadataObject.get_aliesMap(output)

            def regexReplaceFn(value,oper):
                if type(value) is unicode:
                    value = value.encode('ascii', 'ignore')
                #if
                elif value is None or str(value) == 'nan':
                     return value
                #elif
                print("Executing regexReplaceFn")
                operation = str("".join(oper[0])).split("#")
                pattern = re.compile(operation[1],re.IGNORECASE)
                value = re.sub(r'[^\x00-\x7F]+',' ', str(value))
                isMatch = pattern.match(value)
                if isMatch:
                    return operation[0]
                #if
                else:
                    return value
                #else
            #def
            regexReplaceUDF = udf(regexReplaceFn,StringType())


            def regexPartialReplaceFn(value, oper):

                if type(value) is unicode:
                    value = value.encode('ascii', 'ignore')
                #if
                elif value is None or str(value) == 'nan':
                     return value
                #elif

                operation = str("".join(oper[0])).split("#")
                pattern = re.compile(operation[1],re.IGNORECASE)
                returnValue = re.sub(pattern,"\g<"+str(operation[2])+">", value)
                return str(operation[0])+returnValue
            
            #def 
            regexPartialReplaceUDF = udf(regexPartialReplaceFn,StringType())
            
            def accentRemovalFn(value):
                try:
                    if value is None or str(value) == 'nan':
                        value = ''
                    #if
                    else:
                        value = unicodedata.normalize('NFKD', value).encode('ASCII', 'ignore')
                        value = re.sub('\W+',' ', str(value))
                    #else
                    return value
                #try
                except:
                    traceback.print_exc()
                    raise ValueError("Error In Accent Removal")
                #except    
            #def    
            accentRemovalUDF = udf(accentRemovalFn,StringType())

            def encrypt_val(clear_text,MASTER_KEY):
                from cryptography.fernet import Fernet
                f = Fernet(MASTER_KEY)
                clear_text_b=bytes(clear_text, 'utf-8')
                cipher_text = f.encrypt(clear_text_b)
                cipher_text = str(cipher_text.decode('ascii'))
                return cipher_text
 
            # Decrypting data for detokenization
            def decrypt_val(cipher_text,MASTER_KEY):
                from cryptography.fernet import Fernet
                f = Fernet(MASTER_KEY)
                clear_val=f.decrypt(cipher_text.encode()).decode()
                return clear_val 

            encrypt = udf(encrypt_val, StringType())
            decrypt = udf(decrypt_val, StringType())

            rules_list = []
            for row in config_prop['DATA-RULES']:
                rules_list.append(row)
                column_list =  row["col"].lower()
                if "$alias$" in column_list:
                    column_names = column_list.replace("$alias$","").split(";")
                    cnames = []
                    for item in column_names:
                        for k,v in aliesMap.items():
                            if v.lower().strip() == item:
                                cnames.append(k.lower()) 
                            #if
                        #for
                    #for
                #if
                else:
                    cnames = row["col"].lower().split(";")
                    cnames = [x.strip(' ') for x in cnames]
                #else
                column_list =  row["newcol"].lower()
                new_col_names = []
                if "$alias$" in column_list:
                    column_names = column_list.replace("$alias$","").split(";")
                    cnames = []
                    for item in column_names:
                        for k,v in aliesMap.items():
                            if v.lower() == item:
                                new_col_names.append(k.lower()) 
                            #if
                        #for
                    #for
                #if
                else:
                    new_col_names = row["newcol"].lower().split(";")
                    new_col_names = [x.strip(' ') for x in new_col_names]
                #else
                #PATTERN-1
                if 'replacevalue' == row["pattern"].lower():
                    logger.info("Inside Replace Value")
                    rule = row["rule"]
                    replaceValue =  row["with"]
                    originalValue =  row["on"]
                    for column,new_col in zip(cnames,new_col_names):
                        if "$REG$" in originalValue:
                            originalValue = originalValue.replace("$REG$","")
                            operation_list=[]
                            operation_list.append(replaceValue+"#"+originalValue)
                            op_lit = array(*[array(*[lit(op)]) for op in operation_list])
                            print(str(op_lit))
                            inputDF = inputDF.withColumn(new_col,regexReplaceUDF(col(column).cast("string"),op_lit))
                        #if
                        else:
                            if originalValue == 'null' or  originalValue == 'NULL' or originalValue == "":
                                logger.info("Replacing null value with:" + str(replaceValue))
                                inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),replaceValue)
                                        .otherwise(col(column)))
                            #if
                            if rule == 'Replace value with Regex':
                                logger.info("Replacing Regular expression")
                                inputDF = inputDF.withColumn(new_col,regexp_replace(col(column), originalValue, replaceValue))

                            else:
                                if new_col in inputDF.columns:
                                    inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column)).otherwise(when(col(column).cast("string") == originalValue, replaceValue).otherwise(col(new_col))))
                                else:
                                     inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column)).otherwise(when(col(column).cast("string") == originalValue, replaceValue)))
                                #else
                            #else
                        #else
                    #for
                #if  
                #PATTERN-2
                elif 'replacepartial' == row["pattern"].lower():
                    replaceValue =  row["with"]
                    originalValue =  row["on"]
                    logger.info("Replacing partial value with:" +str(replaceValue))
                    for column,new_col in zip(cnames,new_col_names):
                        if "$REG$" in originalValue:
                            group = row["grp"]
                            originalValue = originalValue.replace("$REG$","")
                            operation_list=[]
                            operation_list.append(replaceValue+"#"+originalValue+"#"+str(group))
                            op_lit = array(*[array(*[lit(op)]) for op in operation_list])
                            inputDF = inputDF.withColumn(new_col,regexPartialReplaceUDF(col(column).cast("string"),op_lit))
                        #if
                        else:
                            print("Replace partial " + str(originalValue) + "with " + str(replaceValue))
                            inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column))
                                    .otherwise(regexp_replace(col(column).cast("string"), originalValue, replaceValue ))
                                    )
                        #else
                    #for
                #elif
                #PATTERN-3
                elif 'anonymization' == row["pattern"].lower():
                    expression =  row["with"]
                    for column,new_col in zip(cnames,new_col_names):
                        logger.info("Anonymizing the column with:" + str(expression))
                        if "sha1" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,sha1(col(column)))
                        elif "sha2" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,sha2(col(column),256))
                        #if
                        elif "hex" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,hex(col(column)))
                        #elif
                        elif "base64" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,base64(col(column)))
                        #elif
                    #for
                #elif
                #PATTERN-4
                #elif 'imputation' == row["pattern"].lower():
                   #expression =  row["rule"]
                   #for column,new_col in zip(cnames,new_col_names):
                       #logger.info("Performing Imputation operation: " + expression)
                       #if "mean" in expression.lower():
                           #inputDF = inputDF.withColumn(new_col,_mean(col(column)))
                
                      # elif "median" in expression.lower():
                           #inputDF = inputDF.withColumn(new_col,col(column))
                        #if
                       #elif "mode" in expression.lower():
                           #inputDF = inputDF.withColumn(new_col,col(column)))

                #PATTERN-5
                elif 'functional' == row["pattern"].lower():
                    expression =  row["with"]
                    logger.info("Performing Functional operation: " + expression)
                    if "concat" in expression.lower():
                        value = row["value"]
                        inputDF = inputDF.withColumn(new_col_names[0],concat_ws(value, *(col(c) for c in cnames)))
                    #if
                    else:
                        for column,new_col in zip(cnames,new_col_names):
                            if "lower" in expression.lower():
                                inputDF = inputDF.withColumn(new_col,lower(col(column)))
                            #if
                            elif "upper" in expression.lower():
                                inputDF = inputDF.withColumn(new_col,upper(col(column)))
                            #elif
                            elif "base64" in expression.lower():
                                inputDF = inputDF.withColumn(new_col,base64(col(column)))
                            #elif
                            elif "substring" in expression.lower():
                                start_pos = row["start"]
                                substring_length = row["length"]
                                inputDF = inputDF.withColumn(new_col,substring(col(column), int(start_pos),int(substring_length)))
                            #elif
                            elif "dropduplicates" in expression.lower():
                                inputDF = inputDF.dropDuplicates()
                            #elif
                            elif "dropna" in expression.lower():
                                inputDF = inputDF.na.drop(subset=column)
                            #elif
                            elif "prefix" in expression.lower():
                                prefix_value = row["value"]
                                inputDF = inputDF.withColumn(new_col,concat(lit(" "+prefix_value),col(column).cast("string")))
                            #elif
                            elif "suffix" in expression.lower():
                                prefix_value = row["value"]
                                inputDF = inputDF.withColumn(new_col,concat(col(column).cast("string"),lit(" "+prefix_value)))
                            #elif
                            elif "removeaccent" in expression.lower() or 'accentremove' in expression.lower():
                                inputDF = inputDF.withColumn(new_col,accentRemovalUDF(col(column).cast("string")))
                            #elif
                            elif "ltrim" in expression.lower() :
                                inputDF = inputDF.withColumn(new_col,ltrim(col(column).cast("string")))
                            #elif
                            elif "rtrim" in expression.lower() :
                                inputDF = inputDF.withColumn(new_col,rtrim(col(column).cast("string")))
                            #elif
                            elif "trim" in expression.lower():
                                inputDF = inputDF.withColumn(new_col,trim(col(column).cast("string")))
                            elif "rpad" in expression.lower():
                                pad_length = int(row['length'])
                                pad_value = row['value']
                                inputDF = inputDF.withColumn(new_col,rpad(col(column).cast("string"),pad_length, pad_value ))
                            #elif
                            elif "lpad" in expression.lower():
                                pad_length = int(row['length'])
                                pad_value = row['value']
                                inputDF = inputDF.withColumn(new_col,lpad(col(column).cast("string"),pad_length, pad_value ))
                            #elif
                            elif "split" in expression.lower():
                                split_value = row['value']
                                split_grp = int(row['grp'])-1
                                inputDF = inputDF.withColumn(new_col,split(col(column).cast("string"),split_value )[split_grp])
                            #elif
                            elif "rename" in expression.lower():
                                inputDF = inputDF.withColumnRenamed(column,new_col)
                            #elifcolumn
                            elif "drop" in expression.lower():
                                inputDF = inputDF.drop(column)
                            #elif
                            elif "utf-8" in expression.lower():
                                inputDF = inputDF.withColumn(new_col, decode(col(column),'UTF-8'))
                            #elif
                            elif "unicode-escape" in expression.lower():
                                decode_udf = udf(lambda x: x.encode().decode('unicode-escape'),StringType())
                                inputDF = inputDF.withColumn(new_col, my_udf(column))
                            elif "trimdoublequotes" in expression.lower():
                                inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column))
                                .otherwise(regexp_replace(col(column).cast("string"), '"', "" )))
                            elif "tokenization" in expression.lower():
                                encryptionKey = dbutils.secrets.get(scope='Idfrgscope1',key='TokenizationKey')
                                inputDF = inputDF.withColumn(column, encrypt(col(column),lit(encryptionKey)))
                            
                            logger.info(str(expression) + " process completed successfully")
                            #elif
                        #for
                    #else
                #elif
            #for              
            destRowCount=inputDF.count()
            logger.info("Total records written in Curated: " + str(destRowCount))
           
            logger.debug("output path  is :" + output)
            inputDF.write.save(output,format=str(config_prop['target-format']),mode='overwrite')
            targetTableColCount=len(inputDF.columns)
            success_status_Desc="Data Rules engine Completed Successfully"
            audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'Succeeded',destRowCount,targetTableColCount,0,'NA')
            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
      
            inputDF.show()
            exit_doc['EXIT_CODE']=0
            return inputDF, exit_doc           
           
            
        #if
    #try
    except:
        try:
                             
            logger.error(traceback.print_exc())
            raise transformationError(transType)
        except transformationError as tne:
            audit_rec=TransformLoadDataVault(exit_doc,stage,tne,'Failed',0,0,0,'NA')
            audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,tne)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
            return 0,exit_doc #except
    finally:
        logger.info("End of "+ __name__+ " process...")
        #context.stop()
    #finally
# #def



