import traceback
import sys,os
import logging
import re
import hashlib
import time
from shutil import copyfile
import glob
from pyspark.sql import SparkSession
import datetime
from collections import OrderedDict
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import *
import  pyspark.sql.functions as F
from delta.tables import *
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/codebase/')
# sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-ingestion/')
# sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
from streamingMetadataManager import streamingMetadataManager
from utilsShared import UtilsShared
from UtilsCurate import UtilsCurate
from customException import *
from gen_audit_entry import *
from UtilStream import UtilsStream


class MultipleStreamsDataProcess:

    def __init__(self):
        pass
    # millis = int(round(time.time() * 1000))
    ###################################################################################################
    def process(conf,obj,inputDF,dbutils,exit_doc):
        job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")) 
        stage='multiple-streams-data-process'
        logger = UtilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
        validation_flag=False    
        spark = SparkSession.builder.appName(obj["use-case"]).getOrCreate()
        spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
        metadataObject = streamingMetadataManager()
        readDF = 0
        countValueSource = 1
        try:
            logger.info("Inside " + stage)
            audit_doc=OrderedDict()      
            #Create a readStream

            try:
                readDF = UtilsStream.readStream(spark,conf,obj,dbutils,logger)
            except:
                try :
                    logger.error(str(traceback.print_exc()))
                    err_desc = str(traceback.format_exc())            
                    raise readStreamException(err_desc)
                except readStreamException as rse:
                    audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',ue,job_start_time)
                    audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,ue)
                    metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0

            
            if 'data-source' in obj and 'eventhubs' in obj['data-source']:
                readDF = readDF.select("payload.*").drop('_corrupt_record')
            readDF = UtilsStream.streamTransform(spark,obj,readDF,logger)
                

            if "streamList" in obj:
                for stream in obj["streamList"]:
                    logger.info("Adding" + stream)
                    countValueSource = countValueSource + 1
                    streamObj = obj[stream]
                    streamObj['azure'] = obj['azure']
                    streamObj['local_log_file_name'] = obj['local_log_file_name']
                    streamObj['load_userid'] = obj['load_userid']
                    streamObj['log_file_name'] = obj['log_file_name']
                    streamObj['prcs-name'] = obj['prcs-name']
                    streamObj['sourceName'] = obj['sourceName']
                    streamReadDF = UtilsStream.readStream(spark,conf,streamObj,dbutils,logger)
                    
                    if 'data-source' in obj and 'eventhubs' in obj['data-source']:
                        streamReadDF = streamReadDF.select("payload.*").drop('_corrupt_record')               
                    
                    streamReadDF = UtilsStream.streamTransform(spark,streamObj,streamReadDF,logger)
                    
                    readDF = UtilsStream.combine_source(spark,obj,countValueSource,streamObj,streamReadDF,readDF,logger)
                    print("After JOIN")
            
            if "foreachBatch" in obj and str(obj['foreachBatch']).lower() == 'true':
                outputStream = UtilsStream.writeStream(spark,readDF,conf,obj,dbutils,audit_doc,exit_doc,logger)
            else:
                checkpoint = obj['azure']['checkpoint-base-path'] + obj['targetStream']['targetDir']
                readDF.writeStream.format(obj['targetStream']['targetFormat']).outputMode(obj['targetStream']['mode_of_write']).option("checkpointLocation", checkpoint).table(obj['targetStream']['targetDir'])
            #readDF.writeStream.format("console").start()                               

            return inputDF
        except:
            try :
                logger.error(str(traceback.print_exc()))
                err_desc = str(traceback.format_exc())        
                raise uncatchException(err_desc)
            except uncatchException as ue:
                audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',ue,job_start_time)
                audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,ue)
                metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                UtilsStream.stopStream(spark,logger)
                exit_doc["EXIT_CODE"]=0
                return 0