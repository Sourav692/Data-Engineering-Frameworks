import traceback
import sys,os
import logging
import re
import hashlib
import time
import glob
from pyspark.sql.functions import udf,lit,split,input_file_name,reverse,split,monotonically_increasing_id,col,collect_list
from pyspark.sql.types import StringType, DateType, IntegerType,TimestampType
from pyspark.sql import SparkSession
import Utils
from metadataManager import metadataManager
import datetime
from collections import OrderedDict
from pyspark.sql import DataFrame as SparkDataFrame


sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
from customException import *
from gen_audit_entry import *

millis = int(round(time.time() * 1000))
###################################################################################################



def process(obj,inputDF,dbutils, exit_doc):
	return 0, exit_doc