import traceback
import sys
import json
import logging
import re
import datetime
import hashlib
import pyspark
import glob
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession,DataFrame,SQLContext
from pyspark.sql.functions import lit,col,udf,trim
from collections import OrderedDict
import time
import os

# Custom Libs
from metadataManager import metadataManager
import utilsTrans
import utilsIO

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')


from customException import *
from gen_audit_entry import *
import utilsShared

millis = int(round(time.time() * 1000))
start_time =str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
inputPath=''
#M1
"""
Process to extract data from curated and enriched layer (For lookups) And transformed it as per business requirements
"""
def process(obj,hashDF,dbutils,exit_doc):
	# Logger initialization
	stage='data-extract-process'
	logger = utilsShared.getFormattedLogger(stage, obj['local_log_file_name'])

	# Spark session  with required conf initialzation
	conf = pyspark.SparkConf()
	spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
	spark.conf.set("spark.sql.crossJoin.enabled", True)
	PRC_EXECUTION_ID=str(hashlib.md5(str(millis).encode()).hexdigest())

	metadataObject = metadataManager()
	combineFlag = isinstance(hashDF,DataFrame)

	audit_doc = OrderedDict()

	try:
		#Reading all the source one by one and apply join and union with last Dataframe
		countValueSource = 0
		baseDF = 0
		print(len(obj["sourceList"]))
		master_Data_validation_flag=False
		for source in obj["sourceList"]:
			print(countValueSource)
			countValueSource = countValueSource + 1
			sourceDict = obj[source]
			if "type" in sourceDict:
				sourceType = sourceDict["type"]
			else:
				sourceType = "curated-zone"
			logger.debug("Processing source " + source + " with source-type " + sourceType)
			if "alias" in sourceDict:
				colAlias = sourceDict["alias"]
			else:
				colAlias = 0
			# Read from the source - curated zone or ADV
			if sourceType == "curated-zone":
				if "read-type" in sourceDict:
					readType = str(sourceDict["read-type"])
				else:
					readType = "batch-date-single"
				logger.debug("Processing readType as  " + readType)
				dependency_flag=True
				if "check-dependency" in sourceDict:
					dependency_flag = utilsTrans.check_dependency_extract(spark,sourceDict,obj,logger)							

				if dependency_flag:
					# read from single file or multiple files
					if readType == "batch-date-single":
						inputPath,inputPathList = utilsTrans.get_curated_base_path(spark,sourceDict,obj,logger)
					print(inputPath)
					logger.debug("Input Path "+str(inputPath))
					logger.info("Input Path list is:"+str(inputPathList))
					inputFileCounter = 0
					sourceDF = 0
					for dynamicInputPath in inputPathList:
						try:
							listOfFiles = glob.glob(dynamicInputPath)
							if len(listOfFiles) == 0 :
								if os.path.isdir(dynamicInputPath)==False:
									logger.error("File not found for path:"+str(dynamicInputPath))
									raise fileNotFoundError(dynamicInputPath)
								continue
						except fileNotFoundError as fnf:
							logger.error(e)
							audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',fnf)
							audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,fnf)
							metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
							exit_doc["EXIT_CODE"]=0
							return 0,exit_doc
						try:
							# Updated by arindom Task #306
							# tempDF = spark.read.parquet(dynamicInputPath[5:])	##Reading from parquet i.e. Curated zone
							tempDF = spark.read.format(obj[source]['file-format']).load(dynamicInputPath[5:])
						except Exception as e:
							try:
								logger.error(e)
								raise fileNotFoundError(dynamicInputPath[5:])
							except fileNotFoundError as fnf:
								audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',fnf)
								audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,fnf)
								print(audit_doc)
								metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
								exit_doc["EXIT_CODE"]=0
								return 0,exit_doc
						size = utilsTrans.gen_tgt_file_sz(dbutils,dynamicInputPath,logger)						
						try:
							bid=tempDF.select("BATCH_ID").distinct().first()[0]
							audit_doc["PRCS_EXECUTION_ID"],exit_doc['PRCS_EXECUTION_ID']=bid, bid
							PRC_EXECUTION_ID=bid
						except :
							audit_doc["PRCS_EXECUTION_ID"],exit_doc['PRCS_EXECUTION_ID']=str(hashlib.md5(str(millis).encode()).hexdigest()), str(hashlib.md5(str(millis).encode()).hexdigest())
							tempDF=tempDF.withColumn("BATCH_ID",lit(audit_doc["PRCS_EXECUTION_ID"]))
						# extract the required columns
						#tempDF = utilsIO.get_col_with_alias(tempDF,sourceDict["cols"],colAlias)
						if inputFileCounter == 0 :
							sourceDF = tempDF
						else:
							sourceDF = utilsTrans.df_union(sourceDF,tempDF)
						# read data for current financial year and given forcast index
						if "forecast-plan-flag" in sourceDict :
							sourceDF = utilsTrans.forecast_plan_process(spark,obj,sourceDict,sourceDF,dynamicInputPath,logger)
						elif "prod17-flag" in sourceDict and "incremental-flag" in sourceDict:
							sourceDF=utilsTrans.gen_prod17_inc_delta_identifier(obj,dbutils,dynamicInputPath,sourceDF,logger)
							if sourceDF!=0:
								pass
							else:
								try:
									logger.error(" exiting job as Curated file for current batchdate is not present or Failed while data validation ")
									raise noIncrementalData(utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),str(sourceDict["path"]) +str(sourceDict["fileName"]))
								except noIncrementalData as cbf:
									audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',cbf)
									audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,cbf)
									metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
									exit_doc["EXIT_CODE"]=0
									return 0,exit_doc
						if "last-month-available-flag" in sourceDict:
							print(obj["batchDate"],"last-month-available-flag")
							availability_flag=utilsTrans.get_last_mth_available_flag(dbutils,dynamicInputPath,obj["batchDate"],logger)
							if availability_flag!=0:
								pass
							else:
								try:
									logger.error(" exiting job as Curated file for current batchdate is not present or Failed while data validation ")
									raise noIncrementalData(utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),str(sourceDict["path"]) +str(sourceDict["fileName"]))
								except noIncrementalData as cbf:
									audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',cbf)
									audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,cbf)
									metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
									exit_doc["EXIT_CODE"]=0
									return 0,exit_doc
						if "cols" in sourceDict:
							sourceDF = utilsIO.get_col_with_alias(sourceDF,sourceDict["cols"],sourceDict,colAlias)
						inputFileCounter = inputFileCounter +1
						logger.debug("Dataframe Count "+ str(sourceDF.count()))
					# skip if the source is not available
					if not isinstance(sourceDF,DataFrame) :
						countValueSource = countValueSource - 1
						continue
				else:
					try:
						logger.error(" exiting job as Curated file for current batchdate is not present or Failed while data validation ")
						raise noIncrementalData(utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),str(sourceDict["path"]) +str(sourceDict["fileName"]))
					except noIncrementalData as cbf:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',cbf)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,cbf)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc
						#raise Exception(" exiting job as Curated file for current batchdate is not present or Failed while data validation ")
			# Read from dwh-enrich (fcp)
			elif sourceType == "dwh-enrich" :
				tableName = str(sourceDict["table-name"])
				exception_table_name="idfrgpoc.C2E_EXCEPTIONS"
				dependency_flag=True
				if "check-dependency" in sourceDict:
					dependency_flag = utilsTrans.check_dependency_extract(spark,sourceDict,obj,logger)

				if dependency_flag:
					""" code in progress  to load Dim table from Transaction to avoid missing dimensions in Fact table, would go in
					 functions in utilsTrans"""
					try:
						sourceDF = utilsIO.read_enrich(spark,tableName,obj,sourceDict)
					except Exception as ex:
						try: 
							logger.error(traceback.print_exc())
							raise dbReadError(tableName)
						except dbReadError as dbe:
							audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',dbe)
							audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
							print("audit_doc",audit_doc)
							metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
							exit_doc["EXIT_CODE"]=0
							return 0,exit_doc					
					# Generate Distinct Dimension from Transaction file
					required_col_list=sourceDict["combine"]["base-table-key"]+["SRC_ID","BATCH_ID"]
					distinct_dim=baseDF.select(required_col_list).distinct()

					src_table_keys=sourceDict["combine"]['source-table-Actual-key'] if "source-table-Actual-key" in sourceDict["combine"] else sourceDict["combine"]['source-table-key']
					missing_dim=utilsTrans.df_join(distinct_dim,sourceDict["combine"]['base-table-key'],sourceDF,src_table_keys,logger,"left_anti")
					missing_dim=missing_dim.select(required_col_list)
					
					missing_dim.show()
					if "missing-dimensions-ingestion-flag" in sourceDict:
						missing_dim_with_metadata_cols=utilsTrans.gen_tgt_schema_fr_missing_dim(missing_dim,sourceDict,obj)
					
						HASH_TABLE=utilsTrans.match_target_table_schema(spark,missing_dim_with_metadata_cols,obj,tableName)
						if HASH_TABLE.count() >0:
							try:
								utilsIO.write_enrich(dbutils, HASH_TABLE, spark, obj, 'append',tableName)
							except Exception as ex:
								try: 
									logger.error(traceback.print_exc())
									raise dbInsertError(tableName)
								except dbInsertError as dbe:
									audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',dbe)
									audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)	
									print(audit_doc)
									metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
									exit_doc["EXIT_CODE"]=0
									return exit_doc
							sourceDF = utilsIO.read_enrich(spark,tableName,obj,sourceDict)
					exception_df=utilsTrans.gen_exception_schema(spark,missing_dim,obj,sourceDict,logger)
					if len(exception_df.head(1))>0:
						master_Data_validation_flag=True
						try:
							utilsIO.write_enrich(dbutils, exception_df, spark, obj, 'append',exception_table_name)
						except Exception as ex:
							try: 
								logger.error(traceback.print_exc())
								raise dbInsertError(exception_table_name)
							except dbInsertError as dbe:
								audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',dbe)
								audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
								print(audit_doc)
								metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
								exit_doc["EXIT_CODE"]=0
								return 0,exit_doc
					sourceDF = utilsIO.get_col_with_alias(sourceDF,sourceDict["cols"],sourceDict,colAlias)
				else:
					try:
						logger.info("exiting job as "+ tableName + " is not populated for current batchdate")
						raise noIncrementalData(utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),tableName)
						#raise Exception(" curated_to_enriched process for this table and expecting file didnt finish yet ")
					except noIncrementalData as fnf:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',fnf)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,fnf)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc

			logger.debug("File/Table count "+ str(sourceDF.count()))
			# Generated dervied key by source
			if "derived-key-process" in sourceDict:
				objDict = sourceDict["derived-key-process"].copy()
				transType="derived-key-process"
				try:
					sourceDF = utilsTrans.derived_key_process(spark,objDict,sourceDF,logger,obj["batchDate"])
				except Exception as ex:
					try:
						logger.error(traceback.print_exc())
						raise transformationError(transType+ "source :"+source)
					except transformationError as te:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',te)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,te)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc
				logger.debug("derived-key-process completed")
			# Filter processed key
			if "filter" in sourceDict:
				transType="filter"
				objDict = sourceDict["filter"].copy()
				try:
					sourceDF= utilsTrans.source_filter(spark,objDict,sourceDF,obj["batchDate"],logger)
				except Exception as ex:
					try:
						logger.error(traceback.print_exc())
						raise transformationError(transType+ "source :"+source)
					except transformationError as te:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',te)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,te)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc
				logger.debug("File/Table count After processed filter "+ str(sourceDF.count()))
			# Default value generation
			if "default-value" in sourceDict:
				objDict = sourceDict["default-value"].copy()
				sourceDF = utilsTrans.default_vaule_process(spark,objDict,hashDF,logger)
				logger.debug("default-value completed")
			# Renaming columns
			if "source-alias" in sourceDict:
				print(" in Source Alias")
				objDict = sourceDict["source-alias"].copy()
				sourceDF = utilsTrans.source_alias(spark,objDict,sourceDF,logger)
				logger.debug("source-alias completed")

			#Skip join if first table
			try:
				transType="Combine"
				baseDF = utilsTrans.combine_source(spark,obj,countValueSource,sourceDict,sourceDF,baseDF,logger)
			except Exception as ex:
				try:
					logger.error(traceback.print_exc())
					raise transformationError(transType+ "source :"+source)
				except transformationError as te:
					audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',te)
					audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,te)
					print(audit_doc)
					metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
					exit_doc["EXIT_CODE"]=0
					return 0,exit_doc

			if "custome-query" in sourceDict:
				transType="custom-query"
				objDict = sourceDict["custome-query"].copy()
				try:
					baseDF = utilsTrans.custom_query_execution(spark,objDict,baseDF,logger)
				except Exception as ex:
					try:
						logger.error(traceback.print_exc())
						raise transformationError(transType+ "source :"+source)
					except transformationError as te:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',te)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,te)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc			
			# Restricting the columns need to pass to next source or next operation
			if "derived-key-process-l1" in sourceDict:
				objDict = sourceDict["derived-key-process-l1"].copy()
				transType="derived-key-process-level-1"
				try:
					baseDF = utilsTrans.derived_key_process(spark,objDict,baseDF,logger,obj["batchDate"])
				except Exception as ex:
					try:
						logger.error(traceback.print_exc())
						raise transformationError(transType+ "source :"+source)
					except transformationError as te:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',te)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,te)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc
				logger.debug("derived-key-process completed")
			if "target-col-list" in sourceDict:
				target_col_list = sourceDict["target-col-list"]
				print(baseDF.columns)
				baseDF=baseDF.select(target_col_list)
			# Assign other column if value is null
			if "assign-non-null-value" in sourceDict:
				objDict = sourceDict["assign-non-null-value"].copy()
				baseDF = utilsTrans.assign_non_null_value(spark,objDict,baseDF,logger)
			print(baseDF.count())

			if baseDF.count()>0:
				pass
			else:
				if str(obj["scd_type"]).lower()=='append':
					try:
						raise noIncrementalData(utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),0)
					except noIncrementalData as nid:
						audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',nid)
						audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,nid)
						print(audit_doc)
						metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
						exit_doc["EXIT_CODE"]=0
						return 0,exit_doc
				else:

					audit_rec=CuratedAfterDestinationwrite(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,"Succeeded","Data extract completed successfully! No new data  found to process further",str(inputPath),0,0,size,0,0,obj['log_file_name'],master_Data_validation_flag)
					audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
					print(audit_doc)
					metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
					exit_doc['EXIT_CODE']=0
					return 0, exit_doc
					#audit_doc["STATUS"],exit_doc['STATUS'] = "Succeeded", "Succeeded"
					#audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'] = "Data extract completed successfully! No new data  found to process further","Data extract completed successfully! No new data  found to process further"
					#audit_doc["JOB_START_TIME"], exit_doc['JOB_START_TIME'] = start_time,start_time
					#audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']  = "",""
					#audit_doc["SOURCE_PATH"], exit_doc['SOURCE']['SOURCE_PATH'] = str(inputPath),str(inputPath)
					#audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = "",""
					#audit_doc["SOURCE_COL_COUNT"], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = "",""
					#audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT'] = "",""
					#audit_doc["SOURCE_FILE_SIZE"], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = "",""
					#audit_doc["DEST_PATH"], exit_doc['DESTINATION']['DEST_PATH'] = "",""
					#audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = '0','0'
					#audit_doc["DEST_COL_COUNT"], exit_doc['DESTINATION']['DEST_COL_COUNT'] = '0','0'
					#audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT'] = "",""
					#audit_doc["DEST_FILE_SIZE"], exit_doc['DESTINATION']['DEST_FILE_SIZE'] = "",""
					#audit_doc["REJECTED_ROW_COUNT"], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = "",""
					#audit_doc["REJECTED_FILE_NAME"], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = "",""
					#audit_doc["LOG_PATH"] = log_filename
					#audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
					#return 0, exit_doc
				# Updating the combine flag to true after first run - Should combine next source in case
		# Combine the baseDF with the master/Hash df if present
		if combineFlag and "master-combine" in obj:
			#Join with the master/hash Table
			joinType = "inner"
			if "join-type" in obj["master-combine"]:
				joinType = str(obj["master-combine"]["join-type"])
			logger.debug("Applying join of type " + str(joinType)+ " with the base table.")
			hashDF = utilsTrans.df_join(hashDF,obj["master-combine"]['master-table-key'],baseDF,obj["master-combine"]['base-table-key'],logger,joinType)
		else:
			hashDF = baseDF
		#logger.debug("Count of Master DF after join : "+ str(hashDF.count()))
		# creating Audit Entry to push into process execution file
		logger.debug("Before calling CuratedAfterDestinationwrite" + str(obj["batchDate"]))
		audit_rec=CuratedAfterDestinationwrite(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,"In Progress","Data extract completed successfully!",str(inputPath),hashDF.count(),len(hashDF.columns),size,hashDF.count(),len(hashDF.columns),obj['log_file_name'],master_Data_validation_flag)
		logger.debug("After calling CuratedAfterDestinationwrite" + str(audit_rec.BATCH_DATE))
		logger.debug("audit_rec Batch Date")
		audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
		print(audit_doc)
		logger.debug("After calling gen_audit_dict, going to insert data into process_execution")
		#metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
		exit_doc["EXIT_CODE"]=0
		logger.info("Audit record saved successfully for data-extract-process")
		return hashDF, exit_doc

		#audit_doc["STATUS"],exit_doc['STATUS'] = "In Progress","In Progress"
		#audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'] = "Data extract completed successfully!","Data extract completed successfully!"
		#audit_doc["JOB_START_TIME"], exit_doc['JOB_START_TIME'] = start_time,start_time
		#audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME'] = "",""
		#audit_doc["SOURCE_PATH"], exit_doc['SOURCE']['SOURCE_PATH'] = str(inputPath),str(inputPath)
		#audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = "",str(hashDF.count())
		#audit_doc["SOURCE_COL_COUNT"], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = "",str(len(hashDF.columns))
		#audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT'] = "",""
		#audit_doc["SOURCE_FILE_SIZE"], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = "",""
		#audit_doc["DEST_PATH"], exit_doc['DESTINATION']['DEST_PATH'] = "",""
		#audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = str(hashDF.count()),str(hashDF.count())
		#audit_doc["DEST_COL_COUNT"], exit_doc['DESTINATION']['DEST_COL_COUNT'] = str(len(hashDF.columns)),str(len(hashDF.columns))
		#audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT'] = "","" 
		#audit_doc["DEST_FILE_SIZE"], exit_doc['DESTINATION']['DEST_FILE_SIZE'] = "","" r
		#audit_doc["REJECTED_ROW_COUNT"], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = "",""
		#audit_doc["REJECTED_FILE_NAME"], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = "",""
		#audit_doc["LOG_PATH"] = log_filename
		#audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
		logger.debug(str(audit_doc))
		#####Doubt Not writing to prcs_execution
		#metadataObject.insert_auditRecord(audit_doc)
		#logger.debug("Inserted Audit Entry - Job Successfull")
		# Return the master dataframe
		hashDF.show()
		#return hashDF, exit_doc
	#try
	except:
		print("======= In Data-Extract  =============== Except block")
		logger.error(str(traceback.print_exc()))
		err_desc = str(traceback.format_exc())
		try :
			logger.error(traceback.print_exc())
			raise uncatchException(err_desc)
		except uncatchException as ue:
			audit_rec=CuratedBeforeSourceRead(obj,utilsTrans.gen_batch_Date_formatted(obj["batchDate"],logger),PRC_EXECUTION_ID,'Failed',ue)
			audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
			print(audit_doc)
			print(exit_doc)
			metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
			exit_doc["EXIT_CODE"]=0
			return 0,exit_doc
		
	#	logger.error(str(traceback.print_exc()))
	#	audit_doc["STATUS"],exit_doc['STATUS'] = "Failure","Failure"
	#	ERROR_DESC = str(traceback.format_exc())
	#	audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'] = ERROR_DESC[:255],ERROR_DESC
	#	audit_doc["JOB_START_TIME"], exit_doc['JOB_START_TIME'] = start_time,start_time
	#	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME'] = "",""
	#	audit_doc["SOURCE_PATH"], exit_doc['SOURCE']['SOURCE_PATH'] = "",""
	#	audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = "",""
	#	audit_doc["SOURCE_COL_COUNT"], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = "",""
	#	audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT'] = "",""
	#	audit_doc["SOURCE_FILE_SIZE"], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = "",""
	#	audit_doc["DEST_PATH"], exit_doc['DESTINATION']['DEST_PATH'] = "",""
	#	audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = "",""
	#	audit_doc["DEST_COL_COUNT"] , exit_doc['DESTINATION']['DEST_COL_COUNT']= "",""
	#	audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT'] = "",""
	#	audit_doc["DEST_FILE_SIZE"], exit_doc['DESTINATION']['DEST_FILE_SIZE'] = "",""
	#	audit_doc["REJECTED_ROW_COUNT"], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = "",""
	#	audit_doc["REJECTED_FILE_NAME"], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = "",""
	#	audit_doc["LOG_PATH"] = log_filename
	#	audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")),str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
	#	logger.debug(str(audit_doc))
	#	metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
	#	logger.debug("Inserted Audit Entry - Job Failure")
	#	traceback.print_exc()
	#	raise ValueError("ERROR in "+ __name__+ " for type "+ str(obj['type']) + " >>" + str(traceback.format_exc()))
	
	#except
	finally:
		logger.info("End of "+ __name__+ " process...")
		#sqlContext.clearCache()
		#context.stop()
	#finally
###################################################################################################
