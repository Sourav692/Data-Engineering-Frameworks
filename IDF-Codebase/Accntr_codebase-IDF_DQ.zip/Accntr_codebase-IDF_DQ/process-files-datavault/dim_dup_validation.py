import traceback
import sys
import json
import logging
import re
import datetime
import hashlib
import pyspark
import glob
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession,DataFrame,SQLContext
from pyspark.sql.functions import lit,col,udf,trim
from collections import OrderedDict
import time
import os
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

# Custom Libs
import utilsTrans
import utilsIO

#M1
"""
Process to extract data from curated and enriched layer (For lookups) And transformed it as per business requirements
"""
def process(obj,exit_doc):
	print("inside datavault script")
	# Logger initialization
	log_filename = obj['log_path'] + obj['pipelineName'] +"_"+ obj['config_name'] + "_"+str(datetime.datetime.strftime(datetime.datetime.now(),'%Y%m%d')) + '.log'
	logger = logging.getLogger("data-extract-process")
	logger.setLevel(logging.DEBUG)
	file_handler = logging.FileHandler(log_filename)
	file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	file_handler.setFormatter(file_format)
	logger.addHandler(file_handler)
	logging.getLogger("py4j").setLevel(logging.ERROR)

	# Spark session  with required conf initialzation
	conf = pyspark.SparkConf()
	spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
	spark.conf.set("spark.sql.crossJoin.enabled", True)

	try:
		dups_json=utilsTrans.dup_validation(obj,spark)
		exit_doc["STATUS"]='Succeeded'
		exit_doc["STATUS_DESC"]='Completed Successfully!'
		exit_doc["DUPLICATES_IN_DIM"]=dups_json
		return exit_doc
	#try	
	except:
		exit_doc["STATUS"]='Failure'
		exit_doc["STATUS_DESC"]=str(traceback.print_exc())[:255]
		exit_doc["DUPLICATES_IN_DIM"]=''
		return exit_doc
		raise ValueError("ERROR in "+ __name__+ " for type "+ str(obj['type']) + " >>" + str(traceback.format_exc()))
	#except
	finally:
		logger.info("End of "+ __name__+ " process...")
		#sqlContext.clearCache()
		#context.stop()
	#finally
###################################################################################################
