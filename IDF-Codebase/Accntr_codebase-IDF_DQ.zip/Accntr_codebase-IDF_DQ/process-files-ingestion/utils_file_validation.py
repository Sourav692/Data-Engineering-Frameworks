"""utils_file_validation.py

        @description: Checks different File validation test cases
"""
import os
import logging
import hashlib
import json
import re
import csv
import string 
import glob
import jsonschema
from pyspark.sql.functions import *
import chardet
import magic

class UtilsFileValidation:
    """
    @description: Checks different File validation test cases
    @contents:
        1.file_hash_to_equal
        2.file_size_to_be_between
        3.file_to_be_valid_json
        4.file_to_have_valid_table_header
        5.assert_csv_file_correct
        6.assert_csv_files_correct
        7.assert_text_file_correct
        8.assert_text_files_correct
        9.assert_binary_file_correct
        10.file_to_exist    
    """
    def file_hash_to_equal(self,path,value,hash_al,logger):

        """
        @description: check if the file hash is equal to the input string
        @params: path,value,hash_al
        @returns: a boolean
        
        """
    
        buf_size = 65536

    
        alg = hashlib.new(hash_al)

        with open(path) as file_s:
            while True:
                data = file_s.read(buf_size).encode('utf-8')
                if not data:
                    break
                alg.update(data)
        

        if alg.hexdigest() == value:
            result = True
        else:
            result = False
    
        logger.info("hash value" + alg.hexdigest())
        return result



    def file_size_to_be_between(self,path,minsize,maxsize,logger):
        
        """
            @description: check if the file size is between the maxsize and minsize
            @params: path,minsize,maxsize,logger
            @returns: a boolean
        """
        try:
            size = os.path.getsize(path)
            if not float(minsize).is_integer():
                logger.info("minsize must be an integer")
            minsize = int(float(minsize))

            if not float(maxsize).is_integer():
                logger.info("maxsize must be an integer")
            maxsize = int(float(maxsize))
        except ValueError:
            logger.info("Please enter a valid input.")

        if minsize < 0:
            logger.error("minsize must be greater than or equal to 0")

        if maxsize < 0:
            logger.error("maxsize must be greater than or equal to 0")

        if minsize > maxsize:
            logger.error("maxsize must be greater than or equal to minsize")


        if (size >= minsize) and (size <= maxsize):
            result = True
        else:
            result = False

        logger.info("File size is" + str(size))
        return result



    def file_to_be_valid_json(self,path,logger,schema=None):

        """
            @description: check if the file is a valid JSON
            @params: path,schema,logger
            @returns: a boolean   
        """
        result = False
        try:
        
            with open(path) as file_s:
                jstr = json.loads(file_s.read())
            if schema is None:
                result = True
            else:
                jsonschema.validate(jstr, schema)
            result = True
        except jsonschema.exceptions.ValidationError as error:
            logger.info("The JSON structure is not matching with the Schema:", error)
        except json.decoder.JSONDecodeError as error:
            logger.info("Not valid JSON:", error)
        
        return result



    def file_to_have_valid_table_header(self,path,delimiter,regex,logger,skip):

        """
        @description: check if the header names are distinct and they contain valid characters
        @params: path,delimiter,regex,logger,skip
        @returns: a boolean   
        """
        try:
            with open(path) as file_s:
                lines = file_s.readlines()  
            comp_regex = re.compile(regex)
        except ValueError:
            logger.info("Must enter valid input")

        if skip !=0 and skip <= len(lines):
            for i in range(1, skip + 1):
                lines.pop(0)
        
        result = False

        header_line = lines[0].strip()
        header_delim = header_line.split(delimiter)
        header_names = comp_regex.split(header_line)
        if len(header_delim) == len(header_names):
            if len(header_delim) == len(set(header_delim)):
                result = True
        
        return result


    def assert_csv_file_correct(self,path,logger):
        """
            @description: Checks if the file provided is a valid CSV file.
            @params: path,logger
            @returns: a boolean
        """
        try:
            with open(path, newline='') as csvfile:
                start = csvfile.read(4096)
                file_ext=path.split('.')[-1]

                # isprintable does not allow newlines, printable does not allow umlauts...
                if not all([c in string.printable or c.isprintable() for c in start]):
                    return False
                elif (file_ext=='csv'):  
                    dialect = csv.Sniffer().sniff(start)
                    return True
                else:
                    return False
        except csv.Error:
            logger.error("Could not identify csv")
            # Could not get a csv dialect -> probably not a csv.
            return False


    def assert_csv_files_correct(self,path,logger):
        """
            @description: Checks the folder path and gives a count of valid CSV files and names of the invalid files.
            @params: path,logger
            @returns: a string
        """
        valid=0
        invalid=0
        dict={"Valid files":[],"Invalid files":[],"Invalid filename":[]}
        csv=[]
        csv_failed=[]
        for file in glob.glob(path+'/*.csv'):
            self.assert_csv_file_correct(file,logger)
            if self.assert_csv_file_correct(file,logger)==True:
                csv.append(file.split('/')[-1])
                valid=valid+1
            else:
                csv_failed.append(file.split('/')[-1])
                invalid=invalid+1
        dict["Valid files"].append(valid)
        dict["Invalid files"].append(invalid)
        dict["Invalid filename"].append(csv_failed)
        dict2=str(dict)
        return dict2

     
    def assert_text_file_correct(self,path,logger):
        """
            @description: Checks if the file provided is a valid Text file.
            @params: path,logger
            @returns: a boolean
        """
        file_ext=path.split('.')[-1]
        f = magic.Magic(mime=True)
        k=f.from_file(path)
        if k=='text/plain' and file_ext =='txt' :
            return True 
        else:
            return False

    
    def assert_text_files_correct(self,path,logger):
        """
            @description: Checks the folder path and gives a count of valid Text files and names of the invalid files.
            @params: path,logger
            @returns: a string
        """
        valid=0
        invalid=0
        txt=[]
        txt_failed=[]
        dict={"Valid files":[],"Invalid files":[],"Invalid filename":[]}
        for file in glob.glob(path+'/*.txt'):
            self.assert_text_file_correct(file,logger)
            if self.assert_text_file_correct(file,logger)==True:
                txt.append(file.split('/')[-1])
                valid=valid+1
            else:
                txt_failed.append(file)
                invalid=invalid+1 
        dict["Valid files"].append(valid)
        dict["Invalid files"].append(invalid)
        dict["Invalid filename"].append(txt_failed)
        dictTxt=str(dict)
        return dictTxt


    # -*- coding: utf-8 -*-


    """
    binaryornot
    -------------------

    """     
    def assert_binary_file_correct(self,path,logger):
        """
            @description: Checks if the file provided is a valid Binary file.
            @params: path,logger
            @returns: a boolean
        """
        _control_chars = b'\n\r\t\f\b'
        if bytes is str:
            # Python 2 means we need to invoke chr() explicitly
            _printable_ascii = _control_chars + b''.join(map(chr, range(32, 127)))
            _printable_high_ascii = b''.join(map(chr, range(127, 256)))
        else:
            # Python 3 means bytes accepts integer input directly
            _printable_ascii = _control_chars + bytes(range(32, 127))
            _printable_high_ascii = bytes(range(127, 256))
        # Ensure we open the file in binary mode
        length=1024
        try:
            with open(path, 'rb') as f:
                chunk = f.read(length)
        except IOError as e:
            print(e)
       
        logger.debug('is_binary: %(path)r', locals())

        # Check if the file extension is in a list of known binary types
    #     binary_extensions = ['.pyc', ]
    #     for ext in binary_extensions:
    #         if filename.endswith(ext):
    #             return True

        # Check if the starting chunk is a binary string
        #chunk = get_starting_chunk(filename)
        #return is_binary_string(chunk)
        """
        Uses a simplified version of the Perl detection algorithm,
        based roughly on Eli Bendersky's translation to Python:
        http://eli.thegreenplace.net/2011/10/19/perls-guess-if-file-is-text-or-binary-implemented-in-python/
        This is biased slightly more in favour of deeming files as text
        files than the Perl algorithm, since all ASCII compatible character
        sets are accepted as text, not just utf-8.
        :param bytes: A chunk of bytes to check.
        :returns: True if appears to be a binary, otherwise False.
        """

        # Empty files are considered text files
        if not chunk:
            return False

        # Now check for a high percentage of ASCII control characters
        # Binary if control chars are > 30% of the string
        low_chars = chunk.translate(None, _printable_ascii)
        nontext_ratio1 = float(len(low_chars)) / float(len(chunk))
        logger.debug('nontext_ratio1: %(nontext_ratio1)r', locals())

        # and check for a low percentage of high ASCII characters:
        # Binary if high ASCII chars are < 5% of the string
        # From: https://en.wikipedia.org/wiki/UTF-8
        # If the bytes are random, the chances of a byte with the high bit set
        # starting a valid UTF-8 character is only 6.64%. The chances of finding 7
        # of these without finding an invalid sequence is actually lower than the
        # chance of the first three bytes randomly being the UTF-8 BOM.

        high_chars = chunk.translate(None, _printable_high_ascii)
        nontext_ratio2 = float(len(high_chars)) / float(len(chunk))
        logger.debug('nontext_ratio2: %(nontext_ratio2)r', locals())

        if nontext_ratio1 > 0.90 and nontext_ratio2 > 0.90:
            return True

        is_likely_binary = (
            (nontext_ratio1 > 0.3 and nontext_ratio2 < 0.05) or
            (nontext_ratio1 > 0.8 and nontext_ratio2 > 0.8)
        )
        logger.debug('is_likely_binary: %(is_likely_binary)r', locals())

        # then check for binary for possible encoding detection with chardet
        detected_encoding = chardet.detect(chunk)
        logger.debug('detected_encoding: %(detected_encoding)r', locals())

        # finally use all the check to decide binary or text
        decodable_as_unicode = False
        if (detected_encoding['confidence'] > 0.9 and
                detected_encoding['encoding'] != 'ascii'):
            try:
                try:
                    chunk.decode(encoding=detected_encoding['encoding'])
                except TypeError:
                    # happens only on Python 2.6
                    unicode(chunk, encoding=detected_encoding['encoding'])  # noqa
                decodable_as_unicode = True
                logger.debug('success: decodable_as_unicode: '
                            '%(decodable_as_unicode)r', locals())
            except LookupError:
                logger.debug('failure: could not look up encoding %(encoding)s',
                            detected_encoding)
            except UnicodeDecodeError:
                logger.debug('failure: decodable_as_unicode: '
                            '%(decodable_as_unicode)r', locals())

        logger.debug('failure: decodable_as_unicode: '
                    '%(decodable_as_unicode)r', locals())
        if is_likely_binary:
            if decodable_as_unicode:
                return False
            else:
                return True
        else:
            if decodable_as_unicode:
                return False
            else:
                if b'\x00' in chunk or b'\xff' in chunk:
                    # Check for NULL bytes last
                    logger.debug('has nulls:' + repr(b'\x00' in chunk))
                    return True
            return False

    def file_to_exist(self,path):
        """
            @description: check if the file exists
            @params: path
            @returns: a boolean
        """
        return os.path.isfile(path)

    def file_string_match(self,path,user_str):
        """
            @description: check if string provided exists in a file
            @params: path,string
            @returns: a boolean
        """
        with open(path) as f:
            result = False
            if user_str in f.read():
                result = True
        return result

    def files_hash_to_equal(self,path_a,path_b,hash_al,logger):
        """
            @description: check if the hash of two files are equal
            @params: path,value,hash_al
            @returns: a boolean
            
        """
        
        BUF_SIZE = 65536  # lets read file in 64kb chunks!

        
        alg_1 = hashlib.new(hash_al)
        alg_2 = hashlib.new(hash_al)

        with open(path_a) as f_1:
            while True:
                data_1 = f_1.read(BUF_SIZE).encode('utf-8')
                if not data_1:
                    break
                alg_1.update(data_1)
            

        with open(path_b) as f_2:
            while True:
                data_2 = f_2.read(BUF_SIZE).encode('utf-8')
                if not data_2:
                    break
                alg_2.update(data_2)
        
        if alg_1.hexdigest() == alg_2.hexdigest():
            result = True
        else:
            result = False
        
        logger.info("Hash: {0}".format(alg_1.hexdigest()))
        logger.info("Hash: {0}".format(alg_2.hexdigest()))
        
        return result
            
        
