import traceback
import sys
import json
import logging
import re
import datetime
import hashlib
import pyspark
import glob
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession,DataFrame,SQLContext
from pyspark.sql.functions import lit,col,udf,trim
from collections import OrderedDict
import time
import os

# Custom Libs
import utilsTrans
import utilsIO

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

from customException import *
from gen_audit_entry import *

#M1
print("in data validation1")
"""
process to validate duplicates in dimension/ file Size Alert / Account exists in L0
"""
def process(obj,exit_doc,config_name,batchdate,base_environment_path):
	# Logger initialization
	log_filename = obj['log_path'] + obj['pipelineName'] +"_"+ obj['config_name'] + "_"+str(datetime.datetime.strftime(datetime.datetime.now(),'%Y%m%d')) + '.log'
	logger = logging.getLogger("data-extract-process")
	logger.setLevel(logging.DEBUG)
	file_handler = logging.FileHandler(log_filename)
	file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
	file_handler.setFormatter(file_format)
	logger.addHandler(file_handler)
	logging.getLogger("py4j").setLevel(logging.ERROR)

	# Spark session  with required conf initialzation
	conf = pyspark.SparkConf()
	spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
	spark.conf.set("spark.sql.crossJoin.enabled", True)
	audit_doc = OrderedDict()
	print("in data validation2")
	try:
		print(obj)
		if config_name=='alltables_dim_duplicate_validation':
			try:
				dups_json,cnt=utilsTrans.dup_validation(obj,spark)
			except:
				try:
					logger.error(traceback.print_exc())
					raise uncatchException(str(traceback.format_exc()))
				except uncatchException as ue:
					audit_rec=ValidationEntry(obj,batchdate,"Failed",True,ue)
					audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
					return exit_doc
			if cnt>0:
				validation_exception=DimHavingDuplicatesError(str(dups_json))
				validation_flag=True
				validation_code=validation_exception
			else:
				validation_exception="Completed Successfully"
				validation_code=0
				validation_flag=False
			audit_rec=ValidationEntry(obj,batchdate,"Succeeded",validation_flag,validation_exception)
			audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,validation_code)
			return exit_doc
			
		elif config_name=='allsources_filesize_validation':
			print(config_name,"in validation")
			try:
				file_size_json,cnt=utilsTrans.gen_invalid_file_size(spark,obj,batchdate)
			except:
				try:
					logger.error(traceback.print_exc())
					raise uncatchException(str(traceback.format_exc()))
				except uncatchException as ue:
					audit_rec=ValidationEntry(obj,batchdate,"Failed",True,ue)
					audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
					return exit_doc
			if cnt>0:
				validation_exception=SrcFileSizeTooHighorLow(str(file_size_json))
				validation_flag=True
				validation_code=validation_exception
			else:
				validation_exception="Completed Successfully"
				validation_flag=False
				validation_code=0
			audit_rec=ValidationEntry(obj,batchdate,"Succeeded",validation_flag,validation_exception)
			audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,validation_code)
			print(exit_doc)
			return exit_doc

	#try	
	except:
		try:
			logger.error(traceback.print_exc())
			raise uncatchException(str(traceback.format_exc()))
		except uncatchException as ue:
			audit_rec=ValidationEntry(obj,batchdate,"Failed","",ue)
			audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
			return exit_doc
	#except
	finally:
		logger.info("End of "+ __name__+ " process...")
		#sqlContext.clearCache()
		#context.stop()
	#finally
###################################################################################################
