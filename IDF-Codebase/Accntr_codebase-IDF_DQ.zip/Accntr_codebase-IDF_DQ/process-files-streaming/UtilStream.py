import traceback
import os
import glob
import sys
import logging
import numpy as np
import json
import pandas as pd
import datetime
import UtilsCurate
import uuid
import re
from pyspark.sql.types import *
from pyspark.sql import DataFrame as SparkDataFrame
from shutil import copyfile
from pyspark import SparkContext
from pyspark.sql.functions import *
import  pyspark.sql.functions as F
from delta.tables import *
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
from streamingMetadataManager import streamingMetadataManager
import utilsShared
import time
from customException import *
from gen_audit_entry import *
import utilsTrans
import utilsTransDelta
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
import utilsIO
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-ingestion/')
import Utils
import utilsDq


def cloudFile_setup(dbutils,obj):
    cloudFile = {
        "cloudFiles.subscriptionId": obj['azure']['subscriptionId'],
        "cloudFiles.connectionString": obj['azure']['queuesaskey'],
        "cloudFiles.format": obj['data-source']['autoloader']['file-format'],
        "cloudFiles.tenantId": obj['azure']['tenantId'],
        "cloudFiles.clientId": obj['azure']['clientId'],
        "cloudFiles.clientSecret": dbutils.secrets.get(scope=obj['azure']['scope'],key=obj['azure']['clientSecret']),
        "cloudFiles.resourceGroup": "IDFRG",
        "cloudFiles.useNotifications": obj['data-source']['autoloader']['useNotifications']
        }
    return cloudFile

def eventhub_setup(spark,dbutils,obj):
    namespace = obj["azure"]["eventhub-namespace"]
    sharedAccesskey = obj["azure"]["eventhub-shared-access-key"]
    connString = obj["azure"]["eventhub-connection-string"]
    entityPath = obj['data-source']['eventhubs']['entityPath']
    print(entityPath)
    eventhubConnString=connString.format(namespace, sharedAccesskey,entityPath)
    conf = {}
    conf["eventhubs.connectionString"] = spark.sparkContext._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(eventhubConnString)
    #conf["eventhubs.connectionString"] = eventhubConnString
    return conf


def readStream(spark,conf,obj,dbutils,logger): 
    
    #Schema evolve/schema enforce
    if 'enforce' in obj['schema']['type']:
        event_schema_broadcast=spark.sparkContext.broadcast(obj["schema"]["cols"])
        schema = Utils.create_struct_schema(event_schema_broadcast.value,obj)
    elif 'evolve' in obj['schema']['type']:
        schema = obj['schema']['type']
    else:
        logger.error('Invalid schema defination should be either evolve/enforce')
        return 0

    #Supported event source Eventhub/autoloader
    if 'data-source' in obj and 'eventhubs' in obj['data-source']:
        logger.info('Reading from EventHub')
        auditCols = []
        confEH = eventhub_setup(spark,dbutils,obj)
        #conf = eventhub_setup(dbutils,obj)
        if schema != 'evolve':
            logger.info("Schema enforce is enabled")
            readDF = (spark.readStream.format("org.apache.spark.sql.eventhubs.EventHubsSourceProvider").options(**confEH).schema(schema).load())
            readDF = readDF.select(from_json(col("body").cast("string"), schema).alias("payload"))  
        else:
            logger.info("Schema evolve is enabled")
            readDF = (spark.readStream.format("org.apache.spark.sql.eventhubs.EventHubsSourceProvider").options(**confEH).load())
            readDF = readDF.withColumn('payload',decode(col('body'),'UTF-8'))#.select('payload')
            cols = readDF.columns
            payload = cols[-1]
            auditCols = cols[:-1]
            auditCols[:0] = [payload]
            readDF = readDF.select(auditCols)
                
    elif 'data-source' in obj and 'autoloader' in obj['data-source']:
        logger.info('Reading from auto-loader')
        datasourceObj = obj['data-source']['autoloader']
        cloudFile = cloudFile_setup(dbutils,obj)
        dynamicInputPath = obj['base_environment_path'] + datasourceObj['source-dir']
        logger.info('Autoloader listerner set at: ' + dynamicInputPath)
        readDF = (spark.readStream.format("cloudFiles").options(**cloudFile).option("header", "true").schema(schema).load(dynamicInputPath))
    
    ## Kafka data source defined
    elif 'data-source' in obj and 'kafka' in obj['data-source']:
        logger.info('Reading from kafka topic')
        confluentTopicName = obj["kafka"]["confluentTopicName"]
        confluentApiKey = obj["kafka"]["confluentApiKey"]
        confluentSecret = obj["kafka"]["confluentSecret"]
        confluentBootstrapServers = obj["kafka"]["confluentBootstrapServers"]
        # if schema != 'evolve':
            # logger.info("Schema enforce is enabled")
        readDF = (spark.readStream.format("kafka").option("kafka.bootstrap.servers", confluentBootstrapServers)
            .option("kafka.security.protocol", "SASL_SSL")
            .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))
            .option("kafka.ssl.endpoint.identification.algorithm", "https")
            .option("kafka.sasl.mechanism", "PLAIN")
            .option("subscribe", confluentTopicName)
            .option("startingOffsets", "latest")
            .option("failOnDataLoss", "false")
            .load())
    else:
        logger.error('No data source defined')
    
    return readDF

def readStream1(spark,conf,obj,dbutils,logger): 
   
    #Schema evolve/schema enforce
    if 'enforce' in obj['schema']['type']:
        event_schema_broadcast=spark.sparkContext.broadcast(obj["schema"]["cols"])
        schema = create_struct_schema(event_schema_broadcast.value,obj)
    elif 'evolve' in obj['schema']['type']:
        schema = obj['schema']['type']
    else:
        logger.error('Invalid schema defination should be either evolve/enforce')
        return 0

    #Supported event source Eventhub/autoloader
    if 'data-source' in obj and 'eventhubs' in obj['data-source']:
        logger.info('Reading from EventHub')
        auditCols = []
        #conf = eventhub_setup(dbutils,obj)
        if schema != 'evolve':
            logger.info("Schema enforce is enabled")
            readDF = (spark.readStream.format("org.apache.spark.sql.eventhubs.EventHubsSourceProvider").options(**conf).schema(schema).load())
            df = df.select(from_json(col("payload").cast("string"), schema).alias("payload"))  
        else:
            logger.info("Schema evolve is enabled")
            readDF = (spark.readStream.format("org.apache.spark.sql.eventhubs.EventHubsSourceProvider").options(**conf).load())
            readDF = readDF.withColumn('payload',decode(col('body'),'UTF-8'))#.select('payload')
            cols = readDF.columns
            payload = cols[-1]
            auditCols = cols[:-1]
            auditCols[:0] = [payload]
            readDF = readDF.select(auditCols)
                
    elif 'data-source' in obj and 'autoloader' in obj['data-source']:
        logger.info('Reading from auto-loader')
        datasourceObj = obj['data-source']['autoloader']
        cloudFile = cloudFile_setup(dbutils,obj)
        dynamicInputPath = obj['base_environment_path'] + datasourceObj['source-dir']
        logger.info('Autoloader listerner set at: ' + dynamicInputPath)
        readDF = (spark.readStream.format("cloudFiles").options(**cloudFile).option("header", "true").schema(schema).load(dynamicInputPath))
    
    ## Kafka data source defined
    elif 'data-source' in obj and 'kafka' in obj['data-source']:
        logger.info('Reading from kafka topic')
        confluentTopicName = obj["kafka"]["confluentTopicName"]
        confluentApiKey = obj["kafka"]["confluentApiKey"]
        confluentSecret = obj["kafka"]["confluentSecret"]
        confluentBootstrapServers = obj["kafka"]["confluentBootstrapServers"]
        # if schema != 'evolve':
            # logger.info("Schema enforce is enabled")
        readDF = (spark.readStream.format("kafka").option("kafka.bootstrap.servers", confluentBootstrapServers)
            .option("kafka.security.protocol", "SASL_SSL")
            .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(confluentApiKey, confluentSecret))
            .option("kafka.ssl.endpoint.identification.algorithm", "https")
            .option("kafka.sasl.mechanism", "PLAIN")
            .option("subscribe", confluentTopicName)
            .option("startingOffsets", "latest")
            .option("failOnDataLoss", "false")
            .load())
    else:
        logger.error('No data source defined')
    
    return readDF

def readProcessExec(spark,exit_doc):
    auditDF = spark.table("PRCS_EXECUTION")
    auditDF = auditDF.filter(col("SOURCE_NAME") == exit_doc['SOURCE_NAME'])
    lastStreamProcess = "NEW"
    if auditDF.count() != 0:
        lastStreamProcess = auditDF.select('STAGE').first()[0]
        
    return lastStreamProcess
         
def getStreamInfo(spark,exit_doc):
    streamMetadata = []
    lastStreamProcess = 'NEW'
    for s in spark.streams.active:
        streamMetadata = s.lastProgress
    checkpoint_dirname = exit_doc["CHECKPOINT_PATH"]
    if  streamMetadata:
        exit_doc['ID'] = streamMetadata['id']
        exit_doc['RUNID'] = streamMetadata['runId']
        exit_doc['NAME'] = streamMetadata['name']
        exit_doc['STREAM_TIMESTAMP'] = streamMetadata['timestamp']
        exit_doc['BATCHID'] = streamMetadata['batchId']
        for sources in streamMetadata['sources']:
            exit_doc['SOURCE_DESCRIPTION'] = sources['description']
            exit_doc['START_OFFSET'] = str(sources['startOffset'])
            exit_doc['END_OFFSET'] = str(sources['endOffset'])
        exit_doc['SINK_DESCRIPTION'] = streamMetadata['sink']['description']

    return exit_doc,lastStreamProcess

def add_metadata_columns(inputDF,obj,exit_doc):
    inputDF = inputDF.withColumn("BATCH_ID",lit(exit_doc['BATCHID']).cast(IntegerType()))
    inputDF = inputDF.withColumn("ID",lit(exit_doc['ID']))
    inputDF = inputDF.withColumn("RUNID",lit(exit_doc['RUNID']))
    inputDF = inputDF.withColumn("FOREACHBATCH",lit(exit_doc['FOREACHBATCH']))
    inputDF = inputDF.withColumn("LOAD_TS",lit(str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))).cast(TimestampType()))
    inputDF = inputDF.withColumn("LOAD_USERID",lit(obj["load_userid"]).cast(StringType()))
    inputDF = inputDF.withColumn("ERROR_CODE",lit(0))
    inputDF = inputDF.withColumn("ERROR_DESC",lit("NA"))
    return inputDF

def stopStream(spark,logger):
    logger.info("Stopping the stream")
    for s in spark.streams.active:
        s.stop()

def updateEntries(spark,dynamicPath,foreachbatch,err_desc,logger):
    exists = DeltaTable.isDeltaTable(spark,dynamicPath)                
    if exists:
        deltaTable = DeltaTable.forPath(spark, dynamicPath)
        logger.info("Setting ERROR_CODE = 1 for foreachbatch ID: " + foreachbatch)
        deltaTable.update(condition = col("FOREACHBATCH") == foreachbatch,set = { "ERROR_CODE": lit(1), "ERROR_DESC": lit(err_desc)})

def foreach_batch_function(df,epoch_id,spark,obj,exit_doc,audit_doc,dbutils):
    stage='foreachbatch'
    logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
    metadataObject = streamingMetadataManager()
    exit_doc,lastStreamProcess = getStreamInfo(spark,exit_doc)
    logger.info("Curent state: " + lastStreamProcess)
    logger.info("epoch_id: " + str(epoch_id))    
    foreachbatchid = str(uuid.uuid4())
    logger.info("foreachbatchid: " + foreachbatchid)
    exit_doc['FOREACHBATCH'] = foreachbatchid
   
    try:
        #Write to Raw
        exit_doc['STAGE'] = 'RAW'
        dynamicRawPath = obj['azure']['raw-base-path'] + obj['raw-path']                
        exit_doc['RAW_PATH'] = dynamicRawPath
        rawdf = add_metadata_columns(df,obj,exit_doc)
        rawdfCount = rawdf.count()
        if rawdfCount > 0:
            logger.info(exit_doc['STAGE'] + ': files ingested at: ' + dynamicRawPath)
            rawdf.write.format(obj['raw-format']).mode(obj['raw-mode-write']).save(dynamicRawPath)
            rawdf.show()
        
        exit_doc['RAW_ROW_COUNT'] = str(rawdfCount)
        exit_doc['RAW_COL_COUNT'] = str(len(rawdf.columns))
    except:
            try :
                logger.error(str(traceback.print_exc()))
                err_desc = str(traceback.format_exc())                           
                raise WriteStreamException(dynamicRawPath,err_desc)
            except WriteStreamException as wse:
                updateEntries(spark,dynamicRawPath,foreachbatchid,err_desc,logger)
                audit_rec= StreamForeachbatch(exit_doc,obj,'Failed',wse,exit_doc['JOB_START_TIME'])
                audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wse)
                metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                logger.error("Updating the error: " + err_desc)
                stopStream(spark,logger)
                exit_doc["EXIT_CODE"]=0
                return 0

    try:
        if "data-curate-process" in obj:        
            #Write to Curated        
            #Prepare curated dataframe based on schema
            curateObj = obj['data-curate-process']
            dynamicCuratedPath = obj['azure']['clean-base-path'] + curateObj['curated-path']
            logger.info('Curated files ingested at: ' + dynamicCuratedPath)
            exit_doc['CURATED_PATH'] = dynamicCuratedPath            
            write_mode = curateObj['curated-mode-write']
            schemaOption = "mergeSchema"
            mergeSchema = "false"
            exit_doc['STAGE'] = 'CURATED'

            if 'evolve' in obj['schema']['type'] and 'eventhubs' in obj['data-source']:                
                schema = spark.read.json(df.select("payload").rdd.map(lambda x: x[0])).schema
                df = df.select(F.from_json(F.col("payload").cast("string"), schema).alias("payload"))  
                mergeSchema = "true"
                schemaOption = obj['schema']['schema-option']

            #if 'eventhubs' in obj['data-source']:      
                #df = df.select("payload.*")

            if "DATA-RULES" not in curateObj:
                logger.info("No curation rules defined")
            else:
                # Transform
                logger.info("Running Data rule engine")
                secret_scope = obj['azure']['scope']
                curateObj['secret_scope'] = secret_scope
                df = UtilsCurate.data_rule_engine(curateObj,df,dbutils,logger)
            
            record_count = df.count()
            curdf = add_metadata_columns(df,obj,exit_doc)
            
            if record_count > 0:
                exists = DeltaTable.isDeltaTable(spark,dynamicCuratedPath)   
                if exists and "merge-col" in obj:
                    deltaTable = DeltaTable.forPath(spark, dynamicCuratedPath)
                    mergeColumns = obj['merge-col']
                    query = ""
                    for cols in mergeColumns:
                        query = query +" s."+ cols + "=" +" t." + cols + " and "
                        #remove last "and"
                        remove="and"
                        reverse_remove=remove[::-1]
                        query = query[::-1].replace(reverse_remove,"",1)[::-1]
                            
                    if schemaOption == "mergeSchema":
                        spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true") 
                    deltaTable.alias("t").merge(curdf.alias("s"), query).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
                else:
                    curdf.write.format(curateObj['curated-format']).option(schemaOption, mergeSchema).mode(write_mode).save(dynamicCuratedPath)

                exit_doc['CURATED_ROW_COUNT'] = str(curdf.count())
                exit_doc['CURATED_COL_COUNT'] = str(len(curdf.columns))

    except WriteStreamException as wse:
        updateEntries(spark,dynamicRawPath,foreachbatchid,err_desc,logger)
        updateEntries(spark,dynamicCuratedPath,foreachbatchid,err_desc,logger)
        audit_rec= StreamForeachbatch(exit_doc,obj,'Failed',wse,exit_doc['JOB_START_TIME'])
        audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wse)
        metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark,logger)
        exit_doc["EXIT_CODE"]=0
        return 0

    try:
                #Write to enrich
                if "data-enrich-process" in obj:
                    stage='data-stream-extract-process - ENRICH'
                    logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
                    objDict = obj["data-enrich-process"]
                    countValueSource = 1
                    for source in objDict["lookupSourceList"]:
                        countValueSource = countValueSource + 1
                        sourceDict = objDict[source]
                        if "alias" in sourceDict:
                            colAlias = sourceDict["alias"]
                        else:
                            colAlias = 0
                        inputPath,inputPathList = utilsTrans.get_curated_base_path(spark,sourceDict,obj,logger)
                        for dynamicInputPath in inputPathList:
                            try:
                                listOfFiles = glob.glob(dynamicInputPath)
                                if len(listOfFiles) == 0 :
                                    if os.path.isdir(dynamicInputPath)==False:
                                        logger.error("File not found for path:"+str(dynamicInputPath))
                                        raise fileNotFoundError(dynamicInputPath)
                                    continue
                            except fileNotFoundError as fnf:
                                logger.error(e)
                                
                        sourceDF = spark.read.parquet(dynamicInputPath[5:])    ##Reading from parquet i.e. Curated zone
                        if "cols" in sourceDict:
                            sourceDF = utilsIO.get_col_with_alias(sourceDF,sourceDict["cols"],sourceDict,colAlias)
                        
                        required_col_list=sourceDict["combine"]["base-table-key"]
                        distinct_dim=df.select(required_col_list).distinct()
                        
                        if "derived-key-process" in sourceDict:
                            srcObjDict = sourceDict["derived-key-process"].copy()
                            sourceDF = utilsTrans.derived_key_process(spark,srcObjDict,sourceDF,logger)
                        
                        if "filter" in sourceDict:
                            srcObjDict = sourceDict["filter"].copy()
                            batchDate = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                            sourceDF= utilsTrans.source_filter(spark,srcObjDict,sourceDF,batchDate,logger)
                        
                        # Default value generation
                        if "default-value" in sourceDict:
                            srcObjDict = sourceDict["default-value"].copy()
                            sourceDF = utilsTrans.default_vaule_process(spark,srcObjDict,sourceDF,logger)
                        
                        # Renaming columns
                        if "source-alias" in sourceDict:
                            srcObjDict = sourceDict["source-alias"].copy()
                            sourceDF = utilsTrans.source_alias(spark,srcObjDict,sourceDF,logger)
                        
                        #Combine baseDF and SourceDF
                        df = utilsTrans.combine_source(spark,obj,countValueSource,sourceDict,sourceDF,df,logger)
                        
                        # Updating BaseDF columns that need to pass to next source or next operation
                        if "custom-query" in sourceDict:
                            srcObjDict = sourceDict["custom-query"].copy()
                            df = utilsTrans.custom_query_execution(spark,srcObjDict,df,logger)
                        
                        if "derived-key-process-l1" in sourceDict:
                            srcObjDict = sourceDict["derived-key-process-l1"].copy()
                            df = utilsTrans.derived_key_process(spark,srcObjDict,df,logger)
                        
                        if "filter-l1" in sourceDict:
                            srcObjDict = sourceDict["filter-l1"].copy()
                            batchDate = str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
                            df = utilsTrans.source_filter(spark,srcObjDict,df,batchDate,logger)
                        
                        if "target-col-list" in sourceDict:
                            target_col_list = sourceDict["target-col-list"]
                            df=df.select(target_col_list)
                        
                        if "assign-non-null-value" in sourceDict:
                            srcObjDict = sourceDict["assign-non-null-value"].copy()
                            df = utilsTrans.assign_non_null_value(spark,srcObjDict,df,logger)
                    
                    HASH_TABLE = df
                    stage='data-stream-extract-process: data-enrich-process - ENRICH'
                    logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
                    dynamicEnrichPath = obj['azure']['enrich-base-path'] + objDict['enrich-path']
                    logger.info('Enriched files ingested at: ' + dynamicEnrichPath)
                    srcColCount = len(HASH_TABLE.columns)
                     # Row count of files used as input
                    target_colList = ''
                    totalRowCount = HASH_TABLE.count()
                    logger.debug('Total Row count generated ' + str(totalRowCount))
                    
                    # Default value in case SCD & CDC not applied
                    updateRowCount = 0
                    destRowCount = totalRowCount
                    targetTableCount = 0
                    targetTableColCount = 0
                    # Adding default process keys
                    logger.info('Adding additional Columns')
                    
                    objDict['batchDate'] = str(datetime.datetime.strftime(datetime.datetime.now(), '%Y%m%d'))
                    HASH_TABLE = utilsTransDelta.system_value_process(spark,objDict,HASH_TABLE,logger)
                    
                    target_exists = DeltaTable.isDeltaTable(spark,dynamicEnrichPath)
                    logger.info('Check if the enrich layer is empty of not')
                    if target_exists:
                        initialLoad = False
                    else:
                        initialLoad = True
                    
                    if initialLoad == False:
                        # Perform CDC based on the keys provided with the target table
                        if 'cdc-flag' in objDict and str(objDict['cdc-flag']) == 'true':
                            stage='data-stream-extract-process: data-enrich-process - ENRICH - CDC'
                            logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
                            # Read the existing table from source
                            TARGET_TABLE = DeltaTable.forPath(spark, dynamicEnrichPath)
    
                            targetTableColCount = len(TARGET_TABLE.toDF().columns)
                            targetTableCount = TARGET_TABLE.toDF().count()
    
                            logger.debug('Dropping duplicate based on CDC key '+ str(objDict['cdc-keys']['table-keys']))
                            HASH_TABLE = HASH_TABLE.dropDuplicates(objDict['cdc-keys']['table-keys'])
    
                            totalRowCount = HASH_TABLE.count()
                            logger.debug('Total Row count generated after removing duplicates &  null '+ str(totalRowCount))
                            if targetTableCount > 0:
                                logger.debug('Performing CDC on ' + str(objDict['cdc-keys']['table-keys']))
                                cdcCols = objDict['cdc-keys']['table-keys']
                                query = ""
                                for i in range(0,len(cdcCols)):
                                    query += "updates."+cdcCols[i] + " " + "<>" + " " + "target."+cdcCols[i] + " "
                                    if i == len(cdcCols)-1:
                                        break
                                    query += " "+ "or" + " "
                                logger.info('query: ' + query)
                                rowsToUpdate = HASH_TABLE.alias("updates").join(TARGET_TABLE.toDF().alias("target"), objDict['scd2']['table-keys']).where(F.expr(query)).where("target.CURR_IND == '1'")    
                            
                            else:
                                logger.debug('Skipping CDC since target table is empty ')
    
                            # Row count being exported to target table after removing duplicate - based on CDC key    
                            destRowCount = rowsToUpdate.count()
                            logger.debug('Row count after removing CDC ' + str(destRowCount))
                        else:
                            logger.debug('Skipping CDC since CDC is not configured')
                    else:
                        logger.debug('CDC is not required for Initial Load')
                        
                    # Rejected rows while exporting
                    rejRowCount = totalRowCount - destRowCount
                    logger.debug('Rejected row count after CDC ' + str(rejRowCount))
    
                    for colName in HASH_TABLE.columns:
                        logger.debug('Column being validated : ' + colName)
                        if colName in sorted(objDict['target-schema'].keys()):
                            # cast if datatype not maches
                            for dfCol in HASH_TABLE.dtypes:
                                if dfCol[0] == colName:
                                    if dfCol[1] != str(objDict['target-schema'][colName]['type']):
                                        logger.debug('converting ' + colName + ' from datatype ' + dfCol[1]+ ' to ' + str(objDict['target-schema'][colName]['type']))
                                        HASH_TABLE = HASH_TABLE.withColumn(colName,col(colName).cast(str(objDict['target-schema'][colName]['type'])))
    
                    if initialLoad == False:
                        if 'scd2-flag' in objDict and str(objDict['scd2-flag']) == 'true':
                            stage='data-stream-extract-process: data-enrich-process - ENRICH - SCD2'
                            logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
                            #Remove the not Changed rows from Hash Table
                            
                            NoChangeRows = HASH_TABLE.alias("updates").join(TARGET_TABLE.toDF().alias("target"), objDict['cdc-keys']['table-keys']).select("updates.*")#.where("target.CURR_IND == '1'")
                            cols = HASH_TABLE.columns
                            rowsForSCD2 = HASH_TABLE.alias("a").join(NoChangeRows.alias("b"),objDict['cdc-keys']['table-keys'],how = "leftAnti").select(cols)   
                            scdKey = objDict['scd2']['table-keys'][0]
                            
                            rowsToUpdate = rowsToUpdate.selectExpr("updates.*").select(cols)

                            stagedUpdates = (
                                rowsToUpdate
                            .selectExpr("NULL as mergeKey", "updates.*")   # Rows for 1
                            .union(rowsForSCD2.selectExpr(scdKey+" as mergeKey", "*"))  # Rows for 2.
                            )
                            
                        else:
                            logger.debug('Skipping SCD2 since SCD2 is turned off ')

                    else:
                        logger.debug('SCD2 is not required for Initial Load')

                    for colName in HASH_TABLE.columns:
                        logger.debug('Column being validated : ' + colName)
                        if colName in sorted(objDict['target-schema'].keys()):
                            colNewName = objDict['target-schema'][colName]['colName']
                            # Rename column if not matches with the existing
    
                            if colName != colNewName:
                                logger.debug('Renaming to column : ' + colName)
    
                                # colName = "`" + colName +"`"
                                HASH_TABLE = HASH_TABLE.withColumnRenamed(colName,colNewName)
                        else:
                            logger.debug('Dropping column : ' + colName)
                            HASH_TABLE = HASH_TABLE.drop(colName)

                    objDict["load_userid"] = obj['load_userid']
                    objDict["loadDate"] = obj["loadDate"]
                    
                    # Write to Enrich Layer
                    stage='data-stream-extract-process: data-enrich-process - ENRICH - LOAD'
                    logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
                    expected_period_key='NA'
                    
                    if destRowCount > 0:
                        logger.info('target list:' + str(objDict['target-col-list']))
                        if initialLoad == True:
                            HASH_TABLE = utilsTransDelta.add_Audit_columns(HASH_TABLE,logger, objDict)
                            HASH_TABLE = HASH_TABLE.select(objDict['target-col-list'])
                        else:
                            if 'scd2-flag' in objDict and str(objDict['scd2-flag']) == 'true':
                                stagedUpdates = utilsTransDelta.add_Audit_columns(stagedUpdates,logger, objDict)
                            else:
                                HASH_TABLE = utilsTransDelta.add_Audit_columns(HASH_TABLE,logger, objDict) 
                                HASH_TABLE = HASH_TABLE.select(objDict['target-col-list'])
                        
                        logger.debug('Writing new records to Enrich '+ str(destRowCount))
    
                        if initialLoad == True:
                            logger.info('Performing Initial Load')
                            if "partition-by" in objDict:
                                HASH_TABLE.write.partitionBy(objDict["partition-by"]).mode(objDict['enrich-mode-write']).save(dynamicEnrichPath,format=str(objDict['enrich-format']))
                            else:
                                HASH_TABLE.write.mode(objDict['enrich-mode-write']).save(dynamicEnrichPath,format=str(objDict['enrich-format']))
    
                        else:
                            if 'scd2-flag' in objDict and str(objDict['scd2-flag']) == 'true':
                                logger.info('Performing Delta Merge and Reload the New and updated Record to the respective partition')
                                condition_query = ""
                                for i in range(0,len(cdcCols)):
                                    condition_query += "target."+cdcCols[i] + " " + "<>" + " " + "staged_updates."+cdcCols[i] + " "
                                    if i == len(cdcCols)-1:
                                        break
                                    condition_query += " "+ "or" + " "
                                condition_query+= " and target.CURR_IND = '1'"
                                update_dict = {}
                                for item in TARGET_TABLE.toDF().columns:
                                    update_dict[item] = "staged_updates."+item
                            
                                update_dict["UPD_USERID"] = "null"
                                update_dict["UPD_TS"] = "null"
                                logger.info("condition_query: " + str(condition_query))
                                logger.info("update_dict: " + str(update_dict))
                                #datetime_object = datetime.datetime.strptime(obj["batchDate"],"%Y%m%d%H%M%S")
                                datetime_object = datetime.datetime.utcnow()
                                TARGET_TABLE.alias("target").merge(
                                    stagedUpdates.alias("staged_updates"),
                                    "target."+scdKey+" = mergeKey").whenMatchedUpdate(condition = condition_query,set =
                                        {                                         # Set current to false and endDate to source's effective date.
                                        "SNAPSHOT_END_DT": "staged_updates.SNAPSHOT_BEG_DT",
                                        "CURR_IND" : "0",
                                        "UPD_USERID" : "null",
                                        "UPD_TS" : obj["batchDate"]
                                        }
                                    ).whenNotMatchedInsert(values =update_dict).execute()
                            else:
                                if "partition-by" in objDict:
                                    HASH_TABLE.write.partitionBy(objDict["partition-by"]).mode(objDict['enrich-mode-write']).save(dynamicEnrichPath,format=str(objDict['enrich-format']))
                                else:
                                    HASH_TABLE.write.mode(objDict['enrich-mode-write']).save(dynamicEnrichPath,format=str(objDict['enrich-format']))

                    
                    exit_doc['STAGE'] = 'ENRICH'
                    exit_doc['ENRICH_PATH'] = dynamicEnrichPath
                    exit_doc['ENRICH_ROW_COUNT'] = str(df.count())
                    exit_doc['ENRICH_COL_COUNT'] = str(len(df.columns))


    except WriteStreamException as wse:
        updateEntries(spark,dynamicRawPath,foreachbatchid,err_desc,logger)
        updateEntries(spark,dynamicCuratedPath,foreachbatchid,err_desc,logger)
        #updateEntries(spark,dynamicEnrichPath,foreachbatchid,err_desc,logger)
        audit_rec= StreamForeachbatch(exit_doc,obj,'Failed',wse,exit_doc['JOB_START_TIME'])
        audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wse)
        metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark,logger)
        exit_doc["EXIT_CODE"]=0
        return 0
    
    ################### Data Quality Stream process ############
    try:

        if "data-quality-process" in obj:
            stage='data-quality-stream-process'
            
            if 'evolve' in obj['schema']['type'] and 'eventhubs' in obj['data-source']:                
                schema = spark.read.json(df.select("payload").rdd.map(lambda x: x[0])).schema
                df = df.select(F.from_json(F.col("payload").cast("string"), schema).alias("payload"))  
                mergeSchema = "true"
                schemaOption = obj['schema']['schema-option']
            
            # if 'evolve' in obj['schema']['type'] and 'kafka' in obj['data-source']:                
            #     schema = spark.read.json(df.select("offset").rdd.map(lambda x: x[0])).schema
            #     df = df.select(F.from_json(F.col("offset").cast("string"), schema))  
            #     mergeSchema = "true"
            #     schemaOption = obj['schema']['schema-option']

            if 'eventhubs' in obj['data-source']:      
                df = df.select("payload.*")
            hash_table = df

            emptyRDD = spark.sparkContext.emptyRDD()
            exit_doc['STAGE'] = 'DQ'
            logger = utilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
            objDict = obj["data-quality-process"]
            table_name = objDict['table_name']
            rule_exe_ts = datetime.datetime.now()
            # logger = getFormattedLogger(stage, obj['local_log_file_name'])
            logger.info("Started executing "+str(stage)+" module")
            skipped_dq_rules="SKIPPED VAILDATING THE BELOW DQ RULES: \n TABLE_NAME || RULE_ID || RULE_TYPE "
            skipped_tables="SKIPPED VAILDATING THE TABLES: \n TABLE_NAMES : "
            if table_name:
                logger.debug("Performing data quality on table: " + table_name)
                df_dq_master = utilsIO.read_data_sql_table(spark, obj, table_name,logger)
            else:
                logger.error("Failed to get valid dq master table name or no data found in input dataframe")
                raise invalidInputParams ("Failed to get valid dq master table name or no data found in input dataframe")
            TablesInDqMaster=df_dq_master.select(col('TABLE_NAME')).distinct().rdd.map(lambda x: x[0].lower()).collect()
            Input_tableNames=[]
            if (str(trim(objDict['table_name'])) == '' or objDict['table_name'] is None):
                logger.error("Invalid input table list, please provide valid comma seperated tables names")
                raise invalidInputParams ("Invalid input table list, please provide valid comma seperated tables names for tableNames")
            Input_tableNames = objDict['table_name'].lower().split(',')
            tableList= list(set(Input_tableNames).intersection(TablesInDqMaster))
            batchDate = obj['batchDate']
            tablesNotInDqMaster=list(set(Input_tableNames)-set(TablesInDqMaster))
            if (len(tableList) > 0) :
                for tableName in tableList :
                    dqStatistics=None
                    vldtd_hash_tbl_res=None
                    counts_vldtn_df = None
                    logger.info("Performing data quality on table: " + tableName)
                    dqStats_schema = StructType([StructField("RULE_ID", StringType()), StructField("FAILED_ROW_COUNT", IntegerType())])
                    dqStats0=spark.createDataFrame(emptyRDD, dqStats_schema)
                    if df is not None:
                        vldtd_hash_tbl_res = hash_table.select('*').limit(1).withColumn('ERR_CD', lit(""))
                        hash_table_cnt = hash_table.count()
                        df_dq_master2 = df_dq_master.filter(lower(col('TABLE_NAME')) == tableName)
                        dq_master = df_dq_master2.toPandas().transpose().to_dict()
                        for ruleKey in dq_master:
                            rule = dq_master[ruleKey]
                            ruleType = dq_master[ruleKey]['RULE_TYPE'].lower()
                            ruleCol = rule['COL_NAME']
                            ruleID = rule['RULE_ID']
                            ruleVal = rule['RULE_VAL']
                            dynamicInputPath = rule['DATA_PATH_OR_TOPIC']
                            lookup_path= rule['REF_PATH']
                            refPathType = rule['FORMAT']
                            logger.info('RULE_TYPE is')
                            # Applying rules on data
                            dq_table = None
                            dqStats0_df = None
                            if ruleType == 'isnull':
                                dq_table, dq_rule_count = utilsDq.data_quality_null_validation(spark, hash_table, ruleCol, ruleID, logger)
                                dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                                logger.debug("NULL-CHECK rule type executed successfully for table "+tableName)
                            elif ruleType == 'duplicate-check':
                                dq_table, dq_rule_count = utilsDq.data_quality_duplicates_valdation(spark, hash_table, ruleCol, ruleID, logger)
                                dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                                logger.debug("DUPLICATE-CHECK rule type executed successfully for table "+tableName)
                            elif ruleType == 'custom-expr':
                                dq_table, dq_rule_count = utilsDq.data_quality_expression_validation(obj, hash_table, ruleID, rule, logger)
                                dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                                # logger.debug("DQ_Table count is ",str(dq_rule_count))
                                logger.debug("CUSTOM_EXPRESSION rule type executed successfully for table "+tableName)
                            elif ruleType == 'straight-look-up':
                                dq_table, dq_rule_count = utilsDq.data_quality_straight_lookup_validation(spark, obj, hash_table, ruleVal, ruleID, lookup_path, refPathType, logger)
                                dqStats0_df = spark.createDataFrame([(ruleID, dq_rule_count) ], dqStats_schema)
                                logger.debug("STRAIGHT_LOOKUP rule type executed successfully for table "+tableName)
                            if dq_table is not None:
                                if dq_table.count()>0:
                                    vldtd_hash_tbl_res=vldtd_hash_tbl_res.union(dq_table)
                                    logger.info('Data in DQ_Table')
                                else:
                                    dqStats0 = dqStats0.union(dqStats0_df)
                                    logger.info('Data not in DQ_Table')
                            
                        #Aggregating the final results
                        FailedData = vldtd_hash_tbl_res.where("Not(ERR_CD is Null or trim(ERR_CD) = '')")
                        FailedDataFinal = FailedData.join( df_dq_master.select("RULE_ID","RULE_TYPE").alias("df_dq_master"), FailedData.ERR_CD ==  df_dq_master.RULE_ID  , "left").select(FailedData.columns + ["RULE_TYPE"])

                        #TODO: check where to write failed data
                        if FailedDataFinal.count() > 0:
                            FailedDataFinal.coalesce(1).write.mode('append').format('csv').save('/mnt/mountdatalake/batchData/temp/failedData/')
                            # FailedDataFinal.write.mode("append").save("/mnt/mountdatalake/batchData/temp/failedData/",format="csv")
                            logger.info('FailedData Written to ADLS Successfully')
                        else:
                            logger.debug('FailedData not written to ADLS Successfully')

                        dqStats = FailedData.groupby("ERR_CD").count()\
                            .withColumnRenamed("count", "FAILED_ROW_COUNT" )\
                            .selectExpr("ERR_CD as RULE_ID","FAILED_ROW_COUNT")
                            
                        dqStats= dqStats.union(dqStats0)

                        dqStats1 = dqStats.withColumn("TOTAL_ROW_CNT", lit(hash_table_cnt))\
                            .withColumn("PASSED_ROW_CNT" , (col("TOTAL_ROW_CNT")-col("FAILED_ROW_COUNT")))
                        dqStats2 = dqStats1.withColumn("RULE_FAIL_PC", lit(100*col("FAILED_ROW_COUNT")/col("TOTAL_ROW_CNT")) )\
                            .withColumn("EXEC_DATE",lit(rule_exe_ts))\
                            .withColumn("BATCH_DATE", lit(batchDate))
                        dqStatistics = dqStats2.join(df_dq_master\
                            .select(['RULE_ID','RULE_TYPE','RULE_DIMENSION','TABLE_NAME', 'COL_NAME']),'RULE_ID','inner')\
                            .select( "RULE_ID","RULE_TYPE","RULE_DIMENSION","TABLE_NAME","COL_NAME","BATCH_DATE","TOTAL_ROW_CNT","FAILED_ROW_COUNT","RULE_FAIL_PC","EXEC_DATE")
                        
                        #TODO: Write dqStatistics results for the table
                        if dqStatistics.count() > 0:
                            dqStatistics.coalesce(1).write.mode('append').format('csv').save('/mnt/mountdatalake/batchData/temp/dqStats/')
                            # dqStatistics.write.mode("append").save("/mnt/mountdatalake/batchData/temp/dqStats/",format="parquet")
                            logger.info('DQ Stats Written to ADLS Successfully')
                        else:
                            logger.debug('DQ Stats not written to ADLS Successfully')

                        return dqStatistics


    except WriteStreamException as wse:
        updateEntries(spark,dynamicRawPath,foreachbatchid,err_desc,logger)
        updateEntries(spark,dynamicCuratedPath,foreachbatchid,err_desc,logger)
        #updateEntries(spark,dynamicEnrichPath,foreachbatchid,err_desc,logger)
        audit_rec= StreamForeachbatch(exit_doc,obj,'Failed',wse,exit_doc['JOB_START_TIME'])
        audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wse)
        metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark,logger)
        exit_doc["EXIT_CODE"]=0
        return 0



    #############################################################

    #Create log file
    log_file_name = obj['log_file_name']
    log_file_folder = "/".join(log_file_name.split("/")[:-1])
    os.makedirs(log_file_folder, exist_ok=True)
    logger.info("copying logs to: " + log_file_name)
    copyfile(obj['local_log_file_name'], log_file_name)
    wse = "New records added successfully"
    audit_rec= StreamForeachbatch(exit_doc,obj,'In Progress',wse,exit_doc['JOB_START_TIME'])
    audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,0)
    metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
    pass

def writeStream(spark,readDF,conf,obj,dbutils,audit_doc,exit_doc,logger):
    print(obj["streamName"])
    if readDF != 0:
            logger.info("Write the stream")
            if 'eventhubs' in obj['data-source']:
                obj['source_type'] = "eventhubs"
                checkpoint_dirname = obj['data-source']['eventhubs']['entityPath']
            ######## kafka code added ############
            elif 'kafka' in obj['data-source']:
                obj['source_type'] = "kafka"
                checkpoint_dirname = obj['data-source']['kafka']['topicName']
            ######################################
            else:
                obj['source_type'] = "autoloader"
                checkpoint_dirname = obj['data-source']['autoloader']['source-dir']
            
            checkpoint = obj['azure']['checkpoint-base-path'] + checkpoint_dirname
            logger.info('Checkpoint directory set at: ' + checkpoint)

            sourceType = obj['source_type']

            try:
                exit_doc['TRIGGER_TYPE'] = obj["trigger"]['trigger-type']
                exit_doc['SOURCE_TYPE'] = obj['source_type']
                exit_doc['CHECKPOINT_PATH'] = checkpoint
            
                if "default" in obj["trigger"]['trigger-type']:
                    logger.info('Default trigger stream will run micro-batch as soon as it can')
                    query = (readDF.writeStream.queryName(obj["streamName"]).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
                    logger.info("lastprogress: " + str(query.lastProgress))              
                    
                elif "processingTime" in obj["trigger"]['trigger-type']:            
                    interval = str(obj["trigger"]["trigger-interval"]) #Eg '2 seconds'
                    logger.info('ProcessingTime trigger with '+ interval + ' micro-batch interval')
                    query = (readDF.writeStream.queryName(obj["streamName"]).trigger(processingTime=interval).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
        
                elif "once" in obj["trigger"]['trigger-type']:
                    logger.info('One-time trigger')
                    query = (readDF.writeStream.queryName(obj["streamName"]).trigger(once=True).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())

                elif "continuous" in obj["trigger"]['trigger-type']:
                    interval = str(obj["trigger"]["trigger-interval"]) #Eg '1 second'
                    logger.info('Continuous trigger with '+ interval + ' checkpointing interval')
                    query = (readDF.writeStream.queryName(obj["streamName"]).trigger(continuous=interval).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
                else:
                    try:
                        obj['trigger'] = 'NA'
                        trigger = "Trigger is not defined"
                        logger.error(trigger)
                        raise triggerException(trigger)
                    except triggerException as te:
                        audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',te,job_start_time)
                        audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,te)
                        metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0
                query.awaitTermination(20)
                return query
            except:
                try :
                    logger.error(str(traceback.print_exc()))
                    err_desc = str(traceback.format_exc())                         
                    raise WriteStreamForEachBatch(err_desc)
                except WriteStreamForEachBatch as wre:                        
                    audit_rec= WriteStreamForEachBatch(exit_doc,obj,'Failed',wre,job_start_time)
                    audit_doc,exit_doc=utilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wre)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    stopStream(spark,logger)
                    exit_doc["EXIT_CODE"]=0
                    return 0

def aggregate_process(spark,objDict,HASH_DF,logger):
    for keyName in sorted(objDict.keys()):
        print(objDict[keyName])
        if (objDict[keyName]["process"] == "group-by-w-agg"):
            group_by_list = objDict[keyName]["group_by_list"]
            agg_list=objDict[keyName]["agg_list"]
            agg_type=str(objDict[keyName]["agg_type"])
            HASH_DF=HASH_DF.groupBy(group_by_list)
            HASH_DF=HASH_DF.agg(agg_list)
            print('sfg')
            HASH_DF = HASH_DF.toDF(*(re.sub(r'[\,\s;\n\t\={}():]+', '', c.replace(agg_type,'AGG_')) for c in HASH_DF.columns))
        elif (objDict[keyName]["process"] == "subtract"):
            colName=str(objDict[keyName]["colName"])
            left_col_name= str(objDict[keyName]["left_col_name"])
            right_col_name= str(objDict[keyName]["right_col_name"])
            HASH_DF=HASH_DF.withColumn(colName,col(left_col_name)-col(right_col_name))
        elif (objDict[keyName]["process"] == "product"):
            colName=str(objDict[keyName]["colName"])
            first_col= str(objDict[keyName]["first_col"])
            second_col= str(objDict[keyName]["second_col"])
            HASH_DF=HASH_DF.withColumn(colName,col(first_col)*col(second_col))
        elif (objDict[keyName]["process"] == "addition"):
            colName=str(objDict[keyName]["colName"])
            first_col= str(objDict[keyName]["first_col"])
            second_col= str(objDict[keyName]["second_col"])
            HASH_DF=HASH_DF.withColumn(colName,col(first_col)+col(second_col))
    return HASH_DF

def streamTransform(spark,obj,readDF,logger):
    

    if "aggregation" in obj:
        logger.info('Aggregation added')
        objDict = obj['aggregation'].copy()
        readDF = aggregate_process(spark,objDict,readDF,logger)

    if "watermark" in obj:
        logger.info('Watermark added')
        readDF = stream_watermarking(readDF,obj,logger)
    return readDF  

# Function to join the dataframes
def df_join(leftDF,watermarkExpression,rightDF,logger,joinType="inner"):
    logger.debug("Inside df_join " + joinType)
    leftDF= leftDF.join(rightDF,expr(watermarkExpression),how = joinType)
    return leftDF

def combine_source(spark,obj,countValueSource,sourceDict,sourceDF,baseDF,logger):
    #Skip join if first table
    if countValueSource > 1 and "combine" in sourceDict:        
        
        #Join with the base Table
        joinType = "inner"
        if "join-type" in sourceDict["combine"]:
            joinType = str(sourceDict["combine"]["join-type"])
        logger.debug("Applying join of type " + str(joinType)+ " with the base table.")
                                 
        baseDF = df_join(baseDF,sourceDict["combine"]['lookup-watermark-expression'],sourceDF,logger,joinType)
            #logger.debug("Count of base DF after join : "+ str(baseDF.count()))
    else:  # First frame if the base DF was empty
        baseDF = sourceDF
    return baseDF

def stream_watermarking(readDF,obj,logger):
    if "select-expr" in obj['watermark']:
            expr = obj['watermark']['select-expr']
            logger.info("select-expr " + str(expr) + " defined for watermarking")
            readDF = readDF.selectExpr(expr)
    
    logger.info("Stream is configured for watermark: " + obj['watermark']['watermarkCol'] + " with delay: " + obj['watermark']['delayTime'])
    readDF = readDF.withWatermark(obj['watermark']['watermarkCol'],obj['watermark']['delayTime'])

    return readDF

def test():
    print("test----------------")




