import sys
import json
import traceback
import re
import unicodedata
import logging
import pyspark
from pyspark.sql import SQLContext, Row
from pyspark.sql.types import *
from pyspark.sql.types import StringType
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf, lit, trim, concat_ws, when, isnull, col, isnan, array, regexp_replace, sha1, sha2, hex, base64, lower, upper, substring, concat, lpad, rpad, ltrim, rtrim, split, mean
import Utils
import UtilsCurate
import time
import datetime
from collections import OrderedDict
from metadataManager import metadataManager

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
import utilsShared
from customException import *
from gen_audit_entry import *
                                                
###################################################################################################
#M1
def process(obj,inputDF,dbutils, exit_doc):   
    job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    loc = str(obj['varbatchdate'])
    stage='load-curated-process'
    log_filename =  obj['local_log_file_name']
    logger = utilsShared.getFormattedLogger(stage,log_filename)
    validation_flag=False

    #spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
    spark = SparkSession.builder.appName(obj["use-case"]).getOrCreate()
    spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
    spark.conf.set("spark.sql.legacy.timeParserPolicy","LEGACY")
    metadataObject = metadataManager()
    document={}
    document['applicationid']= str(spark.sparkContext.applicationId)
    document['doc-type']= str(obj['use-case'])    
    try:
        logger.info("Inside try of data-rules-engine-process")
        audit_doc=OrderedDict()

        file_ext=obj["fileExt"]
        dynamicInputPath = exit_doc['SOURCE']['SOURCE_PATH']
        inputRowCount = exit_doc['SOURCE']['SOURCE_ROW_COUNT']
        inputColumnCount= exit_doc['SOURCE']['SOURCE_COL_COUNT']
        src_file_size = exit_doc['SOURCE']['SOURCE_FILE_SIZE']
        rejected_row_count = exit_doc['DESTINATION']['REJECTED_ROW_COUNT']
        print(exit_doc)
        logger.info("rejected_row_count: " + rejected_row_count)       
        output =  str(obj['clean-location']) + "/" #+loc # + loc +"_output"
        if int(rejected_row_count) > 0:
            validation_flag=True
            exception_path=str(obj['azure']['exception-base-path']) + str(obj['exception-layer-location']) + "/"
            inputDF = inputDF.filter(inputDF.ERROR_CODE == 0)
            
        else:
            exception_path = 'NA'
        print("**********************************************")
        obj["target-dir"] = exit_doc['FILE_NAME']
        logger.info("Target output path is: " + output)
        #comapring source and Target DF for current Financial year
        
        if "DATA-RULES" in obj:
            inputDF = UtilsCurate.data_rule_engine(obj,inputDF,dbutils,logger)

        try:
            if file_ext == 'parquet' and inputDF.count() != 0:
                    # Comparing Source and Target Dataframe
                    try:
                        inputDF=Utils.src_tgt_comparison(obj,output,inputDF,spark)
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise sourceVsTargetComparisonError()
                        except sourceVsTargetComparisonError as sve:
                            audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',sve,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size)
                            audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,sve)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0, exit_doc
            
            if inputDF.count() != 0:
                Utils.write_df(obj,inputDF,output)
            else:
                audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Succeeded','Completed Successfully! No change in destination',job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,output,0,0,0,rejected_row_count,exception_path,log_filename)
                audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc['EXIT_CODE']=0
                return 0, exit_doc

        except Exception as ex:
            try:
                logger.error(traceback.print_exc())
                raise writeDataframeError(output)
            except writeDataframeError as wde:
                audit_rec=BeforeDestinationRead(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',wde,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size)
                audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,wde)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0
                return 0, exit_doc
        
        try:
            target_df=spark.read.parquet(output)
            if "filter-by-src_filename" in obj:
                DF = inputDF
                DF = DF.select("src_filename").distinct()
                file_list=DF.select(collect_list("src_filename")).collect()[0][0]
                target_df= target_df.where(col("src_filename").isin(file_list))
            
        except Exception as ex:
            try:
                logger.error(traceback.print_exc())
                raise readingTargetDFError(output)
            except readingTargetDFError as wde:
                audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Failed',wde,job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,output,0,0,0,0,'NA',log_filename)
                audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,wde)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0
                return 0, exit_doc

        # Extracting Destination File Size
        dest_file_size=Utils.gen_tgt_file_sz(dbutils,output)
        # Insert the success record in Audit Table, change audit information
        target_cnt=target_df.count()  if isinstance(target_df,SparkDataFrame) else 0
        tgt_col_cnt=len(target_df.columns)  if isinstance(target_df,SparkDataFrame) else 0
        

        #Appending p as suffix signify file is processed
        if( file_ext not in ('xlsx','xlsm','parquet')):
            Utils.rename_files('/dbfs'+ dynamicInputPath)
            logger.info("Files renamed successfully")
        
        if validation_flag:
            logger.info("Inside validation flag")
            invalid_val=InvalidValue()
        else:
            invalid_val=0
        success_status_Desc="Completed Successfully!"
        audit_rec=AfterDestinationWrite(obj,Utils.gen_batch_Date_formatted(obj["batchDate"]),'Succeeded','Completed Successfully!',job_start_time,dynamicInputPath,inputRowCount,inputColumnCount,src_file_size,output,target_cnt,tgt_col_cnt,dest_file_size,rejected_row_count,exception_path,log_filename,validation_flag,invalid_val)
        audit_doc,exit_doc=Utils.gen_audit_dict(audit_doc,exit_doc,audit_rec,invalid_val)
        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
        exit_doc["EXIT_CODE"]=1
        logger.info("Audit record saved successfully for load-curated-process")
        return inputDF,exit_doc  
            
        #if
    #try
    except:
        try:
                             
            logger.error(traceback.print_exc())
            raise transformationError(transType)
        except transformationError as tne:
            audit_rec=TransformLoadDataVault(exit_doc,stage,tne,'Failed',0,0,0,'NA')
            audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,tne)
            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
            exit_doc["EXIT_CODE"]=0
            return 0,exit_doc #except
    finally:
        logger.info("End of "+ __name__+ " process...")
        #context.stop()
    #finally
# #def



