#!/usr/bin/python
# -*- coding: utf-8 -*-
import traceback
import sys
import json
import logging
import re
import hashlib
import time
import pandas as pd
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType
from pyspark.sql.functions import udf,expr
from pyspark.sql import SparkSession
#from pyspark.sql.functions import *
from datetime import  timedelta, date
from pyspark.sql.functions import lit, col, trim, rank,when,coalesce
from pyspark.sql import Window
from collections import OrderedDict
from metadataManager import metadataManager
from dateutil.relativedelta import relativedelta
from delta.tables import *

import utilsTransDelta
import utilsIO
metadataObject = metadataManager()
import os

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

from customException import *
from gen_audit_entry import *
import utilsShared   

###################################################################################################

def process(obj, HASH_TABLE, dbutils, exit_doc):

    stage='load-enrich-process-delta'
    logger = utilsShared.getFormattedLogger(stage, obj['local_log_file_name'])
    
    conf = pyspark.SparkConf()
    spark = SparkSession.builder.appName(obj['use-case']).config(conf=conf).getOrCreate()
    
    #PRC_CURR_ID =str(hashlib.md5(str(millis).encode()).hexdigest())
    PRC_CURR_ID = dbutils.widgets.get("prm_act_pipeline_id")
    PRC_EXECUTION_ID = PRC_CURR_ID 
    spark.conf.set("spark.databricks.delta.formatCheck.enabled", "false")
    srcColCount = len(HASH_TABLE.columns)
    
    try:

        # Row count of files used as input
        target_colList = ''
        totalRowCount = HASH_TABLE.count()
        logger.debug('Total Row count generated ' + str(totalRowCount))
      
        # Default value in case SCD & CDC not applied
        updateRowCount = 0
        destRowCount = totalRowCount
        targetTableCount = 0
        targetTableColCount = 0
        audit_doc = OrderedDict()

        # Adding default process keys
        logger.info('Adding additional Columns')
        HASH_TABLE = utilsTransDelta.system_value_process(spark, obj,
                HASH_TABLE, logger)        
        
        
        enrichPath = "/dbfs"+obj["enrich-path"]
        logger.info('Check if the enrich layer is empty or not')
        if os.path.isdir(enrichPath) == False:
          logger.info('Path doesnot exist, setting initalLoad as true')
          initialLoad = True
        else:
          listOfFiles = os.listdir(enrichPath) 
          if len(listOfFiles) == 0 :
            initialLoad = True
          else:
            logger.info('Path does exist, setting initalLoad as false')
            initialLoad = False
		
		#if initialLoad == True:
		#	logger.info('This is Initial Load')
		#else:
		#	logger.info('SCD2 Operation Expected')
        
        if initialLoad == False:           
        # Perform CDC based on the keys provided with the target table
            if 'cdc-flag' in obj and str(obj['cdc-flag']) == 'true':
    
                # Read the existing table from source
    
                if 'target-table-view' in obj:
                    targetTableName = str(obj['target-table-view'])
                    logger.debug('Fetching data from target table view : '+ targetTableName)
                else:
                    targetTableName = str(obj['enrich-path'])
                    logger.debug('Fetching data from enrich delta path since view is not configured : '+ targetTableName)
                try:
                    TARGET_TABLE = DeltaTable.forPath(spark,targetTableName)
                except Exception as e:
                    try:
                        logger.error(traceback.print_exc())
                        raise dbReadError(targetTableName)
                    except dbReadError as dbe:
                        audit_rec=TransformLoadDataVault(exit_doc,stage,dbe,'Failed',0,0,0,'NA',obj['enrich-path'])
                        audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        exit_doc["EXIT_CODE"]=0
                        return 0,exit_doc
    
                targetTableColCount = len(TARGET_TABLE.toDF().columns)
                targetTableCount = TARGET_TABLE.toDF().count()
                
                if targetTableCount > 0:
                    TARGET_TABLE.toDF().cache()
    
                logger.debug('Dropping duplicate based on CDC key '+ str(obj['cdc-keys']['input-table-keys']))
                HASH_TABLE = HASH_TABLE.dropDuplicates(obj['cdc-keys']['input-table-keys'])
    
                # logger.debug("Dropping nulls based on CDC key " + str(obj["cdc-keys"]["input-table-keys"]))
                # HASH_TABLE = HASH_TABLE.na.drop(subset = obj["cdc-keys"]["input-table-keys"])
    
                totalRowCount = HASH_TABLE.count()
                logger.debug('Total Row count generated after removing duplicates &  null '+ str(totalRowCount))
                if targetTableCount > 0:
                    logger.debug('Performing CDC on ' + str(obj['cdc-keys']['input-table-keys']))
                    cdcCols = obj['cdc-keys']['input-table-keys']
                    query = ""
                    for i in range(0,len(cdcCols)):
                        query += "updates."+cdcCols[i] + " " + "<>" + " " + "target."+cdcCols[i] + " "
                        if i == len(cdcCols)-1:
                            break
                        query += " "+ "or" + " "
                    rowsToUpdate = HASH_TABLE.alias("updates").join(TARGET_TABLE.toDF().alias("target"), obj['scd2']['input-table-keys']).where(expr(query)).where("target.CURR_IND == '1'")    
                        
                else:
                    logger.debug('Skipping CDC since target table is empty ')
    
                # Row count being exported to target table after removing duplicate - based on CDC key
    
                destRowCount = rowsToUpdate.count()
                logger.debug('Row count after removing CDC '
                            + str(destRowCount))
            else:
                logger.debug('Skipping CDC since CDC is not configured')
        else:
            logger.debug('CDC is not required for Initial Load')
        
        # Rejected rows while exporting
        rejRowCount = totalRowCount - destRowCount
        logger.debug('Rejected row count after CDC ' + str(rejRowCount))

        # Cast columns based on their data types
        HASH_TABLE.show()
        for colName in HASH_TABLE.columns:
            logger.debug('Column being validated : ' + colName)
            if colName in sorted(obj['target-schema'].keys()):
                # cast if datatype not maches
                for dfCol in HASH_TABLE.dtypes:
                    try:
                        if dfCol[0] == colName:
                            if dfCol[1] != str(obj['target-schema'][colName]['type']):
                                logger.debug('converting ' + colName + ' from datatype ' + dfCol[1]+ ' to ' + str(obj['target-schema'][colName]['type']))
                                HASH_TABLE = HASH_TABLE.withColumn(colName,col(colName).cast(str(obj['target-schema'][colName]['type'])))
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise columnCastError(colName,obj['target-schema'][colName]['type'])
                        except columnCastError as cce:
                            audit_rec=TransformLoadDataVault(exit_doc,stage,cce,'Failed',0,0,0,'NA',obj['target-table'])
                            audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,cce)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0,exit_doc
        
        if initialLoad == False:
            # Perform SCD2
            try:
                if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true':
                    #Remove the not Changed rows from Hash Table
                    NoChangeRows = HASH_TABLE.alias("updates").join(TARGET_TABLE.toDF().alias("target"), obj['cdc-keys']['input-table-keys']).select("updates.*")#.where("target.CURR_IND == '1'")
                    cols = HASH_TABLE.columns
                    rowsForSCD2 = HASH_TABLE.alias("a").join(NoChangeRows.alias("b"),obj['cdc-keys']['input-table-keys'],how = "leftAnti").select(cols)   
                    scdKey = obj['scd2']['input-table-keys'][0]
                    stagedUpdates = (
                            rowsToUpdate
                           .selectExpr("NULL as mergeKey", "updates.*")   # Rows for 1
                           .union(rowsForSCD2.selectExpr(scdKey+" as mergeKey", "a.*"))  # Rows for 2.
                            )
                else:
                    logger.debug('Skipping SCD2 since SCD2 is turned off ')
            except Exception as ex:
                try:
                    logger.error(traceback.print_exc())
                    raise scdError("SCD2 Error "+ ex)
                except scdError as se:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,se,'Failed',0,0,0,'NA',obj['target-table'])
                    audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,se)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc
        else:
            logger.debug('SCD2 is not required for Initial Load')
        
        # TARGET_TABLE.unpersist()
        if initialLoad == True:
            HASH_TABLE.cache()
        else:
            if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true':
                stagedUpdates.cache()
            else:
                HASH_TABLE.cache()
       # List of the existing columns
       # column_list = HASH_TABLE.columns
       # DF_TYPES = HASH_TABLE.dtypes

        # Validate the schema and drop additional columns

        for colName in HASH_TABLE.columns:
            logger.debug('Column being validated : ' + colName)
            if colName in sorted(obj['target-schema'].keys()):
                colNewName = obj['target-schema'][colName]['colName']
                # Rename column if not matches with the existing

                if colName != colNewName:
                    logger.debug('Renaming to column : ' + colName)

                    # colName = "`" + colName +"`"
                    HASH_TABLE = HASH_TABLE.withColumnRenamed(colName,colNewName)
            else:
                logger.debug('Dropping column : ' + colName)
                HASH_TABLE = HASH_TABLE.drop(colName)
      
        # Write to Enrich Layer
        expected_period_key='NA'
        if destRowCount > 0:
            logger.info('target list:' + str(obj['target-col-list']))
            if initialLoad == True:
                HASH_TABLE = utilsTransDelta.add_Audit_columns(HASH_TABLE,logger, obj)
                HASH_TABLE = HASH_TABLE.select(obj['target-col-list'])
            else:
                if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true':
                    stagedUpdates = utilsTransDelta.add_Audit_columns(stagedUpdates,logger, obj)
                else:
                   HASH_TABLE = utilsTransDelta.add_Audit_columns(HASH_TABLE,logger, obj) 
                   HASH_TABLE = HASH_TABLE.select(obj['target-col-list'])
           
            if "FISCAL_PERIOD_KEY" in obj['target-col-list']:
                try:
                    max_df=HASH_TABLE.select("FISCAL_PERIOD_KEY").agg({"FISCAL_PERIOD_KEY":"max"})
                    expected_period_key=max_df.first()[0]
                except:
                    expected_period_key='NA'
           
               
            logger.debug('Writing new records to Enrich '+ str(destRowCount))
           
        #    stg_tb_nm=str(obj['target-table']).replace(".","_stg.")+"_STG"
            try:
                if initialLoad == True:
                    logger.info('Performing Initial Load')
                    if "partition-by" in obj:
                        HASH_TABLE.write.partitionBy(obj["partition-by"]).mode('append').save(obj['enrich-path'],format=str(obj['target-format']))
                    else:
                        HASH_TABLE.write.mode('overwrite').save(obj['enrich-path'],format=str(obj['target-format']))
                        #utilsIO.write_enrich(dbutils, HASH_TABLE, spark, obj, 'append',stg_tb_nm)
                else:
                    if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true':
                        logger.info('Performing Delta Merge and Reload the New and updated Record to the respective partition')
                        condition_query = ""
                        for i in range(0,len(cdcCols)):
                            condition_query += "target."+cdcCols[i] + " " + "<>" + " " + "staged_updates."+cdcCols[i] + " "
                            if i == len(cdcCols)-1:
                                break
                            condition_query += " "+ "or" + " "
                        condition_query+= " and target.CURR_IND = '1'"
                        update_dict = {}
                        for item in TARGET_TABLE.toDF().columns:
                            update_dict[item] = "staged_updates."+item
                        
                        
                        update_dict["UPD_USERID"] = "null"
                        update_dict["UPD_TS"] = "null"
                        #datetime_object = datetime.datetime.strptime(obj["batchDate"],"%Y%m%d%H%M%S")
                        datetime_object = datetime.datetime.utcnow()
                        TARGET_TABLE.alias("target").merge(
                            stagedUpdates.alias("staged_updates"),
                            "target."+scdKey+" = mergeKey").whenMatchedUpdate(condition = condition_query,set =
                                {                                         # Set current to false and endDate to source's effective date.
                                "SNAPSHOT_END_DT": "staged_updates.SNAPSHOT_BEG_DT",
                                "CURR_IND" : "0",
                                "UPD_USERID" : "null",
                                "UPD_TS" : obj["batchDate"]
                                }
                            ).whenNotMatchedInsert(values =update_dict).execute()
                    else:
                        if "partition-by" in obj:
                            HASH_TABLE.write.partitionBy(obj["partition-by"]).mode('append').save(obj['enrich-path'],format=str(obj['target-format']))
                        else:
                            HASH_TABLE.write.mode('overwrite').save(obj['enrich-path'],format=str(obj['target-format']))

            except Exception as ex:
                try:
                    logger.error(traceback.print_exc())
                  #  raise dbInsertError(stg_tb_nm)
                except dbInsertError as dbe:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,dbe,'Failed',0,0,0,'NA',obj['target-table'])
                    audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc
            targetTableColCount = len(HASH_TABLE.columns)
        else:
            logger.debug('Skipping the Write to atomic since no data to write')
        spark.catalog.clearCache()
        success_status_Desc="Load Enrich completed"
        if exit_doc["VALIDATION_FLAG"]=='Failed':
            invalid_dim=InvalidDimValidationError()
        else:
            invalid_dim=0
        #audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'In Progress',destRowCount,targetTableColCount,rejRowCount,expected_period_key,obj['target-table'],invalid_dim)
        audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'In Progress',destRowCount,targetTableColCount,rejRowCount,expected_period_key,obj['enrich-path'])
        audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,invalid_dim)
        exit_doc["EXIT_CODE"]=1
        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
        logger.debug('Inserted Audit Entry - Job Successful ')
        return HASH_TABLE, exit_doc
    except:

    # try       
        err_desc = str(traceback.format_exc())
        logger.error(str(err_desc))
        try:
            raise uncatchException(err_desc)
        except uncatchException as ue:
            # Update the failure entry
            audit_rec=TransformLoadDataVault(exit_doc,stage,ue,'Failed',0,0,0,'NA',obj['target-table'])
            audit_doc,exit_doc=utilsTransDelta.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
            exit_doc["EXIT_CODE"]=0
            print("2Before DB Update")
            metadataObject.insert_auditRecord(dbutils,obj, spark, audit_doc)
            logger.debug('Inserted Audit Entry - Job Failure ')
            return 0,exit_doc
    finally:

    # except

        logger.info('End of ' + __name__ + ' process...')


# sqlContext.clearCache()
# context.stop()
# finally
###################################################################################################
