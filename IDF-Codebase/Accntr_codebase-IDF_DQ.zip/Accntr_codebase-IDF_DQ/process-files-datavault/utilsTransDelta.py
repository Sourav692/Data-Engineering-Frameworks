# -*- coding: utf-8 -*-
import time
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType,DateType,TimestampType,IntegerType,DoubleType
#from elasticsearch import Elasticsearch
from pyspark.sql import SparkSession,Window
from pyspark.sql.functions import *
from datetime import datetime,timedelta
from pyspark.sql.functions import explode,create_map,lit,col,lower,trim,coalesce,upper,rank,udf,substring,regexp_replace,lpad,when,isnull,split,monotonically_increasing_id,current_timestamp,unix_timestamp
import hashlib
import re
from collections import OrderedDict
import os
import pandas as pd
from itertools import chain
import math
import utilsIO
import dateutil
from  dateutil.relativedelta import relativedelta
import builtins

# Get default initialised audit_doc
def gen_audit_dict(audit_doc,exit_doc,audit_rec,exception):
    audit_doc=OrderedDict()
    audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
    audit_doc['FILE_NAME'], exit_doc['FILE_NAME'] = audit_rec.FILE_NAME,audit_rec.FILE_NAME
    audit_doc['BATCH_DATE'],exit_doc['BATCH_DATE'] = audit_rec.BATCH_DATE,audit_rec.BATCH_DATE
    audit_doc['SOURCE_NAME'],exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
    audit_doc['PRCS_EXECUTION_ID'], exit_doc['PRCS_EXECUTION_ID'] = audit_rec.PRCS_EXECUTION_ID,audit_rec.PRCS_EXECUTION_ID
    audit_doc['PIPELINE_NAME'],exit_doc['PIPELINE_NAME']=audit_rec.PIPELINE_NAME,audit_rec.PIPELINE_NAME
    audit_doc['TRIG_NAME'],exit_doc['TRIG_NAME']=audit_rec.TRIG_NAME,audit_rec.TRIG_NAME
    audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
    audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC,audit_rec.TECH_STATUS_DESC
    exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
    audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
    audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
    exit_doc["VALIDATION_FLAG"]="Failed" if audit_rec.VALIDATION_FLAG else "Succeeded"

    audit_doc['SOURCE_PATH'], exit_doc['SOURCE']['SOURCE_PATH'] = audit_rec.SOURCE_PATH,audit_rec.SOURCE_PATH
    audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = audit_rec.SOURCE_ROW_COUNT,audit_rec.SOURCE_ROW_COUNT
    audit_doc['SOURCE_COL_COUNT'], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = audit_rec.SOURCE_COL_COUNT,audit_rec.SOURCE_COL_COUNT
    audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT']=audit_rec.SOURCE_AMOUNT,audit_rec.SOURCE_AMOUNT
    audit_doc['SOURCE_FILE_SIZE'], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = audit_rec.SOURCE_FILE_SIZE,audit_rec.SOURCE_FILE_SIZE
    exit_doc["EXPECTED_PERIOD_KEY"]=audit_rec.EXPECTED_PERIOD_KEY
    audit_doc['DEST_PATH'], exit_doc['DESTINATION']['DEST_PATH'] = audit_rec.DEST_PATH,audit_rec.DEST_PATH
    audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = audit_rec.DEST_ROW_COUNT,audit_rec.DEST_ROW_COUNT
    audit_doc['DEST_COL_COUNT'], exit_doc['DESTINATION']['DEST_COL_COUNT'] = audit_rec.DEST_COL_COUNT,audit_rec.DEST_COL_COUNT
    audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT']=audit_rec.DEST_AMOUNT,audit_rec.DEST_AMOUNT
    audit_doc['DEST_FILE_SIZE'], exit_doc['DESTINATION']['DEST_FILE_SIZE'] =audit_rec.DEST_FILE_SIZE,audit_rec.DEST_FILE_SIZE
    audit_doc['REJECTED_ROW_COUNT'], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = audit_rec.REJECTED_ROW_COUNT,audit_rec.REJECTED_ROW_COUNT
    audit_doc['REJECTED_FILE_NAME'], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = audit_rec.REJECTED_FILE_NAME,audit_rec.REJECTED_FILE_NAME
    audit_doc["LOG_PATH"]=audit_rec.LOG_PATH
    exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
    return audit_doc,exit_doc

# Function to join the dataframes
def df_join(leftDF,leftcolList,rightDF,rightColList,logger,joinType="inner"):
	logger.debug("Inside df_join")
	for (colNameleft, colNameRight) in zip(leftcolList,rightColList) :
		logger.debug("Casting  "+ colNameRight + " with datatype of  " + colNameleft)
		rightDF = rightDF.withColumn(colNameRight, col(colNameRight).cast(leftDF.schema[str(colNameleft)].dataType))

	for colName in rightColList:
		colName2 = "tempJoin_"+ colName
		logger.debug("Renaming column "+ colName + " with " + colName2 )
		rightDF = rightDF.withColumnRenamed(colName,colName2)

	leftDF= leftDF.join(broadcast(rightDF),[trim(col(f)).eqNullSafe(trim(col("tempJoin_" + s))) for (f, s) in zip(leftcolList,rightColList)], how = joinType)

	# Dropping the columns which are renamed after joining
	for colName in rightColList:
		colName2 = "tempJoin_"+ colName
		logger.debug("Dropping column "+ colName2)
		leftDF = leftDF.drop(colName2)

	if "CURR_IND" in leftDF.columns:
		leftDF = leftDF.drop("CURR_IND")
	return leftDF

# Function to Union the dataframes
def df_union(baseDF,sourceDF,unionType="byName"):

	if unionType == "byName":
		col_basetable = baseDF.columns
		col_currentTable = sourceDF.columns
		colToAddBase = list(set(col_currentTable).difference(col_basetable))
		colToAddCurrent = list(set(col_basetable).difference(col_currentTable))

		for colName in colToAddBase :
			baseDF = baseDF.withColumn(colName,lit(None).cast("string"))
		for colName in colToAddCurrent :
			sourceDF = sourceDF.withColumn(colName,lit(None).cast("string"))

		baseDF = baseDF.unionByName(sourceDF)

	elif unionType == "direct" :
		baseDF = baseDF.union(sourceDF)

	return baseDF



# PRocessed derived key function
def derived_dataframe_process(spark,objDict,HASH_DF,logger):
	if objDict.has_key("type"):
		logger.error("Executing the dervied dataframe process as :" + str(objDict["type"]))
		# Derive the new DF with the union
		if objDict["type"] == "col-union":
			setCounter = 0
			for setNo in objDict["sets-col"]:
				if setCounter == 0 :
					derivedDF = HASH_DF.select(objDict[setNo])
				else:
					derivedDF = derivedDF.union(HASH_DF.select(objDict[setNo]))
				setCounter = 1

		return derivedDF
	else:
		logger.error("No Type defined for derived dataframe process")

# PRocessed derived key function
def derived_key_process(spark,objDict,HASH_DF,logger,batch_Date=None):
	# Apply the derived key process as per the configs
	for keyName in sorted(objDict.keys()):
                
		colName = str(objDict[keyName]["colName"])
		HASH_DF = HASH_DF.withColumn(colName,lit(""))

		if objDict[keyName]["process"] == "lower" :
			colToLower = str(objDict[keyName]["colToLower"])
			logger.debug("Applying lower case  on col : " + colToLower + " to create column :" + str(colName))
			HASH_DF = HASH_DF.withColumn(colName,lower(col(colToLower)))

		if objDict[keyName]["process"] == "hash-key" :
			tempDict={}
			tempDict = {objDict[keyName]["colName"] : objDict[keyName]["hash-key"]}
			HASH_DF = generate_hash(spark,tempDict,HASH_DF,logger)
			logger.debug("Hash key generation process performed successfully")

		if objDict[keyName]["process"] == "substring" :
			substring_col = str(objDict[keyName]["substring_col"])
			start_index = int(objDict[keyName]["start_index"])
			if "length" in objDict[keyName]:
				length = int(objDict[keyName]["length"])
				HASH_DF = HASH_DF.withColumn(colName,substring(trim(col(substring_col)),start_index,length))
			else:
				column_name = objDict[keyName]["length_column_name"]
				length_sub=int(objDict[keyName]["length_sub"])
				expr_substring="substring(trim("+substring_col+"),"+str(start_index)+",length(trim("+substring_col+"))-"+str(length_sub)+")"
				print(expr_substring)
				HASH_DF = HASH_DF.withColumn(colName,expr(expr_substring))

		if objDict[keyName]["process"] == "new-default" :
			defaultValue = objDict[keyName]["default-value"]
			logger.debug("Creating new column :" + str(colName) + " with default value as : " + str(defaultValue))
			HASH_DF = HASH_DF.withColumn(colName,lit(defaultValue))
                  

		if objDict[keyName]["process"] == "default_value_to_key" :
			defaultValue = objDict[keyName]["default-value"]
			col_list = objDict[keyName]["col_list"]
			print( str(col_list) + "==============================" +str(defaultValue) )
			logger.debug("Creating new column :" + str(col_list) + " with default value as : " + str(defaultValue))
                                                                                                                       
                  
			HASH_DF=HASH_DF.na.fill(defaultValue,subset=col_list)
                  

		if objDict[keyName]["process"] == "new-copy" :
			copyCol = str(objDict[keyName]["copy-col"]).strip()
			logger.debug("Creating new column :" + str(colName) + " with copy of column : " + str(copyCol))
			HASH_DF = HASH_DF.withColumn(colName,col(copyCol))

		if objDict[keyName]["process"] == "rename" :
			colTorename = str(objDict[keyName]["colTorename"])
			new_name = str(objDict[keyName]["new_name"])
			logger.debug("renaming column :" + str(colTorename))
			HASH_DF = HASH_DF.withColumnRenamed(colTorename,new_name)

		if objDict[keyName]["process"] == "upper" :
			colToUpper = str(objDict[keyName]["colToUpper"])
			logger.debug("Applying Upper case  on col : " + colToUpper + " to create column :" + str(colName))
			HASH_DF = HASH_DF.withColumn(colName,upper(col(colToUpper)))

		if objDict[keyName]["process"] == "todate" :
			dateformat = str(objDict[keyName]["dateformat"]).strip()
			colToFormat = str(objDict[keyName]["colToFormat"])
			logger.debug("Applying to_date on column :" + str(colToFormat)+ " to create column :" + str(colName))
			HASH_DF = HASH_DF.withColumn(colName,to_date(trim(col(colToFormat).cast("string")),dateformat))

		if objDict[keyName]["process"] == "not-null-list" :
			logger.debug("Applying non null list case to create column :" + str(colName))
			notNullList = objDict[keyName]["cols"]
			for colToNull in notNullList:
				HASH_DF = HASH_DF.withColumn(colName,
							when(  (isnull(col(str(colToNull)))),
							col(colName)).otherwise(col(colToNull)))

		if objDict[keyName]["process"] == "flag" :
			logger.debug("Applying process flag to create column :" + str(colName))
			for ruleID in sorted(objDict[keyName]["rule_list"].keys()):
				ruleType = str(objDict[keyName]["rule_list"][ruleID]["rule_type"])
				ruleCol = str(objDict[keyName]["rule_list"][ruleID]["rule_col"])
				returnValue = str(objDict[keyName]["rule_list"][ruleID]["return-value"])
				defaultValue = str(objDict[keyName]["rule_list"][ruleID]["default-value"])

				if ruleType == "isnull" :
					HASH_DF = HASH_DF.withColumn(colName,when( ((trim(col(str(ruleCol))) == lit("")) |
					(isnull(col("`" + str(ruleCol) + "`"))) ) ,
							lit(returnValue)).otherwise(lit(defaultValue)))

		if objDict[keyName]["process"] == "concat-str" :
			logger.debug("Applying process concate with specified string to create column :" + str(colName))
			valueToAppend = str(objDict[keyName]["value_to_append"])
			derivedSeprator = str(objDict[keyName]["seprator"])
			colToConcat = str(objDict[keyName]["col_to_concat"])
			position=str(objDict[keyName]["pos"])
			if position=="prefix":
				HASH_DF=HASH_DF.withColumn(colName,when((trim(col(colToConcat)) == lit("")) | (isnull(col("`"+colToConcat+"`"))),col(colName)).otherwise(concat(lit(valueToAppend),lit(derivedSeprator),colToConcat)))
			else:
				HASH_DF=HASH_DF.withColumn(colName,when((trim(col(colToConcat)) == lit("")) | (isnull(col("`"+colToConcat+"`"))),col(colName)).otherwise(concat(colToConcat,lit(derivedSeprator),lit(valueToAppend))))

		if objDict[keyName]["process"] == "concat_sep" :
			derivedSeprator = str(objDict[keyName]["seprator"])
			logger.debug("Applying process concat with seprator : " + derivedSeprator + " to create column :" + str(colName))
			noCols = len(objDict[keyName]["cols"])
			for idx,colValKeys in enumerate(objDict[keyName]["cols"]):
				castDataType = "string"
				if "cast" in objDict[keyName]:
					if colValKeys in objDict[keyName]["cast"]:
						castDataType = str(objDict[keyName]["cast"][colValKeys])
				# Add the Seprator if not null
				if "index" not in objDict[keyName]:
					HASH_DF = HASH_DF.withColumn(colName,
								when((trim(col(str(colValKeys))) == lit("")) | (isnull(col("`" + str(colValKeys) + "`")))  ,
								col(colName)).otherwise(concat(col(colName),trim(col(colValKeys)).cast(castDataType),lit(derivedSeprator))))
				else:
					#HASH_DF = HASH_DF.withColumn(colName,when((trim(substring(col(str(colValKeys)),objDict[keyName]["index"][idx][0],objDict[keyName]["index"][idx][1])) == lit("")) | (isnull(col("`" + substring(col(str(colValKeys)),objDict[keyName]["index"][idx][0],objDict[keyName]["index"][idx][1])  + "`")))  ,col(colName)).otherwise(concat(col(colName),trim(substring(col(str(colValKeys)),objDict[keyName]["index"][idx][0],objDict[keyName]["index"][idx][1])).cast(castDataType),lit(derivedSeprator))))
					HASH_DF=HASH_DF.withColumn(colName,concat(col(colName),trim(substring(col(str(colValKeys)),objDict[keyName]["index"][idx][0],objDict[keyName]["index"][idx][1])).cast(castDataType),lit(derivedSeprator)))

			if len(derivedSeprator) > 0 :
				udfTrimLastChar = udf(lambda x:x[0:-1] if x is not None else x,StringType())
				HASH_DF = HASH_DF.withColumn(colName,udfTrimLastChar(colName))
                              

		if objDict[keyName]["process"] == "case_cond" :
			print(" In Case condition ")
			def case_cond(HASH_DF,colName,colToMatch,matchValue,matchType,returnValue,returnType,default_value):
				if matchType == "strmatch" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) & (trim(col(colToMatch)) == lit(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) & (trim(col(colToMatch)) == lit(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "like" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) & (trim(col(colToMatch)).like(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) & (trim(col(colToMatch)).like(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "colmatch" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) == trim(col(matchValue))), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) == trim(col(matchValue))), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "strmatch-notequal" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) != lit(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) != lit(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "colmatch-notequal" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) != trim(col(matchValue))), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) != trim(col(matchValue))), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "intmatch-greater" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) > lit(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)) > lit(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "match-list" :
					#matchValue=str(matchValue).replace("[","{").replace("]","}")
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)).isin(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) &  (trim(col(colToMatch)).isin(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "not-match-list" :
					#matchValue=str(matchValue).replace("[","{").replace("]","}")
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (~trim(col(colToMatch)).isin(matchValue)), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) &  (~trim(col(colToMatch)).isin(matchValue)), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "is-null" :
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)).isNull()), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) &  (trim(col(colToMatch)).isNull()), lit(returnValue)).otherwise(col(colName)))

				elif matchType == "is-not-null" :
					print("colToMatch")
					print(str(col(colToMatch)))
					if returnType  == "col" :
						HASH_DF = HASH_DF.withColumn(colName,
							when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)).isNotNull()), col(returnValue)).otherwise(col(colName)))
					elif returnType == "lit" :
						HASH_DF = HASH_DF.withColumn(colName,
							when((col(colName) == lit(default_value)) &  (trim(col(colToMatch)).isNotNull()), lit(returnValue)).otherwise(col(colName)))
					print("not-null check:")
					print(str(col(colName)))
					print(HASH_DF.withColumn(colName, when( (col(colName) == lit(default_value)) & (trim(col(colToMatch)).isNotNull()), col(returnValue)).otherwise(col(colName))))
					print("not-null check end:")

				else :
					index=0
					for ctm,cv,mt,rv,rt in zip(colToMatch,matchValue,matchType,returnValue,returnType):
						if index==0:
							HASH_DF=case_cond(HASH_DF,colName,ctm,cv,mt,rv,rt,"")
						else:
							HASH_DF=case_cond(HASH_DF,colName,ctm,cv,mt,rv,rt,"TRUE")
						index=index+1
				return HASH_DF

			logger.debug("Applying process conditional case to create column :" + str(colName))
			for idx,caseID in enumerate(sorted(objDict[keyName]["case_list"].keys())):
				matchValue = objDict[keyName]["case_list"][caseID]["match-value"]

				colToMatch = objDict[keyName]["case_list"][caseID]["col-to-match"]
				matchType = objDict[keyName]["case_list"][caseID]["match-type"]
				returnValue = objDict[keyName]["case_list"][caseID]["return-value"]
				returnType = objDict[keyName]["case_list"][caseID]["return-type"]
				logger.debug(" For Conditional Case , column to match :" + str(colToMatch))
				logger.debug(" column to Match : "+ str(colToMatch) + "Match Value : " + str(matchValue) + " ,Match Type : "+ str(matchType) + ", returnValue :" + str(returnValue) + ",returnType : "+ str(returnType))

				HASH_DF=case_cond(HASH_DF,colName,colToMatch,matchValue,matchType,returnValue,returnType,"")
			#HASH_DF.show()

		if objDict[keyName]["process"] == "lpad" :
                       
			maxlength = int(objDict[keyName]["length"])
			colNameToProcess = str(objDict[keyName]["colToPad"])
			newColName = str(objDict[keyName]["colName"])
			padValue = str(objDict[keyName]["pad-char"]).strip()
			logger.debug("Applying process type "+ objDict[keyName]["process"] + " on column :" + colNameToProcess)
			HASH_DF = HASH_DF.withColumn(newColName,lpad(col(colNameToProcess),maxlength,padValue))

		if objDict[keyName]["process"] == "dateformat" :
			dateformat = str(objDict[keyName]["dateformat"]).strip()
			newColName = str(objDict[keyName]["colName"])
			colNameToProcess = str(objDict[keyName]["colToFormat"])
			logger.debug("Applying process type "+ objDict[keyName]["process"] + " on column :" + colNameToProcess)
			HASH_DF = HASH_DF.withColumn(newColName,date_format(col(colNameToProcess),dateformat))

		if (objDict[keyName]["process"] == "window"):
			logger.debug("Applying windowing function")
			colToGenerate = str(objDict[keyName]["colName"])
			partitionCol1 = str(objDict[keyName]["partitionBycols1"])
			orderingCol1 = str(objDict[keyName]["orderBycols1"])
			order = str(objDict[keyName]["order"])
			logger.debug("Rank column "+colToGenerate)
			logger.debug("Partition column "+partitionCol1)
			logger.debug("Order by column "+orderingCol1)
			logger.debug("Ordering "+order)

			window = Window.partitionBy(col(partitionCol1)).orderBy(col(orderingCol1).desc())
			HASH_DF = HASH_DF.withColumn(colToGenerate,rank().over(window))
			logger.debug("Rank column derivation complete")

		if (objDict[keyName]["process"] == "gen-last-year-and-month"):
			monthColumn = str(objDict[keyName]["month_col"])
			yearColumn = str(objDict[keyName]["year_col"])
			HASH_DF=HASH_DF.withColumn(monthColumn,when(col(monthColumn)+1==13,lit(1)).otherwise(col(monthColumn)+1))
			HASH_DF=HASH_DF.withColumn(yearColumn,when(col(monthColumn)+1==13,(col(yearColumn)+1)).otherwise(col(yearColumn)))

		if (objDict[keyName]["process"] == "type-conversion"):
			prevColumn = str(objDict[keyName]["prevColumn"])
			colName = str(objDict[keyName]["colName"])
			dataType = str(objDict[keyName]["dataType"])
			HASH_DF=HASH_DF.withColumn(colName,col(prevColumn).cast(dataType))

		if (objDict[keyName]["process"] == "replace-string"):
			prevColumn = str(objDict[keyName]["prevColumn"])
			colName = str(objDict[keyName]["colName"])
			oldString = str(objDict[keyName]["oldString"])
			newString = str(objDict[keyName]["newString"])
			HASH_DF = HASH_DF.withColumn(colName, regexp_replace(prevColumn,oldString,newString))

		if (objDict[keyName]["process"] == "concat-list-values"):
			prevColumn = str(objDict[keyName]["prevColumn"])
			colName = str(objDict[keyName]["colName"])
			startIndex = objDict[keyName]["startIndex"]

			concatListValues = udf(lambda arr: concat_udf(arr), StringType())
			spark.udf.register("concatListValues", concatListValues)

			def concat_udf(arr_list):
				if "lastIndex" in objDict[keyName]["lastIndex"]:
					lastIndex=objDict[keyName]["lastIndex"]
				else:
					lastIndex=len(arr_list)
				final_string=""
				for x in range(startIndex,lastIndex):
					final_string=final_string+" "+arr_list[x]
				return final_string

			HASH_DF = HASH_DF.withColumn(colName, concatListValues(col(prevColumn)))

		if (objDict[keyName]["process"] == "trim-column"):
			prevColumn = str(objDict[keyName]["prevColumn"])
			colName = str(objDict[keyName]["colName"])
			HASH_DF=HASH_DF.withColumn(colName,trim(col(prevColumn)))

		if (objDict[keyName]["process"] == "split"):
			colName = str(objDict[keyName]["colName"])
			splitColName=str(objDict[keyName]["split-col-name"])
			delimiter=str(objDict[keyName]["delimiter"])
			if "index" not in objDict[keyName]:
				HASH_DF=HASH_DF.withColumn(colName,split(col(splitColName),delimiter))
			else:
				index=int(objDict[keyName]["index"])
				HASH_DF=HASH_DF.withColumn(colName,split(col(splitColName),delimiter)[index])
		if (objDict[keyName]["process"] == "gen-financial-period"):
			batch_date_formatted=datetime.strptime(batch_Date,"%Y%m%d")
			colName=str(objDict[keyName]["colName"])
			#numberOfMonths=int(objDict[keyName]["number-of-month"])
			HASH_DF=HASH_DF.withColumn(colName,lit(batch_date_formatted))
			HASH_DF=HASH_DF.withColumn("FIS_YEAR",when(month(col(colName))==lit(1),year(col(colName))).otherwise(year(col(colName))+1))
			HASH_DF=HASH_DF.withColumn("FIS_MONTH",when(month(col(colName))==lit(1),lit(12)).otherwise(month(col(colName))-1))
			HASH_DF=HASH_DF.withColumn("INC_MNTH",when(month(col(colName))==lit(1),lit(12)).otherwise(month(col(colName))-2))
			HASH_DF=HASH_DF.withColumn("FISC_PERIOD",concat(col("FIS_YEAR").cast("string"),lpad(col("FIS_MONTH").cast("string"),2,'0')))
			HASH_DF=HASH_DF.withColumn("INC_PRD",concat(col("FIS_YEAR").cast("string"),lpad(col("INC_MNTH").cast("string"),2,'0')))

		if (objDict[keyName]["process"]=="distinct"):
			logger.debug("Applying distinct  on DataFrame")
			HASH_DF=HASH_DF.distinct()
			logger.debug("distinct applied successfully on dataframe")

		# pivoting set of columns
		if (objDict[keyName]["process"]=="pivot"):
			logger.debug("Applying pivot on set of columns on  dataframe")
			pivot_column_list=objDict[keyName]["pivot_column_list"]
			key=str(objDict[keyName]["key"])
			value=str(objDict[keyName]["value"])
			HASH_DF=HASH_DF.withColumn(colName,create_map(list(chain(*((lit(column_name),col(column_name))for column_name in pivot_column_list  )))))
			HASH_DF=HASH_DF.select("*",explode(colName).alias(key,value))
			logger.debug("pivot applied successfully on dataframe")

		if (objDict[keyName]["process"] == "replace-custom-string"):
			colName = str(objDict[keyName]["colName"])
			substring_val = objDict[keyName]["substring_val"]
			HASH_DF=HASH_DF.withColumn(colName,expr(substring_val))

	# REturn the updated HASH_DF
	return HASH_DF

# default value function
def default_vaule_process(spark,objDict,hashDF,logger,obj):
	for defaultKeys in objDict.keys():
		logger.debug("Generating default col " + defaultKeys + " of type "+ str(objDict[defaultKeys]["type"]) )
		if objDict[defaultKeys]["type"] == "STRING" :
			hashDF = hashDF.withColumn(defaultKeys,lit(objDict[defaultKeys]["value"]))
		if objDict[defaultKeys]["type"] == "DATE" :
			if objDict[defaultKeys]["value"] == "BATCH_DATE" :
				datetime_object = datetime.strptime(obj["loadDate"],"%Y%m%d%H%M%S")
			elif objDict[defaultKeys]["value"] == "LOAD_DATE" :
				datetime_object = datetime.strptime(obj["loadDate"],"%Y%m%d%H%M%S")
			elif objDict[defaultKeys]["value"] == "CURRENT_DATE" :
				datetime_object = datetime.utcnow()
			else:
				datetime_object = datetime.strptime("01019999", "%d%m%Y")
			hashDF = hashDF.withColumn(defaultKeys,lit(datetime_object))

	return hashDF

def assign_non_null_value(spark,objDict,HASH_DF,logger):
	for key in sorted(objDict.keys()):
		print("Assign non null value " + key)
		first_col=str(objDict[key]["first_col"])
		second_col=str(objDict[key]["second_col"])
		HASH_DF=HASH_DF.withColumn(first_col,when( isnull(col(first_col)) ,col(second_col)).otherwise(col(first_col)))
	return HASH_DF

def custom_query_execution(spark,objDict,HASH_DF,logger):
	logger.debug(" create Dataframe with given query from config")
	if "row-num" in objDict:
		HASH_DF=HASH_DF.withColumn("rownum",monotonically_increasing_id())
	if "interim-query" in objDict:
		print("inside interim")
		logger.debug("creating intermediate DF from hash_df using query : "+ objDict["interim-query"])
		HASH_DF.registerTempTable("hash_df")
		interm_df=spark.sql(objDict["interim-query"].format("hash_df"))
	else:
		interm_df=HASH_DF

	logger.debug("creating final DF from hash_df or intermediate Dataframe using query : "+ objDict["final-query"])
	interm_df.registerTempTable("interm_df")
	final_df=spark.sql(objDict["final-query"].replace("{}","interm_df"))


	return final_df

# Function to filter by source
def source_filter(spark,objDict,HASH_DF,batchDate,logger):

	if "custom-query" in objDict:
		HASH_DF = HASH_DF.where(objDict["custom-query"])
	else:
		print(objDict)
		for keyToProcess in sorted(objDict.keys()):
			print(keyToProcess)
			HASH_DF.printSchema()
			processType = str(objDict[keyToProcess]["filter-type"])
			#logger.debug("Applying filter type : "+ processType)

			if processType == "notequal" :
				filterValue = str(objDict[keyToProcess]["value"]).strip()
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				HASH_DF = HASH_DF.filter(trim(col(keyFilter)) != filterValue)

			if processType == "like" :
				filterValue = str(objDict[keyToProcess]["value"]).strip()
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				HASH_DF = HASH_DF.filter(trim(col(keyFilter)).like(filterValue))

			if processType == "equal" :
				filterValue = str(objDict[keyToProcess]["value"]).strip()
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				HASH_DF = HASH_DF.filter(trim(col(keyFilter)) == filterValue)

			if processType == "col-equal" :
				filterValue = str(objDict[keyToProcess]["col-to-match"]).strip()
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				HASH_DF = HASH_DF.filter(trim(col(keyFilter)) == trim(col(filterValue)))

			if processType == "null" :
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				HASH_DF = HASH_DF.na.drop(subset = keyFilter)
				HASH_DF = HASH_DF.filter(trim(col(keyFilter))!=lit(""))

			if processType == "equal-list" :
				filterList = objDict[keyToProcess]["value"]
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying fiter type "+ processType + " on column :" + str(keyFilter))
				#print filterList
				logger.debug("Filter List on  "+ str(filterList) )
				HASH_DF = HASH_DF.filter(trim(col(keyFilter)).isin(filterList))

			if processType == "max" :
				keyFilter = str(objDict[keyToProcess]["colName"])
				logger.debug("Applying max type "+ processType + " on column :" + str(keyFilter))
				logger.debug("max logic started " + keyFilter)
				HASH_DF.registerTempTable("maxTemp")
				maxcol = HASH_DF.select(col(keyFilter)).distinct().collect()
				logger.debug(maxcol)
				HASH_DF = HASH_DF.where(str(keyFilter) + " = (select max("+ str(keyFilter) +") from maxTemp)")
				maxcol = HASH_DF.select(str(keyFilter)).distinct().collect()
				logger.debug(maxcol)
				logger.debug("max logic ended")

			if processType == "derived-filter":
				colName=str(objDict[keyToProcess]["colName"])
				suffix_final=""
				print("suffix_final:"+suffix_final)
				if "substarct-months" in objDict[keyToProcess]:
					batch_date_formatted=datetime.strptime(batchDate,"%Y%m%d")-dateutil.relativedelta.relativedelta(months=objDict[keyToProcess]["substarct-months"])

					month= batch_date_formatted.strftime("%b")
					if "case" in objDict[keyToProcess]:
						case = str(objDict[keyToProcess]["case"])
						if case == "upper":
							month = month.upper()
						else:
							month = month.lower()

					suffix_final="%"+month+objDict[keyToProcess]["seprator"]+objDict[keyToProcess]["string-suffix"]

					if "substarct-maxperiod" in objDict[keyToProcess]:
						batch_date_formatted_per=datetime.strptime(batchDate,"%Y%m%d")-dateutil.relativedelta.relativedelta(months=objDict[keyToProcess]["substarct-maxperiod"])
						period= str(batch_date_formatted_per.month)
						suffix_final=month+objDict[keyToProcess]["seprator"]+objDict[keyToProcess]["string-suffix"]+period

				if "substarct-periods" in objDict[keyToProcess]:
					batch_date_formatted=datetime.strptime(batchDate,"%Y%m%d")-dateutil.relativedelta.relativedelta(months=objDict[keyToProcess]["substarct-periods"])
					period= batch_date_formatted.strftime("%m")
					if "string-prefix" in objDict[keyToProcess]:
						string_prefix = str(objDict[keyToProcess]["string-prefix"])
						suffix_final="%"+string_prefix+objDict[keyToProcess]["seprator"]+objDict[keyToProcess]["string-suffix"]+period+"%"
					else:
						suffix_final="%"+period+objDict[keyToProcess]["seprator"]+objDict[keyToProcess]["string-suffix"]+"%"

				custom_string = "{} like '{}' ".format(colName, suffix_final)
                                        
				logger.debug("Applying fiter type "+ processType + " on column :" + str(colName))
				HASH_DF = HASH_DF.where(custom_string)

	return HASH_DF


# Creating the alias for source DF in mapping processes
def source_alias(spark,objDict,HASH_TABLE,logger):
	for colName in objDict.keys():
                                     
		if "newType" in objDict[colName]:
			HASH_TABLE = HASH_TABLE.withColumn(objDict[colName]["newName"], col(colName).cast(objDict[colName]["newType"])).drop(colName)
			logger.debug("Replacing ColName "+ str(colName) + " with " + str(objDict[colName]["newName"]) + " of type " + objDict[colName]["newType"])
		else:
			HASH_TABLE = HASH_TABLE.withColumnRenamed(colName,objDict[colName]["newName"])
			logger.debug("Replacing ColName "+ str(colName) + " with " + str(objDict[colName]["newName"]))
	return HASH_TABLE


def generate_hash(spark,objDict,HASH_TABLE,logger):
	generateHashKey =  udf(lambda x: str(hashlib.md5(x.encode(encoding="utf-8",errors="replace")).hexdigest()),StringType())
	for HASH_KEY in objDict.keys():
		logger.debug("HASH Table Count before null drop "+ str(HASH_TABLE.count()))
		HASH_TABLE = HASH_TABLE.filter(trim(col(objDict[HASH_KEY]))!=lit(""))
		HASH_TABLE = HASH_TABLE.na.drop(subset = objDict[HASH_KEY])
		logger.debug("HASH Table Count after null drop "+ str(HASH_TABLE.count()))
		HASH_TABLE = HASH_TABLE.withColumn(str(HASH_KEY), generateHashKey(col(objDict[HASH_KEY])))

	return HASH_TABLE

#Add LOAD_USERID,UPD_TS,UPD_USERID
def add_Audit_columns(hashDF,logger,objDict):
	logger.debug("Adding LOAD_USERID,UPD_TS,UPD_USERID - Audit columns in Dataframe")
	datetime_object = datetime.strptime(objDict["loadDate"],"%Y%m%d%H%M%S")
	hashDF=hashDF.withColumn("LOAD_TS",lit(datetime_object).cast(TimestampType()))
	hashDF=hashDF.withColumn("LOAD_USERID",lit(objDict["load_userid"]).cast(StringType()))
	hashDF=hashDF.withColumn("UPD_TS",lit(None).cast(TimestampType()))
	hashDF=hashDF.withColumn("UPD_USERID",lit(None).cast(StringType()))
	return hashDF

# Generate the system/process defined columns like batch ID, Batch Date & LoadDate
def system_value_process(spark,objDict,hashDF,logger):

    #if "batchID" in objDict:
		#hashDF = hashDF.withColumn("BATCH_ID",lit(objDict["batchID"]))
	print(objDict)
	if "loadDate" in objDict:
		if objDict["loadDate"]=="":
			datetime_object = datetime.utcnow()
		else:
			datetime_object = datetime.strptime(objDict["loadDate"],"%Y%m%d%H%M%S")
		hashDF = hashDF.withColumn("LOAD_TS",lit(datetime_object))
	if "batchDate" in objDict and  "scd2-flag" in objDict and  objDict["scd2-flag"]=="true":
		datetime_object = datetime.strptime(objDict["batchDate"],"%Y%m%d")
		batchDate_formatted=datetime.strftime(datetime_object, '%Y%m%d')
		hashDF = hashDF.withColumn("CREATED_DATE",lit(batchDate_formatted))
		hashDF = hashDF.withColumn("SNAPSHOT_BEG_DT",lit(datetime_object))
		hashDF = hashDF.withColumn("SNAPSHOT_END_DT",lit(None).cast(DateType()))
		hashDF = hashDF.withColumn("CURR_IND",lit('1'))
	else:
		datetime_object = datetime.strptime(objDict["batchDate"],"%Y%m%d")
		batchDate_formatted=datetime.strftime(datetime_object, '%Y%m%d')
		hashDF = hashDF.withColumn("CREATED_DATE",lit(batchDate_formatted))
		hashDF = hashDF.withColumn("SNAPSHOT_BEG_DT",lit(datetime_object))
		hashDF = hashDF.withColumn("SNAPSHOT_END_DT",lit(None).cast(DateType()))
		hashDF = hashDF.withColumn("CURR_IND",lit('1'))

	return hashDF

# Aggregation
def aggregate_process(spark,objDict,HASH_DF,logger):
	for keyName in sorted(objDict.keys()):
		if (objDict[keyName]["process"] == "group-by-w-agg"):
			group_by_list = objDict[keyName]["group_by_list"]
			agg_list=objDict[keyName]["agg_list"]
			agg_type=str(objDict[keyName]["agg_type"])
			HASH_DF=HASH_DF.groupBy(group_by_list)
			HASH_DF=HASH_DF.agg(agg_list)
			HASH_DF = HASH_DF.toDF(*(re.sub(r'[\,\s;\n\t\={}():]+', '', c.replace(agg_type,'AGG_')) for c in HASH_DF.columns))
		elif (objDict[keyName]["process"] == "subtract"):
			colName=str(objDict[keyName]["colName"])
			left_col_name= str(objDict[keyName]["left_col_name"])
			right_col_name= str(objDict[keyName]["right_col_name"])
			HASH_DF=HASH_DF.withColumn(colName,col(left_col_name)-col(right_col_name))
		elif (objDict[keyName]["process"] == "product"):
			colName=str(objDict[keyName]["colName"])
			first_col= str(objDict[keyName]["first_col"])
			second_col= str(objDict[keyName]["second_col"])
			HASH_DF=HASH_DF.withColumn(colName,col(first_col)*col(second_col))
	return HASH_DF



# Generate the Load_end Value
def generate_load_end_value(obj,logger):
	loadEndValue = "NULL"
	if str(obj["scd2"]["load-end-key"]["type"]) == "STRING":
		loadEndValue = str(obj["scd2"]["load-end-key"]["value"])
	elif str(obj["scd2"]["load-end-key"]["type"]) == "DATE":
		if str(obj["scd2"]["load-end-key"]["value"]) == "SNAPSHOT_END_DT":
			loadEndValue = datetime.strptime(obj["loadDate"],"%Y%m%d%H%M%S")
		elif str(obj["scd2"]["load-end-key"]["value"]) == "SNAPSHOT_END_DT-1":
			loadEndValue = datetime.strptime(obj["loadDate"],"%Y%m%d%H%M%S") + timedelta(days=-1)
		elif str(obj["scd2"]["load-end-key"]["value"]) == "LOAD_DATE-1":
			loadEndValue = datetime.strptime(obj["loadDate"],"%Y%m%d%H%M%S") + timedelta(days=-1)
		elif str(obj["scd2"]["load-end-key"]["value"]) == "CURRENT_DATE":
			loadEndValue = datetime.utcnow()

	return loadEndValue

def rename_cols(DF,table_name):
	col_list =DF.columns
	#hive_cols_list is to used to avoid renaming exiting cols load_userid and load_ts presnet in Hive parquet file
	hive_cols_list =[table_name+".load_userid",table_name+".load_ts",table_name+".upd_userid",table_name+".upd_ts"]
	for old_col in col_list:
		if old_col in hive_cols_list:
			continue
		if table_name in old_col:
			DF = DF.withColumnRenamed(old_col,old_col.replace(table_name+"_",""))
	return DF

def type_conversion(DF,objDict):
	DF=DF.withColumn(objDict["newColName"],col(objDict["colName"]).cast(objDict["dataType"]))
	return DF

def format_date_to_string(DF,objDict):
	for key in sorted(objDict.keys()):
		DF=DF.withColumn(objDict[key]["colName"],regexp_replace(col(objDict[key]["colToFormat"]).cast(DateType()).cast(StringType()),"-",objDict[key]["replace-char"]))
                                                                     
                                                  
	return DF

def data_quality_rules(sampleDF,objDict,fraction):
	col_dq_rules=[]
	src_count=sampleDF.count()
	fraction=fraction
	for keyName in sorted(objDict.keys()):
		col_name=objDict[keyName]["col_name"]
		dq_check_col=str.lower(col_name)+"_"+objDict[keyName]["quality_type"].replace("-","_")
		if objDict[keyName]["quality_type"]=="string_in_range":
			if objDict[keyName]["range"]=="generate_range":
				str_range=[]
				for iter in range(objDict[keyName]["start_range"],objDict[keyName]["end_range"]):
					str_range.append(str(iter).rjust(objDict[keyName]["char_length"],objDict[keyName]["fill_char"]))
			else:
				str_range=objDict[keyName]["str_range"]
			sampleDF=sampleDF.withColumn(dq_check_col,when((col(col_name).isin(str_range)),lit("TRUE")).otherwise(lit("FALSE")))
		if objDict[keyName]["quality_type"]=='string_length':
			sampleDF=sampleDF.withColumn(dq_check_col,when(  (length(col(col_name))>= objDict[keyName]["min_len"]) & (length(col(col_name))<=objDict[keyName]["max_len"]),lit("TRUE")).otherwise(lit("FALSE")))
		if objDict[keyName]["quality_type"]=='start_with':
			sampleDF=sampleDF.withColumn(dq_check_col,when((substring(col(col_name),0,objDict[keyName]["substring_len"]).isin(objDict[keyName]["match_list"])),lit("TRUE")).otherwise(lit("FALSE")))
		if objDict[keyName]["quality_type"]=='type-check':
			sampleDF=sampleDF.withColumn(dq_check_col,when(col(col_name).cast(objDict[keyName]["type"]).isNotNull(),lit("TRUE")).otherwise(lit("FALSE")))
		if objDict[keyName]["quality_type"]=='null-check':
			sampleDF=sampleDF.withColumn(dq_check_col,when((col(col_name).isNotNull()),lit("TRUE")).otherwise(lit("FALSE")))
		if objDict[keyName]["quality_type"]=='fixed-value-check':
			sampleDF=sampleDF.withColumn(dq_check_col,when(  (col(col_name)==lit(objDict[keyName]["fixed_value"])),lit("TRUE")).otherwise(lit("FALSE")))
		failed_dq_df=sampleDF.filter(col(dq_check_col)=="FALSE").count()
		column_stats=OrderedDict()
		column_stats["COLUMN_NAME"]=col_name
		column_stats["DQ_RULES"]=objDict[keyName]["quality_type"]
		column_stats["SAMPLE_SIZE"]=str(fraction*100)+ " %"
		column_stats["RECORDS_VALIDATED"]=src_count
		column_stats["BAD_RECORD"]=failed_dq_df
		column_stats["DQ %"]=str(int(failed_dq_df*100/src_count))+ " %"
		col_dq_rules.append(column_stats)
	return col_dq_rules

def insert_profiling_rec(doc,filepath):
		header_set=None
		if os.path.isfile(filepath):
			header_set=False
		else:
			header_set=True
		audit_df = pd.DataFrame(doc)
		audit_data =audit_df.to_csv(sep='|',index=False,header=header_set)

		with open(filepath,"a") as f:
			f.write(str(audit_data))
			f.write("\n")

# Fiscal period logic
def generate_financial_period(batchdate):

	if batchdate.strftime('%m')=='01':
		year= int(batchdate.strftime('%Y'))
		month=11
	elif batchdate.strftime('%m')=='02':
		year= int(batchdate.strftime('%Y'))
		month=12
	else:
		year= int(batchdate.strftime('%Y'))+1
		month=int(batchdate.strftime('%m'))-2
	return datetime.strptime(str(year)+str(month).ljust(2,'0')+"01", '%Y%m%d')

# Generate target folder with date (Fiscal/sys date)
def generate_target_period(batchdate,target_format,period_type):
	if target_format =='YYYY-MM-DD' and period_type=='sys':
		tgt_period=batchdate.strftime('%Y-%m-%d')
	elif target_format =='YYYY-MM' and period_type=='sys' :
		tgt_period=batchdate.strftime('%Y-%m')
	elif target_format =='YYYY-MM' and period_type=='financial' :
		batchdate=generate_financial_period(batchdate)
		tgt_period=batchdate.strftime('%Y-%m')
	elif target_format =='YYYY' and period_type=='sys' :
		tgt_period=batchdate.strftime('%Y')
	elif target_format =='YYYY' and period_type=='financial' :
		batchdate=generate_financial_period(batchdate)
		tgt_period=batchdate.strftime('%Y')
	else:
		print("didnt matched with expected format")
		return 0
	return tgt_period

def gen_fin_year(batch_date,format):
	batch_date_formatted=datetime.strptime(batch_date,"%Y%m%d")
	fin_year=str(int(datetime.strftime(batch_date_formatted,"%Y"))+1) if datetime.strftime(batch_date_formatted,"%m") not in ('01','02') else datetime.strftime(batch_date_formatted,"%Y")
	cal_year=str(datetime.strftime(batch_date_formatted,"%Y"))
	#start_year=str(int(datetime.strftime(batch_date_formatted,"%Y"))-1) if datetime.strftime(batch_date_formatted,"%m")  in ('01','02') else datetime.strftime(batch_date_formatted,"%Y")
	if (format=="YYYY"):
		fin_year=fin_year
	elif(format=="FYYY"):
		fin_year="FY"+fin_year[2:]
	elif(format=="CYYY"):
		fin_year=cal_year
	return fin_year



def check_dependency(sourceDict,batchDate,spark,obj):
	batch_date_formatted=datetime.strptime(batchDate,"%Y%m%d")
	batch_date_formatted=datetime.strftime(batch_date_formatted,"%Y-%m-%d")
	dependecy_table="ww_fin_fcp_secure.PRCS_EXECUTION"
	if sourceDict["type"]=="curated-zone" :
		process_name="raw_to_curated"
		file_name=sourceDict["fileName"]
		where_clause=" PRCS_NAME='"+process_name+"' and FILE_NAME='"+file_name+"' and BATCH_DATE='"+batch_date_formatted+"' and STATUS='Succeeded' and DEST_ROW_COUNT>0 "
	elif sourceDict["type"]=="dwh-enrich":
		process_name="curated_to_enrich"
		file_name=sourceDict["table-name"]
		source_list=sourceDict["source-list"]
		where_clause=" PRCS_NAME='"+process_name+"' and FILE_NAME='"+file_name+"' and SOURCE_NAME in "+source_list +" and BATCH_DATE='"+batch_date_formatted+"' and STATUS='Succeeded' "

	#SOURCE_NAME

                    

	sourceDF = utilsIO.read_enrich(spark,dependecy_table,obj,sourceDict)
	sourceDF.show()
	filtered_df_row_count=sourceDF.where(where_clause).count()

	dependency_flag=True if filtered_df_row_count>=1 else False
	return dependency_flag

def gen_tgt_schema_fr_missing_dim(missing_dim,sourceDict,objDict):
	for base,src in zip(sourceDict["combine"]['base-table-key'],sourceDict["combine"]['source-table-key']):
		missing_dim=missing_dim.withColumnRenamed(base,src)
	if "CURR_IND" in sourceDict["cols"]:
		missing_dim=missing_dim.withColumn("LOAD_TS",current_timestamp()).withColumn("LOAD_USERID",lit(objDict["load_userid"]).cast(StringType())).withColumn("CURR_IND",lit("1").cast(StringType()))
	else:
		missing_dim=missing_dim.withColumn("LOAD_TS",current_timestamp()).withColumn("LOAD_USERID",lit(objDict["load_userid"]).cast(StringType()))
	return missing_dim

def gen_exception_schema(missing_dim,objDict,sourceDict):
	DF=missing_dim.withColumn("file_nm",lit(objDict["source1"]["fileName"]))
	DF=DF.withColumn("entity_nm",lit(sourceDict["table-name"]))
	transformation_dict={}
	transformation_dict["colName"]="entity_col_val"
	transformation_dict["process"]="concat_sep"
	transformation_dict["cols"]=sourceDict["combine"]["base-table-key"]
	transformation_dict["seprator"]="|"

	new_dict={}
	new_dict["T1"]=transformation_dict
                
	DF=derived_key_process(spark,new_dict,DF,logger)
	DF=DF.withColumn("batch_date",lit(obj["batchDate"]))

	src_table_keys=sourceDict["combine"]['source-table-Actual-key'] if "source-table-Actual-key" in sourceDict["combine"] else sourceDict["combine"]['source-table-key']
	DF=DF.withColumn("entity_col",lit("|".join(src_table_keys)))
	DF=DF.withColumn("LOAD_TS",current_timestamp()).withColumn("LOAD_USERID",lit(objDict["load_userid"]).cast(StringType()))
	DF=DF.withColumn("dim_exist_flag",lit(0))

	DF.show()

def spark_dt(dt):
	otpt_dt=''
	if "char" in dt:
		otpt_dt=StringType()
	elif "int" in dt:
		otpt_dt=IntegerType()
	elif "datetime" in dt:
		otpt_dt=TimestampType()
	elif "decimal" in dt:
		otpt_dt=DoubleType()
	elif "date" in dt:
		otpt_dt=DateType()
	else:
		otpt_dt=StringType()
	return otpt_dt



def match_target_table_schema(spark,DF,obj,target_table):
	schema_table_name="information_schema.columns"
	sourceDF = utilsIO.read_enrich(spark,schema_table_name,obj)
	dbtable=target_table.split('.')
	schema_name=dbtable[0]
	table_name=dbtable[1]

	where_calse="Table_Schema='"+schema_name+"' and table_name='"+table_name+"' and ORDINAL_POSITION<> 1"
	agg_df=sourceDF.where(where_calse).select(["COLUMN_NAME","DATA_TYPE","table_name"]).groupBy(["table_name"]).agg(collect_list(col("COLUMN_NAME")),collect_list(col("DATA_TYPE")))
	req_data=agg_df.first()
	all_cols_nm=req_data[1]
	all_cols_dt=req_data[2]

	src_cols=DF.columns
	for col_name,col_dt in zip(all_cols_nm,all_cols_dt):
		if col_name in src_cols:
			DF=DF.withColumn(col_name,col(col_name))
		else:
			DF=DF.withColumn(col_name,lit(None).cast(spark_dt(col_dt)))
	
	DF=DF.select(all_cols_nm)
	return DF

def gen_exception_schema(spark,missing_dim,objDict,sourceDict,logger):
	DF=missing_dim.withColumn("FILE_NM",lit(objDict["source1"]["fileName"]))
	DF=DF.withColumn("ENTITY_NM",lit(sourceDict["table-name"]))
	src_table_keys=sourceDict["combine"]['source-table-Actual-key'] if "source-table-Actual-key" in sourceDict["combine"] else sourceDict["combine"]['source-table-key']
	DF=DF.withColumn("ENTITY_COL",lit("|".join(src_table_keys)))
	transformation_dict={}
	transformation_dict["colName"]="ENTITY_COL_VAL"
	transformation_dict["process"]="concat_sep"
	transformation_dict["cols"]=sourceDict["combine"]["base-table-key"]
	transformation_dict["seprator"]="|"

	new_dict={}
	new_dict["T1"]=transformation_dict
                
	DF=derived_key_process(spark,new_dict,DF,logger)
	batchDate_formatted=datetime.strptime(objDict["batchDate"], '%Y%m%d')
	batchDate_formatted=datetime.strftime(batchDate_formatted, '%Y-%m-%d')
	DF=DF.withColumn("BATCH_DT",lit(batchDate_formatted))
	
	DF=DF.withColumn("LOAD_TS",current_timestamp()).withColumn("LOAD_USERID",lit(objDict["load_userid"]).cast(StringType())).withColumn("UPD_TS",lit(None).cast(TimestampType())).withColumn("UPD_USERID",lit(None).cast(StringType()))
	DF=DF.withColumn("DIM_EXIST_FLAG",lit(0))

	DF=DF.select(["SRC_ID","FILE_NM","ENTITY_NM","ENTITY_COL","ENTITY_COL_VAL","BATCH_DT","LOAD_TS","LOAD_USERID","UPD_TS","UPD_USERID","BATCH_ID","DIM_EXIST_FLAG"])
          
	return DF

def get_latest_mth_prn(batchdate,dynamicInputPath,fin_year,latest_period_frm_data):
	batch_date1=datetime.strptime(batchdate,"%Y%m%d")
	batch_date_formatted=datetime.strftime(batch_date1,"%Y-%m-%d")
	if latest_period_frm_data==True:
		final_pth=dynamicInputPath+"/fin_year="+fin_year
		mth_ptns=os.listdir("/dbfs"+final_pth)
		print(mth_ptns)
		fin_mth=builtins.max(mth_ptns).replace('fin_mth=','').zfill(2)
	else:
		fin_mth=datetime.strftime(batch_date1+relativedelta(months=-2),"%m")
	return fin_mth

def dup_validation(obj,spark):
	DictWithDupTable = {}
	for source in obj["sourceList"]:
		dupRowCount = 0
		sourceDict = obj[source]
		tableName = str(sourceDict["table-name"])
		colList = sourceDict["cols"]
		scd_type = sourceDict["scd-type"]
		colString = ",".join(colList)
		sourceDF = utilsIO.read_enrich(spark,tableName,obj)
		sourceDF.registerTempTable('sourceTable')
		if scd_type=='Type-1':
			query = "SELECT {colName}, count(*) FROM sourceTable GROUP BY {colName} HAVING COUNT(*) > 1".format(colName = colString)
		else:
			query = "SELECT {colName}, count(*) FROM sourceTable where CURR_IND='1' GROUP BY {colName} HAVING COUNT(*) > 1".format(colName = colString)
		print("query", query)
		resultDF=spark.sql(query)
		dupRowCount=resultDF.count()
		if dupRowCount != 0:
			DictWithDupTable[tableName] = dupRowCount
		duplicate_count=0
		for tbl, count in DictWithDupTable.items():
			print("Table Name: {}, Duplicate Record Count: {}".format(tbl,count))
			duplicate_count=duplicate_count+1
	return DictWithDupTable,duplicate_count

def gen_invalid_file_size(spark,obj,batchdate):
	for source in obj["sourceList"]:
		sourceDict = obj[source]
		custom_query=str(sourceDict["custom_query"]).replace('{}',batchdate)
		hash_df = utilsIO.read_enrich(spark,sourceDict["table-name"],obj)
		hash_df.registerTempTable(sourceDict["temp-table-1"])
		hash_df=spark.sql(custom_query)
		hash_df.registerTempTable(sourceDict["temp-table-2"])
	fianl_df=spark.sql(obj["final-query"])
	invalidfiles_count=fianl_df.count()
	pandas_df = fianl_df.toPandas()
	json = pandas_df.to_json(orient ='records')
	return json,invalidfiles_count

def hrchy_validation(spark,obj,batchdate,base_environment_path):
	print(batchdate)
	for source in obj["sourceList"]:
		print(source)
		sourceDict = obj[source]
		colString = ",".join(sourceDict["cols"])
		hash_df = utilsIO.read_enrich(spark,sourceDict["table-name"],obj).select(sourceDict["cols"])
		if "filter" in sourceDict:
			hash_df = hash_df.where(sourceDict["filter"])
		hash_df.registerTempTable(sourceDict["temp-table"])
	resultDF=spark.sql(obj["final-query"].replace('{}',batchdate))  
	resultDF.registerTempTable("finalTable")
	path = base_environment_path+"missing_in_hrchy/"+batchdate+"/"
	resultDF.repartition("SRC_NM").write.partitionBy("SRC_NM").mode("overwrite").format("csv").save(path,header='true')

	distDF = spark.sql("SELECT distinct SRC_NM FROM finalTable")
	distDF.show()
	pandas_df = distDF.toPandas()
	key_count = 0
	src_nm_list = pandas_df["SRC_NM"].tolist()
	part_dict={}
	for src_nm in src_nm_list:
		key_count = key_count + 1
		key = "SRC_NM="+src_nm
		value = path+key
		part_dict["sourceFile" + str(key_count)] = src_nm
		part_dict["Location" + str(key_count)] = value
	print(part_dict)
	return part_dict,key_count

def check_dependency_extract(spark,sourceDict,obj,logger):
	dependency_flag=False
	counter=0
	retries_count=int(sourceDict["number-of-retries"]) if "number-of-retries" in sourceDict else 1
	print(retries_count)
	sleep_time=int(sourceDict["waiting-period-in-mins"])*60 if "waiting-period-in-mins" in sourceDict else 600
	print(sleep_time)
	while(dependency_flag==False and counter<retries_count):
		dependency_flag=check_dependency(sourceDict,obj["batchDate"],spark,obj)
		print(dependency_flag)
		counter=counter+1
		print(counter)
		if(dependency_flag==False and counter<retries_count):
			print("sleeping for ", str(sleep_time))
			time.sleep(sleep_time)
	return dependency_flag

def combine_source(spark,obj,countValueSource,sourceDict,sourceDF,baseDF,logger):
	#Skip join if first table
	if countValueSource > 1 and "combine" in sourceDict:
		# Combine by Union with baseDF
		if sourceDict["combine"]["type"] == "union" :
			unionType=sourceDict["combine"]["unionType"]
			logger.debug("Performing combining by union")
			# Default union by Name
			if "internal-target-col-list" in sourceDict:
                                  
                   
				target_col_list = sourceDict["internal-target-col-list"]
				sourceDF=sourceDF.select(target_col_list)
                                                 
                   
			baseDF = df_union(baseDF,sourceDF,unionType)
                       
                
			logger.debug("Count of base DF after union : "+ str(baseDF.count()))
		# Combine by joining to baseDF
		elif sourceDict["combine"]["type"] == "join" :
			#Join with the base Table
			joinType = "inner"
			if "join-type" in sourceDict["combine"]:
				joinType = str(sourceDict["combine"]["join-type"])
			logger.debug("Applying join of type " + str(joinType)+ " with the base table.")
                                 
			baseDF = df_join(baseDF,sourceDict["combine"]['base-table-key'],sourceDF,sourceDict["combine"]['source-table-key'],logger,joinType)
			logger.debug("Count of base DF after join : "+ str(baseDF.count()))
	else:  # First frame if the base DF was empty
		baseDF = sourceDF
	return baseDF

def forecast_plan_process(spark,obj,sourceDict,sourceDF,dynamicInputPath,logger):
	if "year-format" in sourceDict:
		fin_year=gen_fin_year(obj["batchDate"],sourceDict["year-format"])
	else:
		fin_year=gen_fin_year(obj["batchDate"],"FYYY")

	if "load-last-month-only" in sourceDict:
		latest_period_frm_data=sourceDict['latest_period_frm_data'] if "latest_period_frm_data" in sourceDict else False
		fin_mth=get_latest_mth_prn(obj["batchDate"],dynamicInputPath[5:],fin_year,latest_period_frm_data)
		where_clause="fin_year='"+fin_year+"' and fin_mth='"+str(fin_mth)+"'"
	elif "load-loaded-period-in-curated" in sourceDict:
		path=obj["prm_act_src_path_if_any"]
		path_tokenizer=path.split("/")
		where_clause=path_tokenizer[-2].replace("=","='")+"' and "+path_tokenizer[-1].replace("=","='")+"'"
	else:
		where_clause="fin_year='"+fin_year+"'"
	logger.info("Where clause "+ where_clause)
	sourceDF=sourceDF.where(where_clause)
	return sourceDF

def get_curated_base_path(spark,sourceDict,obj,logger):
	#change path once path is changed in raw zone
	if "path" in sourceDict:
		if "max_batchdate_flag" in sourceDict and sourceDict["max_batchdate_flag"]=="True" :
			batch_date=utilsIO.get_max_batchdate(str(obj['azure']["clean-base-path"])  + str(sourceDict["path"])+str(sourceDict["fileName"])+"/")
		elif "forecast-plan-flag" in sourceDict :
			batch_date=""
		else :
			batch_date=str(datetime.strptime(obj["batchDate"], '%Y%m%d'))[:10]
		if "prod17-flag" in sourceDict:
			inputPath = str(obj['azure']["clean-prod17-base-path"])  + str(sourceDict["path"]) +str(sourceDict["fileName"]) + "/"
		else:
			inputPath = str(obj['azure']["clean-base-path"])  + str(sourceDict["path"]) +str(sourceDict["fileName"]) + "/" #+ batch_date+ "/"
	else:
		inputPath = str(obj['azure']["clean-base-path"]) +"/" + str(obj['curated-location'])
	inputPathList = [ "/dbfs"+ str(inputPath)]
	logger.info("Input Path list is:"+str(inputPathList))
	return inputPath,inputPathList

def gen_tgt_file_sz(dbutils,dynamicInputPath,logger):
	dynamicInputPath = dynamicInputPath[5:]
	logger.debug("Reading Data from  "+ str(dynamicInputPath))
	lst=dbutils.fs.ls(dynamicInputPath)
	size=0
	for file_info in lst:
		size=size+file_info[2]
	return size

def gen_batch_Date_formatted(batchDate,logger):
	logger.debug("Inside gen_batch_Date_formatted to fetch date "+ str(batchDate))
	batchDate_formatted=datetime.strptime(batchDate, '%Y%m%d')
	batchDate_formatted=datetime.strftime(batchDate_formatted, '%Y-%m-%d')
	logger.debug("checking batchDate_formatted value" + str(batchDate_formatted))
	return batchDate_formatted

def get_last_mth_available_flag(dbutils,path,batch_date,logger):
	logger.debug("Inside get_last_mth_available_flag to make fin_year and fin_month "+ str(batch_date))
	d=datetime.strptime(batch_date,'%Y%m%d')
	logger.debug("Batch Date "+ str(d))
	d2=d-relativedelta(months=1)
	year,month=d2.year,str(d2.month).zfill(2)
	logger.debug("fin_year= "+str(year) + " and fin_month = "+str(month))
	abs_path=path[5:]+"/fin_year="+str(year)+"/fin_mth="+str(month)
	logger.debug("Path should exists for running this table "+ abs_path)
	try:
		length=len(dbutils.fs.ls(abs_path))
	except :
		length=0
	return length

def gen_prod17_inc_delta_identifier(obj,dbutils,dynamicInputPath,sourceDF,logger):
	schema_name=dynamicInputPath.split('/')[-3]
	table_name=dynamicInputPath.split('/')[-2]
	batch_date=gen_batch_Date_formatted(obj["batchDate"],logger)
	partition_updated_path=obj["azure"]["partition-log-path"]+batch_date+"/"+schema_name+".db/"+table_name+"/"
	success_file=partition_updated_path+schema_name+".db_"+table_name+"_SUCCESS"
	print(success_file)
	list_of_partition_file=partition_updated_path+"partitions_written_parquet.txt"
	try:
		success_file=len(dbutils.fs.ls(success_file))
	except:
		success_file=0
	if success_file==1:
		with open("/dbfs"+list_of_partition_file,'r') as fl :
			list_of_partition_updated=fl.read()
		where_clause=''
		for ptn_info in list_of_partition_updated.split("\n"):
			list_of_partitions=ptn_info.split("|")[1:-2]
			where_clause=where_clause+"("
			for ptn in list_of_partitions:
				if len(ptn.strip()) > 0:
					# Consider only non empty items.
					where_clause=where_clause+ptn.replace('=',"='")+"' and "
			where_clause=where_clause[:-4]+') or '
		where_clause=where_clause[:-5]
		print(where_clause)
		sourceDF=sourceDF.where(where_clause)
	else:
		sourceDF=0
	return sourceDF
