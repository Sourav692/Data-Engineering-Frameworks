"""file_validation.py
        @description: Checks different File validation test cases and generates dqStatistics table
           
"""
import os
import json
from pyspark.sql.functions import *
from pyspark.sql.types import StructType, StructField, StringType
from utils_file_validation import UtilsFileValidation

class FileValidation:
    """
        @description: Checks different File validation test cases and generates dqStatistics table
        @contents:
            1.data_quality_file_validation
            2.stats_gen
          
    """
    def data_quality_file_validation(self,spark, ref_input_path, ref_path, rule_val, ruleID, df_dq_master,rule_exe_ts,batchDate, logger):
        
        """
        @description: Checks different File validation test cases
        @params: hash_table, ref_input_path, ref_path, rule_val, ruleID, df_dq_master,rule_exe_ts,batchDate, logger
        @returns: dq_statistics -> a dataframe
        """
        rule_val = json.loads(rule_val)
        rule = rule_val["file_validation"]
        input_path = '/dbfs' + ref_input_path
        input_dir = '/dbfs' + ref_path
        input_path2 = '/dbfs' + ref_path
        file_obj=UtilsFileValidation()

        if rule.lower() != 'file_to_exist':
            if os.path.isfile(input_path) is False:
                logger.error("Please enter valid File Path")

        if rule.lower() == 'file_hash_to_equal':
            hash_val = rule_val["hash_val"]
            hash_alg = rule_val["hash_alg"]
            validation_res = file_obj.file_hash_to_equal(input_path, hash_val, hash_alg, logger)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'file_size_to_be_between':
            min_size = rule_val["min_size"]
            max_size = rule_val["max_size"]
            validation_res = file_obj.file_size_to_be_between(input_path, min_size, max_size, logger)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'file_to_be_valid_json': 
            schema_mat= None
            if "schema" in rule_val.keys():
                schema_mat = rule_val["schema"]
            validation_res = file_obj.file_to_be_valid_json(input_path, logger, schema_mat)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'file_to_have_valid_table_header':
            delimiter = rule_val["delimiter"]
            reg_exp = rule_val["reg_exp"]
            skip = rule_val["skip"]
            validation_res = file_obj.file_to_have_valid_table_header(input_path, delimiter, reg_exp, logger, skip)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'assert_binary_file_correct':
            validation_res = file_obj.assert_binary_file_correct(input_path, logger)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'assert_text_file_correct':
            validation_res = file_obj.assert_text_file_correct(input_path, logger)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'assert_csv_file_correct':
            validation_res = file_obj.assert_csv_file_correct(input_path, logger)
            val_res = "File is not valid"
            if validation_res is True:
                val_res = "File is valid"
        elif rule.lower() == 'assert_text_files_correct':
            val_res = file_obj.assert_text_files_correct(input_dir,logger)
        elif rule.lower() == 'assert_csv_files_correct':
            val_res = file_obj.assert_csv_files_correct(input_dir,logger)
        elif rule.lower() == 'file_to_exist':
            validation_res = file_obj.file_to_exist(input_path)
            logger.info(input_path)
            val_res = "File does not exist"
            if validation_res is True:
                val_res = "File exists"
        elif rule.lower() == 'file_string_match':
            user_str = rule_val["user_string"]
            validation_res = file_obj.file_string_match(input_path,user_str)
            val_res= "String does not exist" 
            if validation_res is True:
                val_res= "String exists"
        elif rule.lower() == 'files_hash_to_equal':
            hash_alg = rule_val["hash_alg"]
            validation_res = file_obj.files_hash_to_equal(input_path, input_path2, hash_alg, logger)
            val_res = "Files hash does not match"
            if validation_res is True:
                val_res = "File hash match"             
        else:
            logger.error("Please select valid File Validation Rule")
        
        dq_statistics= self.stats_gen(spark, df_dq_master, val_res, ruleID,rule_exe_ts,batchDate)
        return dq_statistics

    def stats_gen(self,spark,df_dq_master,stats,ruleID,rule_exe_ts,batchDate):
        """
        @description: Generates the dq statistics table 
        @params: df_dq_master,stats,ruleID,rule_exe_ts,batchDate
        @returns: dq_statistics -> a dataframe  
        """
        empty_rdd = spark.sparkContext.emptyRDD()
        dq_file_stats_schema = StructType([StructField("RULE_ID", StringType()), StructField("STATS_DESC", StringType())])
        dq_file_stats = spark.createDataFrame(empty_rdd, dq_file_stats_schema)
        dq_file_stats = dq_file_stats.union(spark.createDataFrame([(ruleID, stats)], dq_file_stats_schema))
        dq_stats= dq_file_stats
        dq_stats2 = dq_stats.withColumn("TOTAL_ROW_CNT", lit("0")).withColumn("FAILED_ROW_COUNT", lit("0")).withColumn("RULE_FAIL_PC", lit("0")).withColumn("EXEC_DATE",lit(rule_exe_ts)).withColumn("BATCH_DATE", lit(batchDate))
        dq_statistics = dq_stats2.join(df_dq_master.select(['RULE_ID','RULE_TYPE','RULE_DIMENSION','FILE_OR_TABLE_NAME', 'COL_NAME']),'RULE_ID','inner')\
        .select( "RULE_ID","RULE_TYPE","RULE_DIMENSION","FILE_OR_TABLE_NAME","COL_NAME","BATCH_DATE","TOTAL_ROW_CNT","FAILED_ROW_COUNT","RULE_FAIL_PC","EXEC_DATE","STATS_DESC")
    
        return dq_statistics
