import traceback
import os
import glob
import sys
import logging
import re
from pyspark.sql.functions import (abs as df_abs, col, count, countDistinct,
                                   max as df_max, mean, min as df_min,
                                   sum as df_sum, when
                                   )
from pyspark.sql.functions import date_format,datediff,variance, stddev, kurtosis, skewness,explode,col,udf,coalesce,when,to_date,lit,concat,lpad,monotonically_increasing_id,ceil,length,expr,substring,concat_ws,input_file_name,split
import numpy as np
from pyspark.sql.functions import *
import json
import pandas as pd
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import *
import pyspark.sql.functions as F
import datetime
from pyspark.sql.types import *
import math
from dateutil.relativedelta import relativedelta
import csv
from pytz import timezone
import hashlib
from collections import OrderedDict
from decimal import *
from pyspark.sql.functions import decode,upper,lower
import dateutil.relativedelta
import time
import Utils

sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
import utilsTransDelta
import utilsIO


# millis = int(round(time.time() * 1000))

def flatten_DF(nested_df):
    flat_cols = [c[0] for c in nested_df.dtypes if c[1][:6] != 'struct']
    nested_cols = [c[0] for c in nested_df.dtypes if c[1][:6] == 'struct' ]

    flat_df = nested_df.select(flat_cols +
                               [F.col(nc+'.'+c).alias(nc+'_'+c.replace(" ",""))
                                for nc in nested_cols
                                for c in nested_df.select(nc+'.*').columns]
                              )

    nested_cols_array = [c[0] for c in flat_df.dtypes if c[1][:5] == 'array']

    for nc2 in nested_cols_array:
      flat_df = flat_df.withColumn(nc2,explode(nc2))

    return flat_df

def profile(df,advance_profile="false", bins=5):

    if not isinstance(df, SparkDataFrame):
      raise TypeError("df must be of type pyspark.sql.DataFrame")

    # Number of rows:
    table_stats = {"n": df.count()}
    if table_stats["n"] == 0:
        raise ValueError("df cannot be empty")

    def describe_num_1d(df, column, current_result, nrows):

        stats_df = df.select(column).na.drop().agg(variance(col(column)).alias("variance"),
                                                    df_sum(col(column)).alias("sum")
                                                    ).toPandas()
        #stats = stats_df.ix[0].to_dict()
        stats = stats_df.ix[0].copy()
        stats["type"] = "NUM"
        stats['p_zeros'] = df.select(column).where(col(column)==0.0).count() / float(nrows)
        stats['histogram'] = df.groupBy(column).count().rdd.values().histogram(bins)

        return stats

    def describe_date_1d(df, column):
        stats_df = df.select(column).na.drop().agg(df_min(col(column)).cast(StringType()).alias("min"),
                                                   df_max(col(column)).cast(StringType()).alias("max")
                                                  ).toPandas()
        #stats = stats_df.ix[0].to_dict()
        stats = stats_df.ix[0].copy()
        #stats["col_name"] = column
        stats["type"] = "DATE"
        return stats

    def describe_categorical_1d(df, column):
        value_counts = (df.select(df[column].cast(StringType())).na.drop()
                        .groupBy(column)
                        .agg(count(col(column)))
                        .orderBy("count({c})".format(c=column),ascending=False)
                       ).cache()

        # Get the most frequent class:
        stats = (value_counts
                 .limit(1)
                 .withColumnRenamed(column, "top")
                 .withColumnRenamed("count({c})".format(c=column), "freq")
                ).toPandas().ix[0]

        # Get the top 5 classes by value count,
        # and put the rest of them grouped at the
        # end of the Series:
        top_5 = value_counts.limit(5).toPandas().sort_values("count({c})".format(c=column),
                                                               ascending=False)
        top_5_categories = top_5[column].values.tolist()

        others_count = pd.Series([df.select(df[column].cast(StringType())).na.drop()
                        .where(~(col(column).isin(*top_5_categories)))
                        .count()
                        ], index=["***Other Values***"])

        top = top_5.set_index(column)["count({c})".format(c=column)]
        top = top.append(others_count)
        value_counts.unpersist()
        stats["value_counts"] = top.to_dict()
        stats["type"] = "CAT"
        return stats

    def describe_constant_1d(df, column):
        stats = pd.Series(['CONST'], index=['type'], name=column)
        stats["value_counts"] = (df.select(df[column].cast(StringType()))
                                 .na.drop()
                                 .limit(1)).toPandas().ix[:,0].value_counts().to_dict()
        return stats

    def describe_unique_1d(df, column):
        stats = pd.Series(['UNIQUE'], index=['type'], name=column)
        stats["value_counts"] = (df.select(df[column].cast(StringType()))
                                 .na.drop()
                                 .limit(5)).toPandas().ix[:,0].value_counts().to_dict()
        return stats

    def describe_freeflow_1d(df, column):
        stats = pd.Series(['FREE_TEXT'], index=['type'], name=column)
        stats["value_counts"] = (df.select(df[column].cast(StringType()))
                                 .na.drop()
                                 .limit(5)).toPandas().ix[:,0].value_counts().to_dict()
        return stats


    def describe_1d(df, column, nrows):
        column_type = df.select(column).dtypes[0][1]
        # TODO: think about implementing analysis for complex
        # data types:
        if ("array" in column_type) or ("stuct" in column_type) or ("map" in column_type):
            raise NotImplementedError("Column {c} is of type {t} and cannot be analyzed".format(c=column, t=column_type))

        distinct_count = df.select(column).agg(countDistinct(col(column)).alias("distinct_count")).toPandas()
        non_nan_count = df.select(column).na.drop().select(count(col(column)).alias("count")).toPandas()
        results_data = pd.concat([distinct_count, non_nan_count],axis=1)
        if float(results_data["count"]) > 0 and int(results_data["distinct_count"]) >= 0 :
          results_data["p_unique"] = str(int(results_data["distinct_count"]) / float(results_data["count"]))
        else:
          results_data["p_unique"] = "NA"
        if int(results_data["distinct_count"]) == nrows :
          results_data["is_unique"] = "true"
        else:
          results_data["is_unique"] = "false"

        result = results_data.ix[0].copy()
        result.name = column

        if result["distinct_count"] <= 1:
            result = result.append(describe_constant_1d(df, column))
        elif column_type in {"tinyint", "smallint", "int", "bigint","float", "double", "decimal"}:
            result = result.append(describe_num_1d(df, column, result, nrows))
        elif column_type in {"date", "timestamp"}:
            result = result.append(describe_date_1d(df, column))
        elif result["is_unique"] == "true":
            result = result.append(describe_unique_1d(df, column))
        elif result["distinct_count"] <= 10 and result["distinct_count"] > 1 :
            result = result.append(describe_categorical_1d(df, column))
        else:
            result = result.append(describe_freeflow_1d(df, column))

        result_dict = result.to_dict()
        result_dict['col_type'] = str(column_type)
        return result_dict

    # Basic Describe functionality
    columnListNonString = [item[0] for item in df.dtypes if not item[1].startswith('string')]
    statisticsList= df.describe().collect()
    ldesc = {}
    #print statisticsList

    for row in statisticsList:
        temp={}
        if row['summary'] == 'count' :
            temp = row.asDict()
            temp.pop('summary',None)
            temp1={}
            for colName in temp.keys():
                temp1[colName] = (table_stats["n"] - float(row[colName]))/table_stats["n"]
            ldesc['p_missing']= temp1
        else:
            for colName in columnListNonString:
              if colName in row.asDict().keys():
                temp[colName] = row[colName]
            temp.pop('summary',None)

        #print temp
        ldesc[row['summary']]= temp

    if advance_profile == "true" :
        ldesc_temp = {}
        for colum in df.columns:
            desc = describe_1d(df, colum, table_stats["n"])
            #print desc
            ldesc_temp.update({colum: desc})

        type_col={}
        p_unique={}
        histogram_stats= {}
        p_zeros = {}

        variance_stats={}
        val_count_stats={}
        dist_count_stats = {}
        date_min={}
        date_max={}
        for colum in df.columns:
            type_col[colum] = ldesc_temp[colum]['type']
            p_unique[colum] = ldesc_temp[colum]['p_unique']
            dist_count_stats[colum] = ldesc_temp[colum]['distinct_count']
            if ldesc_temp[colum]['type'] == "NUM" :
                histogram_stats[colum]= ldesc_temp[colum]['histogram']
                p_zeros[colum]= ldesc_temp[colum]['p_zeros']
                variance_stats[colum] = ldesc_temp[colum]['variance']
            elif ldesc_temp[colum]['type'] == "DATE" :
                date_min[colum] = ldesc_temp[colum]['min']
                date_max[colum] =ldesc_temp[colum]['max']
            else:
                val_count_stats[colum] = ldesc_temp[colum]['value_counts']


        ldesc['col_type'] = type_col
        ldesc['p_unique'] = p_unique
        ldesc['variance'] = variance_stats
        ldesc['p_zeros'] = p_zeros
        ldesc['histogram'] = histogram_stats
        ldesc['value_counts']= val_count_stats
        ldesc['distinct_count']= dist_count_stats
        ldesc['date_min']= date_min
        ldesc['date_max']= date_max

    return ldesc


''' Function to validate Date fields and assigned default values '''
def date_field_validation(df,date_col_list):
  for col_info in date_col_list:
    
    df=df.withColumn(col_info['col_name'],F.from_unixtime(F.unix_timestamp(col(col_info['col_name']),col_info['format'])).cast("timestamp")).withColumn("ERROR_CODE", when(col(col_info['col_name']).isNotNull(),col("ERROR_CODE")).otherwise(lit("1"))).withColumn("ERROR_DESC", when(col(col_info['col_name']).isNotNull(),col("ERROR_DESC")).otherwise(concat(col("ERROR_DESC"),lit(col_info['col_name']+"|")) ))
    #df=df.withColumn(col_info['col_name'],when(col(col_info['col_name']).isNotNull(),col(col_info['col_name'])).otherwise(lit(col_info['default_value'])))
    df=df.withColumn(col_info['col_name'],when(col(col_info['col_name']).isNotNull(),col(col_info['col_name'])).otherwise(F.current_timestamp()))
    
  return df


def get_spark_datatype(primitive_datatype):
    if primitive_datatype=='string':
        dataType=StringType()
    elif primitive_datatype=='int':
        dataType=IntegerType()
    elif primitive_datatype=='double':
        dataType=DoubleType()
    elif primitive_datatype=='float':
        dataType=FloatType()
    elif "decimal" in str.lower(primitive_datatype):
        dt_type=primitive_datatype.replace(")","")
        s_nd_p=dt_type.split("(")[1].split(",")
        dataType=DecimalType(int(s_nd_p[0]),int(s_nd_p[1]))
    elif primitive_datatype=='short':
        dataType=ShortType()
    elif primitive_datatype=='long':
        dataType=LongType()
    elif primitive_datatype=='timestamp':
        dataType=TimestampType()
    elif primitive_datatype=='binary':
        dataType=BinaryType()
    elif primitive_datatype=='boolean':
        dataType=BooleanType()
    elif primitive_datatype=='byte':
        dataType=ByteType()
    else:
        dataType=StringType()
    return dataType

''' create Spark Struct Schema for parsing using column info provided '''
def create_struct_schema(file_schema_broadcast,obj):
    struct_schema=[]
    for col_info in file_schema_broadcast:
        dataType=get_spark_datatype(col_info['datatype'])
        struct_schema.append(StructField(col_info['col_name'],dataType,col_info['isNullable']))
    struct_schema.append(StructField('_corrupt_record', StringType(), True))
    """if (obj["src_filename"]=="yes"):
        struct_schema.append(StructField("SRC_FILENAME",StringType(),True))"""
    return StructType(struct_schema)

""" this will look into each column value against data type, if not matched then would raise error code flag and put
 column name in error_desc"""
def column_level_validation(source_df,col_list,file_ext,nullValue):
    
    soruce_df_columns=source_df.columns
    source_df=source_df.withColumn("ERROR_CODE",lit(0)).withColumn("ERROR_DESC",lit(""))
    for idx,col_info in enumerate(col_list):
        print(col_info)
        if file_ext !='xlsx':
            source_df=source_df.withColumn("srcCol",when(col("whole_record")[idx]==lit(nullValue),lit(None)).otherwise(col("whole_record")[idx]))
            source_df=source_df.withColumn("exception_layer_"+col_info['col_name'],col("whole_record")[idx])
        else:
            source_df=source_df.withColumn("srcCol",when(col(soruce_df_columns[idx])==lit(nullValue),lit(None)).otherwise(col(soruce_df_columns[idx])))
            source_df=source_df.withColumn("exception_layer_"+col_info['col_name'],col(soruce_df_columns[idx]))

        if col_info['datatype'] != 'date':
            if col_info['datatype'] != 'string':
                source_df=source_df.withColumn(col_info['col_name'],F.trim(F.regexp_replace(col("srcCol"),'"','')))
            else:
                source_df=source_df.withColumn(col_info['col_name'],F.regexp_replace(col("srcCol"),'"',''))
            
            source_df=source_df.withColumn(col_info['col_name'],col(col_info['col_name']).cast(get_spark_datatype(col_info['datatype']))).withColumn("ERROR_CODE", when(col(col_info['col_name']).isNull() & col("srcCol").isNotNull(),lit(1)).otherwise(col("ERROR_CODE"))).withColumn("ERROR_DESC", when(col(col_info['col_name']).isNull() & col("srcCol").isNotNull(),concat(col("ERROR_DESC"),lit(col_info['col_name']+" : EC1, "))).otherwise(col("ERROR_DESC") ))
            source_df=source_df.withColumn(col_info['col_name'],when(col(col_info['col_name']).isNotNull(),col(col_info['col_name'])).otherwise(lit(col_info['default_value'])))
            

        else:
            print(col_info)
            source_df=source_df.withColumn(col_info['col_name'],F.trim(F.regexp_replace(col("srcCol"),'"','')))
            source_df=source_df.withColumn(col_info['col_name'],F.from_unixtime(F.unix_timestamp(col(col_info['col_name']),col_info['format'])).cast("date")).withColumn("ERROR_CODE", when(col(col_info['col_name']).isNull() & col("srcCol").isNotNull(),lit(1)).otherwise(col("ERROR_CODE"))).withColumn("ERROR_DESC", when(col(col_info['col_name']).isNull() & col("srcCol").isNotNull(),concat(col("ERROR_DESC"),lit(col_info['col_name']+" : EC1, "))).otherwise(col("ERROR_DESC") ))
            source_df=source_df.withColumn(col_info['col_name'],when(col(col_info['col_name']).isNotNull(),col(col_info['col_name'])).otherwise(lit(col_info['default_value'])))
        source_df=source_df.drop("srcCol")
    source_df=source_df.withColumn("ERROR_DESC",expr("case when ERROR_DESC!='' then concat('{',ERROR_DESC,'}') else ERROR_DESC end"))
    source_df=source_df.drop("whole_record")
    return source_df

# Generate Target column list
def gen_target_column_list(file_schema,df_type="normal"):

    tgt_col_list=[]
    errored_metdata_cols=["ERROR_CODE","ERROR_DESC"]
    for col_info in file_schema:
        if isinstance(col_info,dict):
            col_info=col_info['col_name']
        else:
            col_info=col_info

        if df_type=="normal":
            tgt_col_list.append(col_info)
        else:
            if col_info not in ["SRC_FILENAME"] + errored_metdata_cols:
                tgt_col_list.append("exception_layer_"+col_info)
            else:
                tgt_col_list.append(col_info)
    if "ERROR_CODE" in tgt_col_list:
        tgt_col_list=tgt_col_list
    else:
        tgt_col_list=tgt_col_list+errored_metdata_cols
    return tgt_col_list

def nullability_check(df,col_list):
    null_where_clause=""
    nonnull_where_clause=""
    for col_info in col_list:
        print(col_info)
        if col_info["isNullable"]==False:
            null_where_clause=null_where_clause+ "STRING(" + col_info["col_name"]+") is null or STRING("+col_info["col_name"]+ ") = '' or "
            nonnull_where_clause=nonnull_where_clause + "STRING("+col_info["col_name"]+") is not null and STRING("+col_info["col_name"]+ ") <> '' and "
            expr_case="case when STRING("+ col_info["col_name"]+ ") is null or STRING("+col_info["col_name"]+ ") = '' then case when ERROR_DESC!='' then replace(ERROR_DESC,'}',' , "+col_info["col_name"]+": EC2}') else '{"+col_info["col_name"]+" : EC2 }' end else ERROR_DESC end "
            error_cd_expr_case="case when STRING("+ col_info["col_name"]+ ") is null or STRING("+col_info["col_name"]+ ") = ''  then 1 else ERROR_CODE end"
            df=df.withColumn("ERROR_DESC",expr(expr_case))
            df=df.withColumn("ERROR_CODE",expr(error_cd_expr_case))
            df.show()
    print(null_where_clause)
    print(nonnull_where_clause)
    null_where_clause=null_where_clause[:-4] if null_where_clause !='' else None
    nonnull_where_clause=nonnull_where_clause[:-4] if nonnull_where_clause !='' else None
    if null_where_clause is not None :
        hvng_null_df=df.where(null_where_clause)
        clean_df=df.where(nonnull_where_clause)
    else:
        clean_df=df
        hvng_null_df=None

        
    clean_df.show()
    #hvng_null_df.show()

    return clean_df,hvng_null_df

def blank_as_null(df,schema):
    for col_info in schema:
        if col_info['datatype']=='string':
            df=df.withColumn(col_info['col_name'],when(col(col_info['col_name'])!="",col(col_info['col_name'])).otherwise(None))
    return df

def default_column(obj,inputDF):
    for row in obj['file_schema']:
        if row['default_value'] != None:
            inputDF = inputDF.na.fill(row['default_value'],subset=row['col_name'])    
    return inputDF

""" this will segregate  good and corrupted records based on schema applied and process corrupted record to insert default value and
raise Error code and Error desc """
def schema_validation(obj,parsed_df,file_schema_broadcast,extension):

    if  extension not in ( 'xlsx','xlsm')  :
        ''' error out DF based on if corrupt record is not null '''
        errored_out_df=parsed_df.filter(parsed_df["_corrupt_record"].isNotNull() ).select(col("_corrupt_record").alias('whole_record')) if "src_filename" in obj and obj["src_filename"]!="yes" else parsed_df.filter(parsed_df["_corrupt_record"].isNotNull()).select(col("_corrupt_record").alias('whole_record'),col('SRC_FILENAME'))
        ''' error out DF based on if corrupt record is  null '''
        without_error_df=parsed_df.filter(parsed_df["_corrupt_record"].isNull()).drop(col('_corrupt_record')).withColumn("ERROR_CODE",lit(0)).withColumn("ERROR_DESC",lit(None).cast(StringType()))
        if "date_fields" in obj:
            without_error_df=date_field_validation(without_error_df,obj["date_fields"])
    else:
        errored_out_df=parsed_df

    errored_out_df.cache()

    ''' if error out DF count is not 0 , which means some of the records are corrupted and not as per given schema '''
    inputDF=None
    exception_df_dt=None
    exception_df_nl=None
    if isinstance(errored_out_df,SparkDataFrame):
        if errored_out_df.count()!=0 :
            nullValue=obj["nullValue"] if "nullValue" in obj else "";
            if extension not in  ('xlsx','xlsm'):
                errored_out_df=errored_out_df.withColumn("whole_record",F.split(col("whole_record"),obj["delimiter"]))
                errored_out_dflt_values_df=column_level_validation(errored_out_df,file_schema_broadcast,"txt",nullValue)
                errored_out_w_dflt_values_df=errored_out_dflt_values_df.select(gen_target_column_list(without_error_df.columns))
                errored_out_df.unpersist()

                exception_df_dt=errored_out_dflt_values_df.where(" ERROR_CODE !=0 ").select(gen_target_column_list(without_error_df.columns,"exception"))
                ''' union Error out df and without error DF '''
                inputDF=without_error_df.unionByName(errored_out_w_dflt_values_df)
            else:
                inputDF_wcv=column_level_validation(errored_out_df,file_schema_broadcast,"xlsx",nullValue)
                inputDF=inputDF_wcv.select(gen_target_column_list(file_schema_broadcast))

                exception_df_dt=inputDF_wcv.where(" ERROR_CODE !=0 ").select(gen_target_column_list(file_schema_broadcast,"exception"))
            
            inputDF=blank_as_null(inputDF,file_schema_broadcast)
            if exception_df_dt is not None :
                exception_df_dt = exception_df_dt.toDF(*(re.sub(r'exception_layer_', '', c) for c in exception_df_dt.columns))
            
        else:
            without_error_df=blank_as_null(without_error_df,file_schema_broadcast)
            inputDF=without_error_df.withColumn("ERROR_CODE",lit(0)).withColumn("ERROR_DESC",lit(None).cast(StringType())) if extension not in  ('xlsx','xlsm') else None
    else:
        without_error_df=blank_as_null(without_error_df,file_schema_broadcast)
        inputDF=without_error_df.withColumn("ERROR_CODE",lit(0)).withColumn("ERROR_DESC",lit(None).cast(StringType()))
    
    inputDF,exception_df_nl =nullability_check(inputDF,file_schema_broadcast)
    inputDF = default_column(obj,inputDF)
              
    
    null_cnt=exception_df_nl.count() if exception_df_nl is not None else 0
    exception_df_nl=exception_df_nl.withColumn("ec",lit(2)) if exception_df_nl is not None else exception_df_nl
    exception_df_dt=exception_df_dt.withColumn("ec",lit(1)) if exception_df_dt is not None else exception_df_dt
    if exception_df_nl is not None and exception_df_dt is not None:
        exception_df=exception_df_dt.union(exception_df_nl) 
    elif exception_df_nl is not None :
        exception_df=exception_df_nl
    else :
        exception_df=exception_df_dt
    print("Exception DF null count:")
    print(null_cnt)
    return inputDF,exception_df,null_cnt

# Rename the raw file name After it fet processed
def rename_files(path):
    files_list = glob.glob(path)
    for file in files_list:
        if os.path.isfile(file):
            if file[-2:]!="_p":
                os.rename(file,file+"_p")

def gen_fin_year(batch_date,format):
    batch_date_formatted=datetime.datetime.strptime(batch_date,"%Y%m%d")
    fin_year=str(int(datetime.datetime.strftime(batch_date_formatted,"%Y"))+1) if datetime.datetime.strftime(batch_date_formatted,"%m") not in ('01','02') else datetime.datetime.strftime(batch_date_formatted,"%Y")
    start_year=str(int(datetime.datetime.strftime(batch_date_formatted,"%Y"))-1) if datetime.datetime.strftime(batch_date_formatted,"%m")  in ('01','02') else datetime.datetime.strftime(batch_date_formatted,"%Y")
    cal_year=str(datetime.datetime.strftime(batch_date_formatted,"%Y"))
    if (format=="YYYY"):
        fin_year=fin_year
    elif (format=="SDT"):
        fin_year=start_year
    elif(format=="FYYY"):
        fin_year="FY"+fin_year[2:]
    elif(format=="CYYY"):
        fin_year=cal_year
    return fin_year

def gen_forcast_index_list(batch_date):
    batch_date_formatted=datetime.datetime.strptime(batch_date,"%Y%m%d")
    year_start_date=datetime.datetime.strptime(gen_fin_year(batch_date,"SDT")+"0301","%Y%m%d") #(Incorrect)
    days_diff=(batch_date_formatted-year_start_date).days
    btch_dt_week_day=batch_date_formatted.weekday()
    if (btch_dt_week_day!=5 and days_diff<7):
        max_week=1
    else:
        max_week=math.ceil((days_diff+2)/7)
    return max_week

def add_fiscal_yr_ptn(inputDF, obj):
    format = 'SDT'
    if 'add-fin-year-mapping' in obj:
        inputDF = inputDF.withColumn('fin_year',
                col(obj['add-fin-year-mapping']['colName'
                ]).substr(obj['add-fin-year-mapping']['start_index'],
                obj['add-fin-year-mapping']['length']))
    else:
        inputDF = inputDF.withColumn('fin_year',col(obj['fin-year-mapping']))
    return inputDF

def add_fiscal_mth_ptn(inputDF,filepath,obj):
    fin_mth=''
    if "fin-month-mapping" not in obj:
        filename=filepath.split("/")[-1]
        file_tokenized=filename.split("_")
        print(file_tokenized)
        for nm in file_tokenized:
            print(nm)
            if 'per' in nm.lower():
                fin_mth=nm[3:]
                break
        inputDF=inputDF.withColumn("fin_mth",lit(fin_mth))
    else:
        inputDF = inputDF.withColumn('fin_mth',substring(col(obj['fin-month-mapping']),2,2))
        fin_mth=inputDF.select('fin_mth').first()[0]
    return inputDF,fin_mth

def df_diff(src_df,tgt_df,partitioned_by=False):
    if 'SRC_FILENAME' in src_df.columns:
        columns_to_be_dropped=["LOAD_TS","LOAD_USERID","UPD_TS","UPD_USERID","SRC_ID","BATCH_ID","ERROR_CODE","ERROR_DESC","SRC_FILENAME"]
    else:
        columns_to_be_dropped=["LOAD_TS","LOAD_USERID","UPD_TS","UPD_USERID","SRC_ID","BATCH_ID","ERROR_CODE","ERROR_DESC"]
    if partitioned_by:
        src_df=src_df.drop(partitioned_by)
    src_df=src_df.drop(*columns_to_be_dropped)
    tgt_df=tgt_df.drop(*columns_to_be_dropped)
    final_df=src_df.unionAll(tgt_df).subtract(src_df.intersect(tgt_df))
    final_df_len=len(final_df.head(1))
    return final_df_len

# Transformation logic for concatination
def concat_lpad(inputDF,newcolname,concatcolname1,concatcolname2,pad_length,pad_value):
    inputDF=inputDF.withColumn(newcolname,concat(inputDF[concatcolname1],lit('.'),lpad(inputDF[concatcolname2],int(pad_length),pad_value)))
    return inputDF

def custom_data_manipulation(inputDF,custom_query_dict,batch_Date):
    for keyName in custom_query_dict.keys():
        col_name=custom_query_dict[keyName]["col-name"]
        query=str(custom_query_dict[keyName]["custom-query"]).replace('{}',"'"+batch_Date+"'")
        inputDF=inputDF.withColumn(col_name,expr(query))

    return inputDF

# Get optimal number of partitions to be written in ADLS curated layer
def set_optimal_partitions(DF,record_count,logger, BYTES_PER_RECORD=97.7, PARTITION_TO_FILE_SIZE_RATIO=2.97, TARGET_FILE_SIZE_MB=64):
  ## Calculate how many bytes should be in each Spark partition at the time of writing to achieve target file size.
  bytes_per_partition = PARTITION_TO_FILE_SIZE_RATIO * TARGET_FILE_SIZE_MB * 1024 * 1024
  ## Calculate approximately how many total bytes are being processed by multiplying number of records by bytes per record.
  total_record_bytes = record_count * BYTES_PER_RECORD
  ## Calculate the number of partitions required to achieve files of size TARGET_FILE_SIZE_MB by dividing the total bytes being processed by the number of bytes we want in each partition.
  optimal_partitions = math.ceil(total_record_bytes / bytes_per_partition)

  # Setting Shuffle partition count optimal partitions or default 200 which ever is bigger
  logger.info("Using " + str(optimal_partitions) + " partitions given " + str(BYTES_PER_RECORD) + " bytes per record and " + str(TARGET_FILE_SIZE_MB) + " desired MB per written file. Corresponding MB per dataframe partition: " + str(bytes_per_partition / (1024 * 1024)))
  shuffle_partitions = max(optimal_partitions,200)
  logger.info("Setting shuffle partitions to: " + str(shuffle_partitions))
  spark.conf.set("spark.sql.shuffle.partitions", shuffle_partitions)

  df_indexed = DF.withColumn("idx", monotonically_increasing_id()).withColumn("partition_idx", col('idx') % optimal_partitions)
  salt_col="partition_idx"
  ####### Step 5 #######
  ######################
  ## Create Spark Sql view in order to programmatically specify partition columns. DISTRIBUTE BY statement is equivalent to repartition.
  df_indexed.createOrReplaceTempView("df_indexed")
  subset_df_repartitioned = spark.sql("select * from df_indexed DISTRIBUTE BY "+ salt_col)
  final_df = subset_df_repartitioned.drop('idx', 'partition_idx')

  return final_df

def check_colsum(inputDF,targetDF,objdict,logger):
    logger.info("Validating source numeric and string column sum against target written")
    checksum_flag=False
    numeric_col=objdict["numeric_col"][0] if len(objdict["numeric_col"])>0 else "default_numeric"
    string_col=objdict["string_col"][0] if len(objdict["string_col"])>0 else "default_string"

    inputDF=inputDF.withColumn("default_numeric",lit(0)).withColumn("default_string",lit('0'))
    targetDF=targetDF.withColumn("default_numeric",lit(0)).withColumn("default_string",lit('0'))
    input_df_agg=inputDF.withColumn("string_col_length",length(col(string_col))).agg({numeric_col:"sum","string_col_length":"sum"})
    target_df_agg=targetDF.withColumn("string_col_length",length(col(string_col))).agg({numeric_col:"sum","string_col_length":"sum"})
    input_df_first_row=input_df_agg.first()
    target_df_first_row=target_df_agg.first()
    inp_numeric=str(input_df_first_row[0])
    inp_string=str(input_df_first_row[1])
    tgt_numeric=str(target_df_first_row[0])
    tgt_string=str(target_df_first_row[1])

    logger.info(" input string col "+ string_col + "sum(length()) = "+inp_string )
    logger.info(" input numeric col "+ numeric_col + "sum() = "+inp_numeric )
    logger.info(" target string col "+ string_col + "sum(length()) = "+tgt_string )
    logger.info(" target numeric col "+ numeric_col + "sum() = "+tgt_numeric )

    if inp_numeric==tgt_numeric and inp_string==tgt_string:
        checksum_flag=True

    return checksum_flag
    
def get_max_date_file(obj, dynamicInputPath, dbutils, logger):
    # Logic to find max date
    absolutefilepath=glob.glob('/dbfs'+dynamicInputPath)
    filenames = [f[:-18] for f in absolutefilepath]
    filename = max(filenames) if len(filenames)>0 else None

    logger.debug("absolute file path: " + str(absolutefilepath))
    logger.debug("file name: " + str(filename))
    max_latest_filename = [i for i in absolutefilepath if filename in i]
    max_latest_filename_len=len(max_latest_filename)
    dynamicInputPath = max_latest_filename[0] if max_latest_filename_len>0 else None
    logger.debug("Dynamic Input Path for max latest file is: " + str(dynamicInputPath))
   
        
    # Logic to remove max date file from the list
    if max_latest_filename_len>0:
        maxfileindex = absolutefilepath.index(max_latest_filename[0])
        del absolutefilepath[maxfileindex]

    # Logic to archive the unwanted files using list absolutefilepath
    archival_base_path=str(obj['azure']['archive-base-path']) + "/" + str(obj['raw-path']) 

    logger.debug("absolutefilepath: ")
    logger.debug(absolutefilepath)
    logger.debug("archival_base_path ::")
    logger.debug(archival_base_path)

    for path in absolutefilepath:
        archival_path = archival_base_path + str(path).rpartition('/')[-1]
        print("archival full Path:::")
        logger.debug(archival_path)
        print(archival_path)
        dbutils.fs.mv(str(path)[5:],archival_path)

    dynamicInputPath = dynamicInputPath[5:] if dynamicInputPath is not None else dynamicInputPath
    print("absolutefilepath is ::")
    print(absolutefilepath)

    return dynamicInputPath

def get_max_batchdate_raw_file(obj, dynamicInputPath, dbutils, logger):
    # Logic to find max timestamp from raw path
    absolutefilepath=glob.glob('/dbfs'+dynamicInputPath)
    #dynamicInputPath = dynamicInputPath if len(absolutefilepath)>0 else None
    print("List of files:")
    print(absolutefilepath)
    ls = []
    if absolutefilepath:
        for f in absolutefilepath:
            total_len = len(f)
            prefix=total_len-17
            suffix=total_len-4
            ls.insert(0, f[prefix:suffix])

        print(ls)
        filename = max(ls)
        print(filename)
        max_latest_filename_len=len(filename)
        dynamicInputPathlst = [i for i in absolutefilepath if filename in i] if max_latest_filename_len>0 else None
        if dynamicInputPathlst is not None:
            dynamicInputPath = dynamicInputPathlst[0]
             # Logic to remove max date file from the list
            if max_latest_filename_len>0:
                maxfileindex = absolutefilepath.index(dynamicInputPath)
                del absolutefilepath[maxfileindex]

        print("Dynamic Input Path for max latest file is::: ")
        print(dynamicInputPath)
       
        # Logic to archive the unwanted files using list absolutefilepath
        archival_base_path=str(obj['azure']['archive-base-path']) + "/" + str(obj['raw-path']) 
        logger.debug("absolutefilepath: ")
        logger.debug(absolutefilepath)
        logger.debug("archival_base_path ::")
        logger.debug(archival_base_path)
        print("Archival Path:::")
        print(archival_base_path)
        
        for path in absolutefilepath:
            archival_path = archival_base_path + str(path).rpartition('/')[-1]
            print("archival full Path:::")
            logger.debug(archival_path)
            print(archival_path)
            print("str(path)[5:]::")
            print(str(path)[5:])
            dbutils.fs.mv(str(path)[5:],archival_path)

        dynamicInputPath = dynamicInputPath[5:]

    print("absolutefilepath is ::")
    print(absolutefilepath)
    print("dynamicInputPath is ::")
    print(dynamicInputPath)
      
    return dynamicInputPath

def gen_batch_Date_formatted(batchDate):
    batch_date1=datetime.datetime.strptime(batchDate,"%Y%m%d")
    batch_date_formatted=datetime.datetime.strftime(batch_date1,"%Y-%m-%d")
    return batch_date_formatted

def gen_audit_dict(audit_doc,exit_doc,audit_rec,exception):
    audit_doc=OrderedDict()
    audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
    audit_doc['FILE_NAME'], exit_doc['FILE_NAME'] = audit_rec.FILE_NAME,audit_rec.FILE_NAME
    audit_doc['BATCH_DATE'],exit_doc['BATCH_DATE'] = audit_rec.BATCH_DATE,audit_rec.BATCH_DATE
    audit_doc['SOURCE_NAME'],exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
    audit_doc['PRCS_EXECUTION_ID'], exit_doc['PRCS_EXECUTION_ID'] = audit_rec.PRCS_EXECUTION_ID,audit_rec.PRCS_EXECUTION_ID
    audit_doc['PIPELINE_NAME'],exit_doc['PIPELINE_NAME']=audit_rec.PIPELINE_NAME,audit_rec.PIPELINE_NAME
    audit_doc['TRIG_NAME'],exit_doc['TRIG_NAME']=audit_rec.TRIG_NAME,audit_rec.TRIG_NAME
    audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
    audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC,audit_rec.TECH_STATUS_DESC
    exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
    audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
    audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
    exit_doc["VALIDATION_FLAG"]="Failed" if audit_rec.VALIDATION_FLAG else "Succeeded"

    audit_doc['SOURCE_PATH'], exit_doc['SOURCE']['SOURCE_PATH'] = audit_rec.SOURCE_PATH,audit_rec.SOURCE_PATH
    audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = audit_rec.SOURCE_ROW_COUNT,audit_rec.SOURCE_ROW_COUNT
    audit_doc['SOURCE_COL_COUNT'], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = audit_rec.SOURCE_COL_COUNT,audit_rec.SOURCE_COL_COUNT
    audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT']=audit_rec.SOURCE_AMOUNT,audit_rec.SOURCE_AMOUNT
    audit_doc['SOURCE_FILE_SIZE'], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = audit_rec.SOURCE_FILE_SIZE,audit_rec.SOURCE_FILE_SIZE
    exit_doc["EXPECTED_PERIOD_KEY"]=audit_rec.EXPECTED_PERIOD_KEY
    audit_doc['DEST_PATH'], exit_doc['DESTINATION']['DEST_PATH'] = audit_rec.DEST_PATH,audit_rec.DEST_PATH
    audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = audit_rec.DEST_ROW_COUNT,audit_rec.DEST_ROW_COUNT
    audit_doc['DEST_COL_COUNT'], exit_doc['DESTINATION']['DEST_COL_COUNT'] = audit_rec.DEST_COL_COUNT,audit_rec.DEST_COL_COUNT
    audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT']=audit_rec.DEST_AMOUNT,audit_rec.DEST_AMOUNT
    audit_doc['DEST_FILE_SIZE'], exit_doc['DESTINATION']['DEST_FILE_SIZE'] =audit_rec.DEST_FILE_SIZE,audit_rec.DEST_FILE_SIZE
    audit_doc['REJECTED_ROW_COUNT'], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = audit_rec.REJECTED_ROW_COUNT,audit_rec.REJECTED_ROW_COUNT
    audit_doc['REJECTED_FILE_NAME'], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = audit_rec.REJECTED_FILE_NAME,audit_rec.REJECTED_FILE_NAME
    audit_doc["LOG_PATH"]=audit_rec.LOG_PATH
    exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
    return audit_doc,exit_doc
        

def gen_dynamic_input_path(obj,dynamicInputPath,dbutils,logger):
    # Read only max timestamp file from landing layer
    logger.info("dynamicInputPath: " + dynamicInputPath)
    if "findmaxdate" in obj:
        logger.info("find max date")
        findmaxdate = str(obj["findmaxdate"])
        if findmaxdate == "True":
            dynamicInputPath = get_max_date_file(obj, dynamicInputPath, dbutils, logger)
    else:
    # Read only max timestamp file from raw layer
        if "src_filename" in obj and str(obj["src_filename"]).lower() == "no":
            dynamicInputPath = get_max_batchdate_raw_file(obj, dynamicInputPath, dbutils, logger)
    return dynamicInputPath

def gen_src_file_size(dynamicInputPath,dbutils):
    src_file_size=0
    file_path=glob.glob('/dbfs'+dynamicInputPath)
    act_path=None
    try:
        act_path = str(file_path[0])[5:]
        print('act_path ='+ str(act_path))
        lst=dbutils.fs.ls(act_path)
        for file_info in lst:
            src_file_size=src_file_size+file_info[2]
        print('src_file_size ='+ str(src_file_size))
    except:
        pass
    return src_file_size,act_path

def get_file_cnt_check(obj,dynamicInputPath):
    file_cnt_chk_flag=True
    expected_file_count=1
    actual_files_count=1
    if "file-count-check" in obj:
        expected_file_count=str(obj["file-count-check"])
        actual_files_count=str(len(glob.glob('/dbfs'+dynamicInputPath)))
        if(actual_files_count!=expected_file_count):
            file_cnt_chk_flag=False
        else:
            file_cnt_chk_flag=True
    return file_cnt_chk_flag,expected_file_count,actual_files_count

def get_transformation(inputDF,obj):
    if obj["transformation"]!="":
        if obj["transformation"]=="concat_lpad":
            inputDF=concat_lpad(inputDF,obj["concat_lpad"]["newcolname"],obj["concat_lpad"]["concatcolname1"],obj["concat_lpad"]["concatcolname2"],obj["concat_lpad"]["pad_length"],obj["concat_lpad"]["pad_value"])
        if obj["transformation"]=="custom-data-manipulation":
            print("inside transformation")
            custom_query_dict=obj["custom-data-manipulation"].copy()
            print(custom_query_dict)
            inputDF=custom_data_manipulation(inputDF,custom_query_dict,gen_batch_Date_formatted(obj["batchDate"]))
           
        if (obj["transformation"] == "split-process"):
            colName = str(obj["split-process"]["colName"])
            splitColName=str(obj["split-process"]["split-col-name"])
            delimiter=str(obj["split-process"]["delimiter"])
            if delimiter == ".":
                delimiter = delimiter.replace(".","\.")
            if "index" not in obj["split-process"]:
                inputDF=inputDF.withColumn(colName,split(col(splitColName,delimiter)))
            else:
                index=int(obj["split-process"]["index"])
                inputDF=inputDF.withColumn(colName,split(col(splitColName),delimiter)[index])
                
    return inputDF,obj["transformation"]

def add_fin_yr_mth_ptn(obj,dynamicInputPath,output,inputDF,act_path):
    destination_path=output
    inputDF=add_fiscal_yr_ptn(inputDF,obj)
    if  "fin_mth" in obj["partition-by"]:
        inputDF,fin_mth=add_fiscal_mth_ptn(inputDF,act_path,obj)
    if(os.path.exists("/dbfs/"+output)):
        if "fin_mth" not in obj["partition-by"]:
            inputDF=inputDF.where("fin_year='"+gen_fin_year(obj["batchDate"],obj["fin-year-format"])+"'")
            destination_path=output+"fin_year="+gen_fin_year(obj["batchDate"],obj["fin-year-format"])
        else:
            inputDF,fin_mth=add_fiscal_mth_ptn(inputDF,act_path,obj)
            print(fin_mth)
            inputDF=inputDF.where("fin_year='"+gen_fin_year(obj["batchDate"],obj["fin-year-format"])+"'")
            destination_path=output+"fin_year="+gen_fin_year(obj["batchDate"],obj["fin-year-format"])+"/fin_mth="+str(fin_mth)
    else:
        inputDF=inputDF
        destination_path=output
    return inputDF,destination_path

def add_metadata_columns(inputDF,obj):
    inputDF = inputDF.withColumn("LOAD_TS",lit(str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))).cast(TimestampType()))
    inputDF = inputDF.withColumn("LOAD_USERID",lit(obj["load_userid"]).cast(StringType()))
    inputDF = inputDF.withColumn("UPD_TS",lit(None).cast(TimestampType()))
    inputDF = inputDF.withColumn("UPD_USERID",lit(None).cast(StringType()))
    inputDF = inputDF.withColumn("SRC_ID",lit(obj["srcId"]).cast(IntegerType()))
    inputDF = inputDF.withColumn("BATCH_ID",lit(obj["prcs_runid"]))
    return inputDF

def src_tgt_comparison(obj,destination_path,inputDF,spark):
    if 'data-overwrite-flag' in obj:
        inputDF = inputDF
    print(destination_path)
    if(os.path.exists("/dbfs/"+destination_path)):
         if 'data-overwrite-flag' not in obj:
            target_df_bfr_wrt=spark.read.parquet(destination_path)
            if "partition-by" in obj:
                inputDF=src_tgt_df_diff(inputDF,target_df_bfr_wrt,obj["partition-by"])
            else:
                inputDF=src_tgt_df_diff(inputDF,target_df_bfr_wrt)
    else:
        inputDF=inputDF
    return inputDF


def src_tgt_df_diff(src_df,tgt_df,partitioned_by=False):
    
    columns_to_be_dropped=["LOAD_TS","LOAD_USERID","UPD_TS","UPD_USERID","SRC_ID","BATCH_ID","ERROR_CODE","ERROR_DESC"]
    if partitioned_by:
        src_df=src_df.drop(partitioned_by)
    src_df=src_df.drop(*columns_to_be_dropped)
    tgt_df=tgt_df.drop(*columns_to_be_dropped)
    src_df.show()
    tgt_df.show()
    final_df=src_df.subtract(tgt_df)
    final_df.show()
    return final_df

def gen_src_tgt_comparison_flag(obj,destination_path,src_vs_tgt_diff,inputDF,spark):
    if 'data-overwrite-flag' in obj:
        src_vs_tgt_diff = 1
    print(destination_path)
    if(os.path.exists("/dbfs/"+destination_path)):
         if 'data-overwrite-flag' not in obj:
            target_df_bfr_wrt=spark.read.parquet(destination_path)
            if "partition-by" in obj:
                src_vs_tgt_diff=df_diff(inputDF,target_df_bfr_wrt,obj["partition-by"])
            else:
                src_vs_tgt_diff=df_diff(inputDF,target_df_bfr_wrt)
    else:
        src_vs_tgt_diff=1
    return src_vs_tgt_diff

def write_df(obj,inputDF,output):
    mode_of_write = obj['mode-of-write']
    if "partition-by" in obj:
        inputDF.write.partitionBy(obj["partition-by"]).mode(mode_of_write).save(output,format=str(obj['target-format']))
    else:
        inputDF.write.mode(mode_of_write).save(output,format=str(obj['target-format']))

def gen_tgt_file_sz(dbutils,destination_path):
    dest_file_size=0
    dst=dbutils.fs.ls(destination_path)
    for file_info in dst:
        dest_file_size=dest_file_size+file_info[2]
    return dest_file_size
    
def file_delimit_validation(obj, dynamicInputPath, dbutils, logger):
    try:
        logger.info("Inside delimiter")
        file_path=glob.glob('/dbfs'+dynamicInputPath)
        config_delimit = str(obj['delimiter'])
        for file_info in file_path:
          file_name = str(file_info)   
          if (os.stat(file_name).st_size != 0):
            with open(file_name, newline = "") as csvfile:
                csvreader = csv.reader(csvfile)
                lines= len(list(csvreader))              
                csvfile.seek(0)
                if (lines > 2):
                    next(csvreader)
                    next(csvreader)
                try:
                    dialect = csv.Sniffer().sniff(csvfile.readline(4096),  delimiters = config_delimit)
                    logger.info("Delimiter Matched " + config_delimit)
                except:
                    logger.info("Delimiter Not Matched " + config_delimit)
                    return False
    except:
        pass
    return True

def get_exception_data(spark, obj, exception_df, dbutils, logger):
    logger.debug("Inside get_exception_data function")
    final_exception_df=None
    cols = exception_df.columns
    col_list = list(cols)
    del_col_list = ['ERROR_CODE','ERROR_DESC','ec' ]
    if del_col_list in col_list:
        for col in del_col_list:
            col_list.remove(col)
    src_colname = '|'.join(col_list)
    
    exception_df = exception_df.withColumn('SRC_ID',lit(obj['srcId']))
    exception_df = exception_df.withColumn('BATCH_ID',lit(obj["prcs_runid"]))
    exception_df = exception_df.withColumn('SRC_COLNAME',lit(src_colname))
    exception_df = exception_df.withColumn('SRC_COLVALUE',concat_ws('|',*[coalesce(c, lit("")) for c in col_list]))
    exception_df = exception_df.withColumn('BATCH_DATE',lit(gen_batch_Date_formatted(obj["batchDate"])))
    exception_df = exception_df.withColumn("LOAD_TS",lit(str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))).cast(TimestampType()))
    if "SRC_FILENAME" in col_list:
        exception_df=exception_df.drop("SRC_FILENAME")
    exception_df = exception_df.withColumn('SRC_FILENAME',lit(obj['target-dir']))
    if obj['type'] == 'data-quality-batch-process-rca' or obj['type'] == 'data-quality-batch-process':
        exception_df=exception_df.withColumnRenamed('ERROR_CODE','ERROR_TYPE')
        final_exception_df = exception_df.select('SRC_ID','SRC_FILENAME','BATCH_DATE','ERROR_TYPE','SRC_COLNAME','SRC_COLVALUE','ERROR_DESC','LOAD_TS','BATCH_ID')
    else:
        exception_df=exception_df.withColumnRenamed('ec','ERROR_TYPE')
        final_exception_df = exception_df.select('SRC_ID','SRC_FILENAME','BATCH_DATE','ERROR_TYPE','SRC_COLNAME','SRC_COLVALUE','ERROR_DESC','LOAD_TS','BATCH_ID')
    logger.info("Exception process Completed")
    return final_exception_df

  
def sla_check(obj, dynamicInputPath_p):
    absolutefilepath=glob.glob('/dbfs'+dynamicInputPath_p)
    filenames = [f[5:] for f in absolutefilepath]
    print(filenames)
    # Fail pipeline if sla breached
    cst = timezone('America/Chicago')
    cst_time = datetime.datetime.now(cst)
    hm=cst_time.strftime('%H%M')
    first_run = '1st'
    second_run = '2nd'
    #If first SLA wont have file received [count of files=0] then it should fail
    if len(filenames)==0 and int(str(hm))>int(obj["sla_start_1"]) and int(str(hm))<int(obj["sla_end_1"]):    
      return first_run
    elif "sla_start_2" in obj: #check if any second SLA to check
      #If second SLA has less than two files or zero files then it wont have file received [count of files=0 or count of files=1 but not =2] then it should fail  
      if (len(filenames)<2) and int(str(hm))>int(obj["sla_start_2"]) and int(str(hm))<int(obj["sla_end_2"]):
        return second_run

def adjustment_validation(spark,inputDF, obj, logger):
    try:
        print("Inside adjustment_validation ")
        sum = 0        
        batch_date_formatted = datetime.datetime.strptime(obj["batchDate"],"%Y%m%d")
        period = batch_date_formatted - dateutil.relativedelta.relativedelta(months=1)
        mth = 'Per' + str(period)[5:7]
        mth1 = 'P' + str(period)[5:7]
        col_match_list = [mth, mth1]
        df_cols = list(inputDF.columns)   
        col_name = list((set(col_match_list) & set(df_cols)))        
        inputDF.registerTempTable('sourceTable')
        query = "SELECT distinct {colName} FROM sourceTable".format(colName = col_name[0])    
        distDF = spark.sql(query)
        pd_df = distDF.toPandas()
        amnt = pd_df[col_name[0]].tolist()
        if len(amnt) != 0:
            for val in amnt:
                if(val != '' and val != 0 and val is not None):                                
                    sum = sum + Decimal(val)
                    if(sum > 0):
                        break;            
        if (sum == 0):       
            return False,col_name[0]
    except:
        pass
    return True,col_name[0]

## method to append error code
def error_code_append(curr_str,error_code):
    """
    @params: current string and error code
    @returns: current string with error code appended to it
    """
    if len(curr_str) == 0 or curr_str == '0':
        curr_str = error_code
    elif error_code in curr_str:
        curr_str = error_code
    elif len(error_code) > 0:
        curr_str = curr_str + '|' + error_code
    return curr_str

error_code_append_udf = udf(error_code_append, StringType())

## method to validate null data in a dataframe and append error code based on rule ID
def data_quality_null_validation(hash_table,ruleCol,ruleID):
    hash_table = hash_table.withColumn("ERR_CD", when(
        (trim(col(str(ruleCol))) == lit("")) | (isnull(col("`" + str(ruleCol) + "`"))),
        error_code_append_udf(col('ERR_CD'), lit(ruleID))) \
                                       .otherwise(col('ERR_CD')))
    return hash_table

## method to validate custom expression validation on spark dataframe
def data_quality_expression_validation(hash_table,ruleCol,ruleID,rule):
    ruleVal = rule['RULE_VAL']
    ruleExpr = expr(ruleVal)
    hash_table = hash_table.withColumn(ruleCol, ruleExpr) \
        .withColumn('ERR_CD',
                    when((trim(col(str(ruleCol))) == lit("")) | (
                        isnull(col("`" + str(ruleCol) + "`"))) | (
                                 trim(col(str(ruleCol))) == lit("false")),
                         error_code_append_udf(col('ERR_CD'), lit(ruleID))) \
                    .otherwise(col("ERR_CD")))

    return hash_table


## method to do straight lookup between to two dataframes
def data_quality_straight_lookup_validation(spark, envConfig, hash_table, ruleVal, ruleID, lookup_path, format, logger):
    try:
        ruleValLkUp = json.loads(ruleVal)
        hash_colList = list(ruleValLkUp['RULE_COL_TO_MATCH'].keys())
        ref_colList = list(ruleValLkUp['RULE_COL_TO_MATCH'].values())
        retColName = ruleValLkUp['REF_RET_COL']
        lookupTable = ruleValLkUp['REF_TABLE_NAME']
        REF_DF = utilsIO.read_data_based_on_format(spark,envConfig,format,lookup_path,lookupTable,logger)

        hash_table = utilsTransDelta.df_join(hash_table,hash_colList,REF_DF,ref_colList)
        hash_table = hash_table.withColumn('ERR_CD',
                                           when((trim(col(str(retColName))) == lit("")) | (
                                               isnull(col("`" + str(retColName) + "`"))),
                                                error_code_append_udf(col('ERR_CD'), lit(ruleID))) \
                                           .otherwise(col("ERR_CD")))
        return hash_table
    except:
        logger.error("Failed to apply straight lookup for rule value: " + ruleVal)
        return 0

# determine numerical and string col list
def get_num_cat_col(inputDF, reqColType):
    meta = inputDF.schema.fields
    if reqColType.lower() == 'numerical':
        numericalColList = [field.name for field in meta if isinstance(
                field.dataType, IntegerType) or isinstance(field.dataType, LongType) or isinstance(field.dataType, DoubleType)]
        return numericalColList
    elif reqColType.lower() == 'string':
        catColList = [field.name for field in meta if isinstance(
                field.dataType, StringType)]
        return catColList
    else:
        return 0


# get datatype of any col in a dataframe
def get_dtype(df,colname):
    """
    @params: dataframe and column name
    @return: data type in string format
    """
    return [dtype for name, dtype in df.dtypes if name == colname][0]

# Auxiliar functions
def equivalent_type(f):
    if f == 'datetime64[ns]': return TimestampType()
    elif f == 'int64': return LongType()
    elif f == 'int32': return IntegerType()
    elif f == 'float64': return FloatType()
    else: return StringType()

def define_structure(string, format_type):
    try: typo = equivalent_type(format_type)
    except: typo = StringType()
    return StructField(string, typo)

# Given pandas dataframe, it will return a spark's dataframe.
def pandas_to_spark(pandas_df):
    columns = list(pandas_df.columns)
    types = list(pandas_df.dtypes)
    struct_list = []
    for column, typo in zip(columns, types):
      struct_list.append(define_structure(column, typo))
    p_schema = StructType(struct_list)
    return sqlContext.createDataFrame(pandas_df, p_schema)


# Method to impute categorical columns
def get_impute_interpolate_col(inputDF, nullCol, labelEnc, method, logger):
    """
    @params: inputDF- spark dataframe, nullCol- column name to interpolate, method - interpolation method, labelEnc- LabelEncoder()
    @returns: imputated spark dataframe
    """
    if inputDF.count() > 0:
        try:
            #create train and test data
            train_data = inputDF.filter(col(nullCol).isNotNull()).toPandas()
            test_data = inputDF.filter(col(nullCol).isNull()).toPandas()
        except:
            logger.error("Failed to convert spark dataframe to Pandas")
            return 0

        # check column datatype and determine the imputation technique
        colDataType = get_dtype(inputDF,nullCol).lower()
        logger.info("Column provided for imputation is of {} type".format(colDataType))

        if colDataType == 'string':
            # Encode string using Label encoder
            enc_Col = nullCol+'_enc'
            train_data[enc_Col] = labelEnc.fit_transform(getattr(train_data,nullCol))
            try:
                enc_inputDF = train_data.append(test_data)
            except:
                logger.error("Append of test and train data in Pandas failed")
                return 0

            # include only string columns and encoded column interpolate method to avoid interpolation of other numerical columns
            # get all categorical and numerical columns
            strColList = get_num_cat_col(inputDF,'string')
            allColList = [field.name for field in inputDF.schema.fields]

            #append encoded column to the string column name list
            strColList.append(enc_Col)
            cat_df = enc_inputDF[strColList]

            #interpolate
            intr_df = cat_df.interpolate(method=method)
            logger.info("Interpolation of categorical column {} is completed successfully".format(nullCol))

            #get all remaining columns
            remColList = [x for x in allColList if x not in strColList]
            rem_df = enc_inputDF[remColList]

            # complete dataframe
            merge_df = pd.concat([rem_df,intr_df], axis = 'columns')

            # convert pandas to pyspark dataframe
            sp_df = pandas_to_spark(merge_df)

            # dropping the additional column(with interpolated values) from the data set
            final_df = sp_df.drop(enc_Col)

            return final_df

        elif colDataType == 'float' or colDataType == 'int' or colDataType == 'double':
            strColList = get_num_cat_col(inputDF,'string')
            allColList = [field.name for field in inputDF.schema.fields]
            # append encoded column to the string column name list
            strColList.append(nullCol)

            try:
                pd_df = inputDF.toPandas()
                feature_df = pd_df[strColList]
                intr_df = feature_df.interpolate(method=method)
                logger.info("Interpolation of categorical column {} is completed successfully".format(nullCol))
                remColList = [x for x in allColList if x not in strColList]
                rem_df = pd_df[remColList]
                comp_df = pd.concat([rem_df, intr_df], axis='columns')
                # final imputated dataframe
                final_imp_df = pandas_to_spark(comp_df)
                return final_imp_df
            except:
                logger.error(traceback.print_exc())
                return 0
    else:
        logger.error("dataframe is empty")
        return 0


# method to impute using mean, median
def get_mean(inputDF,colName,logger):
    """
    @params: inputDF- spark dataframe, colName- column name to impute mean on
    @returns: imputated spark dataframe
    """
    inputDF = inputDF.withColumn(colName,inputDF[colName].cast(IntegerType()))
    dt_type = get_dtype(inputDF,colName)
    if dt_type == 'int' or dt_type == 'float' or dt_type == 'double':
        df_stats = inputDF.select(mean(col(colName)).alias('mean')).collect()
        meanf = df_stats[0]['mean']
        logger.info("Null values in column {} is replaced with mean".format(colName))
        inputDF = replace_default_value(inputDF, colName, meanf)
        return inputDF
    else:
        logger.error("Column {} is not a numerical column".format(colName))
        return 0

# method to replace null values with default value
def replace_default_value(inputDF, colName, colValue, logger):
    """
    @params: inputDF- spark dataframe, colName- column name to impute mean on, colValue- value to be imputated in place of Null values
    @returns: imputated spark dataframe
    """
    dt_type = get_dtype(inputDF,colName)
    var_type = type(colValue)
    try:
        if dt_type == 'string' and var_type == 'string':
            inputDF = inputDF.withColumn(colName, when(((col(colName).isNull()) | (col(colName) == '')), colValue)\
                                         .otherwise(col(colName)))
            logger.info("Null values in column {} is replaced with default value {}".format(colName,colValue))
        elif dt_type == 'float' or dt_type == 'double':
            colValue = float(colValue)
            inputDF = inputDF.withColumn(colName, when(((col(colName).isNull()) | (col(colName) == '')), colValue)\
                                         .otherwise(col(colName)))
            logger.info("Null values in column {} is replaced with default value {}".format(colName, colValue))
        elif dt_type == 'integer':
            colValue = int(colValue)
            inputDF = inputDF.withColumn(colName, when(((col(colName).isNull()) | (col(colName) == '')), colValue)\
                                         .otherwise(col(colName)))
            logger.info("Null values in column {} is replaced with default value {}".format(colName, colValue))
        else:
            inputDF = inputDF.withColumn(colName, when(((col(colName).isNull()) | (col(colName) == '')), colValue)\
                                         .otherwise(col(colName)))
            logger.info("Null values in column {} is replaced with default value {}".format(colName, colValue))
    except:
        logger.error(traceback.print_exc())

# method to generate Metadata from within the data
def get_metadata(inputDF, obj, path):
  fDF = inputDF.select(obj['metadata-list'])
  fDF.coalesce(1).write.option("header", "true").mode("overwrite").format("com.databricks.spark.csv").save(path)

"""DQ_Modulerization"""
def get_data_frame(spark,obj,logger,file_path,FORMAT):
    """From the provided file_path import the file and create a frame according to the conditions in json obj"""
    if "file_schema" in obj:
        output_df=None
        logger.debug("Parsing the file with schema given explicitly in config")
        try:
            file_schema_broadcast=spark.sparkContFORMAT.broadcast(obj["file_schema"])
            nullValue=obj["nullValue"] if "nullValue" in obj else ""
            if ((FORMAT in ('csv', 'txt', 'dat')) and "src_filename" in obj and obj["src_filename"]!="yes"):
                output_df = spark.read.format("csv").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
            elif ((FORMAT in ('csv', 'txt', 'dat')) and "src_filename" in obj and  obj["src_filename"]=="yes"):
                output_df = spark.read.format("csv").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("SRC_FILENAME",input_file_name()).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                output_df=output_df.withColumn("SRC_FILENAME",reverse(split(col("SRC_FILENAME"),'/'))[0])
            elif((FORMAT == 'parquet') and "src_filename" in obj and obj["src_filename"]!="yes"):
                output_df = spark.read.format("parquet").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
            elif((FORMAT == 'parquet') and "src_filename" in obj and  obj["src_filename"]=="yes"):
                output_df = spark.read.format("parquet").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("SRC_FILENAME",input_file_name()).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                output_df=output_df.withColumn("SRC_FILENAME",reverse(split(col("SRC_FILENAME"),'/'))[0])
            elif((FORMAT == 'delta') and "src_filename" in obj and obj["src_filename"]!="yes"):
                output_df = spark.read.format("delta").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
            elif((FORMAT == 'delta') and "src_filename" in obj and  obj["src_filename"]=="yes"):
                output_df = spark.read.format("delta").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).option("nullValue",nullValue).load(file_path,schema = Utils.create_struct_schema(file_schema_broadcast.value,obj)).withColumn("SRC_FILENAME",input_file_name()).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                output_df=output_df.withColumn("SRC_FILENAME",reverse(split(col("SRC_FILENAME"),'/'))[0])
        except:
            logger.error(traceback.print_exc())
            raise fileNotFoundError(file_path)

        logger.debug("Schema is exposed to the data and Dataframe is created")
    else:
        output_df=None
        logger.debug("Parsing the file with inferring the schema from file itself")
        if ((FORMAT in ('csv', 'txt')) and "src_filename" in obj and  obj["src_filename"]!="yes"):
            output_df = spark.read.format("csv").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
        elif ((FORMAT in ('csv', 'txt')) and "src_filename" in obj and obj["src_filename"]=="yes"):
            output_df = spark.read.format("csv").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
            output_df=output_df.withColumn("SRC_FILENAME",input_file_name())
            split_source_filename=reverse(split(output_df['SRC_FILENAME'],'/'))
            output_df=output_df.withColumn("SRC_FILENAME",lit(split_source_filename.getItem(0)))
        elif((FORMAT == 'parquet') and "src_filename" in obj and obj["src_filename"]!="yes"):
            output_df = spark.read.format("parquet").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
        elif((FORMAT == 'parquet') and "src_filename" in obj and  obj["src_filename"]=="yes"):
            output_df = spark.read.format("parquet").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
            output_df=output_df.withColumn("SRC_FILENAME",input_file_name())
            split_source_filename=reverse(split(output_df['SRC_FILENAME'],'/'))
            output_df=output_df.withColumn("SRC_FILENAME",lit(split_source_filename.getItem(0)))
        elif((FORMAT == 'delta') and "src_filename" in obj and obj["src_filename"]!="yes"):
            output_df = spark.read.format("delta").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
        elif((FORMAT == 'delta') and "src_filename" in obj and  obj["src_filename"]=="yes"):
            output_df = spark.read.format("delta").option("inferSchema", "true").option("header",obj["header"]).option("comment",obj["comment"]).option("delimiter",obj['delimiter']).load(file_path).withColumn("index", monotonically_increasing_id()).filter(col("index") >= int(obj["skippedRows"])).drop("index")
            output_df=output_df.withColumn("SRC_FILENAME",input_file_name())
            split_source_filename=reverse(split(output_df['SRC_FILENAME'],'/'))
            output_df=output_df.withColumn("SRC_FILENAME",lit(split_source_filename.getItem(0)))
    return output_df

#method to check distinct path and format
def distinct_path(Input_df,logger):
    if Input_df:
        Input_df1 = Input_df[0]
        Input_dff = pd.DataFrame(dict([ (k,pd.Series(v)) for k,v in Input_df1.items() ]))
        unq_items1 = len(pd.unique(Input_dff['DATA_PATH_OR_TOPIC']))
        unq_items2 = len(pd.unique(Input_dff['FORMAT']))
        if(unq_items1 == 1 and unq_items2 == 1):
            return Input_df
        else:
            logger.error("Enter a distinct path or format")
    else:
        logger.error("Please select a rule")
