# Databricks notebook source
# MAGIC %sh 
# MAGIC pip install --upgrade pip
# MAGIC pip install editdistance
# MAGIC pip install minisom
import csv
import pickle
from collections import defaultdict
import editdistance
import numpy as np
import pandas as pd
import pickle
from minisom import MiniSom
from scipy.spatial import distance
from sklearn import preprocessing
from sklearn.metrics import silhouette_score
from sklearn.metrics.pairwise import cosine_similarity
import logging
import traceback
import optparse

#COMMON
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

x=6
y=6
iterations=5000 
normalized_yn="N" 
edit_distance = {}
cosine_distance = {}
euc_distance = {}


def processEngine(trainfeafile,test_feafile):
    logger.info("Schema matching process started")
    dataFeaturePath = trainfeafile
    test_featurePath = test_feafile
    firstpos=test_feafile.rfind("/")
    lastpos=len(test_feafile)
    foup=test_feafile[firstpos+1:lastpos].split(".")[0]
    DataFeatures = pickle.load(open(dataFeaturePath, 'rb'))
    logger.debug("Read training data from : "+str(dataFeaturePath))
    TestFeatures = pickle.load(open(test_featurePath, 'rb'))
    logger.debug("Read Test data from : "+str(test_featurePath))
    dims=len(list(DataFeatures.values())[0])
    def convert_to_np(dict_vals):
        f = list(dict_vals.values())
        logger.debug("np features "+str("Rows:{} cols:{}".format(len(f),len(f[0]))))
        n_f = np.array(f)
        logger.debug(">>np features:{}".format(n_f.shape))
        return n_f

    np_train_features = convert_to_np(DataFeatures)
    np_test_features = convert_to_np(TestFeatures)


    if normalized_yn=="N":
        normalized_feat = np_train_features
    else:
        min_max_scaler = preprocessing.MinMaxScaler()
        normalized_feat = min_max_scaler.fit_transform(np_train_features)
        logger.debug(">>normalized features:{}".format(normalized_feat.shape))


    # Combine keys and normalized features into dict
    logger.info("Combining keys and normalized features into dict")
    normalized_features_dict=dict(zip(DataFeatures.keys(),normalized_feat))
    # print ("Normalized features: rows={} cols={}".format(len(normalized_features_dict),len(normalized_features_dict['tr_hcp_footnote'])))


    som = MiniSom(x, y, dims, sigma=0.3, learning_rate=0.5)
    logger.info("Training...")
    som.train_random(normalized_feat, iterations,verbose=True)
    logger.info("...ready!")
    attribute_cluster_map={}
    cluster_data_vector_map=defaultdict(list)
    cluster_attrib_map=defaultdict(list)
    predicted_clusters=[]
    for key,data in normalized_features_dict.items():
        winid = som.winner(data)
        clusterid=np.ravel_multi_index(winid,(x,y))
        predicted_clusters.append(clusterid)
        attribute_cluster_map[key]=clusterid
        cluster_attrib_map[clusterid].append(key)
        cluster_data_vector_map[clusterid].append(data)

    logger.debug("Total uniq clusters:{}".format(len(cluster_data_vector_map)))
    cluster_center={}
    for k,v in cluster_data_vector_map.items():
        center  = [sum(j)/len(v) for j in zip(*v)]
        cluster_center[k]=center

    # MAGIC %md #### Finding a match for each Test feature
    test_attrib_clusterid_map={}
    for k,v in TestFeatures.items():
        eudistance = []
        min_dist = 2500000000
        for centerID, center in cluster_center.items():
            eudistance.append(distance.euclidean(v, center))
            min_d = min(eudistance)
            if min_d < min_dist:
                min_dist = min_d
                test_attrib_clusterid_map[k] = centerID
    

    sil_score= silhouette_score(list(DataFeatures.values()),predicted_clusters)
    
    def calculate_edit_distance(test_name, train_names_features):
        global edit_distance
        edit_distance[test_name] = {}
        for name in train_names_features:
            edit_distance[test_name][name] = editdistance.eval(test_name, name)
 

    def cosine_euc_distance(test_name, test_feature, train_name_features):
        cosine_distance[test_name] = {}
        euc_distance[test_name] = {}
        for name in train_name_features.keys():
            # print "shape of test_features:%s train_name_features:%s => name:%s" % 
            # test_feature.shape, train_name_features[
            #     name].shape, name
            test_nd = np.asarray(test_feature).reshape(1, -1)
            train_nd = np.asarray(train_name_features[name]).reshape(1, -1)
            cosine_distance[test_name][name] = cosine_similarity(test_nd,train_nd)[0][0]
            euc_distance[test_name][name] = distance.euclidean(test_feature, train_name_features[name])
    

    def cal_probability(distance_dic, dic2, dic3):
        prob_list=[]
        logger.debug("Writing file to : "+str(('/dbfs/mnt/mountdatalake/AZ_schemaData/resultData/avg_prob__'+str(foup)+str(x)+"_"+str(y)+".csv", 'w')))
        file_path = open('/dbfs/mnt/mountdatalake/AZ_schemaData/resultData/avg_prob__'+str(foup)+str(x)+"_"+str(y)+".csv", 'w')
        Out = csv.writer(file_path, delimiter=',')
        new_row = ['test_attribute', 'train_attribute', 'distance', 'avg_probability']
        Out.writerow(new_row)
        prob_list.append(new_row)
        for test_attribute in distance_dic.keys():
            total = sum(distance_dic[test_attribute].values())
            total2 = sum(dic2[test_attribute].values())
            total3 = sum(dic3[test_attribute].values())
    
            for train_attribute in distance_dic[test_attribute].keys():
                prob = 1 - (distance_dic[test_attribute][train_attribute] / float(total))
                prob2 = 1 - (dic2[test_attribute][train_attribute] / float(total2))
                prob3 = 0 if total3==0 else 1 - (dic3[test_attribute][train_attribute] / float(total3))
                avg_dist = (distance_dic[test_attribute][train_attribute]+
                            dic2[test_attribute][train_attribute]+
                            dic3[test_attribute][train_attribute])/float(3)
                avg_prob = (prob+prob2+prob3)/float(3.0)
                new_row = [test_attribute, train_attribute, avg_dist, avg_prob]
                prob_list.append(new_row)
                Out.writerow(new_row)
        file_path.close()
        return prob_list

    def pick_winner(prob_list, file):
        probDF = pd.DataFrame(prob_list[1:], columns=prob_list[0])
        logger.debug("Probability Dataframe imported:{} ".format(probDF.shape))
        min_distDF = probDF[probDF['distance'] == probDF.groupby(['test_attribute'])['distance'].transform(min)][['test_attribute', 'train_attribute', 'distance']].rename(columns={'train_attribute': 'mind_train_attribute'})
        max_probDF = probDF[probDF['avg_probability'] == probDF.groupby(['test_attribute'])['avg_probability'].transform(max)][['test_attribute', 'train_attribute', 'avg_probability']].rename(columns={'train_attribute': 'prob_train_attribute'})
        allDF = pd.merge(max_probDF, min_distDF, on=['test_attribute'])
        allDF['possible_train_attribute'] = allDF.apply(lambda r:
                                                        r['mind_train_attribute']
                                                        if r['prob_train_attribute'] == r[
                                                            'mind_train_attribute']
                                                        else ','.join(
                                                            [r['mind_train_attribute'], r['prob_train_attribute']]), axis=1)
        allDF = allDF[['test_attribute', 'distance', 'avg_probability', 'possible_train_attribute']]
        logger.debug("Writing data to file :"+str(file))
        allDF.to_csv(file, index=False, sep=',')
    
    print ("test_attrib size:{} train attrib_clus size:{}".format(len(test_attrib_clusterid_map), len(attribute_cluster_map)))  
    for key, val in test_attrib_clusterid_map.items():
        train_names = []
        train_name_features = {}
        for k, v in attribute_cluster_map.items():
            if val == v:
                train_names.append(k)
                train_name_features[k] = DataFeatures[k]
        calculate_edit_distance(key, train_names)
        cosine_euc_distance(key, TestFeatures[key], train_name_features)
    
    avg_prob = cal_probability(edit_distance, cosine_distance, euc_distance)
    logger.debug("Cluster:[{},{}]\n{}\nTotal Uniq Clusters:{}\nSilhouetteScore:{}".format(x,y,"="*20,len(cluster_data_vector_map),sil_score))
    file_name=foup+"test_train_match__"+str(x)+"-"+str(y)+".csv"
    baseResultPath="/dbfs/mnt/mountdatalake/AZ_schemaData/resultData/"
    resultFile=str(baseResultPath)+str(file_name)
    logger.debug("Result file : "+str(resultFile))
    matchDF = pick_winner(avg_prob,resultFile)
    return resultFile
