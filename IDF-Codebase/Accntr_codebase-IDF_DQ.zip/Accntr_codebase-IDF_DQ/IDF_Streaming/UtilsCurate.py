import sys
import json
import traceback
import re
import unicodedata
import logging
import pyspark
from pyspark.sql import SQLContext, Row
from pyspark.sql.types import *
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession
from pyspark.sql.functions import * 
import Utils
import time
import datetime
from collections import OrderedDict
from metadataManager import metadataManager

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/codebase/')
import utilsShared
from customException import *
from gen_audit_entry import *
                                                
###################################################################################################

class UtilsCurate:

    def __init__(self):
        pass

    def regexPartialReplaceFn(value, oper):

        if type(value) is unicode:
            value = value.encode('ascii', 'ignore')
        #if
        elif value is None or str(value) == 'nan':
            return value
        #elif

        operation = str("".join(oper[0])).split("#")
        pattern = re.compile(operation[1],re.IGNORECASE)
        returnValue = re.sub(pattern,"\g<"+str(operation[2])+">", value)
        return str(operation[0])+returnValue

    #def 
    regexPartialReplaceUDF = udf(regexPartialReplaceFn,StringType())

    def regexPartialReplaceFn(value, oper):

        if type(value) is unicode:
            value = value.encode('ascii', 'ignore')
        #if
        elif value is None or str(value) == 'nan':
            return value
        #elif

        operation = str("".join(oper[0])).split("#")
        pattern = re.compile(operation[1],re.IGNORECASE)
        returnValue = re.sub(pattern,"\g<"+str(operation[2])+">", value)
        return str(operation[0])+returnValue

    #def 
    regexPartialReplaceUDF = udf(regexPartialReplaceFn,StringType())

    def accentRemovalFn(value):
        try:
            if value is None or str(value) == 'nan':
                value = ''
            #if
            else:
                value = unicodedata.normalize('NFKD', value).encode('ASCII', 'ignore')
                value = re.sub('\W+',' ', str(value))
            #else
            return value
        #try
        except:
            traceback.print_exc()
            raise ValueError("Error In Accent Removal")
        #except    
            #def    
    accentRemovalUDF = udf(accentRemovalFn,StringType())

    def data_rule_engine(config_prop,inputDF,dbutils,logger):

        rules_list = []
        for row in config_prop['DATA-RULES']:
            rules_list.append(row)
            column_list =  row["col"].lower()
            if "$alias$" in column_list:
                column_names = column_list.replace("$alias$","").split(";")
                cnames = []
                for item in column_names:
                    for k,v in aliesMap.items():
                        if v.lower().strip() == item:
                            cnames.append(k.lower()) 
                        #if
                    #for
                #for
            #if
            else:
                cnames = row["col"].lower().split(";")
                cnames = [x.strip(' ') for x in cnames]
            #else
            column_list =  row["newcol"].lower()
            new_col_names = []
            if "$alias$" in column_list:
                column_names = column_list.replace("$alias$","").split(";")
                cnames = []
                for item in column_names:
                    for k,v in aliesMap.items():
                        if v.lower() == item:
                            new_col_names.append(k.lower()) 
                        #if
                    #for
                #for
            #if
            else:
                new_col_names = row["newcol"].lower().split(";")
                new_col_names = [x.strip(' ') for x in new_col_names]
            #else
            #PATTERN-1
            if 'replacevalue' == row["pattern"].lower():
                logger.info("Inside Replace Value")
                rule = row["rule"]
                replaceValue =  row["with"]
                originalValue =  row["on"]
                for column,new_col in zip(cnames,new_col_names):
                    if "$REG$" in originalValue:
                        originalValue = originalValue.replace("$REG$","")
                        operation_list=[]
                        operation_list.append(replaceValue+"#"+originalValue)
                        op_lit = array(*[array(*[lit(op)]) for op in operation_list])
                        print(str(op_lit))
                        inputDF = inputDF.withColumn(new_col,regexReplaceUDF(col(column).cast("string"),op_lit))
                    #if
                    else:
                        if originalValue == 'null' or  originalValue == 'NULL' or originalValue == "":
                            logger.info("Replacing null value with:" + str(replaceValue))
                            inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),replaceValue)
                                    .otherwise(col(column)))
                        #if
                        if rule == 'Replace value with Regex':
                            logger.info("Replacing Regular expression")
                            inputDF = inputDF.withColumn(new_col,regexp_replace(col(column), originalValue, replaceValue))

                        else:
                            if new_col in inputDF.columns:
                                inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column)).otherwise(when(col(column).cast("string") == originalValue, replaceValue).otherwise(col(new_col))))
                            else:
                                inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column)).otherwise(when(col(column).cast("string") == originalValue, replaceValue)))
                            #else
                        #else
                    #else
                #for
            #if  
            #PATTERN-2
            elif 'replacepartial' == row["pattern"].lower():
                replaceValue =  row["with"]
                originalValue =  row["on"]
                logger.info("Replacing partial value with:" +str(replaceValue))
                for column,new_col in zip(cnames,new_col_names):
                    if "$REG$" in originalValue:
                        group = row["grp"]
                        originalValue = originalValue.replace("$REG$","")
                        operation_list=[]
                        operation_list.append(replaceValue+"#"+originalValue+"#"+str(group))
                        op_lit = array(*[array(*[lit(op)]) for op in operation_list])
                        inputDF = inputDF.withColumn(new_col,UtilsCurate.regexPartialReplaceUDF(col(column).cast("string"),op_lit))
                    #if
                    else:
                        print("Replace partial " + str(originalValue) + "with " + str(replaceValue))
                        inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column))
                                .otherwise(regexp_replace(col(column).cast("string"), originalValue, replaceValue ))
                                )
                    #else
                #for
            #elif
            #PATTERN-3
            elif 'anonymization' == row["pattern"].lower():
                expression =  row["with"]
                for column,new_col in zip(cnames,new_col_names):
                    logger.info("Anonymizing the column with:" + str(expression))
                    if "sha1" in expression.lower():
                        inputDF = inputDF.withColumn(new_col,sha1(col(column)))
                    elif "sha2" in expression.lower():
                        inputDF = inputDF.withColumn(new_col,sha2(col(column),256))
                    #if
                    elif "hex" in expression.lower():
                        inputDF = inputDF.withColumn(new_col,hex(col(column)))
                    #elif
                    elif "base64" in expression.lower():
                        inputDF = inputDF.withColumn(new_col,base64(col(column)))
                    #elif
                #for
            #elif
            #PATTERN-4
            #elif 'imputation' == row["pattern"].lower():
            #expression =  row["rule"]
            #for column,new_col in zip(cnames,new_col_names):
                #logger.info("Performing Imputation operation: " + expression)
                #if "mean" in expression.lower():
                    #inputDF = inputDF.withColumn(new_col,_mean(col(column)))
            
                # elif "median" in expression.lower():
                    #inputDF = inputDF.withColumn(new_col,col(column))
                    #if
                #elif "mode" in expression.lower():
                    #inputDF = inputDF.withColumn(new_col,col(column)))

            #PATTERN-5
            elif 'dataset-all' == row["pattern"].lower():
                expression = row["with"]
                logger.info("Performing dataset rule: " + expression)
                if "utf-8" == expression.lower():
                    column = inputDF.dtypes
                    for new_col in column:
                        if "string" == new_col[1]:
                            inputDF = inputDF.withColumn(new_col[0], decode(col(new_col[0]).cast('string'),'UTF-8'))

                if "trim" == expression.lower():
                    column = inputDF.dtypes
                    for new_col in column:
                        if "string" == new_col[1]:
                            inputDF = inputDF.withColumn(new_col[0], trim(col(new_col[0])))
                logger.info(str(expression) + " process completed successfully")

            #PATTERN-6
            elif 'functional' == row["pattern"].lower():
                expression =  row["with"]
                logger.info("Performing Functional operation: " + expression)
                if "concat" in expression.lower():
                    value = row["value"]
                    inputDF = inputDF.withColumn(new_col_names[0],concat_ws(value, *(col(c) for c in cnames)))
                #if
                else:
                    for column,new_col in zip(cnames,new_col_names):
                        if "lower" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,lower(col(column)))
                        #if
                        elif "upper" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,upper(col(column)))
                        #elif
                        elif "base64" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,base64(col(column)))
                        #elif
                        elif "substring" in expression.lower():
                            start_pos = row["start"]
                            substring_length = row["length"]
                            inputDF = inputDF.withColumn(new_col,substring(col(column), int(start_pos),int(substring_length)))
                        #elif
                        elif "dropduplicates" in expression.lower():
                            inputDF = inputDF.dropDuplicates()
                        #elif
                        elif "dropna" in expression.lower():
                            inputDF = inputDF.na.drop(subset=column)
                        #elif
                        elif "prefix" in expression.lower():
                            prefix_value = row["value"]
                            inputDF = inputDF.withColumn(new_col,concat(lit(" "+prefix_value),col(column).cast("string")))
                        #elif
                        elif "suffix" in expression.lower():
                            prefix_value = row["value"]
                            inputDF = inputDF.withColumn(new_col,concat(col(column).cast("string"),lit(" "+prefix_value)))
                        #elif
                        elif "removeaccent" in expression.lower() or 'accentremove' in expression.lower():
                            inputDF = inputDF.withColumn(new_col,UtilsCurate.accentRemovalUDF(col(column).cast("string")))
                        #elif
                        elif "ltrim" in expression.lower() :
                            inputDF = inputDF.withColumn(new_col,ltrim(col(column).cast("string")))
                        #elif
                        elif "rtrim" in expression.lower() :
                            inputDF = inputDF.withColumn(new_col,rtrim(col(column).cast("string")))
                        #elif
                        elif "trim" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,trim(col(column).cast("string")))
                        elif "rpad" in expression.lower():
                            pad_length = int(row['length'])
                            pad_value = row['value']
                            inputDF = inputDF.withColumn(new_col,rpad(col(column).cast("string"),pad_length, pad_value ))
                        #elif
                        elif "lpad" in expression.lower():
                            pad_length = int(row['length'])
                            pad_value = row['value']
                            inputDF = inputDF.withColumn(new_col,lpad(col(column).cast("string"),pad_length, pad_value ))
                        #elif
                        elif "split" in expression.lower():
                            split_value = row['value']
                            split_grp = int(row['grp'])-1
                            inputDF = inputDF.withColumn(new_col,split(col(column).cast("string"),split_value )[split_grp])
                        #elif
                        elif "rename" in expression.lower():
                            inputDF = inputDF.withColumnRenamed(column,new_col)
                        #elifcolumn
                        elif "drop" in expression.lower():
                            inputDF = inputDF.drop(column)
                        #elif
                        elif "utf-8" in expression.lower():
                            inputDF = inputDF.withColumn(new_col, decode(col(column),'UTF-8'))
                        #elif
                        elif "unicode-escape" in expression.lower():
                            decode_udf = udf(lambda x: x.encode().decode('unicode-escape'),StringType())
                            inputDF = inputDF.withColumn(new_col, decode_udf(column))
                        elif "trimdoublequotes" in expression.lower():
                            inputDF = inputDF.withColumn(new_col,when((isnan(col(column))|col(column).isNull()),col(column))
                            .otherwise(regexp_replace(col(column).cast("string"), '"', "" )))
                        
                    
                        logger.info(str(expression) + " process completed successfully")
                        #elif
                    #for
                #else
            #elif
        #for       
        
        return inputDF        


           
       

