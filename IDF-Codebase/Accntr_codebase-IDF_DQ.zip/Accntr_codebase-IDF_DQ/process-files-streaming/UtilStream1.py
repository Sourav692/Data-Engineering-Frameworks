"""Main file UtilStream"""
import traceback
import os
import glob
import sys
import datetime
import uuid
import re
from shutil import copyfile
import utilsShared
import UtilsCurate
import Utils
import utilsDq
import utilsIO
import utilsTrans
import utilsTransDelta
from pyspark.sql.types import *
from pyspark.sql.functions import *
import pyspark.sql.functions as F
from delta.tables import *
from customException import *
from gen_audit_entry import *
from streamingMetadataManager import streamingMetadataManager

sys.path.insert(0, "/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/")

sys.path.insert(0, "/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/")

sys.path.insert(0, "/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-ingestion/")

def cloudFile_setup(dbutils, obj):
    """inside cloudfile method"""
    cloud_file = {
        "cloudFiles.subscriptionId": obj["azure"]["subscriptionId"],
        "cloudFiles.connectionString": obj["azure"]["queuesaskey"],
        "cloudFiles.format": obj["data-source"]["autoloader"]["file-format"],
        "cloudFiles.tenantId": obj["azure"]["tenantId"],
        "cloudFiles.clientId": obj["azure"]["clientId"],
        "cloudFiles.clientSecret": dbutils.secrets.get(
            scope=obj["azure"]["scope"], key=obj["azure"]["clientSecret"]
        ),
        "cloudFiles.resourceGroup": "IDFRG",
        "cloudFiles.useNotifications": obj["data-source"]["autoloader"][
            "useNotifications"
        ],
    }
    return cloud_file


def eventhub_setup(spark, dbutils, obj):
    """inside cloudfile method"""
    namespace = obj["azure"]["eventhub-namespace"]
    shared_accesskey = obj["azure"]["eventhub-shared-access-key"]
    conn_string = obj["azure"]["eventhub-connection-string"]
    entity_path = obj["data-source"]["eventhubs"]["entityPath"]
    print(entity_path)
    eventhub_conn_string = conn_string.format(namespace, shared_accesskey, entity_path)
    conf = {}
    conf[
        "eventhubs.connectionString"
    ] = spark.sparkContext._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(
        eventhub_conn_string
    )
    # conf["eventhubs.connectionString"] = eventhubConnString
    return conf


def readStream(spark, conf, obj, dbutils, logger):
    """inside readStream function"""

    # Schema evolve/schema enforce
    if "enforce" in obj["schema"]["type"]:
        event_schema_broadcast = spark.sparkContext.broadcast(obj["schema"]["cols"])
        schema = Utils.create_struct_schema(event_schema_broadcast.value, obj)
    elif "evolve" in obj["schema"]["type"]:
        schema = obj["schema"]["type"]
    else:
        logger.error("Invalid schema defination should be either evolve/enforce")
        return 0

    # Supported event source Eventhub/autoloader
    if "data-source" in obj and "eventhubs" in obj["data-source"]:
        logger.info("Reading from EventHub")
        audit_cols = []
        conf_eh = eventhub_setup(spark, dbutils, obj)
        # conf = eventhub_setup(dbutils,obj)
        if schema != "evolve":
            logger.info("Schema enforce is enabled")
            read_df = (
                spark.readStream.format(
                    "org.apache.spark.sql.eventhubs.EventHubsSourceProvider"
                )
                .options(**conf_eh)
                .schema(schema)
                .load()
            )
            read_df = read_df.select(
                from_json(col("body").cast("string"), schema).alias("payload")
            )
        else:
            logger.info("Schema evolve is enabled")
            read_df = (
                spark.readStream.format(
                    "org.apache.spark.sql.eventhubs.EventHubsSourceProvider"
                )
                .options(**conf_eh)
                .load()
            )
            read_df = read_df.withColumn(
                "payload", decode(col("body"), "UTF-8")
            )  # .select('payload')
            cols = read_df.columns
            payload = cols[-1]
            audit_cols = cols[:-1]
            audit_cols[:0] = [payload]
            read_df = read_df.select(audit_cols)

    elif "data-source" in obj and "autoloader" in obj["data-source"]:
        logger.info("Reading from auto-loader")
        datasource_obj = obj["data-source"]["autoloader"]
        cloud_file = cloudFile_setup(dbutils, obj)
        dynamic_input_path = obj["base_environment_path"] + datasource_obj["source-dir"]
        logger.info("Autoloader listerner set at: " + dynamic_input_path)
        read_df = (
            spark.readStream.format("cloudFiles")
            .options(**cloud_file)
            .option("header", "true")
            .schema(schema)
            .load(dynamic_input_path)
        )

    ## Delta table source read setup.
    elif 'data-source' in obj and 'delta' in obj['data-source']:
        logger.info('Reading from delta file')
        datasource_obj = obj['data-source']['delta']
        dynamic_input_path = obj['base_environment_path'] + datasource_obj['source-dir']
        logger.info(dynamic_input_path)
        read_df=(spark.readStream.format("delta").load(dynamic_input_path))
        logger.info('Read from delta topic')

    ## Kafka data source defined
    elif "data-source" in obj and "kafka" in obj["data-source"]:
        logger.info("Reading from kafka topic")
        confluent_topic_name = obj["kafka"]["confluentTopicName"]
        confluent_api_key = obj["kafka"]["confluentApiKey"]
        confluent_secret = obj["kafka"]["confluentSecret"]
        confluent_bootstrap_servers = obj["kafka"]["confluentBootstrapServers"]
        # if schema != 'evolve':
        # logger.info("Schema enforce is enabled")
        read_df = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", confluent_bootstrap_servers)
            .option("kafka.security.protocol", "SASL_SSL")
            .option(
                "kafka.sasl.jaas.config",
                "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(
                    confluent_api_key, confluent_secret
                ),
            )
            .option("kafka.ssl.endpoint.identification.algorithm", "https")
            .option("kafka.sasl.mechanism", "PLAIN")
            .option("subscribe", confluent_topic_name)
            .option("startingOffsets", "latest")
            .option("failOnDataLoss", "false")
            .load()
        )
    else:
        logger.error("No data source defined")

    return read_df


def readStream1(spark, conf, obj, dbutils, logger):
    """Inside readStream1 function """

    # Schema evolve/schema enforce
    if "enforce" in obj["schema"]["type"]:
        event_schema_broadcast = spark.sparkContext.broadcast(obj["schema"]["cols"])
        schema = create_struct_schema(event_schema_broadcast.value, obj)
    elif "evolve" in obj["schema"]["type"]:
        schema = obj["schema"]["type"]
    else:
        logger.error("Invalid schema defination should be either evolve/enforce")
        return 0

    # Supported event source Eventhub/autoloader
    if "data-source" in obj and "eventhubs" in obj["data-source"]:
        logger.info("Reading from EventHub")
        audit_cols = []
        # conf = eventhub_setup(dbutils,obj)
        if schema != "evolve":
            logger.info("Schema enforce is enabled")
            read_df = (
                spark.readStream.format(
                    "org.apache.spark.sql.eventhubs.EventHubsSourceProvider"
                )
                .options(**conf)
                .schema(schema)
                .load()
            )
            df = df.select(
                from_json(col("payload").cast("string"), schema).alias("payload")
            )
        else:
            logger.info("Schema evolve is enabled")
            read_df = (
                spark.readStream.format(
                    "org.apache.spark.sql.eventhubs.EventHubsSourceProvider"
                )
                .options(**conf)
                .load()
            )
            read_df = read_df.withColumn(
                "payload", decode(col("body"), "UTF-8")
            )  # .select('payload')
            cols = read_df.columns
            payload = cols[-1]
            audit_cols = cols[:-1]
            audit_cols[:0] = [payload]
            read_df = read_df.select(audit_cols)

    elif "data-source" in obj and "autoloader" in obj["data-source"]:
        logger.info("Reading from auto-loader")
        datasource_obj = obj["data-source"]["autoloader"]
        cloud_file = cloudFile_setup(dbutils, obj)
        dynamic_input_path = obj["base_environment_path"] + datasource_obj["source-dir"]
        logger.info("Autoloader listerner set at: " + dynamic_input_path)
        read_df = (
            spark.readStream.format("cloudFiles")
            .options(**cloud_file)
            .option("header", "true")
            .schema(schema)
            .load(dynamic_input_path)
        )

    ## Kafka data source defined
    elif "data-source" in obj and "kafka" in obj["data-source"]:
        logger.info("Reading from kafka topic")
        confluent_topic_name = obj["kafka"]["confluentTopicName"]
        confluent_api_key = obj["kafka"]["confluentApiKey"]
        confluent_secret = obj["kafka"]["confluentSecret"]
        confluent_bootstrap_servers = obj["kafka"]["confluentBootstrapServers"]
        # if schema != 'evolve':
        # logger.info("Schema enforce is enabled")
        read_df = (
            spark.readStream.format("kafka")
            .option("kafka.bootstrap.servers", confluent_bootstrap_servers)
            .option("kafka.security.protocol", "SASL_SSL")
            .option(
                "kafka.sasl.jaas.config",
                "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(
                    confluent_api_key, confluent_secret
                ),
            )
            .option("kafka.ssl.endpoint.identification.algorithm", "https")
            .option("kafka.sasl.mechanism", "PLAIN")
            .option("subscribe", confluent_topic_name)
            .option("startingOffsets", "latest")
            .option("failOnDataLoss", "false")
            .load()
        )
    else:
        logger.error("No data source defined")

    return read_df


def readProcessExec(spark, exit_doc):
    """Inside readProcessExec function """
    audit_df = spark.table("PRCS_EXECUTION")
    audit_df = audit_df.filter(col("SOURCE_NAME") == exit_doc["SOURCE_NAME"])
    last_stream_process = "NEW"
    if audit_df.count() != 0:
        last_stream_process = audit_df.select("STAGE").first()[0]

    return last_stream_process


def getStreamInfo(spark, exit_doc):
    """Inside getStreamInfo method"""
    stream_metadata = []
    last_stream_process = "NEW"
    for s in spark.streams.active:
        stream_metadata = s.lastProgress
    exit_doc["CHECKPOINT_PATH"]
    if stream_metadata:
        exit_doc["ID"] = stream_metadata["id"]
        exit_doc["RUNID"] = stream_metadata["runId"]
        exit_doc["NAME"] = stream_metadata["name"]
        exit_doc["STREAM_TIMESTAMP"] = stream_metadata["timestamp"]
        exit_doc["BATCHID"] = stream_metadata["batchId"]
        for sources in stream_metadata["sources"]:
            exit_doc["SOURCE_DESCRIPTION"] = sources["description"]
            exit_doc["START_OFFSET"] = str(sources["startOffset"])
            exit_doc["END_OFFSET"] = str(sources["endOffset"])
        exit_doc["SINK_DESCRIPTION"] = stream_metadata["sink"]["description"]

    return exit_doc, last_stream_process


def add_metadata_columns(input_df, obj, exit_doc):
    """Inside add_metadata_columns method"""
    input_df = input_df.withColumn(
        "BATCH_ID", lit(exit_doc["BATCHID"]).cast(IntegerType())
    )
    input_df = input_df.withColumn("ID", lit(exit_doc["ID"]))
    input_df = input_df.withColumn("RUNID", lit(exit_doc["RUNID"]))
    input_df = input_df.withColumn("FOREACHBATCH", lit(exit_doc["FOREACHBATCH"]))
    input_df = input_df.withColumn(
        "LOAD_TS",
        lit(str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))).cast(
            TimestampType()
        ),
    )
    input_df = input_df.withColumn(
        "LOAD_USERID", lit(obj["load_userid"]).cast(StringType())
    )
    input_df = input_df.withColumn("ERROR_CODE", lit(0))
    input_df = input_df.withColumn("ERROR_DESC", lit("NA"))
    return input_df


def stopStream(spark, logger):
    """Inside stopStream method"""
    logger.info("Stopping the stream")
    for s in spark.streams.active:
        s.stop()


def updateEntries(spark, dynamic_path, foreachbatch, err_desc, logger):
    """Inside updateEntries method"""
    exists = DeltaTable.isDeltaTable(spark, dynamic_path)
    if exists:
        delta_table = DeltaTable.forPath(spark, dynamic_path)
        logger.info("Setting ERROR_CODE = 1 for foreachbatch ID: " + foreachbatch)
        delta_table.update(
            condition=col("FOREACHBATCH") == foreachbatch,
            set={"ERROR_CODE": lit(1), "ERROR_DESC": lit(err_desc)},
        )


def foreach_batch_function(df_dataframe, epoch_id, spark, obj, exit_doc, audit_doc, dbutils):
    """Inside foreach_batch_function function"""
    stage = "foreachbatch"
    logger = utilsShared.getFormattedLogger(stage, obj["local_log_file_name"])
    metadata_object = streamingMetadataManager()
    exit_doc, last_stream_process = getStreamInfo(spark, exit_doc)
    logger.info("Curent state: " + last_stream_process)
    logger.info("epoch_id: " + str(epoch_id))
    foreachbatchid = str(uuid.uuid4())
    logger.info("foreachbatchid: " + foreachbatchid)
    exit_doc["FOREACHBATCH"] = foreachbatchid

    try:
        # Write to Raw
        exit_doc["STAGE"] = "RAW"
        dynamic_raw_path = obj["azure"]["raw-base-path"] + obj["raw-path"]
        exit_doc["RAW_PATH"] = dynamic_raw_path
        rawdf = add_metadata_columns(df_dataframe, obj, exit_doc)
        rawdf_count = rawdf.count()
        if rawdf_count > 0:
            logger.info(exit_doc["STAGE"] + ": files ingested at: " + dynamic_raw_path)
            rawdf.write.format(obj["raw-format"]).mode(obj["raw-mode-write"]).save(
                dynamic_raw_path
            )
            rawdf.show()

        exit_doc["RAW_ROW_COUNT"] = str(rawdf_count)
        exit_doc["RAW_COL_COUNT"] = str(len(rawdf.columns))
    except:
        try:
            logger.error(str(traceback.print_exc()))
            err_desc = str(traceback.format_exc())
            raise WriteStreamException(dynamic_raw_path, err_desc)
        except WriteStreamException as wse:
            updateEntries(spark, dynamic_raw_path, foreachbatchid, err_desc, logger)
            audit_rec = StreamForeachbatch(
                exit_doc, obj, "Failed", wse, exit_doc["JOB_START_TIME"]
            )
            audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
                audit_doc, exit_doc, audit_rec, wse
            )
            metadata_object.insert_StreamingauditRecord(dbutils, obj, spark, audit_doc)
            logger.error("Updating the error: " + err_desc)
            stopStream(spark, logger)
            exit_doc["EXIT_CODE"] = 0
            return 0

    try:
        if "data-curate-process" in obj:
            # Write to Curated
            # Prepare curated dataframe based on schema
            curate_obj = obj["data-curate-process"]
            dynamic_curated_path = (
                obj["azure"]["clean-base-path"] + curate_obj["curated-path"]
            )
            logger.info("Curated files ingested at: " + dynamic_curated_path)
            exit_doc["CURATED_PATH"] = dynamic_curated_path
            write_mode = curate_obj["curated-mode-write"]
            schema_option = "mergeSchema"
            merge_schema = "false"
            exit_doc["STAGE"] = "CURATED"

            if "evolve" in obj["schema"]["type"] and "eventhubs" in obj["data-source"]:
                schema = spark.read.json(
                    df_dataframe.select("payload").rdd.map(lambda x: x[0])
                ).schema
                df_dataframe = df_dataframe.select(
                    F.from_json(F.col("payload").cast("string"), schema).alias(
                        "payload"
                    )
                )
                merge_schema = "true"
                schema_option = obj["schema"]["schema-option"]

            # if 'eventhubs' in obj['data-source']:
            # df = df.select("payload.*")

            if "DATA-RULES" not in curate_obj:
                logger.info("No curation rules defined")
            else:
                # Transform
                logger.info("Running Data rule engine")
                df_dataframe = UtilsCurate.data_rule_engine(curate_obj, df_dataframe, dbutils, logger)

            record_count = df_dataframe.count()
            curdf = add_metadata_columns(df_dataframe, obj, exit_doc)

            if record_count > 0:
                exists = DeltaTable.isDeltaTable(spark, dynamic_curated_path)
                if exists and "merge-col" in obj:
                    delta_table = DeltaTable.forPath(spark, dynamic_curated_path)
                    merge_columns = obj["merge-col"]
                    query = ""
                    for cols in merge_columns:
                        query = query + " s." + cols + "=" + " t." + cols + " and "
                        # remove last "and"
                        remove = "and"
                        reverse_remove = remove[::-1]
                        query = query[::-1].replace(reverse_remove, "", 1)[::-1]

                    if schema_option == "mergeSchema":
                        spark.sql(
                            "SET spark.databricks.delta.schema.autoMerge.enabled = true"
                        )
                    delta_table.alias("t").merge(
                        curdf.alias("s"), query
                    ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()
                else:
                    curdf.write.format(curate_obj["curated-format"]).option(
                        schema_option, merge_schema
                    ).mode(write_mode).save(dynamic_curated_path)

                exit_doc["CURATED_ROW_COUNT"] = str(curdf.count())
                exit_doc["CURATED_COL_COUNT"] = str(len(curdf.columns))

    except WriteStreamException as wse:
        updateEntries(spark, dynamic_raw_path, foreachbatchid, err_desc, logger)
        updateEntries(spark, dynamic_curated_path, foreachbatchid, err_desc, logger)
        audit_rec = StreamForeachbatch(
            exit_doc, obj, "Failed", wse, exit_doc["JOB_START_TIME"]
        )
        audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
            audit_doc, exit_doc, audit_rec, wse
        )
        metadata_object.insert_StreamingauditRecord(dbutils, obj, spark, audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark, logger)
        exit_doc["EXIT_CODE"] = 0
        return 0

    try:
        # Write to enrich
        if "data-enrich-process" in obj:
            stage = "data-stream-extract-process - ENRICH"
            logger = utilsShared.getFormattedLogger(stage, obj["local_log_file_name"])
            obj_dict = obj["data-enrich-process"]
            count_value_source = 1
            for source in obj_dict["lookupSourceList"]:
                count_value_source = count_value_source + 1
                source_dict = obj_dict[source]
                if "alias" in source_dict:
                    col_alias = source_dict["alias"]
                else:
                    col_alias = 0
                input_path, input_path_list = utilsTrans.get_curated_base_path(
                    spark, source_dict, obj, logger
                )
                for dynamic_input_path in input_path_list:
                    try:
                        list_of_files = glob.glob(dynamic_input_path)
                        if len(list_of_files) == 0:
                            if os.path.isdir(dynamic_input_path) == False:
                                logger.error(
                                    "File not found for path:" + str(dynamic_input_path)
                                )
                                raise fileNotFoundError(dynamic_input_path)
                            continue
                    except fileNotFoundError as fnf:
                        logger.error(e)

                source_df = spark.read.parquet(
                    dynamic_input_path[5:]
                )  ##Reading from parquet i.e. Curated zone
                if "cols" in source_dict:
                    source_df = utilsIO.get_col_with_alias(
                        source_df, source_dict["cols"], source_dict, col_alias
                    )

                required_col_list = source_dict["combine"]["base-table-key"]
                df_dataframe.select(required_col_list).distinct()

                if "derived-key-process" in source_dict:
                    src_obj_dict = source_dict["derived-key-process"].copy()
                    source_df = utilsTrans.derived_key_process(
                        spark, src_obj_dict, source_df, logger
                    )

                if "filter" in source_dict:
                    src_obj_dict = source_dict["filter"].copy()
                    batch_date = str(
                        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    )
                    source_df = utilsTrans.source_filter(
                        spark, src_obj_dict, source_df, batch_date, logger
                    )

                # Default value generation
                if "default-value" in source_dict:
                    src_obj_dict = source_dict["default-value"].copy()
                    source_df = utilsTrans.default_vaule_process(
                        spark, src_obj_dict, source_df, logger
                    )

                # Renaming columns
                if "source-alias" in source_dict:
                    src_obj_dict = source_dict["source-alias"].copy()
                    source_df = utilsTrans.source_alias(
                        spark, src_obj_dict, source_df, logger
                    )

                # Combine baseDF and SourceDF
                df_dataframe = utilsTrans.combine_source(
                    spark, obj, count_value_source, source_dict, source_df, df_dataframe, logger
                )

                # Updating BaseDF columns that need to pass to next source or next operation
                if "custom-query" in source_dict:
                    src_obj_dict = source_dict["custom-query"].copy()
                    df_dataframe = utilsTrans.custom_query_execution(
                        spark, src_obj_dict, df_dataframe, logger
                    )

                if "derived-key-process-l1" in source_dict:
                    src_obj_dict = source_dict["derived-key-process-l1"].copy()
                    df_dataframe = utilsTrans.derived_key_process(spark, src_obj_dict, df_dataframe, logger)

                if "filter-l1" in source_dict:
                    src_obj_dict = source_dict["filter-l1"].copy()
                    batch_date = str(
                        datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    )
                    df_dataframe = utilsTrans.source_filter(
                        spark, src_obj_dict, df_dataframe, batch_date, logger
                    )

                if "target-col-list" in source_dict:
                    target_col_list = source_dict["target-col-list"]
                    df_dataframe = df_dataframe.select(target_col_list)

                if "assign-non-null-value" in source_dict:
                    src_obj_dict = source_dict["assign-non-null-value"].copy()
                    df_dataframe = utilsTrans.assign_non_null_value(spark, src_obj_dict, df_dataframe, logger)

            hash_table = df_dataframe
            stage = "data-stream-extract-process: data-enrich-process - ENRICH"
            logger = utilsShared.getFormattedLogger(stage, obj["local_log_file_name"])
            dynamic_enrich_path = (
                obj["azure"]["enrich-base-path"] + obj_dict["enrich-path"]
            )
            logger.info("Enriched files ingested at: " + dynamic_enrich_path)
            len(hash_table.columns)
            # Row count of files used as input
            total_row_count = hash_table.count()
            logger.debug("Total Row count generated " + str(total_row_count))

            # Default value in case SCD & CDC not applied
            dest_row_count = total_row_count
            target_table_count = 0
            # Adding default process keys
            logger.info("Adding additional Columns")

            obj_dict["batchDate"] = str(
                datetime.datetime.strftime(datetime.datetime.now(), "%Y%m%d")
            )
            hash_table = utilsTransDelta.system_value_process(
                spark, obj_dict, hash_table, logger
            )

            target_exists = DeltaTable.isDeltaTable(spark, dynamic_enrich_path)
            logger.info("Check if the enrich layer is empty of not")
            if target_exists:
                initial_load = False
            else:
                initial_load = True

            if initial_load == False:
                # Perform CDC based on the keys provided with the target table
                if "cdc-flag" in obj_dict and str(obj_dict["cdc-flag"]) == "true":
                    stage = "data-stream-extract-process: data-enrich-process - ENRICH - CDC"
                    logger = utilsShared.getFormattedLogger(
                        stage, obj["local_log_file_name"]
                    )
                    # Read the existing table from source
                    target_table = DeltaTable.forPath(spark, dynamic_enrich_path)

                    len(target_table.toDF().columns)
                    target_table_count = target_table.toDF().count()

                    logger.debug(
                        "Dropping duplicate based on CDC key "
                        + str(obj_dict["cdc-keys"]["table-keys"])
                    )
                    hash_table = hash_table.dropDuplicates(
                        obj_dict["cdc-keys"]["table-keys"]
                    )

                    total_row_count = hash_table.count()
                    logger.debug(
                        "Total Row count generated after removing duplicates &  null "
                        + str(total_row_count)
                    )
                    if target_table_count > 0:
                        logger.debug(
                            "Performing CDC on "
                            + str(obj_dict["cdc-keys"]["table-keys"])
                        )
                        cdc_cols = obj_dict["cdc-keys"]["table-keys"]
                        query = ""
                        for i in range(0, len(cdc_cols)):
                            query += (
                                "updates."
                                + cdc_cols[i]
                                + " "
                                + "<>"
                                + " "
                                + "target."
                                + cdc_cols[i]
                                + " "
                            )
                            if i == len(cdc_cols) - 1:
                                break
                            query += " " + "or" + " "
                        logger.info("query: " + query)
                        rows_to_update = (
                            hash_table.alias("updates")
                            .join(
                                target_table.toDF().alias("target"),
                                obj_dict["scd2"]["table-keys"],
                            )
                            .where(F.expr(query))
                            .where("target.CURR_IND == '1'")
                        )

                    else:
                        logger.debug("Skipping CDC since target table is empty ")

                    # Row count being exported to target table after removing duplicate - based on CDC key
                    dest_row_count = rows_to_update.count()
                    logger.debug("Row count after removing CDC " + str(dest_row_count))
                else:
                    logger.debug("Skipping CDC since CDC is not configured")
            else:
                logger.debug("CDC is not required for Initial Load")

            # Rejected rows while exporting
            rej_row_count = total_row_count - dest_row_count
            logger.debug("Rejected row count after CDC " + str(rej_row_count))

            for col_name in hash_table.columns:
                logger.debug("Column being validated : " + col_name)
                if col_name in sorted(obj_dict["target-schema"].keys()):
                    # cast if datatype not maches
                    for df_col in hash_table.dtypes:
                        if df_col[0] == col_name:
                            if df_col[1] != str(
                                obj_dict["target-schema"][col_name]["type"]
                            ):
                                logger.debug(
                                    "converting "
                                    + col_name
                                    + " from datatype "
                                    + df_col[1]
                                    + " to "
                                    + str(obj_dict["target-schema"][col_name]["type"])
                                )
                                hash_table = hash_table.withColumn(
                                    col_name,
                                    col(col_name).cast(
                                        str(obj_dict["target-schema"][col_name]["type"])
                                    ),
                                )

            if initial_load == False:
                if "scd2-flag" in obj_dict and str(obj_dict["scd2-flag"]) == "true":
                    stage = "data-stream-extract-process: data-enrich-process - ENRICH - SCD2"
                    logger = utilsShared.getFormattedLogger(
                        stage, obj["local_log_file_name"]
                    )
                    # Remove the not Changed rows from Hash Table

                    no_change_rows = (
                        hash_table.alias("updates")
                        .join(
                            target_table.toDF().alias("target"),
                            obj_dict["cdc-keys"]["table-keys"],
                        )
                        .select("updates.*")
                    )  # .where("target.CURR_IND == '1'")
                    cols = hash_table.columns
                    rows_for_scd2 = (
                        hash_table.alias("a")
                        .join(
                            no_change_rows.alias("b"),
                            obj_dict["cdc-keys"]["table-keys"],
                            how="leftAnti",
                        )
                        .select(cols)
                    )
                    scd_key = obj_dict["scd2"]["table-keys"][0]

                    rows_to_update = rows_to_update.selectExpr("updates.*").select(cols)

                    staged_updates = rows_to_update.selectExpr(
                        "NULL as mergeKey", "updates.*"
                    ).union(  # Rows for 1
                        rows_for_scd2.selectExpr(scd_key + " as mergeKey", "*")
                    )  # Rows for 2.

                else:
                    logger.debug("Skipping SCD2 since SCD2 is turned off ")

            else:
                logger.debug("SCD2 is not required for Initial Load")

            for col_name in hash_table.columns:
                logger.debug("Column being validated : " + col_name)
                if col_name in sorted(obj_dict["target-schema"].keys()):
                    col_new_name = obj_dict["target-schema"][col_name]["colName"]
                    # Rename column if not matches with the existing

                    if col_name != col_new_name:
                        logger.debug("Renaming to column : " + col_name)

                        # colName = "`" + colName +"`"
                        hash_table = hash_table.withColumnRenamed(col_name, col_new_name)
                else:
                    logger.debug("Dropping column : " + col_name)
                    hash_table = hash_table.drop(col_name)

            obj_dict["load_userid"] = obj["load_userid"]
            obj_dict["loadDate"] = obj["loadDate"]

            # Write to Enrich Layer
            stage = "data-stream-extract-process: data-enrich-process - ENRICH - LOAD"
            logger = utilsShared.getFormattedLogger(stage, obj["local_log_file_name"])

            if dest_row_count > 0:
                logger.info("target list:" + str(obj_dict["target-col-list"]))
                if initial_load == True:
                    hash_table = utilsTransDelta.add_Audit_columns(
                        hash_table, logger, obj_dict
                    )
                    hash_table = hash_table.select(obj_dict["target-col-list"])
                else:
                    if "scd2-flag" in obj_dict and str(obj_dict["scd2-flag"]) == "true":
                        staged_updates = utilsTransDelta.add_Audit_columns(
                            staged_updates, logger, obj_dict
                        )
                    else:
                        hash_table = utilsTransDelta.add_Audit_columns(
                            hash_table, logger, obj_dict
                        )
                        hash_table = hash_table.select(obj_dict["target-col-list"])

                logger.debug("Writing new records to Enrich " + str(dest_row_count))

                if initial_load == True:
                    logger.info("Performing Initial Load")
                    if "partition-by" in obj_dict:
                        hash_table.write.partitionBy(obj_dict["partition-by"]).mode(
                            obj_dict["enrich-mode-write"]
                        ).save(dynamic_enrich_path, format=str(obj_dict["enrich-format"]))
                    else:
                        hash_table.write.mode(obj_dict["enrich-mode-write"]).save(
                            dynamic_enrich_path, format=str(obj_dict["enrich-format"])
                        )

                else:
                    if "scd2-flag" in obj_dict and str(obj_dict["scd2-flag"]) == "true":
                        logger.info(
                            "Performing Delta Merge and Reload the New and updated Record to the respective partition"
                        )
                        condition_query = ""
                        for i in range(0, len(cdc_cols)):
                            condition_query += (
                                "target."
                                + cdc_cols[i]
                                + " "
                                + "<>"
                                + " "
                                + "staged_updates."
                                + cdc_cols[i]
                                + " "
                            )
                            if i == len(cdc_cols) - 1:
                                break
                            condition_query += " " + "or" + " "
                        condition_query += " and target.CURR_IND = '1'"
                        update_dict = {}
                        for item in target_table.toDF().columns:
                            update_dict[item] = "staged_updates." + item

                        update_dict["UPD_USERID"] = "null"
                        update_dict["UPD_TS"] = "null"
                        logger.info("condition_query: " + str(condition_query))
                        logger.info("update_dict: " + str(update_dict))
                        # datetime_object = datetime.datetime.strptime(obj["batchDate"],"%Y%m%d%H%M%S")
                        datetime.datetime.utcnow()
                        target_table.alias("target").merge(
                            staged_updates.alias("staged_updates"),
                            "target." + scd_key + " = mergeKey",
                        ).whenMatchedUpdate(
                            condition=condition_query,
                            set={  # Set current to false and endDate to source's effective date.
                                "SNAPSHOT_END_DT": "staged_updates.SNAPSHOT_BEG_DT",
                                "CURR_IND": "0",
                                "UPD_USERID": "null",
                                "UPD_TS": obj["batchDate"],
                            },
                        ).whenNotMatchedInsert(
                            values=update_dict
                        ).execute()
                    else:
                        if "partition-by" in obj_dict:
                            hash_table.write.partitionBy(obj_dict["partition-by"]).mode(
                                obj_dict["enrich-mode-write"]
                            ).save(
                                dynamic_enrich_path, format=str(obj_dict["enrich-format"])
                            )
                        else:
                            hash_table.write.mode(obj_dict["enrich-mode-write"]).save(
                                dynamic_enrich_path, format=str(obj_dict["enrich-format"])
                            )

            exit_doc["STAGE"] = "ENRICH"
            exit_doc["ENRICH_PATH"] = dynamic_enrich_path
            exit_doc["ENRICH_ROW_COUNT"] = str(df_dataframe.count())
            exit_doc["ENRICH_COL_COUNT"] = str(len(df_dataframe.columns))

    except WriteStreamException as wse:
        updateEntries(spark, dynamic_raw_path, foreachbatchid, err_desc, logger)
        updateEntries(spark, dynamic_curated_path, foreachbatchid, err_desc, logger)
        # updateEntries(spark,dynamicEnrichPath,foreachbatchid,err_desc,logger)
        audit_rec = StreamForeachbatch(
            exit_doc, obj, "Failed", wse, exit_doc["JOB_START_TIME"]
        )
        audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
            audit_doc, exit_doc, audit_rec, wse
        )
        metadata_object.insert_StreamingauditRecord(dbutils, obj, spark, audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark, logger)
        exit_doc["EXIT_CODE"] = 0
        return 0

    ################### Data Quality Stream process ############
    try:

        if "data-quality-process" in obj:
            stage = "data-quality-stream-process"

            if "evolve" in obj["schema"]["type"] and "eventhubs" in obj["data-source"]:
                schema = spark.read.json(
                    df_dataframe.select("payload").rdd.map(lambda x: x[0])
                ).schema
                df_dataframe = df_dataframe.select(
                    F.from_json(F.col("payload").cast("string"), schema).alias(
                        "payload"
                    )
                )
                merge_schema = "true"
                schema_option = obj["schema"]["schema-option"]

            # if 'evolve' in obj['schema']['type'] and 'kafka' in obj['data-source']:
            #     schema = spark.read.json(df.select("offset").rdd.map(lambda x: x[0])).schema
            #     df = df.select(F.from_json(F.col("offset").cast("string"), schema))
            #     mergeSchema = "true"
            #     schemaOption = obj['schema']['schema-option']

            if "eventhubs" in obj["data-source"]:
                df_dataframe = df_dataframe.select("payload.*")
            hash_table = df_dataframe

            empty_rdd = spark.sparkContext.emptyRDD()
            exit_doc["STAGE"] = "DQ"
            logger = utilsShared.getFormattedLogger(stage, obj["local_log_file_name"])
            obj_dict = obj["data-quality-process"]
            table_name = obj_dict["table_name"]
            rule_exe_ts = datetime.datetime.now()
            # logger = getFormattedLogger(stage, obj['local_log_file_name'])
            logger.info("Started executing " + str(stage) + " module")
            if table_name:
                logger.debug("Performing data quality on table: " + table_name)
                df_dq_master = utilsIO.read_data_sql_table(
                    spark, obj, table_name, logger
                )
            else:
                logger.error(
                    "Failed to get valid dq master table name or no data found in input dataframe"
                )
                raise invalidInputParams(
                    "Failed to get valid dq master table name or no data found in input dataframe"
                )
            tables_in_dq_master = (
                df_dq_master.select(col("TABLE_NAME"))
                .distinct()
                .rdd.map(lambda x: x[0].lower())
                .collect()
            )
            input_table_names = []
            if str(trim(obj_dict["table_name"])) == "" or obj_dict["table_name"] is None:
                logger.error(
                    "Invalid input table list, please provide valid comma seperated tables names"
                )
                raise invalidInputParams(
                    "Invalid input table list, please provide valid comma seperated tables names for tableNames"
                )
            input_table_names = obj_dict["table_name"].lower().split(",")
            table_list = list(set(input_table_names).intersection(tables_in_dq_master))
            batch_date = obj["batchDate"]
            list(set(input_table_names) - set(tables_in_dq_master))
            if len(table_list) > 0:
                for table_name in table_list:
                    dq_statistics = None
                    vldtd_hash_tbl_res = None
                    logger.info("Performing data quality on table: " + table_name)
                    dq_stats_schema = StructType(
                        [
                            StructField("RULE_ID", StringType()),
                            StructField("FAILED_ROW_COUNT", IntegerType()),
                        ]
                    )
                    dq_stats0 = spark.createDataFrame(empty_rdd, dq_stats_schema)
                    if df_dataframe is not None:
                        vldtd_hash_tbl_res = (
                            hash_table.select("*")
                            .limit(1)
                            .withColumn("ERR_CD", lit(""))
                        )
                        hash_table_cnt = hash_table.count()
                        df_dq_master2 = df_dq_master.filter(
                            lower(col("TABLE_NAME")) == table_name
                        )
                        dq_master = df_dq_master2.toPandas().transpose().to_dict()
                        for rule_key in dq_master:
                            rule = dq_master[rule_key]
                            rule_type = dq_master[rule_key]["RULE_TYPE"].lower()
                            rule_col = rule["COL_NAME"]
                            rule_id = rule["RULE_ID"]
                            rule_val = rule["RULE_VAL"]
                            dynamic_input_path = rule["DATA_PATH_OR_TOPIC"]
                            lookup_path = rule["REF_PATH"]
                            ref_path_type = rule["FORMAT"]
                            logger.info("RULE_TYPE is")
                            # Applying rules on data
                            dq_table = None
                            dq_stats0_df = None
                            if rule_type == "isnull":
                                (
                                    dq_table,
                                    dq_rule_count,
                                ) = utilsDq.data_quality_null_validation(
                                    spark, hash_table, rule_col, rule_id, logger
                                )
                                dq_stats0_df = spark.createDataFrame(
                                    [(rule_id, dq_rule_count)], dq_stats_schema
                                )
                                logger.debug(
                                    "NULL-CHECK rule type executed successfully for table "
                                    + table_name
                                )
                            elif rule_type == "duplicate-check":
                                (
                                    dq_table,
                                    dq_rule_count,
                                ) = utilsDq.data_quality_duplicates_valdation(
                                    spark, hash_table, rule_col, rule_id, logger
                                )
                                dq_stats0_df = spark.createDataFrame(
                                    [(rule_id, dq_rule_count)], dq_stats_schema
                                )
                                logger.debug(
                                    "DUPLICATE-CHECK rule type executed successfully for table "
                                    + table_name
                                )
                            elif rule_type == "custom-expr":
                                (
                                    dq_table,
                                    dq_rule_count,
                                ) = utilsDq.data_quality_expression_validation(
                                    obj, hash_table, rule_id, rule, logger
                                )
                                dq_stats0_df = spark.createDataFrame(
                                    [(rule_id, dq_rule_count)], dq_stats_schema
                                )
                                # logger.debug("DQ_Table count is ",str(dq_rule_count))
                                logger.debug(
                                    "CUSTOM_EXPRESSION rule type executed successfully for table "
                                    + table_name
                                )
                            elif rule_type == "straight-look-up":
                                (
                                    dq_table,
                                    dq_rule_count,
                                ) = utilsDq.data_quality_straight_lookup_validation(
                                    spark,
                                    obj,
                                    hash_table,
                                    rule_val,
                                    rule_id,
                                    lookup_path,
                                    ref_path_type,
                                    logger,
                                )
                                dq_stats0_df = spark.createDataFrame(
                                    [(rule_id, dq_rule_count)], dq_stats_schema
                                )
                                logger.debug(
                                    "STRAIGHT_LOOKUP rule type executed successfully for table "
                                    + table_name
                                )
                            if dq_table is not None:
                                if dq_table.count() > 0:
                                    vldtd_hash_tbl_res = vldtd_hash_tbl_res.union(
                                        dq_table
                                    )
                                    logger.info("Data in DQ_Table")
                                else:
                                    dq_stats0 = dq_stats0.union(dq_stats0_df)
                                    logger.info("Data not in DQ_Table")

                        # Aggregating the final results
                        failed_data = vldtd_hash_tbl_res.where(
                            "Not(ERR_CD is Null or trim(ERR_CD) = '')"
                        )
                        failed_data_final = failed_data.join(
                            df_dq_master.select("RULE_ID", "RULE_TYPE").alias(
                                "df_dq_master"
                            ),
                            failed_data.ERR_CD == df_dq_master.RULE_ID,
                            "left",
                        ).select(failed_data.columns + ["RULE_TYPE"])

                        # TODO: check where to write failed data
                        if failed_data_final.count() > 0:
                            failed_data_final.coalesce(1).write.mode("append").format(
                                "csv"
                            ).save("/mnt/mountdatalake/batchData/temp/failedData/")
                            # FailedDataFinal.write.mode("append").save("/mnt/mountdatalake/batchData/temp/failedData/",format="csv")
                            logger.info("FailedData Written to ADLS Successfully")
                        else:
                            logger.debug("FailedData not written to ADLS Successfully")

                        dq_stats = (
                            failed_data.groupby("ERR_CD")
                            .count()
                            .withColumnRenamed("count", "FAILED_ROW_COUNT")
                            .selectExpr("ERR_CD as RULE_ID", "FAILED_ROW_COUNT")
                        )

                        dq_stats = dq_stats.union(dq_stats0)

                        dq_stats1 = dq_stats.withColumn(
                            "TOTAL_ROW_CNT", lit(hash_table_cnt)
                        ).withColumn(
                            "PASSED_ROW_CNT",
                            (col("TOTAL_ROW_CNT") - col("FAILED_ROW_COUNT")),
                        )
                        dq_stats2 = (
                            dq_stats1.withColumn(
                                "RULE_FAIL_PC",
                                lit(
                                    100 * col("FAILED_ROW_COUNT") / col("TOTAL_ROW_CNT")
                                ),
                            )
                            .withColumn("EXEC_DATE", lit(rule_exe_ts))
                            .withColumn("BATCH_DATE", lit(batch_date))
                        )
                        dq_statistics = dq_stats2.join(
                            df_dq_master.select(
                                [
                                    "RULE_ID",
                                    "RULE_TYPE",
                                    "RULE_DIMENSION",
                                    "TABLE_NAME",
                                    "COL_NAME",
                                ]
                            ),
                            "RULE_ID",
                            "inner",
                        ).select(
                            "RULE_ID",
                            "RULE_TYPE",
                            "RULE_DIMENSION",
                            "TABLE_NAME",
                            "COL_NAME",
                            "BATCH_DATE",
                            "TOTAL_ROW_CNT",
                            "FAILED_ROW_COUNT",
                            "RULE_FAIL_PC",
                            "EXEC_DATE",
                        )

                        # TODO: Write dqStatistics results for the table
                        if dq_statistics.count() > 0:
                            dq_statistics.coalesce(1).write.mode("append").format(
                                "csv"
                            ).save("/mnt/mountdatalake/batchData/temp/dqStats/")
                            # dqStatistics.write.mode("append").save("/mnt/mountdatalake/batchData/temp/dqStats/",format="parquet")
                            logger.info("DQ Stats Written to ADLS Successfully")
                        else:
                            logger.debug("DQ Stats not written to ADLS Successfully")

                        return dq_statistics

    except WriteStreamException as wse:
        updateEntries(spark, dynamic_raw_path, foreachbatchid, err_desc, logger)
        updateEntries(spark, dynamic_curated_path, foreachbatchid, err_desc, logger)
        # updateEntries(spark,dynamicEnrichPath,foreachbatchid,err_desc,logger)
        audit_rec = StreamForeachbatch(
            exit_doc, obj, "Failed", wse, exit_doc["JOB_START_TIME"]
        )
        audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
            audit_doc, exit_doc, audit_rec, wse
        )
        metadata_object.insert_StreamingauditRecord(dbutils, obj, spark, audit_doc)
        logger.error("Updating the error: " + err_desc)
        stopStream(spark, logger)
        exit_doc["EXIT_CODE"] = 0
        return 0

    #############################################################

    # Create log file
    log_file_name = obj["log_file_name"]
    log_file_folder = "/".join(log_file_name.split("/")[:-1])
    os.makedirs(log_file_folder, exist_ok=True)
    logger.info("copying logs to: " + log_file_name)
    copyfile(obj["local_log_file_name"], log_file_name)
    wse = "New records added successfully"
    audit_rec = StreamForeachbatch(
        exit_doc, obj, "In Progress", wse, exit_doc["JOB_START_TIME"]
    )
    audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
        audit_doc, exit_doc, audit_rec, 0
    )
    metadata_object.insert_StreamingauditRecord(dbutils, obj, spark, audit_doc)


def writeStream(spark, read_df, conf, obj, dbutils, audit_doc, exit_doc, logger):
    """Inside writeStream function"""
    print(obj["streamName"])
    if read_df != 0:
        logger.info("Write the stream")
        if "eventhubs" in obj["data-source"]:
            obj["source_type"] = "eventhubs"
            checkpoint_dirname = obj["data-source"]["eventhubs"]["entityPath"]
        ######## kafka code added ############
        elif "kafka" in obj["data-source"]:
            obj["source_type"] = "kafka"
            checkpoint_dirname = obj["data-source"]["kafka"]["topicName"]
        ######################################

        elif 'delta' in obj['data-source']:
            obj['source_type'] = "delta"
            checkpoint_dirname = obj['data-source']['delta']['source-dir']
               
        else:
            obj["source_type"] = "autoloader"
            checkpoint_dirname = obj["data-source"]["autoloader"]["source-dir"]

        checkpoint = obj["azure"]["checkpoint-base-path"] + checkpoint_dirname
        logger.info("Checkpoint directory set at: " + checkpoint)

        obj["source_type"]

        try:
            exit_doc["TRIGGER_TYPE"] = obj["trigger"]["trigger-type"]
            exit_doc["SOURCE_TYPE"] = obj["source_type"]
            exit_doc["CHECKPOINT_PATH"] = checkpoint

            if "default" in obj["trigger"]["trigger-type"]:
                logger.info(
                    "Default trigger stream will run micro-batch as soon as it can"
                )
                query = (
                    read_df.writeStream.queryName(obj["streamName"])
                    .option("checkpointLocation", checkpoint)
                    .foreachBatch(
                        lambda df, epochId: foreach_batch_function(
                            df, epochId, spark, obj, exit_doc, audit_doc, dbutils
                        )
                    )
                    .start()
                )
                logger.info("lastprogress: " + str(query.lastProgress))

            elif "processingTime" in obj["trigger"]["trigger-type"]:
                interval = str(obj["trigger"]["trigger-interval"])  # Eg '2 seconds'
                logger.info(
                    "ProcessingTime trigger with " + interval + " micro-batch interval"
                )
                query = (
                    read_df.writeStream.queryName(obj["streamName"])
                    .trigger(processingTime=interval)
                    .option("checkpointLocation", checkpoint)
                    .foreachBatch(
                        lambda df, epochId: foreach_batch_function(
                            df, epochId, spark, obj, exit_doc, audit_doc, dbutils
                        )
                    )
                    .start()
                )

            elif "once" in obj["trigger"]["trigger-type"]:
                logger.info("One-time trigger")
                query = (
                    read_df.writeStream.queryName(obj["streamName"])
                    .trigger(once=True)
                    .option("checkpointLocation", checkpoint)
                    .foreachBatch(
                        lambda df, epochId: foreach_batch_function(
                            df, epochId, spark, obj, exit_doc, audit_doc, dbutils
                        )
                    )
                    .start()
                )

            elif "continuous" in obj["trigger"]["trigger-type"]:
                interval = str(obj["trigger"]["trigger-interval"])  # Eg '1 second'
                logger.info(
                    "Continuous trigger with " + interval + " checkpointing interval"
                )
                query = (
                    read_df.writeStream.queryName(obj["streamName"])
                    .trigger(continuous=interval)
                    .option("checkpointLocation", checkpoint)
                    .foreachBatch(
                        lambda df, epochId: foreach_batch_function(
                            df, epochId, spark, obj, exit_doc, audit_doc, dbutils
                        )
                    )
                    .start()
                )
            else:
                try:
                    obj["trigger"] = "NA"
                    trigger = "Trigger is not defined"
                    logger.error(trigger)
                    raise triggerException(trigger)
                except triggerException as te_e:
                    audit_rec = BeforeStreamRead(
                        exit_doc, obj, "Failed", te_e, job_start_time
                    )
                    audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
                        audit_doc, exit_doc, audit_rec, te_e
                    )
                    metadataObject.insert_StreamingauditRecord(
                        dbutils, obj, spark, audit_doc
                    )
                    exit_doc["EXIT_CODE"] = 0
                    return 0
            query.awaitTermination(20)
            return query
        except:
            try:
                logger.error(str(traceback.print_exc()))
                err_desc = str(traceback.format_exc())
                raise WriteStreamForEachBatch(err_desc)
            except WriteStreamForEachBatch as wre:
                audit_rec = WriteStreamForEachBatch(
                    exit_doc, obj, "Failed", wre, job_start_time
                )
                audit_doc, exit_doc = utilsShared.gen_audit_dict_streaming(
                    audit_doc, exit_doc, audit_rec, wre
                )
                metadataObject.insert_auditRecord(dbutils, obj, spark, audit_doc)
                stopStream(spark, logger)
                exit_doc["EXIT_CODE"] = 0
                return 0


def aggregate_process(spark, obj_dict, HASH_DF, logger):
    """Inside aggregate_process function"""
    for key_name in sorted(obj_dict.keys()):
        print(obj_dict[key_name])
        if obj_dict[key_name]["process"] == "group-by-w-agg":
            group_by_list = obj_dict[key_name]["group_by_list"]
            agg_list = obj_dict[key_name]["agg_list"]
            agg_type = str(obj_dict[key_name]["agg_type"])
            HASH_DF = HASH_DF.groupBy(group_by_list)
            HASH_DF = HASH_DF.agg(agg_list)
            print("sfg")
            HASH_DF = HASH_DF.toDF(
                *(
                    re.sub(r"[\,\s;\n\t\={}():]+", "", c.replace(agg_type, "AGG_"))
                    for c in HASH_DF.columns
                )
            )
        elif obj_dict[key_name]["process"] == "subtract":
            col_name = str(obj_dict[key_name]["colName"])
            left_col_name = str(obj_dict[key_name]["left_col_name"])
            right_col_name = str(obj_dict[key_name]["right_col_name"])
            HASH_DF = HASH_DF.withColumn(
                col_name, col(left_col_name) - col(right_col_name)
            )
        elif obj_dict[key_name]["process"] == "product":
            col_name = str(obj_dict[key_name]["colName"])
            first_col = str(obj_dict[key_name]["first_col"])
            second_col = str(obj_dict[key_name]["second_col"])
            HASH_DF = HASH_DF.withColumn(col_name, col(first_col) * col(second_col))
        elif obj_dict[key_name]["process"] == "addition":
            col_name = str(obj_dict[key_name]["colName"])
            first_col = str(obj_dict[key_name]["first_col"])
            second_col = str(obj_dict[key_name]["second_col"])
            HASH_DF = HASH_DF.withColumn(col_name, col(first_col) + col(second_col))
    return HASH_DF


def streamTransform(spark, obj, read_df, logger):
    """Inside streamTransform function"""

    if "aggregation" in obj:
        logger.info("Aggregation added")
        obj_dict = obj["aggregation"].copy()
        read_df = aggregate_process(spark, obj_dict, read_df, logger)

    if "watermark" in obj:
        logger.info("Watermark added")
        read_df = stream_watermarking(read_df, obj, logger)
    return read_df


# Function to join the dataframes
def df_join(left_df, watermark_expression, right_df, logger, join_type="inner"):
    """Inside df_join function"""
    logger.debug("Inside df_join " + join_type)
    left_df = left_df.join(right_df, expr(watermark_expression), how=join_type)
    return left_df


def combine_source(spark, obj, count_value_source, source_dict, source_df, base_df, logger):
    """Inside combine_source function"""
    # Skip join if first table
    if count_value_source > 1 and "combine" in source_dict:

        # Join with the base Table
        join_type = "inner"
        if "join-type" in source_dict["combine"]:
            join_type = str(source_dict["combine"]["join-type"])
        logger.debug("Applying join of type " + str(join_type) + " with the base table.")

        base_df = df_join(
            base_df,
            source_dict["combine"]["lookup-watermark-expression"],
            source_df,
            logger,
            join_type,
        )
        # logger.debug("Count of base DF after join : "+ str(baseDF.count()))
    else:  # First frame if the base DF was empty
        base_df = source_df
    return base_df


def stream_watermarking(read_df, obj, logger):
    """Inside stream_watermarking function"""
    if "select-expr" in obj["watermark"]:
        expr = obj["watermark"]["select-expr"]
        logger.info("select-expr " + str(expr) + " defined for watermarking")
        read_df = read_df.selectExpr(expr)

    logger.info(
        "Stream is configured for watermark: "
        + obj["watermark"]["watermarkCol"]
        + " with delay: "
        + obj["watermark"]["delayTime"]
    )
    read_df = read_df.withWatermark(
        obj["watermark"]["watermarkCol"], obj["watermark"]["delayTime"]
    )

    return read_df


def test():
    """Inside test function"""
    print("test----------------")
