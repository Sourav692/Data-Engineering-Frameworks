# -*- coding: utf-8 -*-

import time
import os,sys
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType

# from elasticsearch import Elasticsearch

from pyspark.sql import SparkSession
#from pyspark.sql.functions import *
from datetime import datetime
from pyspark.sql.functions import *
import hashlib
from pyspark.sql.utils import AnalysisException
from pyspark.sql.types import *
from pyspark.sql.functions import monotonically_increasing_id

sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-ingestion/')
import Utils 

def get_max_batchdate(src_path):
    date_col=os.listdir("/dbfs"+src_path)
    return str(max(date_col))

def read_enrich(spark,tableName,obj,sourceDict=0):

    # Check if the additional filter is provided
    if isinstance(sourceDict, dict) and 'read-type' in sourceDict:
        readType = str(sourceDict['read-type'])
        #sourceName = str(sourceDict['source-filter'])
    elif 'read-type' in obj and 'source-filter' in obj:
        readType = str(obj['read-type'])
        #sourceName = str(obj['source-filter'])
    else:
        readType = 'full'

    if readType == 'rec-source-filtered':
        source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load().where(col('SRC_ID') == str(obj['srcId']))
    if readType == 'rec-batchdate-filtered':
        batch_date=str(datetime.strptime(obj["batchDate"], '%Y%m%d'))[:10]
        source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load()
        source_df1.show()
        print(batch_date)
        source_df1=source_df1.where(col("BATCH_DATE")== batch_date)
        source_df1.show()
    else:
        # Full load
        source_df1 = spark.read.format('jdbc').option('url',str(obj["sqlserver"]["connection-string"])).option('dbtable',str(tableName)).option('driver','com.microsoft.sqlserver.jdbc.SQLServerDriver').load()
    return source_df1


def write_enrich(dbutils, HASH_TABLE, spark, obj,v_mode,tgt_table):
    #  Write data to table
    stg_account_name = "fs.azure.account.key.idfadbworkspace.dfs.core.windows.net"
    stg_account_key = "U51BTllKR3MLuXDjfu5GcRuBPnTbsWRlauhP+Oa3SGWLQzaAxvP8+isDBYdaeJ24IDKzZeqpGKZw864Yw7kBTA=="
    spark.conf.set(stg_account_name,stg_account_key)
    spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "true")
    spark.conf.set("fs.azure.createRemoteFileSystemDuringInitialization", "false")
    #HASH_TABLE.write.format("com.databricks.spark.sqldw").option("url", str(obj["sqlserver"]["connection-string"])).option("useAzureMSI","true").mode(v_mode).option("dbTable", str(obj['target-table'])).option("tempDir", str(obj["sqlserver"]["tempDir"])).save()

    #Changing Driver to jdbc to write subset of column if required
    #tgt_table
    #HASH_TABLE.write.format("com.databricks.spark.sqldw").option("url", str(obj["sqlserver"]["connection-string"])).option("forwardSparkAzureStorageCredentials", "true").mode(v_mode).option("dbTable", tgt_table).option("tempDir", str(obj["sqlserver"]["tempDir"])).option("maxStrLength","4000").save()
    HASH_TABLE.write.format("jdbc").option("url", str(obj["sqlserver"]["connection-string"])).mode(v_mode).option("dbTable", tgt_table ).save()



def ref_look_up_list(spark, obj, ref):

    # Read Atomic Table from phoenix for REF_LOOK_UP
    REF_TABLE = spark.read.format('org.apache.phoenix.spark').option('table',str(ref['ref-table-name'])).option('zkUrl', str(obj['hdi']['zkurl'])).load()

    for refColName in ref['ref-look-up-values'].keys():
        REF_TABLE = REF_TABLE.filter(lower(col(refColName))
                == str(ref['ref-look-up-values'][refColName]).lower())

    # return REF_TABLE
     # Obtain the list of values from the return look up col

    returnList1 = REF_TABLE.select(ref['return-look-up-col']).collect()

    if "return-look-up-col-const" in ref:
        lenConst = int(ref['return-look-up-col-const']['length'])
        padValue = str(ref['return-look-up-col-const']['rpad'])
        returnList = [str(row[ref['return-look-up-col'
                      ]]).strip().rjust(lenConst, str(padValue))
                      for row in returnList1]
    else:
        returnList = [str(row[ref['return-look-up-col']]) for row in returnList1]

    return returnList


def has_column(df, col):
    try:
        df[col]
        return True
    except AnalysisException:
        return False


# TO extract the columns from the Dataframe with rename and explode if the coltype is array

def get_col_with_alias(inputDF,listofCols,sourceDict,listDictofAlias=0,flatten=1):

  # Add col if not preset
    for (ind, colName) in enumerate(listofCols):
        if not has_column(inputDF, colName):
            if '.' in colName:
                colName = colName.replace('.', '_')
                listofCols[ind] = colName
            inputDF = inputDF.withColumn(colName,
                    lit(None).cast('string'))

  # Check if the alias list is passed and whether if its dict or list
    if isinstance(listDictofAlias, list):
        for (colName, colAlias) in zip(listofCols, listDictofAlias):
            inputDF = inputDF.withColumn(colAlias, col(colName))
    elif isinstance(listDictofAlias, dict):

    # Add the column from the dict with new name and then update the list
        listDictofAliasTemp = listDictofAlias
        for colName in listDictofAliasTemp.keys():
            inputDF = inputDF.withColumn(listDictofAliasTemp[colName],col(colName))
            listDictofAlias = [listDictofAliasTemp.get(n, n) for n in listofCols]
    elif listDictofAlias == 0:

  # Generate the names if the alias names not provided
        listDictofAlias = []
        for colName in listofCols:
            if '.' in colName:
                colAlias = colName.replace('.', '_')
                inputDF = inputDF.withColumn(colAlias, col(colName))
            else:
                colAlias = colName
            listDictofAlias.append(colAlias)

  # select the required cols
    resDF = inputDF.select(listDictofAlias)

  # Explode the arrays or struct
    if flatten == 1:
        for (colName, typeCol) in resDF.dtypes:
            if typeCol[0:5] == 'array':
                resDF = resDF.withColumn(colName, explode(colName))
            if typeCol[0:6] == 'struct':
                for c in resDF.select(colName + '.*').columns:
                    resDF = resDF.withColumn(colName + '_' + c,col(colName + '.' + c))
                resDF = resDF.drop(colName)

  # get the distinct rows
    if "drop-duplicates" in sourceDict and sourceDict["drop-duplicates"]==True:
        resDF = resDF.dropDuplicates()


  # Return the resultant Dataframe
    return resDF

def get_df_with_renamed(HASHDF,src_list,trgt_list):
    #HASHDF = HASHDF.select(src_list)

    for x,y in zip(src_list,trgt_list):
        HASHDF=HASHDF.withColumnRenamed(x, y)

    return HASHDF


# write the dataframe into a sql table
def write_data_sql(HASH_TABLE, obj,v_mode,tgt_table):
    if HASH_TABLE.count() > 0:
        database = str(obj['sqlserver']['jdbcDatabase'])
        port = str(obj['sqlserver']['jdbcPort'])
        hostname = str(obj['sqlserver']['jdbcHostname'])
        HASH_TABLE.write \
            .format("jdbc") \
            .option("url",f"jdbc:sqlserver://{hostname}:{port};database={database};") \
            .option("dbtable",tgt_table) \
            .option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver") \
            .option("user",str(obj["sqlserver"]["username"])) \
            .option("password",str(obj["sqlserver"]["password"])) \
            .mode(v_mode) \
            .save()

# read data from sql table
def read_data_sql_table(spark,obj,tableName,logger):
    """
        @params: spark, envConfig, table Name, logger
        @returns: spark dataframe from dq Master table
    """
    try:
        if "sqlserver" in obj.keys():
            jdbcHostname = obj['sqlserver']['jdbcHostname']
            jdbcDatabase = obj['sqlserver']['jdbcDatabase']
            jdbcPort = obj['sqlserver']['jdbcPort']
            username = obj['sqlserver']['username']
            password = obj['sqlserver']['password']
            hostNameInCertificate = obj['sqlserver']['hostNameInCertificate']
            jdbcUrl = obj['sqlserver']['jdbc-connection-string']
            jdbcUrl = jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)
            connectionProperties = {"user": username, "password": password,
                                    "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
            query = '(select * from dbo.dqMaster where TABLE_NAME = {} and IsActive = 1) as t1'.format(tableName)
            print(jdbcUrl)
            # read sql table and create spark dataframe on top of it
            df = spark.read.jdbc(url=jdbcUrl, table=query, properties=connectionProperties)

            if df.count() > 0:
                return df
    except:
        logger.info("Sql server properties are missing")
        raise ValueError("Sql server properties are missing ")

# Read data based on format from multiple source
def read_data_based_on_format(spark,obj, format, path, tableName, logger, delimiter=','):
    """[To read the various types of files and return the dataframe]
        Args:
        spark (functionality): [using to create the dataframe]
        obj (functionality): [it contains the configration]
        format (file format): [file format which is used to read]
        path (path): [directory path which contains file ]
        tableName (filename): [filename inside directory]
        logger (logs): [logs]
        delimiter (delimiter): [data is separated by delimiter]

    Returns:
        [dataframe]: [dataframe]
    """
    try:
        format = format.lower()
        if (format == 'csv') | (format == 'txt'):
            filePath = path+tableName+'.'+format
            outputDF = spark.read.options(header = True, inferSchema=True, delimiter = delimiter).csv(filePath)

        if format == 'parquet':
            filePath = path + tableName + '.' + format
            outputDF = spark.read.parquet(filePath)

        if format == 'sqltable':
            query = '(select * from {}) as t1'.format(tableName)
            outputDF = read_data_sql_table(spark,obj,query)

        return outputDF
    except:
        logger.info("Sql server properties are missing")
        raise ValueError("Sql server properties are missing ")

"""# Read data based on format from multiple source
def read_data_based_on_format(spark,obj, format, path, tableName, logger, delimiter=','):

    try:
        format = format.lower()
        if (format == 'csv') | (format == 'txt'):
            filePath = path+tableName+'.'+format
            outputDF = spark.read.options(header = True, inferSchema=True, delimiter = delimiter).csv(filePath)

        if format == 'parquet':
            filePath = path + tableName + '.' + format
            outputDF = spark.read.parquet(filePath)

        if format == 'sqltable':
            query = '(select * from {}) as t1'.format(tableName)
            outputDF = read_data_sql_table(spark,obj,query)

        return outputDF
    except:
        logger.info("Sql server properties are missing")
        raise ValueError("Sql server properties are missing ")
"""

"""# Read data based on format from multiple source
def read_data_based_on_format(spark, obj , format, path, tableName, logger, delimiter=','):
    
    @params: spark, envConfig, file format, file path, filename/tableName, delimiter (in case of file)
    @returns: spark dataframe from table or file location provided
    
    try:
        format = format.lower()
        if (format == 'csv') | (format == 'txt'):
            filePath = path+tableName+'.'+format
            logger.info(filePath)
            outputDF = spark.read.options(header = True, inferSchema=True, delimiter = delimiter).csv(filePath)
        if format == 'parquet':
            filePath = path + tableName + '.' + format
            outputDF = spark.read.parquet(filePath)

        if format == 'sqltable':
            query = '(select * from {}) as t1'.format(tableName)
            outputDF = read_data_sql_table(spark,obj,query)

        return outputDF
    except:
        logger.info("Sql server properties are missing")
        raise ValueError("Sql server properties are missing ")
"""
# Create and Return a dataFrame from the given Path
"""DQ_Modulerization"""
def get_data_frame(spark,obj,logger,file_path,file_format):
    """
    From the provided file_path import the file and create a frame
    according to the conditions in json obj
    @params: spark, envConfig, logger, file format, file path
    @returns: spark dataframe from file path/location provided
    """
    if "file_schema" in obj:
        output_df=None
        logger.debug("Parsing the file with schema given explicitly in config")
        try:
            file_schema_broadcast=spark.sparkContfile_format.broadcast(obj["file_schema"])
            nullValue=obj["nullValue"] if "nullValue" in obj else ""
            if file_format in ('csv', 'txt', 'dat'):
                output_df = spark.read.format("csv").option("header",obj["header"])\
                    .option("comment",obj["comment"]).option("delimiter",obj['delimiter'])\
                    .option("nullValue",nullValue)\
                    .load(file_path,schema = Utils.create_struct_schema\
                        (file_schema_broadcast.value,obj))\
                    .withColumn("index", monotonically_increasing_id())\
                    .filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
            elif file_format == 'parquet':
                output_df = spark.read.format("parquet").option("header",obj["header"])\
                    .option("comment",obj["comment"]).option("delimiter",obj['delimiter'])\
                    .option("nullValue",nullValue)\
                    .load(file_path,schema = Utils.create_struct_schema\
                        (file_schema_broadcast.value,obj))\
                    .withColumn("index", monotonically_increasing_id())\
                    .filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
            elif file_format == 'delta':
                output_df = spark.read.format("delta").option("header",obj["header"])\
                    .option("comment",obj["comment"]).option("delimiter",obj['delimiter'])\
                    .option("nullValue",nullValue)\
                    .load(file_path,schema = Utils.create_struct_schema\
                        (file_schema_broadcast.value,obj))\
                    .withColumn("index", monotonically_increasing_id())\
                    .filter(col("index") >= int(obj["skippedRows"])).drop("index").cache()
                logger.debug("Reading file from ADLS")
        except:
            logger.error(traceback.print_exc())
            raise fileNotFoundError(file_path)

        logger.debug("Schema is exposed to the data and Dataframe is created")
    else:
        output_df=None
        logger.debug("Parsing the file with inferring the schema from file itself")
        if file_format in ('csv', 'txt'):
            # logger.debug('Reading csv/txt file from path: ',file_path)
            output_df = spark.read.format("csv").option("inferSchema", "true")\
                .option("header",obj["header"])\
                .option("delimiter",obj['delimiter']).load(file_path)\
                .withColumn("index", monotonically_increasing_id())\
                .filter(col("index") >= int(obj["skippedRows"])).drop("index")
        elif file_format == 'parquet':
            output_df = spark.read.format("parquet").option("inferSchema", "true")\
                .option("header",obj["header"])\
                .option("delimiter",obj['delimiter']).load(file_path)\
                .withColumn("index", monotonically_increasing_id())\
                .filter(col("index") >= int(obj["skippedRows"])).drop("index")
        elif file_format == 'delta':
            output_df = spark.read.format("delta").option("inferSchema", "true")\
                .option("header",obj["header"])\
                .option("delimiter",obj['delimiter']).load(file_path)\
                .withColumn("index", monotonically_increasing_id())\
                .filter(col("index") >= int(obj["skippedRows"])).drop("index")
    return output_df
