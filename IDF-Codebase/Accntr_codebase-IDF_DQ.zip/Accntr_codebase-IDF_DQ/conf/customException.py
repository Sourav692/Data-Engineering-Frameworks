import json
from enum import Enum
from utilsShared import getEnvConf

envconfig=getEnvConf(0,0,0,1)
exception_metadata_path=envconfig["custom_exception_metadata_path"]

class Error(Exception):
    """  Base class for other exceptions """
    def __init__(self):
      config_file = open(str(exception_metadata_path), 'r').read()
      dic_enum= Enum('dic_enum',json.loads(config_file))
      self.conf=dic_enum

class fileCountNotMatchedError(Error):
    """ File Count not matched with expected file count mentioned in config """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.fileCountNotMatchedError.value["tech_mess"].format(str(args[0]),str(args[1]))
        self.buss_message=self.conf.fileCountNotMatchedError.value["buss_mess"].format(str(args[0]),str(args[1]))
        self.error_code=self.conf.fileCountNotMatchedError.value["error_code"]
        
    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class issueWhileFindinglatestFileError(Error):
    """ Exception while finding latest File from raw layer """
    def __init__(self, *args):
        super().__init__()        
        self.tech_message=self.conf.issueWhileFindinglatestFileError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.issueWhileFindinglatestFileError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.issueWhileFindinglatestFileError.value["error_code"]
    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class fileNotFoundError(Error):
    """ Exception while reading the file  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.fileNotFoundError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.fileNotFoundError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.fileNotFoundError.value["error_code"]
        
    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class schemaValidationError(Error):
    """ Exception while validating the Schema  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.schemaValidationError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.schemaValidationError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.schemaValidationError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class transformationError(Error):
    """ Exception while validating the Schema  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.transformationError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.transformationError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.transformationError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class addingfinYearAndMonthError(Error):
    """ Exception while Adding fin year and fin month  """
    def __init__(self,*args ):
        super().__init__()
        self.tech_message=self.conf.addingfinYearAndMonthError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.addingfinYearAndMonthError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.addingfinYearAndMonthError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class sourceVsTargetComparisonError(Error):
    """ Exception while comparing source and Target Dataframe  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.sourceVsTargetComparisonError.value["tech_mess"]
        self.buss_message=self.conf.sourceVsTargetComparisonError.value["buss_mess"]
        self.error_code=self.conf.sourceVsTargetComparisonError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class writeDataframeError(Error):
    """ Exception while writing Dataframe to Target  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.writeDataframeError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.writeDataframeError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.writeDataframeError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class readingTargetDFError(Error):
    """ Exception while reading Target Dataframe  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.readingTargetDFError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.readingTargetDFError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.readingTargetDFError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class dbInsertError(Error):
    """ Exception while writing to Database  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.dbInsertError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.dbInsertError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.dbInsertError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class recordCountMismatchError(Error):
    """ Source are Target record count didn't match  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.recordCountMismatchError.value["tech_mess"].format(str(args[0]),str(args[1]))
        self.buss_message=self.conf.recordCountMismatchError.value["buss_mess"].format(str(args[0]),str(args[1]))
        self.error_code=self.conf.recordCountMismatchError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class checkSumMismatchError(Error):
    """ checksum of Source and Atrget didn't match  """
    def __init__(self):
        super().__init__(self)
        self.tech_message=self.conf.checkSumMismatchError.value["tech_mess"]
        self.buss_message=self.conf.checkSumMismatchError.value["buss_mess"]
        self.error_code=self.conf.checkSumMismatchError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class configNotFoundError(Error):
    """ Config not Found  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.configNotFoundError.value["tech_mess"].format(args[0])
        self.buss_message=self.conf.configNotFoundError.value["buss_mess"].format(args[0])
        self.error_code=self.conf.configNotFoundError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message
      
class noIncrementalData(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.noIncrementalData.value['tech_mess'].format(args[0],args[1])
        self.buss_message=self.conf.noIncrementalData.value['buss_mess'].format(args[0],args[1])
        self.error_code=self.conf.noIncrementalData.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class invalidInputParams(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.invalidInputParams.value['tech_mess'].format(args[0])
        self.buss_message=self.conf.invalidInputParams.value['buss_mess'].format(args[0])
        self.error_code=self.conf.invalidInputParams.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class uncatchException(Error):
    """ uncatch Exception  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.uncatchException.value["tech_mess"].format(args[0])
        self.buss_message=self.conf.uncatchException.value["buss_mess"].format(args[0])
        self.error_code=self.conf.uncatchException.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class columnNameRenameError(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.columnNameRenameError.value['tech_mess'].format(args[0],args[1])
        self.buss_message=self.conf.columnNameRenameError.value['buss_mess'].format(args[0],args[1])
        self.error_code=self.conf.columnNameRenameError.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class columnCastError(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.columnCastError.value['tech_mess'].format(args[0],args[1])
        self.buss_message=self.conf.columnCastError.value['buss_mess'].format(args[0],args[1])
        self.error_code=self.conf.columnCastError.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class scdError(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.scdError.value['tech_mess'].format(args[0])
        self.buss_message=self.conf.scdError.value['buss_mess'].format(args[0])
        self.error_code=self.conf.scdError.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class delimitterMismatchError(Error):
    """ no incremental data found  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.delimitterMismatchError.value['tech_mess'].format(args[0])
        self.buss_message=self.conf.delimitterMismatchError.value['buss_mess'].format(args[0])
        self.error_code=self.conf.delimitterMismatchError.value['error_code']

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class dbReadError(Error):
    """ Exception while Reading from Database  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.dbReadError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.dbReadError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.dbReadError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class primaryKeyNotFoundError(Error):

    """ Exception when the primary keys are incorrect  """
    def __init__(self,*args):
        super().__init__()
        print(args)
        self.tech_message=self.conf.primaryKeyNotFoundError.value["tech_mess"].format(args[0],args[1])
        self.buss_message=self.conf.primaryKeyNotFoundError.value["buss_mess"].format(args[0],args[1])
        self.error_code=self.conf.primaryKeyNotFoundError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message
        
class primaryKeyInvalidError(Error):

    """ Exception when the primary keys are incorrect  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.primaryKeyInvalidError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.primaryKeyInvalidError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.primaryKeyInvalidError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class InvalidDimValidationError(Error):
    """ Exception while Reading from Database  """
    def __init__(self):
        super().__init__()
        self.tech_message=self.conf.InvalidDimValidationError.value["tech_mess"]
        self.buss_message=self.conf.InvalidDimValidationError.value["buss_mess"]
        self.error_code=self.conf.InvalidDimValidationError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class DimHavingDuplicatesError(Error):
    """ Exception while Reading from Database  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.DimHavingDuplicatesError.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.DimHavingDuplicatesError.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.DimHavingDuplicatesError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class SrcFileSizeTooHighorLow(Error):
    """ Exception while Reading from Database  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.SrcFileSizeTooHighorLow.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.SrcFileSizeTooHighorLow.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.SrcFileSizeTooHighorLow.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message
        
class SLABreachError(Error):
    """ Exception while Reading from Database  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.SLABreachError.value["tech_mess"].format(args[0],args[1])
        self.buss_message=self.conf.SLABreachError.value["buss_mess"].format(args[0],args[1])
        self.error_code=self.conf.SLABreachError.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class InvalidValue(Error):
    """ Exception while Reading from Database  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.InvalidValue.value["tech_mess"]
        self.buss_message=self.conf.InvalidValue.value["buss_mess"]
        self.error_code=self.conf.InvalidValue.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class readStreamException(Error):
    """ Exception while Reading Stream  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.readStreamException.value["tech_mess"]
        self.buss_message=self.conf.readStreamException.value["buss_mess"]
        self.error_code=self.conf.readStreamException.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message


class InvalidAdjustmentData(Error):
    """ Adjustment data coming as 0"""
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.InvalidAdjustmentData.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.InvalidAdjustmentData.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.InvalidAdjustmentData.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class triggerException(Error):
    """ Adjustment data coming as 0"""
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.triggerException.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.triggerException.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.triggerException.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class WriteForEachException(Error):
    """ Exception while writing to Raw"""
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.WriteForEachException.value["tech_mess"].format(str(args[0]))
        self.buss_message=self.conf.WriteForEachException.value["buss_mess"].format(str(args[0]))
        self.error_code=self.conf.WriteForEachException.value["error_code"]

    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class WriteStreamException(Error):
    """ Exception while writing the stream  """
    def __init__(self, *args):
        super().__init__()
        self.tech_message=self.conf.WriteStreamException.value["tech_mess"].format(str(args[0]),str(args[1]))
        self.buss_message=self.conf.WriteStreamException.value["buss_mess"].format(str(args[0]),str(args[1]))
        self.error_code=self.conf.WriteStreamException.value["error_code"]
        
    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

class schemaMismatchError(Error):
    """ Source are Target record count didn't match  """
    def __init__(self,*args):
        super().__init__()
        self.tech_message=self.conf.schemaMismatchError.value["tech_mess"].format(str(args[0]),str(args[1]))
        self.buss_message=self.conf.schemaMismatchError.value["buss_mess"].format(str(args[0]),str(args[1]))
        self.error_code=self.conf.schemaMismatchError.value["error_code"]
        
    def __str__(self):
        return str(self.error_code)+ " -> " +self.tech_message

