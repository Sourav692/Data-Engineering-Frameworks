import traceback
import json
import sys
import logging
import re

#COMMON
logger = logging.getLogger()
logger.setLevel(logging.INFO)
###################################################################################################
#M1
def process():
	try:
		regexMap = {}
		regexMap['TIMESTAMP_PATTERN'] =  re.compile(r'((((19|20)([2468][048]|[13579][26]|0[48])|2000)-02-29|((19|20)[0-9]{2}-(0[4678]|1[02])-(0[1-9]|[12][0-9]|30)|(19|20)[0-9]{2}-(0[1359]|11)-(0[1-9]|[12][0-9]|3[01])|(19|20)[0-9]{2}-02-(0[1-9]|1[0-9]|2[0-8])))\s([01][0-9]|2[0-3]):([012345][0-9]):([012345][0-9]))',re.IGNORECASE)
		regexMap['MONEY_PATTERN'] =  re.compile(r'^([1-9]\d{0,7}(?:\.\d{1,2}))$',re.IGNORECASE)
		regexMap['ID'] =  re.compile(r'^(\d{8}|\d{7}|\d{6}|\d{5}|\d{4})$',re.IGNORECASE)
		regexMap['EMAIL'] = re.compile(r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$',re.IGNORECASE)
		regexMap['DATE_YYYYMMDD'] = re.compile(r'^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$',re.IGNORECASE)
		regexMap['DATE_MMDDYYYY'] = re.compile(r'^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$',re.IGNORECASE)
		regexMap['CURRENCY_TYPE'] =  re.compile(r'^((USD)|(EU)|(CAD)|(INR)|(AUD)|(EURO)|(GBP))$',re.IGNORECASE)
		regexMap['ACCOUNTID_UNIVAR'] = re.compile(r'^001[a-zA-Z0-9]{12}$')
		#new
		regexMap['US_SSN'] = re.compile(r'^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\1(?!0000)[0-9]{4}$')
		regexMap['LAT_LON'] = re.compile(r'^(\(?)[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?),\s*[-+]?(180(\.0+)?|((1[0-7]\d)|([1-9]?\d))(\.\d+)?(\)?))$',re.IGNORECASE)
		regexMap['CREDIT_CARD'] = re.compile(r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$',re.IGNORECASE)
		regexMap['GENDER'] = re.compile(r'^(?:m|M|male|Male|f|F|female|Female)$',re.IGNORECASE)
		regexMap['US_STATE_CODE'] = re.compile(r'^((AL)|(AK)|(AS)|(AZ)|(AR)|(CA)|(CO)|(CT)|(DE)|(DC)|(FM)|(FL)|(GA)|(GU)|(HI)|(ID)|(IL)|(IN)|(IA)|(KS)|(KY)|(LA)|(ME)|(MH)|(MD)|(MA)|(MI)|(MN)|(MS)|(MO)|(MT)|(NE)|(NV)|(NH)|(NJ)|(NM)|(NY)|(NC)|(ND)|(MP)|(OH)|(OK)|(OR)|(PW)|(PA)|(PR)|(RI)|(SC)|(SD)|(TN)|(TX)|(UT)|(VT)|(VI)|(VA)|(WA)|(WV)|(WI)|(WY))$',re.IGNORECASE)
		regexMap['COUNTRY_ID'] = re.compile(r'^A(BW|FG|GO|IA|L(A|B)|N(D|T)|R(E|G|M)|SM|T(A|F|G)|U(S|T)|ZE)|B(DI|E(L|N)|FA|G(D|R)|H(R|S)|IH|L(M|R|Z)|MU|OL|R(A|B|N)|TN|VT|WA)|C(A(F|N)|CK|H(E|L|N)|IV|MR|O(D|G|K|L|M)|PV|RI|UB|XR|Y(M|P)|ZE)|D(EU|JI|MA|NK|OM|ZA)|E(CU|GY|RI|S(H|P|T)|TH)|F(IN|JI|LK|R(A|O)|SM)|G(AB|BR|EO|GY|HA|I(B|N)|LP|MB|NQ|NB|R(C|D|L)|TM|U(F|M|Y))|H(KG|MD|ND|RV|TI|UN)|I(DN|MN|ND|OT|R(L|N|Q)|S(L|R)|TA)|J(AM|EY|OR|PN)|K(AZ|EN|GZ|HM|IR|NA|OR|WT)|L(AO|B(N|R|Y)|CA|IE|KA|SO|TU|UX|VA)|MA(C|F|R)|CO|D(A|G|V)|EX|HL|U(SA|K)|KD|L(I|T)|MR|N(E|G|P)|OZ|RT|SR|TQ$',re.IGNORECASE)
		regexMap['URL'] = re.compile(r'^((?:ht|f)tps?)\:\/\/([a-zA-Z0-9\-\._]+:[a-zA-Z0-9\-\._]+@)?((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)(\/?)([a-zA-Z0-9\-\.\,\'\/\+\&%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\]*)$',re.IGNORECASE)
		regexMap['ROMAN_NUMBER'] = re.compile(r'^(?=[MDCLXVI])M*(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$',re.IGNORECASE)
		regexMap['PASSWORD'] = re.compile(r'^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$',re.IGNORECASE)
		regexMap['HTML_TAGS'] = re.compile(r"<(\"[^\"]*\"|'[^']*'|[^'\">])*>",re.IGNORECASE)
		regexMap['CUSTOMER_NUMBER'] = re.compile(r'(^|\D)\d{3}(\D|$)',re.IGNORECASE)
		regexMap['LINUX_PATH'] = re.compile(r'^(\/\w+)+$',re.IGNORECASE)
		regexMap['UK_PASSPORT_NUMBER'] = re.compile(r'^([0-9]{10}GBR[0-9]{7}[U,M,F]{1}[0-9]{9})|([A-Z]{1}-[0-9]{7})$',re.IGNORECASE)
		
		#regexMap['BANK_ROUTING-TRANSACTION_NUMBER'] = re.compile(r'^((0[0-9])|(1[0-2])|(2[1-9])|(3[0-2])|(6[1-9])|(7[0-2])|80)([0-9]{7})$',re.IGNORECASE)
		regexMap['COLOR_HEX_CODE'] = re.compile(r'^\#[A-Fa-f0-9]{3}([A-Fa-f0-9]{3})?$',re.IGNORECASE)
		regexMap['DATA_URL'] = re.compile(r'^(?:data)\:([a-z]+\/[a-z]+)?(;charset=([\w-])*)?(;base64)?,([\w\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]+)$',re.IGNORECASE)
		regexMap['FILE_URL'] = re.compile(r'^(?:file)\:(?:\/){2,3}((?:[a-zA-Z0-9\-\._]+(?:[a-zA-Z0-9\-\.\:\|_]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\|\:]*)?$',re.IGNORECASE)
		regexMap['GPS_DECIMAL_FORMAT'] = re.compile(r'^(\d{1,3}[\.]\d*)[, ]+-?(\d{1,3}[\.]\d*)$',re.IGNORECASE)
		regexMap['LAT_LON_DEGREE'] = re.compile(r'^[NS] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,},[EW] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,}$',re.IGNORECASE)
		regexMap['HDFS URL'] = re.compile(r'^(?:hdfs)\:\/\/((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\#\~]*)$',re.IGNORECASE)
		regexMap['IBAN'] = re.compile(r'^[a-zA-Z]{2}[0-9]{2}\ ?([a-zA-Z0-9]{4}\ ?){2,6}([a-zA-Z0-9]{4}\ ?|[a-zA-Z0-9])?[a-zA-Z0-9]{0,2}$',re.IGNORECASE)
		regexMap['ISBN-10'] = re.compile(r'^ISBN(?:-10)?:?\ *((?=\d{1,5}([ -]?)\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}[\dX])$',re.IGNORECASE)
		regexMap['ISBN-13'] = re.compile(r'^ISBN(?:-13)?:?\ *(97(?:8|9)([ -]?)(?=\d{1,5}\2?\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}\d)$',re.IGNORECASE)
		regexMap['MAC_ADDRESS'] = re.compile(r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$',re.IGNORECASE)
		regexMap['MAILTO_URL'] = re.compile(r'^(?:mailto)\:([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(,)?)*((?:\?)((subject|to|body|cc)=(([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4})|([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\])*)+(\&)?)*)*$',re.IGNORECASE)
		regexMap['WEB_DOMAIN'] = re.compile(r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,24}$',re.IGNORECASE)
		regexMap['IPv4_ADDRESS'] = re.compile(r'^([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])$',re.IGNORECASE)
		regexMap['IPv6_ADDRESS'] = re.compile(r'^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$',re.IGNORECASE)
		regexMap['MARITAL_STATUS'] = re.compile(r'^((Married)|(Single)|(Divorced)|(Widowed))$',re.IGNORECASE)
		regexMap['PHONE_NUMBER'] = re.compile(r'^(\+?([0-9]{1,4})?\-?\s?(\d{3}\-\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\d{3}\s\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\-\d{3}\-\d{4}))$',re.IGNORECASE)
		regexMap['INDIAN_PASSPORT_NUMBER'] = re.compile(r'^(?![QXZ])[A-Z]{1}-?\s?[1-9]{1}[0-9]{2}\s?[0-9]{3}[1-9]{1}$',re.IGNORECASE)
		regexMap['GERMAN_PASSPORT_NUMBER'] = re.compile(r'^(?![ABDEIOQSU])(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{9})$',re.IGNORECASE)
		regexMap['UK_DRIVING_LICENCE_NUMBER'] = re.compile(r'^(?:[A-Z]{1}[9]{4}|[A-Z]{2}[9]{3}|[A-Z]{3}[9]{2}|[A-Z]{4}[9]{1}|[A-Z]{5})[0-9]{6}(?:[A-Z]{1}[9]{1}|[A-Z]{2})[0-9]{5}$',re.IGNORECASE)
		regexMap['INDIA_DRIVING_LICENCE_NUMBER'] = re.compile(r'^[A-Z]{2}\s?\-?[0-9]{13}$',re.IGNORECASE)
		#Finance Domain
		regexMap['GERMANY_VAT'] = re.compile(r'^(DE)[0-9]{9}$',re.IGNORECASE)
		regexMap['FRANCE_VAT'] = re.compile(r'^(FR)[0-9A-Z]{2}[0-9]{9}$',re.IGNORECASE)
		regexMap['UK_VAT'] = re.compile(r'^(GB)([0-9]{9}([0-9]{3})?|[A-Z]{2}[0-9]{3})$',re.IGNORECASE)
		regexMap['INDIA_GST'] = re.compile(r'^([0][1-9]|[1-2][0-9]|[3][0-5])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$',re.IGNORECASE)
		regexMap['INDIA_PAN'] = re.compile(r'^[\w]{3}(p|P|c|C|h|H|f|F|a|A|t|T|b|B|l|L|j|J|g|G)[\w][\d]{4}[\w]$',re.IGNORECASE)
		#Health-Care Domain
		regexMap['ICD_CODE'] = re.compile(r'^[A-Z]{1}\d{2}\-[A-Z]{1}\d{2}$',re.IGNORECASE)
		#Banking Domain 
		regexMap['BANK_IDENTIFIER_CODE'] = re.compile(r'^[A-Z]{4}\s[A-Z]{2}\s[a-zA-Z0-9]{2}\s[a-zA-Z0-9]{3}$',re.IGNORECASE)
		regexMap['IFS_CODE'] = re.compile(r'^[A-Z]{4}[0][0-9]{6}$',re.IGNORECASE)
		return regexMap
	#try
	except:
		logger.error(str(traceback.print_exc()))
		traceback.print_exc()
		raise ValueError("ERROR in REGEX Library")
	#except



def regex_pattern():
  regexPat = {}
  regexPat['TIMESTAMP_PATTERN'] =  r'((((19|20)([2468][048]|[13579][26]|0[48])|2000)-02-29|((19|20)[0-9]{2}-(0[4678]|1[02])-(0[1-9]|[12][0-9]|30)|(19|20)[0-9]{2}-(0[1359]|11)-(0[1-9]|[12][0-9]|3[01])|(19|20)[0-9]{2}-02-(0[1-9]|1[0-9]|2[0-8])))\s([01][0-9]|2[0-3]):([012345][0-9]):([012345][0-9]))'
  regexPat['MONEY_PATTERN'] =  r'^([1-9]\d{0,7}(?:\.\d{1,2}))$'
  regexPat['ID'] =  r'^(\d{8}|\d{7}|\d{6}|\d{5}|\d{4})$'
  regexPat['EMAIL'] = r'^[_A-Za-z0-9-\\+]+(\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9]+)*(\.[A-Za-z]{2,})$'
  regexPat['DATE_YYYYMMDD'] = r'^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$'
  regexPat['DATE_MMDDYYYY'] = r'^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$'
  regexPat['CURRENCY_TYPE'] =  r'^((USD)|(EU)|(CAD)|(INR)|(AUD)|(EURO)|(GBP))$'
  regexPat['ACCOUNTID_UNIVAR'] = r'^001[a-zA-Z0-9]{12}$'
  #new
  regexPat['US_SSN'] = r'^(?!000|666)[0-9]{3}([ -]?)(?!00)[0-9]{2}\1(?!0000)[0-9]{4}$'
  regexPat['LAT_LON'] = r'^(\(?)[-+]?([1-8]?\d(\.\d+)?|90(\.0+)?),\s*[-+]?(180(\.0+)?|((1[0-7]\d)|([1-9]?\d))(\.\d+)?(\)?))$'
  regexPat['CREDIT_CARD'] = r'^(4[0-9]{12}(?:[0-9]{3})?)|((?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|(6(?:011|5[0-9]{2})[0-9]{12})|((?:2131|1800|35\d{3})\d{11})$'
  regexPat['GENDER'] = r'^(?:m|M|male|Male|f|F|female|Female)$'
  regexPat['US_STATE_CODE'] = r'^((AL)|(AK)|(AS)|(AZ)|(AR)|(CA)|(CO)|(CT)|(DE)|(DC)|(FM)|(FL)|(GA)|(GU)|(HI)|(ID)|(IL)|(IN)|(IA)|(KS)|(KY)|(LA)|(ME)|(MH)|(MD)|(MA)|(MI)|(MN)|(MS)|(MO)|(MT)|(NE)|(NV)|(NH)|(NJ)|(NM)|(NY)|(NC)|(ND)|(MP)|(OH)|(OK)|(OR)|(PW)|(PA)|(PR)|(RI)|(SC)|(SD)|(TN)|(TX)|(UT)|(VT)|(VI)|(VA)|(WA)|(WV)|(WI)|(WY))$'
  regexPat['COUNTRY_ID'] = r'^A(BW|FG|GO|IA|L(A|B)|N(D|T)|R(E|G|M)|SM|T(A|F|G)|U(S|T)|ZE)|B(DI|E(L|N)|FA|G(D|R)|H(R|S)|IH|L(M|R|Z)|MU|OL|R(A|B|N)|TN|VT|WA)|C(A(F|N)|CK|H(E|L|N)|IV|MR|O(D|G|K|L|M)|PV|RI|UB|XR|Y(M|P)|ZE)|D(EU|JI|MA|NK|OM|ZA)|E(CU|GY|RI|S(H|P|T)|TH)|F(IN|JI|LK|R(A|O)|SM)|G(AB|BR|EO|GY|HA|I(B|N)|LP|MB|NQ|NB|R(C|D|L)|TM|U(F|M|Y))|H(KG|MD|ND|RV|TI|UN)|I(DN|MN|ND|OT|R(L|N|Q)|S(L|R)|TA)|J(AM|EY|OR|PN)|K(AZ|EN|GZ|HM|IR|NA|OR|WT)|L(AO|B(N|R|Y)|CA|IE|KA|SO|TU|UX|VA)|MA(C|F|R)|CO|D(A|G|V)|EX|HL|U(SA|K)|KD|L(I|T)|MR|N(E|G|P)|OZ|RT|SR|TQ$'
  regexPat['URL'] = r'^((?:ht|f)tps?)\:\/\/([a-zA-Z0-9\-\._]+:[a-zA-Z0-9\-\._]+@)?((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)(\/?)([a-zA-Z0-9\-\.\,\'\/\+\&%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\]*)$'
  regexPat['ROMAN_NUMBER'] = r'^(?=[MDCLXVI])M*(C[MD]|D?C{0,3})(X[CL]|L?X{0,3})(I[XV]|V?I{0,3})$'
  regexPat['PASSWORD'] = r'^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$'
  regexPat['HTML_TAGS'] = r"<(\"[^\"]*\"|'[^']*'|[^'\">])*>"
  regexPat['CUSTOMER_NUMBER'] = r'(^|\D)\d{3}(\D|$)'
  regexPat['LINUX_PATH'] = r'^(\/\w+)+$'
  regexPat['UK_PASSPORT_NUMBER'] = r'^([0-9]{10}GBR[0-9]{7}[U,M,F]{1}[0-9]{9})|([A-Z]{1}-[0-9]{7})$'

  #regexPat['BANK_ROUTING-TRANSACTION_NUMBER'] = r'^((0[0-9])|(1[0-2])|(2[1-9])|(3[0-2])|(6[1-9])|(7[0-2])|80)([0-9]{7})$'
  regexPat['COLOR_HEX_CODE'] = r'^\#[A-Fa-f0-9]{3}([A-Fa-f0-9]{3})?$'
  regexPat['DATA_URL'] = r'^(?:data)\:([a-z]+\/[a-z]+)?(;charset=([\w-])*)?(;base64)?,([\w\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]+)$'
  regexPat['FILE_URL'] = r'^(?:file)\:(?:\/){2,3}((?:[a-zA-Z0-9\-\._]+(?:[a-zA-Z0-9\-\.\:\|_]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\|\:]*)?$'
  regexPat['GPS_DECIMAL_FORMAT'] = r'^(\d{1,3}[\.]\d*)[, ]+-?(\d{1,3}[\.]\d*)$'
  regexPat['LAT_LON_DEGREE'] = r'^[NS] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,},[EW] \d{1,}(\:[0-5]\d){2}.{0,1}\d{0,}$'
  regexPat['HDFS URL'] = r'^(?:hdfs)\:\/\/((?:[a-zA-Z0-9\-\._]+(?:\.[a-zA-Z0-9\-\._]+)+)|localhost)\/([a-zA-Z0-9\-\.\/\+\&\%\$_\\]*)?([\d\w\.\/\%\+\-\=\&\#\~]*)$'
  regexPat['IBAN'] = r'^[a-zA-Z]{2}[0-9]{2}\ ?([a-zA-Z0-9]{4}\ ?){2,6}([a-zA-Z0-9]{4}\ ?|[a-zA-Z0-9])?[a-zA-Z0-9]{0,2}$'
  regexPat['ISBN-10'] = r'^ISBN(?:-10)?:?\ *((?=\d{1,5}([ -]?)\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}[\dX])$'
  regexPat['ISBN-13'] = r'^ISBN(?:-13)?:?\ *(97(?:8|9)([ -]?)(?=\d{1,5}\2?\d{1,7}\2?\d{1,6}\2?\d)(?:\d\2*){9}\d)$'
  regexPat['MAC_ADDRESS'] = r'^([0-9a-fA-F][0-9a-fA-F]:){5}([0-9a-fA-F][0-9a-fA-F])$'
  regexPat['MAILTO_URL'] = r'^(?:mailto)\:([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}(,)?)*((?:\?)((subject|to|body|cc)=(([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4})|([\d\w\.\/\%\+\-\=\&\?\:\"\'\,\|\~\;#\\])*)+(\&)?)*)*$'
  regexPat['WEB_DOMAIN'] = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,24}$'
  regexPat['IPv4_ADDRESS'] = r'^([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])\.([01]?[\d][\d]?|2[0-4][\d]|25[0-5])$'
  regexPat['IPv6_ADDRESS'] = r'^((([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}:[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){5}:([0-9A-Fa-f]{1,4}:)?[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){4}:([0-9A-Fa-f]{1,4}:){0,2}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){3}:([0-9A-Fa-f]{1,4}:){0,3}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){2}:([0-9A-Fa-f]{1,4}:){0,4}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){6}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(([0-9A-Fa-f]{1,4}:){0,5}:((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|(::([0-9A-Fa-f]{1,4}:){0,5}((\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b)\.){3}(\b((25[0-5])|(1\d{2})|(2[0-4]\d)|(\d{1,2}))\b))|([0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,5}[0-9A-Fa-f]{1,4})|(::([0-9A-Fa-f]{1,4}:){0,6}[0-9A-Fa-f]{1,4})|(([0-9A-Fa-f]{1,4}:){1,7}:))$'
  regexPat['MARITAL_STATUS'] = r'^((Married)|(Single)|(Divorced)|(Widowed))$'
  regexPat['PHONE_NUMBER'] = r'^(\+?([0-9]{1,4})?\-?\s?(\d{3}\-\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\-\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\s?\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\d{3}\s\d{3}\s\d{4})|(\+?([0-9]{1,4})?\-?\s?\(\d{3}\)\-\d{3}\-\d{4}))$'
  regexPat['INDIAN_PASSPORT_NUMBER'] = r'^(?![QXZ])[A-Z]{1}-?\s?[1-9]{1}[0-9]{2}\s?[0-9]{3}[1-9]{1}$'
  regexPat['GERMAN_PASSPORT_NUMBER'] = r'^(?![ABDEIOQSU])(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]{9})$'
  regexPat['UK_DRIVING_LICENCE_NUMBER'] = r'^(?:[A-Z]{1}[9]{4}|[A-Z]{2}[9]{3}|[A-Z]{3}[9]{2}|[A-Z]{4}[9]{1}|[A-Z]{5})[0-9]{6}(?:[A-Z]{1}[9]{1}|[A-Z]{2})[0-9]{5}$'
  regexPat['INDIA_DRIVING_LICENCE_NUMBER'] = r'^[A-Z]{2}\s?\-?[0-9]{13}$'
  #Finance Domain
  regexPat['GERMANY_VAT'] = r'^(DE)[0-9]{9}$'
  regexPat['FRANCE_VAT'] = r'^(FR)[0-9A-Z]{2}[0-9]{9}$'
  regexPat['UK_VAT'] = r'^(GB)([0-9]{9}([0-9]{3})?|[A-Z]{2}[0-9]{3})$'
  regexPat['INDIA_GST'] = r'^([0][1-9]|[1-2][0-9]|[3][0-5])([a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}[1-9a-zA-Z]{1}[zZ]{1}[0-9a-zA-Z]{1})+$'
  regexPat['INDIA_PAN'] = r'^[\w]{3}(p|P|c|C|h|H|f|F|a|A|t|T|b|B|l|L|j|J|g|G)[\w][\d]{4}[\w]$'
  #Health-Care Domain
  regexPat['ICD_CODE'] = r'^[A-Z]{1}\d{2}\-[A-Z]{1}\d{2}$'
  #Banking Domain 
  regexPat['BANK_IDENTIFIER_CODE'] = r'^[A-Z]{4}\s[A-Z]{2}\s[a-zA-Z0-9]{2}\s[a-zA-Z0-9]{3}$'
  regexPat['IFS_CODE'] = r'^[A-Z]{4}[0][0-9]{6}$'
  return regexPat

def mapping_dict():
    mapping_dict = {'TIMESTAMP PATTERN':'TIMESTAMP_PATTERN',
    'MONEY PATTERN':'MONEY_PATTERN',
    'ID':'ID',
    'EMAIL':'EMAIL',
    'DATE(YYYYMMDD)':'DATE_YYYYMMDD',
    'DATE(MMDDYYYY)':'DATE_MMDDYYYY',
    'CURRENCY TYPE':'CURRENCY_TYPE',
    'ACCOUNT ID UNIVERSAL':'ACCOUNTID_UNIVAR',
    'US SSN':'US_SSN',
    'LATITUDE LONGITUDE':'LAT_LON',
    'CREDIT CARD NUMBER':'CREDIT_CARD',
    'GENDER':'GENDER',
    'US STATE CODE':'US_STATE_CODE',
    'COUNTRY ID':'COUNTRY_ID',
    'URL':'URL',
    'ROMAN NUMBER':'ROMAN_NUMBER',
    'PASSWORD':'PASSWORD',
    'HTML TAGS':'HTML_TAGS',
    'CUSTOMER NUMBER':'CUSTOMER_NUMBER',
    'LINUX PATH':'LINUX_PATH',
    'UK PASSPORT NUMBER':'UK_PASSPORT_NUMBER',
    'COLOR HEX CODE':'COLOR_HEX_CODE',
    'DATA URL':'DATA_URL',
    'FILE URL':'FILE_URL',
    'GPS DECIMAL FORMAT':'GPS_DECIMAL_FORMAT',
    'LATITUDE LONGITUDE DEGREE':'LAT_LON_DEGREE',
    'HDFS URL':'HDFS URL',
    'IBAN':'IBAN',
    'ISBN-10':'ISBN-10',
    'ISBN-13':'ISBN-13',
    'MAC ADDRESS':'MAC_ADDRESS',
    'MAIL TO URL':'MAILTO_URL',
    'WEB DOMAIN':'WEB_DOMAIN',
    'IPv4 ADDRESS':'IPv4_ADDRESS',
    'IPv6 ADDRESS':'IPv6_ADDRESS',
    'MARITAL STATUS':'MARITAL_STATUS',
    'PHONE NUMBER':'PHONE_NUMBER',
    'INDIAN ASSPORT NUMBER':'INDIAN_PASSPORT_NUMBER',
    'GERMAN PASSPORT NUMBER':'GERMAN_PASSPORT_NUMBER',
    'UK DRIVING LICENCE NUMBER':'UK_DRIVING_LICENCE_NUMBER',
    'INDIA DRIVING LICENCE NUMBER':'INDIA_DRIVING_LICENCE_NUMBER',
    'GERMANY VAT':'GERMANY_VAT',
    'FRANCE VAT':'FRANCE_VAT',
    'UK VAT':'UK_VAT',
    'INDIA GST':'INDIA_GST',
    'INDIA PAN':'INDIA_PAN',
    'ICD CODE':'ICD_CODE',
    'BANK IDENTIFIER CODE':'BANK_IDENTIFIER_CODE',
    'IFS CODE':'IFS_CODE'}
    return mapping_dict
###################################################################################################
if __name__=='__main__':
	process()
#if
