#!/usr/bin/python
# -*- coding: utf-8 -*-
import traceback
import sys
import json
import logging
import re
import hashlib
import time
import pandas as pd
import pyspark
from pyspark.sql import SQLContext
from pyspark.sql.types import StringType
from pyspark.sql.functions import udf
from pyspark.sql import SparkSession
#from pyspark.sql.functions import *
from datetime import  timedelta, date
from pyspark.sql.functions import lit, col, trim, rank,when,coalesce
from pyspark.sql import Window
from collections import OrderedDict
from metadataManager import metadataManager


import utilsTrans
import utilsIO
metadataObject = metadataManager()

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

from customException import *
from gen_audit_entry import *
import utilsShared   

###################################################################################################

def process(obj, HASH_TABLE, dbutils, exit_doc):

    stage='load-enrich-process'
    logger = utilsShared.getFormattedLogger(stage, obj['local_log_file_name'])
    
    conf = pyspark.SparkConf()
    spark = SparkSession.builder.appName(obj['use-case']).config(conf=conf).getOrCreate()
    
    #PRC_CURR_ID =str(hashlib.md5(str(millis).encode()).hexdigest())
    PRC_CURR_ID = dbutils.widgets.get("prm_act_pipeline_id")
    PRC_EXECUTION_ID = PRC_CURR_ID
    obj['PRC_EXECUTION_ID'] = PRC_EXECUTION_ID
    
    srcColCount = len(HASH_TABLE.columns)
    
    try:

        # Row count of files used as input
        target_colList = ''
        totalRowCount = HASH_TABLE.count()
        logger.debug('Total Row count generated ' + str(totalRowCount))
      
        # Default value in case SCD & CDC not applied
        updateRowCount = 0
        destRowCount = totalRowCount
        targetTableCount = 0
        targetTableColCount = 0
        audit_doc = OrderedDict()

        # Adding default process keys
        HASH_TABLE = utilsTrans.system_value_process(spark, obj,
                HASH_TABLE, logger)        
        logger.debug('HASH_TABLE Column renaming')
        if 'replace-source-col-list' in obj \
            and 'replace-target-col-list' in obj:
            try:
                HASH_TABLE = utilsIO.get_df_with_renamed(HASH_TABLE,obj['replace-source-col-list'],obj['replace-target-col-list'])
                
            except Exception as ex:
                try:
                    logger.error(traceback.print_exc())
                    raise columnNameRenameError(len(obj['replace-source-col-list']),len(obj['replace-target-col-list']))
                except columnNameRenameError as cne:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,cne,'Failed',0,0,0,'NA',obj['target-table'])
                    audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,cne)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc

        # Perform CDC based on the keys provided with the target table
        if 'cdc-flag' in obj and str(obj['cdc-flag']) == 'true':

            # Read the existing table from source

            if 'target-table-view' in obj:
                targetTableName = str(obj['target-table-view'])
                logger.debug('Fetching data from target table view : '+ targetTableName)
            else:
                targetTableName = str(obj['target-table'])
                logger.debug('Fetching data from target table since view is not configured : '+ targetTableName)
            try:
                TARGET_TABLE = utilsIO.read_enrich(spark, targetTableName, obj)
            except Exception as e:
                try:
                    logger.error(traceback.print_exc())
                    raise dbReadError(targetTableName)
                except dbReadError as dbe:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,dbe,'Failed',0,0,0,'NA',obj['target-table'])
                    audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc

            targetTableColCount = len(TARGET_TABLE.columns)
            targetTableCount = TARGET_TABLE.count()
            if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true' and targetTableCount > 0:
              TARGET_TABLE = TARGET_TABLE.filter(col('CURR_IND') == '1')
              logger.debug("Filtered target table data for CURR_IND=1")


            if 'filter-rec-source-flag' in obj and totalRowCount > 0:
                # Identify the REC_SOURCE Vaule
                filterVaule = HASH_TABLE.select(col('SRC_ID'))
                logger.debug('Filtering SRC_ID for  '+ str(filterVaule))

                # Filter based on REC_SOURCE
                TARGET_TABLE = TARGET_TABLE.filter(col('SRC_ID')== str(filterVaule))
                TARGET_TABLE = TARGET_TABLE.na.drop(subset=obj['cdc-keys']['target-table-keys'])
                targetTableCount = TARGET_TABLE.count()
                logger.debug('target table Row count after source filter '+ str(targetTableCount))

            if targetTableCount > 0:
                TARGET_TABLE.cache()

            logger.debug('Dropping duplicate based on CDC key '+ str(obj['cdc-keys']['input-table-keys']))
            HASH_TABLE = HASH_TABLE.dropDuplicates(obj['cdc-keys']['input-table-keys'])

            # logger.debug("Dropping nulls based on CDC key " + str(obj["cdc-keys"]["input-table-keys"]))
            # HASH_TABLE = HASH_TABLE.na.drop(subset = obj["cdc-keys"]["input-table-keys"])

            totalRowCount = HASH_TABLE.count()
            logger.debug('Total Row count generated after removing duplicates &  null '+ str(totalRowCount))
            if targetTableCount > 0:
                logger.debug('Performing CDC on ' + str(obj['cdc-keys']['input-table-keys']))
                for colName in obj['cdc-keys']['input-table-keys']:
                    colName2 = 'd2_' + colName
                    HASH_TABLE = HASH_TABLE.withColumnRenamed(colName,
                            colName2)
                HASH_TABLE = HASH_TABLE.join(TARGET_TABLE, [col('d2_'
                        + f).eqNullSafe(col(s)) for (f, s) in
                        zip(obj['cdc-keys']['input-table-keys'],
                        obj['cdc-keys']['target-table-keys'])],
                        how='left_anti')

                # obj["cdc-keys"][setKey],how="left_anti")

                for colName in obj['cdc-keys']['input-table-keys']:
                    colName2 = 'd2_' + colName
                    HASH_TABLE = HASH_TABLE.withColumnRenamed(colName2,colName)
            else:
                logger.debug('Skipping CDC since target table is empty ')

            # Row count being exported to target table after removing duplicate - based on CDC key

            destRowCount = HASH_TABLE.count()
            logger.debug('Row count after removing CDC '
                         + str(destRowCount))
        else:
            logger.debug('Skipping CDC since CDC is not configured')

        # Rejected rows while exporting

        rejRowCount = totalRowCount - destRowCount
        logger.debug('Rejected row count after CDC ' + str(rejRowCount))

        # Cast columns based on their data types
        
        for colName in HASH_TABLE.columns:
            logger.debug('Column being validated : ' + colName)
            if colName in sorted(obj['target-schema'].keys()):
                # cast if datatype not maches
                for dfCol in HASH_TABLE.dtypes:
                    try:
                        if dfCol[0] == colName:
                            if dfCol[1] != str(obj['target-schema'][colName]['type']):
                                logger.debug('converting ' + colName + ' from datatype ' + dfCol[1]+ ' to ' + str(obj['target-schema'][colName]['type']))
                                HASH_TABLE = HASH_TABLE.withColumn(colName,col(colName).cast(str(obj['target-schema'][colName]['type'])))
                    except Exception as ex:
                        try:
                            logger.error(traceback.print_exc())
                            raise columnCastError(colName,obj['target-schema'][colName]['type'])
                        except columnCastError as cce:
                            audit_rec=TransformLoadDataVault(exit_doc,stage,cce,'Failed',0,0,0,'NA',obj['target-table'])
                            audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,cce)
                            metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0,exit_doc
        # Perform SCD1
        try:
            if 'scd1-flag' in obj and str(obj['scd1-flag']) == 'true':
                logger.debug('Performing SCD1')
                if targetTableCount > 0:

                    # Update the target column names

                    HASH_TABLE2 = HASH_TABLE
                    baseColList = HASH_TABLE.columns
                    for colName in baseColList:
                        colName2 = 'd2_' + colName
                        HASH_TABLE2 = \
                            HASH_TABLE2.withColumnRenamed(colName, colName2)

                    target_colList = TARGET_TABLE.columns
                    logger.debug('target_colList:' + str(target_colList))

                    # Join to mark the new & updated records

                    TARGET_TABLE = TARGET_TABLE.join(HASH_TABLE2, [col('d2_'
                             + f).eqNullSafe(col(s)) for (f, s) in
                            zip(obj['scd1']['input-table-keys'], obj['scd1'
                            ]['target-table-keys'])], how='inner')
                    logger.debug('After inner join in scd1')

                    targetTableCount2 = TARGET_TABLE.count()
                    logger.debug('Count of Repeated records in Target table based on the provided keys '
                                  + str(targetTableCount2))

                    if targetTableCount2 > 0:

                        TARGET_TABLE = TARGET_TABLE.withColumn('ACTION',
                                lit('NoChange'))

                        scd_list = (obj['scd1']['input-table-keys'])[:]
                        for colToExcludeSCD in [
                            'BATCH_ID',
                            'LOAD_TS',
                            'UPD_TS',
                            'UPD_USERID',
                            'LOAD_USERID',
                            'CURR_IND',
                            ]:
                            scd_list.append(colToExcludeSCD)

                        if 'keys-to-exclude-update-check' in obj['scd1']:
                            scd_list.extend(obj['scd1'
                                    ]['keys-to-exclude-update-check'])
                            scd_list = list(dict.fromkeys(scd_list))

                        colListForSCD1 = \
                            list(set(baseColList).intersection(target_colList))
                        logger.info('colListForSCD1:' + str(colListForSCD1))

                        # Identify the Type of entry - Update

                        for colID in colListForSCD1:
                            if colID not in scd_list:
                               TARGET_TABLE = TARGET_TABLE.withColumn('ACTION',when((trim(coalesce(col(colID),lit('NULL')))!= trim(coalesce(col('d2_' + colID),lit('NULL')))) ,lit('Update')).otherwise(col('ACTION')))

                        # Remove unchanged rows from the Hash table
                        noChangeKeys = obj['scd1']['target-table-keys']
                        NO_CHANGE_ROWS = \
                            TARGET_TABLE.select(noChangeKeys).where("ACTION == 'NoChange'"
                                )

                        # Identify the columns which needs the update

                        TARGET_TABLE = TARGET_TABLE.filter(col('ACTION')
                                == 'Update')

                        for colName in NO_CHANGE_ROWS.columns:
                            colName2 = 'd3_' + colName
                            NO_CHANGE_ROWS = \
                                NO_CHANGE_ROWS.withColumnRenamed(colName,
                                    colName2)

                        NO_CHANGE_ROWS = NO_CHANGE_ROWS.join(TARGET_TABLE,
                                [col(f).eqNullSafe(col('d3_' + s)) for (f,
                                s) in zip(obj['scd1']['input-table-keys'],
                                obj['scd1']['input-table-keys'])],
                                how='left_anti')

                        logger.debug('Rows to be rejected due to no change '
                                      + str(NO_CHANGE_ROWS.count()))

                        HASH_TABLE = HASH_TABLE.join(NO_CHANGE_ROWS,
                                [col(f).eqNullSafe(col('d3_' + s)) for (f,
                                s) in zip(obj['scd1']['input-table-keys'],
                                obj['scd1']['input-table-keys'])],
                                how='left_anti')

                        destRowCount = HASH_TABLE.count()
                        logger.debug('Row count to be updated after removing Unchanged in SCD1 '
                                      + str(destRowCount))

                        # Rejected rows while exporting

                        rejRowCount = totalRowCount - destRowCount
                        logger.debug('Total (including CDC) Rejected row count after SCD1 '
                                      + str(rejRowCount))

                        # Extract the target only colums, here extra columns will be removed like ACTION

                        TARGET_TABLE = TARGET_TABLE.select(target_colList)

                        TARGET_TABLE = \
                            TARGET_TABLE.dropDuplicates(obj['scd1'
                                ]['input-table-keys'])
                        TARGET_TABLE = \
                            TARGET_TABLE.na.drop(subset=obj['scd1'
                                ]['input-table-keys'])

                        # obj["cdc-keys"][setKey],how="left_anti")

                        for colName in obj['scd1']['input-table-keys']:
                            colName2 = 'd2_' + colName
                            HASH_TABLE = \
                                HASH_TABLE.withColumnRenamed(colName2,
                                    colName)

                        # Update the load end key
                        # TARGET_TABLE = TARGET_TABLE.withColumn(loadEndKey, lit(loadEndValue).cast("timestamp")).withColumn("CURR_IND",lit("0"))

                        updateRowCount = TARGET_TABLE.count()
                        logger.debug('Total Row count with SCD1'
                                     + str(updateRowCount))
                else:

                        # Write to Atomic Layer - Update the old record
                        # utilsIO.write_enrich(dbutils, TARGET_TABLE, spark, obj,"append")

                    logger.debug('Skipping SCD1 since no repeated SCD keys data '
                                 )
            else:

                logger.debug('Skipping SCD1 since SCD1 is turned off ')
        except Exception as ex:
            try:
                logger.error(traceback.print_exc())
                raise scdError("SCD1 Error "+ex)
            except scdError as se:
                audit_rec=TransformLoadDataVault(exit_doc,stage,se,'Failed',0,0,0,'NA',obj['target-table'])
                audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,se)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0
                return 0,exit_doc

        # Perform SCD2
        try:
            if 'scd2-flag' in obj and str(obj['scd2-flag']) == 'true':

                # Generate the Load End value

                loadEndValue = utilsTrans.generate_load_end_value(obj,
                        logger)
                loadEndKey = str(obj['scd2']['load-end-key']['colName'])
                logger.debug('Identify the Type of entry - Update '
                             + loadEndKey)

                # Identify the key to be used for Max

                if 'keys-to-identify-unique' in obj['scd2']:
                    maxIdentifyKey_Prev = str(obj['scd2'
                            ]['keys-to-identify-unique']['max-key'])
                    maxIdentifyKey_cast = 'd2_' + str(obj['scd2'
                            ]['keys-to-identify-unique']['max-key'])
                    HASH_TABLE = HASH_TABLE.withColumn(maxIdentifyKey_cast,
                            col(maxIdentifyKey_Prev).cast('long'))
                    HASH_TABLE = HASH_TABLE.withColumn('RankColumn',
                            rank().over(Window.partitionBy(str(obj['scd2'
                            ]['keys-to-identify-unique']['groupby-key'
                            ])).orderBy(col(maxIdentifyKey_cast).desc())))

                    # HASH_TABLE2 = HASH_TABLE.filter(col("RankColumn") == lit("1"))

                    HASH_TABLE2 = HASH_TABLE
                    validInputRowCount = HASH_TABLE2.filter(col('RankColumn'
                            ) == lit('1')).count()
                    logger.debug('Count of open/valid HASH record in source table : '
                                  + str(validInputRowCount))
                    markClosedRowCount = totalRowCount - validInputRowCount
                    logger.debug('Count of record marked closed from new data due to repeat '
                                  + str(markClosedRowCount))
                else:

                    HASH_TABLE2 = HASH_TABLE
                    logger.debug('Skipping Source record SCD2 (closing of invalid record) since keys to identify unique is not configured'
                                 )

                if targetTableCount > 0:

                    # Update the target column names

                    baseColList = HASH_TABLE.columns
                    for colName in baseColList:
                        colName2 = 'd2_' + colName
                        HASH_TABLE2 = \
                            HASH_TABLE2.withColumnRenamed(colName, colName2)

                    target_colList = TARGET_TABLE.columns

                    # TARGET_TABLE = TARGET_TABLE.where(isnull(col(loadEndKey)))

                    TARGET_TABLE = \
                        TARGET_TABLE.filter(TARGET_TABLE[loadEndKey].isNull())

                    targetTableCount2 = TARGET_TABLE.count()
                    logger.debug('Count of Open records in Target table '
                                 + str(targetTableCount2))

                    # Join to mark the new & updated records

                    TARGET_TABLE = TARGET_TABLE.join(HASH_TABLE2, [col('d2_'
                             + f).eqNullSafe(col(s)) for (f, s) in
                            zip(obj['scd2']['input-table-keys'], obj['scd2'
                            ]['target-table-keys'])], how='inner')

                    targetTableCount2 = TARGET_TABLE.count()

                    # logger.debug("Count of Repeated records in Target table based on the provided keys " + str(targetTableCount2))

                    if targetTableCount2 > 0:

                        TARGET_TABLE = TARGET_TABLE.withColumn('ACTION',
                                lit('NoChange'))

                        scd_list = (obj['scd2']['input-table-keys'])[:]
                        for colToExcludeSCD in [
                            'BATCH_ID',
                            'LOAD_TS',
                            'UPD_TS',
                            'UPD_USERID',
                            'LOAD_USERID',
                            'SNAPSHOT_BEG_DT',
                            'SNAPSHOT_END_DT',
                            'CURR_IND',
                            ]:
                            scd_list.append(colToExcludeSCD)

                        if 'keys-to-exclude-update-check' in obj['scd2']:
                            scd_list.extend(obj['scd2'
                                    ]['keys-to-exclude-update-check'])
                            scd_list = list(dict.fromkeys(scd_list))

                        colListForSCD2 = \
                            list(set(baseColList).intersection(target_colList))

                        # logger.log("colListForSCD2:"+str(colListForSCD2))

                        # Identify the Type of entry - Update

                        for colID in colListForSCD2:
                            if colID not in scd_list:
                                TARGET_TABLE = TARGET_TABLE.withColumn('ACTION',when((trim(coalesce(col(colID),lit('NULL')))!= trim(coalesce(col('d2_' + colID),lit('NULL')))) ,lit('Update')).otherwise(col('ACTION')))

                        # Remove unchanged rows from the Hash table

                        noChangeKeys = obj['scd2']['target-table-keys']
                        NO_CHANGE_ROWS = \
                            TARGET_TABLE.select(noChangeKeys).where("ACTION == 'NoChange'"
                                )

                        # Identify the columns which needs the update

                        TARGET_TABLE = TARGET_TABLE.filter(col('ACTION')
                                == 'Update')

                        for colName in NO_CHANGE_ROWS.columns:
                            colName2 = 'd3_' + colName
                            NO_CHANGE_ROWS = \
                                NO_CHANGE_ROWS.withColumnRenamed(colName,
                                    colName2)

                        NO_CHANGE_ROWS = NO_CHANGE_ROWS.join(TARGET_TABLE,
                                [col(f).eqNullSafe(col('d3_' + s)) for (f,
                                s) in zip(obj['scd2']['input-table-keys'],
                                obj['scd2']['input-table-keys'])],
                                how='left_anti')

                        logger.debug('Rows to be rejected due to no change '
                                      + str(NO_CHANGE_ROWS.count()))

                        HASH_TABLE = HASH_TABLE.join(NO_CHANGE_ROWS,
                                [col(f).eqNullSafe(col('d3_' + s)) for (f,
                                s) in zip(obj['scd2']['input-table-keys'],
                                obj['scd2']['input-table-keys'])],
                                how='left_anti')

                        destRowCount = HASH_TABLE.count()
                        logger.debug('Row count to be inserted after removing Unchanged in SCD2 '
                                      + str(destRowCount))

                        # Rejected rows while exporting

                        rejRowCount = totalRowCount - destRowCount
                        logger.debug('Total (including CDC) Rejected row count after SCD2 '
                                      + str(rejRowCount))

                        # Extract the target only colums, here extra columns will be removed like ACTION

                        TARGET_TABLE = TARGET_TABLE.select(target_colList)

                        TARGET_TABLE = \
                            TARGET_TABLE.dropDuplicates(obj['scd2'
                                ]['input-table-keys'])
                        TARGET_TABLE = \
                            TARGET_TABLE.na.drop(subset=obj['scd2'
                                ]['input-table-keys'])

                        # obj["cdc-keys"][setKey],how="left_anti")

                        for colName in obj['scd2']['input-table-keys']:
                            colName2 = 'd2_' + colName
                            HASH_TABLE = \
                                HASH_TABLE.withColumnRenamed(colName2,
                                    colName)

                        # Update the load end key
                        # TARGET_TABLE = TARGET_TABLE.withColumn(loadEndKey, lit(loadEndValue).cast("timestamp")).withColumn("CURR_IND",lit("0"))

                        updateRowCount = TARGET_TABLE.count()
                        logger.debug('Total Row count updated with SCD2 '
                                     + str(updateRowCount))

                        # Write to Atomic Layer - Update the old record

                        HASH_TABLE = utilsTrans.system_value_process(spark,
                                obj, HASH_TABLE, logger)
                else:

                        # utilsIO.write_enrich(dbutils, HASH_TABLE, spark, obj,"append")

                    logger.debug('Skipping SCD2 since no repeatd SCD keys data '
                                 )

                # Identify the key to be used for Max

                if 'keys-to-identify-unique' in obj['scd2']:
                    if 'end-type' in obj['scd2']['keys-to-identify-unique']:
                        if str(obj['scd2']['keys-to-identify-unique'
                               ]['end-type']) == 'end-date-desc':
                            logger.debug('Record end date populated with decreasing load end date for increasing ref id '
                                    )
                            maxCount = HASH_TABLE.agg({'RankColumn': 'max'
                                    }).collect()[0][0]
                            if maxCount > 1:
                                listTemp = []
                                for valCount in range(2, maxCount + 1):
                                    loadEndValue_update = \
                                        datetime.datetime.strptime(obj['loadDate'],
                                            '%Y%m%d%H%M%S') \
                                        + timedelta(seconds=-valCount + 1)
                                    listTemp.append(tuple((valCount,
                                            loadEndValue_update)))
                                df_loadend = \
                                    spark.createDataFrame(listTemp,
                                        ['RankColumn', loadEndKey])
                                HASH_TABLE = HASH_TABLE.drop(loadEndKey)
                                HASH_TABLE = HASH_TABLE.join(df_loadend,
                                        'RankColumn', how='left'
                                        ).withColumn('CURR_IND', lit('0'))
                            else:
                                HASH_TABLE = \
                                    HASH_TABLE.withColumn(loadEndKey,
                                        when(col('RankColumn') != lit('1'),
                                        lit(loadEndValue)).otherwise(lit(''
                                        )).cast('timestamp'
                                        )).withColumn('CURR_IND',
                                        when(col('RankColumn') != lit('1'),
                                        lit('0')).otherwise(lit('1')))
                    else:

                        # Default way of generating load end date with same values

                        HASH_TABLE = HASH_TABLE.withColumn(loadEndKey,
                                when(col('RankColumn') != lit('1'),
                                lit(loadEndValue)).otherwise(lit(''
                                )).cast('timestamp')).withColumn('CURR_IND'
                                , when(col('RankColumn') != lit('1'),
                                lit('0').otherwise(lit('1'))))
            else:

                logger.debug('Skipping SCD2 since SCD2 is turned off ')
        except Exception as ex:
            try:
                logger.error(traceback.print_exc())
                raise scdError("SCD2 Error "+ ex)
            except scdError as se:
                audit_rec=TransformLoadDataVault(exit_doc,stage,se,'Failed',0,0,0,'NA',obj['target-table'])
                audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,se)
                metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                exit_doc["EXIT_CODE"]=0
                return 0,exit_doc

        # TARGET_TABLE.unpersist()

        HASH_TABLE.cache()
        # List of the existing columns
        column_list = HASH_TABLE.columns
        DF_TYPES = HASH_TABLE.dtypes

        # Validate the schema and drop additional columns
        stg_tb_nm=str(obj['target-table']).replace(".","_stg.")+"_STG"
        for colName in column_list:
            logger.debug('Column being validated : ' + colName)
            if colName in sorted(obj['target-schema'].keys()):
                colNewName = obj['target-schema'][colName]['colName']
                # Rename column if not matches with the existing

                if colName != colNewName:
                    logger.debug('Renaming to column : ' + colName)

                    # colName = "`" + colName +"`"
                    HASH_TABLE = HASH_TABLE.withColumnRenamed(colName,colNewName)
            else:
                logger.debug('Dropping column : ' + colName)
                HASH_TABLE = HASH_TABLE.drop(colName)

        # Write to Enrich Layer
        expected_period_key='NA'
        if destRowCount > 0:
            logger.info('target list:' + str(obj['target-col-list']))
            HASH_TABLE = utilsTrans.add_Audit_columns(HASH_TABLE,logger, obj)
            HASH_TABLE = HASH_TABLE.select(obj['target-col-list'])
           
            if "FISCAL_PERIOD_KEY" in obj['target-col-list']:
                try:
                    max_df=HASH_TABLE.select("FISCAL_PERIOD_KEY").agg({"FISCAL_PERIOD_KEY":"max"})
                    expected_period_key=max_df.first()[0]
                except:
                    expected_period_key='NA'
            if "has_indentity" in obj:
                pass 
            else:
                HASH_TABLE=utilsTrans.match_target_table_schema(spark,HASH_TABLE,obj,str(obj['target-table']))

            #Perform SCD2 using ADF Stored Procedure
            if 'storedproc-lookup' in obj and str(obj['storedproc-lookup']['enable-type2']) == "true":
                obj['storedproc'] = str(obj['storedproc-lookup']).replace("\'", '"')

            logger.debug('Writing new records Enrich ')
            stg_tb_nm=str(obj['target-table']).replace(".","_stg.")+"_STG"
            try:
                                           
                destRowCount = utilsIO.write_enrich(dbutils, HASH_TABLE, spark, obj, 'append',stg_tb_nm,logger)                     
                logger.debug('New records to Enrich '+ str(destRowCount))

            except Exception as ex:
                try:
                    logger.error(traceback.print_exc())
                    mismatch_err_mess = utilsTrans.schema_debug_btw_trg_and_stg(spark,obj,HASH_TABLE,str(obj['target-table']),logger)
                    if mismatch_err_mess is None:
                        raise dbInsertError(stg_tb_nm)
                    else:
                        raise schemaMismatchError(mismatch_err_mess, stg_tb_nm)
                except (dbInsertError,schemaMismatchError) as dbe:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,dbe,'Failed',0,0,0,'NA',obj['target-table'])
                    audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,dbe)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    logger.error(exit_doc["ERROR_CODE"])
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc
            targetTableColCount = len(HASH_TABLE.columns)
        else:
            logger.debug('Skipping the Write to atomic since no data to write')
        spark.catalog.clearCache()
        success_status_Desc="Load Enrich completed, stored proc will start"
        if exit_doc["VALIDATION_FLAG"]=='Failed':
            invalid_dim=InvalidDimValidationError()
        else:
            invalid_dim=0
        #audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'In Progress',destRowCount,targetTableColCount,rejRowCount,expected_period_key,obj['target-table'],invalid_dim)
        audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'In Progress',destRowCount,targetTableColCount,rejRowCount,expected_period_key,obj['target-table'])
        audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,invalid_dim)
        exit_doc["EXIT_CODE"]=1
        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
        logger.debug('Inserted Audit Entry - Job Successful ')
        return HASH_TABLE, exit_doc
    except:

    # try       
        err_desc = str(traceback.format_exc())
        logger.error(str(err_desc))
        try:
            raise uncatchException(err_desc)
        except uncatchException as ue:
            # Update the failure entry
            audit_rec=TransformLoadDataVault(exit_doc,stage,ue,'Failed',0,0,0,'NA',obj['target-table'])
            audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
            exit_doc["EXIT_CODE"]=0
            print("2Before DB Update")
            metadataObject.insert_auditRecord(dbutils,obj, spark, audit_doc)
            logger.debug('Inserted Audit Entry - Job Failure ')
            return 0,exit_doc
    finally:

    # except

        logger.info('End of ' + __name__ + ' process...')


# sqlContext.clearCache()
# context.stop()
# finally
###################################################################################################
