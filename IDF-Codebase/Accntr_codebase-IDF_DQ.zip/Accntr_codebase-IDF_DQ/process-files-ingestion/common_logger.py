import logging



class Logger():
    logger = None
    def __init__(self,script_name,filename=None):
        global logger
        logger = logging.getLogger(script_name)
        logger.setLevel(logging.DEBUG)
        if filename:
            file_handler = logging.FileHandler(filename)
        else:
            file_handler = logging.FileHandler("/dbfs/mnt/mountdatalake/idfdata/idfPOC/logs/logging.log")
            
        file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)
    
    
    def logging_debug(self,msg):
        logger.debug(msg)
        
    def logging_info(self,msg):
        logger.info(msg)
        
    def logging_warning(self,msg):
        logger.warning(msg)
        
    def logging_error(self,msg):
        logger.error(msg)
               
    def logging_critical(self,msg):
        logger.critical(msg)
