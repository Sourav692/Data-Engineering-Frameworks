import traceback
import sys
import json
import logging
import re
from datetime import datetime,date
import hashlib
import pyspark
from pyspark.sql.types import StringType
from pyspark.sql import SparkSession,DataFrame,SQLContext
from pyspark.sql.functions import lit,col,udf,trim
import time
import datetime
from collections import OrderedDict
# Custom Libs
from metadataManager import metadataManager
import utilsTrans
import utilsIO

sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_IDFCodebase/conf/')
sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')

from customException import *
from gen_audit_entry import *
import utilsShared

start_time =str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
millis = int(round(time.time() * 1000))

###################################################################################################
#M1
def process(obj,hashDF,dbutils,exit_doc):

    conf = pyspark.SparkConf()
    spark = SparkSession.builder.appName(obj["use-case"]).config(conf=conf).getOrCreate()
    metadataObject = metadataManager()
    stage='data-transform-process'
    logger = utilsShared.getFormattedLogger(stage, obj['local_log_file_name'])
    try:

        logger.info("Inside try of data-transform-process")
        audit_doc = OrderedDict()
        batchDate_formatted=datetime.datetime.strptime(obj["batchDate"], '%Y%m%d')
        batchDate_formatted=datetime.datetime.strftime(batchDate_formatted, '%Y-%m-%d')
        PRC_EXECUTION_ID=dbutils.widgets.get("prm_act_pipeline_id")
        srcColCount = len(hashDF.columns)
        
        if "transform-list" not in obj:
            logger.error("Please provide the list of transformations")
            return hashDF, exit_doc

        for trans in obj["transform-list"]:
            transType = str(obj[trans]["type"])
            objDict = obj[trans]["def"].copy()

            logger.debug("Performing Transformation of type : " + transType )
            try:
                # Generate the default values
                if transType == "default-value" :
                    hashDF = utilsTrans.default_vaule_process(spark,objDict,hashDF,logger,obj)
                    logger.debug("default-values generated successfully")

                # Perform col alias process
                if transType == "col-alias":
                    hashDF = utilsTrans.source_alias(spark,objDict,hashDF,logger)
                    logger.debug("col alias process performed successfully")

                # Performe the derived key process
                if transType == "derived-key-process" :
                    hashDF = utilsTrans.derived_key_process(spark,objDict,hashDF,logger)
                    logger.debug("derived key process performed successfully")

                # Filter processed key
                if transType == "filter-process" :
                    hashDF= utilsTrans.source_filter(spark,objDict,hashDF,obj["batchDate"],logger)
                    logger.debug("HASH Table count After filter process "+ str(hashDF.count()))
                    logger.debug("Filter processed key process performed successfully")

                # Derived dataframe process
                if transType ==  "derived-dataframe-process":
                    hashDF = utilsTrans.derived_dataframe_process(spark,objDict,hashDF,logger)
                    logger.debug("Derived dataframe process performed successfully")

                # Drop duplicate from the column
                if transType == "drop-duplicates":
                    hashDF = hashDF.dropDuplicates(objDict["drop-duplicates-cols"])
                    logger.debug("HASH Table count After removing duplicates based on col provided "+ str(hashDF.count()))
                    logger.debug("Drop duplicate from the column process performed successfully")

                # Hash key generation
                if transType == "hash-key":
                    hashDF = utilsTrans.generate_hash(spark,objDict,hashDF,logger)
                    logger.debug("Hash key generation process performed successfully")

                if transType == "rename-cols" :
                    hashDF = utilsTrans.rename_cols(hashDF,objDict["table-name"])
                    logger.debug("rename-cols process completed successfully")

                if transType == "type-conversion" :
                    hashDF = utilsTrans.type_conversion(hashDF,objDict)
                    logger.debug("type-conversion process completed successfully")

                if transType == "format-date-to-string":
                    hashDF = utilsTrans.format_date_to_string(hashDF,objDict)
                    logger.debug("format-date-to-string process completed successfully")

                if transType == "custom-sql-query":
                    hashDF = utilsTrans.custom_query_execution(spark,objDict,hashDF,logger)
                    hashDF.show()
                    logger.debug("custom-sql-query process completed successfully")

                if transType == "aggregation":
                    hashDF = utilsTrans.aggregate_process(spark,objDict,hashDF,logger)
                    logger.debug("Aggregation process completed successfully")
            except Exception as ex:
                try:
                    logger.error(traceback.print_exc())
                    raise transformationError(transType)
                except transformationError as tne:
                    audit_rec=TransformLoadDataVault(exit_doc,stage,tne,'Failed',0,0,0,'NA')
                    audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,tne)
                    metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0,exit_doc
		
        destRowCount=hashDF.count()
        targetTableColCount=len(hashDF.columns)
        success_status_Desc="Data Transform Process Completed Successfully, initiating load enrich process"
        logger.debug("exit doc of data-trans-process "+str(exit_doc))
					   
        audit_rec=TransformLoadDataVault(exit_doc,stage,success_status_Desc,'In Progress',destRowCount,targetTableColCount,0,'NA')
        logger.debug("audit_rec of data-trans-process "+str(audit_rec.VALIDATION_FLAG))
        audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,0)
        logger.debug("exit doc2 of data-trans-process "+str(exit_doc))
        return hashDF, exit_doc
    except:
        
        err_desc = str(traceback.format_exc())
        logger.error(str(err_desc))
        try:
            raise uncatchException(err_desc)
        except uncatchException as ue:
            #Update the failure entry
            audit_rec=TransformLoadDataVault(exit_doc,stage,ue,'Failed',0,0,0,'NA')
            audit_doc,exit_doc=utilsTrans.gen_audit_dict(audit_doc,exit_doc,audit_rec,ue)
            
            metadataObject.insert_auditRecord(dbutils,obj, spark, audit_doc)
            logger.debug('Inserted Audit Entry - Job Failure ')
            return 0,exit_doc

    finally:
        logger.info("End of "+ __name__+ " process...")
        #sqlContext.clearCache()
		#context.stop()
	#finally
###################################################################################################
