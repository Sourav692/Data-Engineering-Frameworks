# Databricks notebook source
#Databricks notebook source
import os
import csv
import re
import logging
import traceback
import optparse
import pandas as pd
import json
import os
import sys
import itertools

#COMMON
logger = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger.setLevel(logging.DEBUG)
logging.getLogger("py4j").setLevel(logging.ERROR)

def measureProcess(testFile,resultFile):
    logger.info("UI Measure process initiated")
    baseUIMeasurePath="/dbfs/mnt/mountdatalake/AZ_schemaData/UIMeasuresData/"
    firstpos=testFile.rfind("/")
    lastpos=len(testFile)
    fileName=testFile[firstpos+1:lastpos].split(".")[0]+"_"+"UIMeasures.csv"
    fullPathtoWrite=str(baseUIMeasurePath)+fileName
    #test_attribute,distance,avg_probability,possible_train_attribute
    logger.info("Reading result file from :"+str(resultFile))
    resultDf=pd.read_csv(resultFile)
    distanceMask = resultDf['distance'] < 10.0
    avg_proMask = resultDf['avg_probability'] > 0.8
    pos_train_attrMask= resultDf['possible_train_attribute'].str.contains(",") == False
    # resultDf = resultDf[(distanceMask) & (avg_proMask) & (pos_train_attrMask)]
    logger.info("Filtering data based on distance < 10.0 and avg_probability > 0.8")
    resultDf = resultDf[(distanceMask) & (avg_proMask)]
    resultcolList=resultDf['test_attribute'].tolist()
    logger.info("Reading result file from :"+"/dbfs"+str(testFile))
    testFileDF=pd.read_csv("/dbfs/"+str(testFile))
    testFileDF=testFileDF[resultcolList]
    testUniqueCountDF=testFileDF.T.apply(lambda x: x.nunique(), axis=1).to_frame()
    field_count_df=testUniqueCountDF.reset_index().rename(columns={'index':'test_attribute',0:'count'}).sort_values('count',ascending= False)
    # pd.merge(resultDf,field_count_df,on='test_attribute')
    UIMeasuresDf=pd.merge(resultDf,field_count_df,how='inner',left_on=['test_attribute'],right_on=['test_attribute']).sort_values('count',ascending= False)
    logger.info("writing UI measure file to :"+str(fullPathtoWrite))
    UIMeasuresDf.to_csv(fullPathtoWrite, index=False)
    return fileName
