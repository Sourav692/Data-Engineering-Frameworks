import traceback
import sys,os
import logging
import re
import hashlib
import time
from shutil import copyfile
import glob
from pyspark.sql import SparkSession
import datetime
from collections import OrderedDict
from pyspark.sql import DataFrame as SparkDataFrame
from pyspark.sql.types import *
import  pyspark.sql.functions as F
from delta.tables import *
sys.path.insert(0,'/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/codebase/')
# sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-ingestion/')
# sys.path.insert(0, '/dbfs/mnt/mountdatalake/AZ_IDFCodebase/process-files-datavault/')
from streamingMetadataManager import streamingMetadataManager
from utilsShared import UtilsShared
from UtilsCurate import UtilsCurate
from customException import *
from gen_audit_entry import *
# import utilsTrans
# import utilsTransDelta
# import utilsIO
from UtilStream import UtilsStream

###################################################################################################

class StreamingDataProcess:

    def __init__(self):
	    pass

    millis = int(round(time.time() * 1000))
    def process(conf,obj,inputDF,dbutils,exit_doc):
        job_start_time=str(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")) 
        stage='streaming-data-process'
        logger = UtilsShared.getFormattedLogger(stage,obj['local_log_file_name'])
        validation_flag=False    
        spark = SparkSession.builder.appName(obj["use-case"]).getOrCreate()
        spark.conf.set("spark.sql.sources.partitionOverwriteMode","dynamic")
        metadataObject = streamingMetadataManager()
        readDF = 0
        try:
            logger.info("Inside " + stage)
            audit_doc=OrderedDict()      
            #Create a readStream

            try:
                readDF = UtilsStream.readStream(spark,conf,obj,dbutils,logger)
            except:
                try :
                    logger.error(str(traceback.print_exc()))
                    err_desc = str(traceback.format_exc())            
                    raise readStreamException(err_desc)
                except readStreamException as rse:
                    audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',ue,job_start_time)
                    audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,ue)
                    metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                    exit_doc["EXIT_CODE"]=0
                    return 0

            if readDF != 0:
                logger.info("Write the stream")
                if 'eventhubs' in obj['data-source']:
                    obj['source_type'] = "eventhubs"
                    checkpoint_dirname = obj['data-source']['eventhubs']['entityPath']
            ######## kafka code added ############
                elif 'kafka' in obj['data-source']:
                    obj['source_type'] = "kafka"
                    checkpoint_dirname = obj['data-source']['kafka']['topicName']
            ######################################
                else:
                    obj['source_type'] = "autoloader"
                    checkpoint_dirname = obj['data-source']['autoloader']['source-dir']
            
                checkpoint = obj['azure']['checkpoint-base-path'] + checkpoint_dirname
                logger.info('Checkpoint directory set at: ' + checkpoint)

                sourceType = obj['source_type']

                try:
                    exit_doc['TRIGGER_TYPE'] = obj["trigger"]['trigger-type']
                    exit_doc['SOURCE_TYPE'] = obj['source_type']
                    exit_doc['CHECKPOINT_PATH'] = checkpoint
            
                    if "default" in obj["trigger"]['trigger-type']:
                        logger.info('Default trigger stream will run micro-batch as soon as it can')
                        query = (readDF.writeStream.queryName(obj["streamName"]).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: UtilsStream.foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
                        logger.info("lastprogress: " + str(query.lastProgress))              
                        
                    elif "processingTime" in obj["trigger"]['trigger-type']:            
                        interval = str(obj["trigger"]["trigger-interval"]) #Eg '2 seconds'
                        logger.info('ProcessingTime trigger with '+ interval + ' micro-batch interval')
                        query = (readDF.writeStream.queryName(obj["streamName"]).trigger(processingTime=interval).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: UtilsStream.foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
            
                    elif "once" in obj["trigger"]['trigger-type']:
                        logger.info('One-time trigger')
                        query = (readDF.writeStream.queryName(obj["streamName"]).trigger(once=True).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: UtilsStream.foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())

                    elif "continuous" in obj["trigger"]['trigger-type']:
                        interval = str(obj["trigger"]["trigger-interval"]) #Eg '1 second'
                        logger.info('Continuous trigger with '+ interval + ' checkpointing interval')
                        query = (readDF.writeStream.queryName(obj["streamName"]).trigger(continuous=interval).option("checkpointLocation",checkpoint).foreachBatch(lambda df,epochId: UtilsStream.foreach_batch_function(df,epochId,spark,obj,exit_doc,audit_doc,dbutils)).start())
                    else:
                        try:
                            obj['trigger'] = 'NA'
                            trigger = "Trigger is not defined"
                            logger.error(trigger)
                            raise triggerException(trigger)
                        except triggerException as te:
                            audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',te,job_start_time)
                            audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,te)
                            metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                            exit_doc["EXIT_CODE"]=0
                            return 0

                    query.awaitTermination(20)
                except:
                    try :
                        logger.error(str(traceback.print_exc()))
                        err_desc = str(traceback.format_exc())                         
                        raise WriteStreamForEachBatch(err_desc)
                    except WriteStreamForEachBatch as wre:                        
                        audit_rec= WriteStreamForEachBatch(exit_doc,obj,'Failed',wre,job_start_time)
                        audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,wre)
                        metadataObject.insert_auditRecord(dbutils,obj,spark,audit_doc)
                        UtilsStream.stopStream(spark,logger)
                        exit_doc["EXIT_CODE"]=0
                        return 0    

            return inputDF
        except:
            try :
                logger.error(str(traceback.print_exc()))
                err_desc = str(traceback.format_exc())        
                raise uncatchException(err_desc)
            except uncatchException as ue:
                audit_rec= BeforeStreamRead(exit_doc,obj,'Failed',ue,job_start_time)
                audit_doc,exit_doc=UtilsShared.gen_audit_dict_streaming(audit_doc,exit_doc,audit_rec,ue)
                metadataObject.insert_StreamingauditRecord(dbutils,obj,spark,audit_doc)
                UtilsStream.stopStream(spark,logger)
                exit_doc["EXIT_CODE"]=0
                return 0