import sys
import traceback
import os
import logging
from collections import OrderedDict
from pyspark.sql import DataFrame as SparkDataFrame
import hashlib
import time
import json
import utilsIO
#from regexLibrary import *
from shutil import copyfile
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType, DateType, DecimalType, FloatType
from pyspark.sql.functions import *
from datetime import datetime
#emptyRDD = spark.sparkContext.emptyRDD()
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

class UtilsDQ:

	def __init__(self):
		pass


	def getFormattedLogger(scriptName,fileName=None):
		logger = logging.getLogger(scriptName)
		#logger = logging.getLogger() #Enabling root logger
		logger.setLevel(logging.DEBUG)
		file_format = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
		if fileName:
			file_handler = logging.FileHandler(fileName)
			file_handler.setFormatter(file_format)
			logger.addHandler(file_handler)
		ch=logging.StreamHandler()
		ch.setLevel(logging.DEBUG)
		ch.setFormatter(file_format)
		logger.addHandler(ch)
		logging.getLogger("py4j").setLevel(logging.ERROR)
		return logger


	def getEnvConf(logger=0,dbutils=0,storageFlag=0,onlyYaml=0):
		# Read the environment Config file from the static path
		if logger ==0 :
			logger = UtilsDQ.getFormattedLogger(__name__)

		envConfPath= "/dbfs/mnt/mountdatalake/AZ_Gap_Streaming_POC/codebase/envConfig.yaml"
		logger.info("Reading Env Config from: " + envConfPath)
		if onlyYaml==1:
			envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
		else:
			if os.path.isfile(envConfPath):
				envConfig= yaml.load(open(envConfPath,'r'),Loader=yaml.FullLoader)
				"""
				#stg_acct_name = dbutils.secrets.get(scope = 'keyvault',key = '')
				envConfig["azure"]["storage_account_name"]	= "xxxxx"
				envConfig["azure"]["storage_account_access_key"]	=	"xxxxxxxx"
				temp_dir_path = envConfig["sqlserver"]["temp_dir_path"]
				envConfig["sqlserver"]["tempDir"] = 'abfss://' + str(envConfig["azure"]["storage_container_name"]) +'@'+ str(envConfig["azure"]["storage_account_name"]) +'.dfs.core.windows.net'+ str(envConfig["sqlserver"]["temp_dir_path"])
				sql_server_name = str(envConfig["sqlserver"]["sql_server_name"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
				sql_server_db = str(envConfig["sqlserver"]["sql_server_db"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
				sql_server_user = str(envConfig["sqlserver"]["sql_server_user"]) #dbutils.secrets.get(scope = 'keyvault',key = '')
				sql_server_pass = str(envConfig["sqlserver"]["sql_server_pass"]) #dbutils.secrets.get(scope = 'keyvault',key = '')

				conn_string = 'jdbc:sqlserver://' + str(sql_server_name) + ';database=' + str(sql_server_db) +';user='+ str(sql_server_user) +';password='+ str(sql_server_pass) +';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
				envConfig["sqlserver"]["connection-string"]	=	conn_string
				"""
			else:
				logger.info("Env Config is not available " + str(envConfPath) + ", Please place the config file in order to execute the job")
				return 0

		return envConfig



	# Get default initialised audit_doc
	def gen_audit_dict(audit_doc,exit_doc,audit_rec,exception):
		"""
		@params: audit_doc,exit_doc,audit_rec,exception
		@returns: audit_doc,exit_doc
		"""
		audit_doc=OrderedDict()
		audit_doc['PRCS_NAME'], exit_doc['PRCS_NAME'] = audit_rec.PRCS_NAME,audit_rec.PRCS_NAME
		audit_doc['FILE_NAME'], exit_doc['FILE_NAME'] = audit_rec.FILE_NAME,audit_rec.FILE_NAME
		audit_doc['BATCH_DATE'],exit_doc['BATCH_DATE'] = audit_rec.BATCH_DATE,audit_rec.BATCH_DATE
		audit_doc['SOURCE_NAME'],exit_doc['SOURCE_NAME'] = audit_rec.SOURCE_NAME,audit_rec.SOURCE_NAME
		audit_doc['PRCS_EXECUTION_ID'], exit_doc['PRCS_EXECUTION_ID'] = audit_rec.PRCS_EXECUTION_ID,audit_rec.PRCS_EXECUTION_ID
		audit_doc['PIPELINE_NAME'],exit_doc['PIPELINE_NAME']=audit_rec.PIPELINE_NAME,audit_rec.PIPELINE_NAME
		audit_doc['TRIG_NAME'],exit_doc['TRIG_NAME']=audit_rec.TRIG_NAME,audit_rec.TRIG_NAME
		audit_doc["STATUS"], exit_doc['STATUS']=audit_rec.STATUS,audit_rec.STATUS
		audit_doc["STATUS_DESC"],exit_doc['STATUS_DESC'], exit_doc['TECH_STATUS_DESC']=audit_rec.STATUS_DESC[:255],audit_rec.STATUS_DESC,audit_rec.TECH_STATUS_DESC
		exit_doc['BUSS_STATUS_DESC']=audit_rec.BUSS_STATUS_DESC
		audit_doc['JOB_START_TIME'], exit_doc['JOB_START_TIME'] = audit_rec.JOB_START_TIME,audit_rec.JOB_START_TIME
		audit_doc["JOB_END_TIME"], exit_doc['JOB_END_TIME']=audit_rec.JOB_END_TIME,audit_rec.JOB_END_TIME
		exit_doc["VALIDATION_FLAG"]="Failed" if audit_rec.VALIDATION_FLAG else "Succeeded"

		audit_doc['SOURCE_PATH'], exit_doc['SOURCE']['SOURCE_PATH'] = audit_rec.SOURCE_PATH,audit_rec.SOURCE_PATH
		audit_doc["SOURCE_ROW_COUNT"], exit_doc['SOURCE']['SOURCE_ROW_COUNT'] = audit_rec.SOURCE_ROW_COUNT,audit_rec.SOURCE_ROW_COUNT
		audit_doc['SOURCE_COL_COUNT'], exit_doc['SOURCE']['SOURCE_COL_COUNT'] = audit_rec.SOURCE_COL_COUNT,audit_rec.SOURCE_COL_COUNT
		audit_doc["SOURCE_AMOUNT"], exit_doc['SOURCE']['SOURCE_AMOUNT']=audit_rec.SOURCE_AMOUNT,audit_rec.SOURCE_AMOUNT
		audit_doc['SOURCE_FILE_SIZE'], exit_doc['SOURCE']['SOURCE_FILE_SIZE'] = audit_rec.SOURCE_FILE_SIZE,audit_rec.SOURCE_FILE_SIZE
		exit_doc["EXPECTED_PERIOD_KEY"]=audit_rec.EXPECTED_PERIOD_KEY
		audit_doc['DEST_PATH'], exit_doc['DESTINATION']['DEST_PATH'] = audit_rec.DEST_PATH,audit_rec.DEST_PATH
		audit_doc["DEST_ROW_COUNT"], exit_doc['DESTINATION']['DEST_ROW_COUNT'] = audit_rec.DEST_ROW_COUNT,audit_rec.DEST_ROW_COUNT
		audit_doc['DEST_COL_COUNT'], exit_doc['DESTINATION']['DEST_COL_COUNT'] = audit_rec.DEST_COL_COUNT,audit_rec.DEST_COL_COUNT
		audit_doc["DEST_AMOUNT"], exit_doc['DESTINATION']['DEST_AMOUNT']=audit_rec.DEST_AMOUNT,audit_rec.DEST_AMOUNT
		audit_doc['DEST_FILE_SIZE'], exit_doc['DESTINATION']['DEST_FILE_SIZE'] =audit_rec.DEST_FILE_SIZE,audit_rec.DEST_FILE_SIZE
		audit_doc['REJECTED_ROW_COUNT'], exit_doc['DESTINATION']['REJECTED_ROW_COUNT'] = audit_rec.REJECTED_ROW_COUNT,audit_rec.REJECTED_ROW_COUNT
		audit_doc['REJECTED_FILE_NAME'], exit_doc['DESTINATION']['REJECTED_FILE_NAME'] = audit_rec.REJECTED_FILE_NAME,audit_rec.REJECTED_FILE_NAME
		audit_doc["LOG_PATH"]=audit_rec.LOG_PATH
		exit_doc["ERROR_CODE"]=exception.error_code if type(exception) != int else 0
		return audit_doc,exit_doc


	# Function to join the dataframes
	def df_join(leftDF,leftcolList,rightDF,rightColList,logger,joinType="inner"):
		"""
		@params: leftDF,leftcolList,rightDF,rightColList,logger,joinType=inner
		@returns: leftDF
		"""
		logger.info("In JOin")
		for (colNameleft, colNameRight) in zip(leftcolList,rightColList) :
			logger.debug("Casting	"+ colNameRight + " with datatype of	" + colNameleft)
			rightDF = rightDF.withColumn(colNameRight, col(colNameRight).cast(leftDF.schema[str(colNameleft)].dataType))

		for colName in rightColList:
			colName2 = "tempJoin_"+ colName
			logger.debug("Renaming column "+ colName + " with " + colName2 )
			rightDF = rightDF.withColumnRenamed(colName,colName2)

		leftDF= leftDF.join(broadcast(rightDF),[trim(col(f)).eqNullSafe(trim(col("tempJoin_" + s))) for (f, s) in zip(leftcolList,rightColList)], how = joinType)

		# Dropping the columns which are renamed after joining
		for colName in rightColList:
			colName2 = "tempJoin_"+ colName
			logger.debug("Dropping column "+ colName2)
			leftDF = leftDF.drop(colName2)

		if "CURR_IND" in leftDF.columns:
			leftDF = leftDF.drop("CURR_IND")
		return leftDF

	#Reading input data
	def data_quality_read_input_data01(spark,tableName, data_type, data_path, logger):
		"""
		@params: spark dataframe,envConfig,tableName, data_type, data_path, logger_str
		@returns: hash_table dataframe
		"""
		hash_table = None
		if(data_type == 'csv'):
			logger.info("Trying to read data for table: " + tableName + " from file at "+ data_path)
			#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path
			hash_table = spark.read.option("header",True).csv(data_path, header = True)
		elif (data_type == 'delta'):
			logger.info("Trying to read data for table: " + tableName + " from delta file at "+ data_path)
			#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from delta table at "+ data_path
			hash_table = spark.read.format("delta").load(data_path).select('*')

		else:
			logger.error("Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported")
			#logger_str =logger_str+"\nError: "+"Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported"
			raise Exception("Provided file format "+data_type+" not supported yet to read. Currently supported formats: csv, delta ")
		return hash_table

	#Reading input data
	def data_quality_read_input_data(spark,tableName, data_type, data_path, logger):
		"""
		@params: spark dataframe,envConfig,tableName, data_type, data_path, logger_str
		@returns: hash_table dataframe
		"""
		hash_table = None
		if(data_type == 'csv'):
			logger.info("Trying to read data for table: " + tableName + " from file at "+ data_path)
			#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path
			hash_table = spark.read.option("header",True).csv(data_path, header = True)
		elif (data_type == 'delta' or data_type == 'parquet'):
			logger.info("Trying to read data for table: " + tableName + " from "+data_type+" file at "+ data_path)
			#logger_str =logger_str+"\nInfo: "+"Trying to read data for table: " + tableName + " from delta table at "+ data_path
			hash_table = spark.read.format(data_type).load(data_path)

		else:
				#	logger.error("Failed to read data for table: " + tableName + " from "+data_type+" table at "+ data_path+" as the input file format "+ data_type+" not supported")
				#logger_str =logger_str+"\nError: "+"Failed to read data for table: " + tableName + " from delta table at "+ data_path+" as the input file format "+ data_type+" not supported"
				raise Exception("Provided file format "+data_type+" not supported yet to read. Currently supported formats: csv, delta ")
		return hash_table


	#Missing data Valdiation

	def data_quality_null_validation(spark,hash_table,ruleColms,ruleID,logger):
		"""
		@params: envConfig,hash_table,ruleColms,ruleID,logger
		@returns: null validation record, null validation record count
		"""
		ruleColms_lst=ruleColms.split(',')
		# hash_table=hash_table.select('*',"data.*")
		null_filter_str =""
		for ruleCol in ruleColms_lst:
			null_filter_str=null_filter_str + "(trim(cast("+ruleCol+" as string))='') or ("+ruleCol+" is Null) or"
		ruleExpr=null_filter_str[:-2]
		validated_res = hash_table.withColumn("ERR_CD", when(expr(ruleExpr), lit(ruleID)).otherwise(lit(""))).where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )")
		return validated_res, validated_res.count()




	# Duplicate records count
	def data_quality_duplicates_valdation(spark,hash_table,ruleColms,ruleID,logger):
		"""
		@params: envConfig,hash_table,ruleColms,ruleID,logger
		@returns: duplicates valdation record, duplicates valdation record count
		"""
		ruleColms_lst=ruleColms.split(',')
	#	 hash_table=hash_table.select('*',"data.*")
		duplicates_data=hash_table.groupBy(ruleColms_lst).count().where(col("count") > 1)
		new_ruleColms_lst =[]
		new_columns_to_drop=[]
		for clm_name in ruleColms_lst:
			new_clm_name = clm_name
			if('.' in clm_name):
				current_clm_name = clm_name.split('.')[-1]
				new_clm_name=clm_name.replace('.','_')
				duplicates_data = duplicates_data.withColumnRenamed(current_clm_name, new_clm_name)
				hash_table = hash_table.withColumn(new_clm_name, col(clm_name) )
				new_columns_to_drop=new_columns_to_drop+[new_clm_name]
				new_ruleColms_lst=new_ruleColms_lst+[new_clm_name]
		validated_res=duplicates_data.join(hash_table,new_ruleColms_lst, "inner" ).select(hash_table.columns).drop(col("count")).withColumn("ERR_CD", lit(ruleID))
		#logger.info("Trying to load duplicates data: " + validated_res)
		validated_res=validated_res.drop(*new_columns_to_drop)
		return validated_res, validated_res.count()


	# Row Counts validation
	# Will Need To Update The Nmaing Convention and Complete the expressions after getting sample recon file and modify
	def data_quality_counts_valdation(spark,hash_table, refPath,refPathType,ruleID,logger):
		"""
		@params: spark dataframe,envConfig,hash_table, refPath, ruleID,logger
		@returns: counts valdation dataframe
		"""
		#source_side_df=spark.read.format(recon_file_format).load(refPath)
		sample_recon_df= UtilsDQ.data_quality_read_input_data01(spark,'ReconFile', refPathType, refPath, logger)
		job_sesn_strt_ts=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['strm_sesn_strt_ts']
		job_sesn_end_ts=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['strm_sesn_end_ts']
		source_count=sample_recon_df.orderBy("recon_load_ts", ascending=False).first()['total_rec_sent']
		#delta_count=hash_table.where( (col("load_ts")> to_timestamp(job_sesn_strt_ts))	& (col("load_ts")< to_timestamp(job_sesn_end_ts))).count()
		delta_count = hash_table.orderBy("timestamp", ascending=False).first()['numOutputRows']
		count_diff= int(source_count)-int(delta_count)
		counts_vldtn_scma= StructType([
		StructField("RULE_ID", StringType()),
		StructField("FAILED_ROW_COUNT", IntegerType()),
		StructField("TOTAL_ROW_CNT", IntegerType()),
		StructField("PASSED_ROW_CNT", IntegerType())])
		counts_vldtn_data = spark.createDataFrame([(ruleID, int(count_diff), int(source_count), int(delta_count) )], counts_vldtn_scma )
		return counts_vldtn_data

	# Methods to get subject and email body details for Counts validation mismatch Alerting
	def dq_counts_validation_alert_details(envConfig,dqStatisticsRes, TbaleName,logger):
		"""
		@params: envConfig,dqStatisticsRes, TbaleName,logger
		@returns: subject,meesageDict ,records count
		"""
		records_count_res = dqStatisticsRes.where(lower(col("RULE_TYPE")) == 'count_validation').withColumn("EXEC_DATE", col("EXEC_DATE").cast(StringType())).first().asDict()
		records_count_diff = records_count_res['FAILED_ROW_COUNT']
		source_count = records_count_res['TOTAL_ROW_CNT']
		current_count = records_count_res['PASSED_ROW_CNT']
		message=""
		if (records_count_diff != 0):
		# recipient = "santhosh_killi@gap.com"#dbutils.secrets.get(scope = "key-vault-secrets", key = "") # insert secret name
		#recipient="aluguri_koushik@gap.com"
		#"\033[1m" + a_string + "\033[0m"
			subject = "DQ ALERT: Records Count Mismatch for Table: "+TbaleName.upper()
			message00="Hi Team,"
			message01 = "This is a system generated alert to inform that there is record count mismatch between recon and raw table <b>"+TbaleName.upper()+"</b> below are the details for the same:"
			message02="<b>Count_Difference: "+str(records_count_diff)+"</b>"
			message03 = "<b>Source_Count: "+str(source_count)+"</b>"
			message04 = "<b>Current_Count: "+str(current_count)+"</b>"
			message05 = "More DQ validation details below: "
			message06 = str(records_count_res).replace(", '",",'")
			message07 = "Regards,"
			message08 = "DQ Validation."
			meesageDict = {"message00":message00,"message01":message01,"message02":message02,"message03":message03,"message04":message04,"message05":message05,"message06":message06,"message07":message07,"message08":message08}
			return subject,meesageDict,records_count_res
		else:
			return 0


	# Send an Email
	def SendEmail(recipient, subject, meesageDict, dQValResDict, logger):
		"""
		@params: recipient, subject, meesageDict, dQValResDict, logger
		@returns: sendmail to mail Address
		"""
		table = "<table>\n"
		table += "	<tr>\n"
		for key in dQValResDict:
			table += "	<th>{0}</th>\n".format(key.strip())
		table += "	</tr>\n"
		table += "	<tr>\n"
		for key in dQValResDict:
			table += "	<td>{0}</td>\n".format(dQValResDict[key])
		table += "	</tr>\n"
		table += "</table>"
		html = f'''\
		<html>
		<head>
			<style>
			table, th, td {{ border: 1px solid black; border-collapse: collapse; }}
			th, td {{ padding: 5px; }}
			</style>
		</head>
		<body>
			<div>{meesageDict["message00"]}</div><br><br>
			<div>{meesageDict["message01"]}</div><br>
			<div>{meesageDict["message02"]}</div><br>
			<div>{meesageDict["message03"]}</div><br>
			<div>{meesageDict["message04"]}</div><br>
			<div>{meesageDict["message05"]}</div><br>
			<br>{table}<br>
			<div>{meesageDict["message07"]}</div><br>
			<div>{meesageDict["message08"]}</div><br>
		</body>
		</html>
		'''
		server = smtplib.SMTP ('Mailhub.gap.com', 25)
		server.ehlo()
		server.starttls()
		#sender = 'aparna_roy@gap.com'
		sender = 'santhosh_killi@gap.com'
		msg = MIMEMultipart()
		msg['Subject'] = subject
		msg['From'] = sender
		msg['To'] = recipient
		msg.attach(MIMEText(html, 'html'))
		server.sendmail(sender, recipient, msg.as_string())
		logger.info("Email Send to: " + recipient)
		server.close()


	## method to validate custom expression validation on spark dataframe
	def data_quality_expression_validation(envConfig,hash_table,ruleID,rule,logger):
		"""
		@params: envConfig,hash_table,ruleID,rule,logger
		@returns: hash_table dataframe
		"""
		ruleVal = rule['RULE_VAL']
		ruleCol = "DQ_CUST_EXPR_CHECK"
	#	 hash_table=hash_table.select('*',"data.*")
		logger.info("Trying to load data for rule value: " + ruleVal)
		# logger.debug("Hash Table count is",str(hash_table.count()))
		ruleExpr = expr(ruleVal)
		hash_table = hash_table.withColumn(ruleCol, ruleExpr) \
			.withColumn('ERR_CD',
						when((trim(col(str(ruleCol))) == lit("")) | (
							isnull(col("`" + str(ruleCol) + "`"))) | (
									trim(col(str(ruleCol))) == lit("false")),
							lit(ruleID)) \
						.otherwise(lit("")))
		# logger.debug("Hash Table count with column is",str(hash_table.count()))
		validated_res = hash_table.where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )").drop(ruleCol)
		return validated_res, validated_res.count()



	## method to do straight lookup between to two dataframes

	def data_quality_straight_lookup_validation(spark, envConfig, hash_table, ruleVal, ruleID, lookup_path, format, logger):
		"""
		@params: inputDF- spark dataframe, envConfig, hash_table, ruleVal, ruleID, lookup_path, format, logger
		@returns: hash_table dataframe
		"""
		try:
			ruleValLkUp = json.loads(ruleVal)
			# hash_table=hash_table.select('*',"data.*")
			logger.info("Trying to load data for rule value: " + ruleVal)
			hash_colList = list(ruleValLkUp['RULE_COL_TO_MATCH'].keys())
			ref_colList = list(ruleValLkUp['RULE_COL_TO_MATCH'].values())
			retColName = ruleValLkUp['REF_RET_COL']
			lookupTable = ruleValLkUp['REF_TABLE_NAME']
			REF_DF = utilsIO.read_data_based_on_format(spark,envConfig,format,lookup_path,lookupTable,logger)
			hash_table = df_join(hash_table,hash_colList,REF_DF,ref_colList)
			hash_table = hash_table.withColumn('ERR_CD',
												when( ( (trim(col(str(retColName))) == lit("")) | (
													isnull(col("`" + str(retColName) + "`"))) ),lit(ruleID)) \
												.otherwise(""))
			validated_res = hash_table.where(" NOT (ERR_CD is Null or trim(ERR_CD) = '' )").drop(retColName)
			return validated_res, validated_res.count()
		except:
			logger.error("Failed to apply straight lookup for rule value: " + ruleVal)
			return 0


	# write the dataframe into a sql table
	def write_data_sql(HASH_TABLE, obj,v_mode,tgt_table):
		if HASH_TABLE.count() > 0:
			database = str(obj['sqlserver']['jdbcDatabase'])
			port = str(obj['sqlserver']['jdbcPort'])
			hostname = str(obj['sqlserver']['jdbcHostname'])
			HASH_TABLE.write \
				.format("jdbc") \
				.option("url",f"jdbc:sqlserver://{hostname}:{port};database={database};") \
				.option("dbtable",tgt_table) \
				.option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver") \
				.option("user",str(obj["sqlserver"]["username"])) \
				.option("password",str(obj["sqlserver"]["password"])) \
				.mode(v_mode) \
				.save()

	# read data from sql table
	def read_data_sql_table(spark,obj,tableName,logger):
		"""
			@params: spark, envConfig, table Name, logger
			@returns: spark dataframe from dq Master table
		"""
		try:
			if "sqlserver" in obj.keys():
				jdbcHostname = obj['sqlserver']['jdbcHostname']
				jdbcDatabase = obj['sqlserver']['jdbcDatabase']
				jdbcPort = obj['sqlserver']['jdbcPort']
				username = obj['sqlserver']['username']
				password = obj['sqlserver']['password']
				hostNameInCertificate = obj['sqlserver']['hostNameInCertificate']
				jdbcUrl = obj['sqlserver']['jdbc-connection-string']
				jdbcUrl = jdbcUrl.format(jdbcHostname, jdbcPort, jdbcDatabase, username, password, hostNameInCertificate)
				connectionProperties = {"user": username, "password": password,
										"driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"}
				#query = '(select * from dbo.dqMaster where TABLE_NAME = {} and IsActive = 1) as t1'.format(tableName)
				query = '(select * from dbo.dqMaster order by RULE_ID desc OFFSET 0 ROWS) as t1'
				jdbcUrl= conn_string = 'jdbc:sqlserver://' + str(jdbcHostname) + ':' + str(jdbcPort) + ';database=' + str(jdbcDatabase) +';user='+ str(username) +';password='+ str(password) +';encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;loginTimeout=30;'
				# read sql table and create spark dataframe on top of it
				df = spark.read.jdbc(url=jdbcUrl, table=query, properties=connectionProperties)

				if df.count() > 0:
					return df
		except:
			logger.info("Sql server properties are missing")
			raise ValueError("Sql server properties are missing ")

	def data_quality_regex_expr_validation(hash_table,ruleColms,ruleID,ruleVal,logger):
		"""
		@params: envConfig,hash_table,ruleColms,ruleID,logger
		@returns: null validation record, null validation record count
		"""
		map_dict = {}
		regexPat = regex_pattern()
		map_dict = mapping_dict()
		logger.info("Trying to load data for rule value: " + ruleVal)
		key = map_dict[ruleVal]
		reg = regexPat[key]
		if reg:
			validated_res = hash_table.withColumn("ERR_CD", when(regexp_extract(ruleColms, reg, 0) == lit(""), lit(ruleID)).otherwise(lit("")))
		else:
			logger.error("Regular Expression not found" + reg)
		# logger.debug("Hash Table count with column is",str(hash_table.count()))
		return validated_res, validated_res.count()

	def condition(n,mini,maxi,hash_table):
		if n>mini and n<maxi:
			return 0
		else:
			return hash_table.count()

	def get_dtype(df,colname):
		"""
		@params: dataframe and column name
		@return: data type in string format
		"""
		return [dtype for name, dtype in df.dtypes if name == colname][0]

    
	def data_quality_aggregate_validation(hash_table,ruleCol,ruleVal,ruleID,logger):

		"""
		@params: envConfig,hash_table,ruleColms,ruleVal,logger
		@returns: aggregate validation record, aggregate validation record count
		"""
		ruleVal=ruleVal.split(',')
		rule=ruleVal[0]
		mini=int(ruleVal[1])
		maxi=int(ruleVal[2])
		validated_res=hash_table.withColumn("ERR_CD",lit(ruleID))
		outputDF = hash_table.withColumn(ruleCol,hash_table[ruleCol].cast(IntegerType()))
		dt_type = UtilsDQ.get_dtype(outputDF,ruleCol)

		if rule=='sum':
			if dt_type == 'int' or dt_type == 'float' or dt_type == 'double':
				df_stats = outputDF.select(sum(col(ruleCol)).alias('sum')).collect()
				m=df_stats[0]['sum']
				sum1=int(m)
				validated_res_count=condition(sum1,mini,maxi,hash_table)
			else:
				logger.error("Column {} is not a numerical column".format(ruleCol))	

		if rule=='max':
			if dt_type == 'int' or dt_type == 'float' or dt_type == 'double':
				df_stats = outputDF.select(max(col(ruleCol)).alias('maxi')).collect()
				m = df_stats[0]['maxi']
				max1 = int(m)
				validated_res_count=condition(max1,mini,maxi,hash_table)
			else:
				logger.error("Column {} is not a numerical column".format(ruleCol))

		if rule=='min':
			if dt_type == 'int' or dt_type == 'float' or dt_type == 'double':
				df_stats = outputDF.select(min(col(ruleCol)).alias('mini')).collect()
				m = df_stats[0]['mini']
				min1 = int(m)
				validated_res_count=condition(min1,mini,maxi,hash_table)
			else:
				logger.error("Column {} is not a numerical column".format(ruleCol))

		if rule=='median':
			if dt_type == 'int' or dt_type == 'float' or dt_type == 'double':
				output_df = outputDF.where(col(ruleCol).isNotNull())
				k=output_df.select(col(ruleCol)).count()
				if k%2==0:
					median = (outputDF.approxQuantile(ruleCol,[0.50],0.001)[0]+outputDF.approxQuantile(ruleCol,[0.51],0.001)[0])/2
				else:
					median = outputDF.approxQuantile(ruleCol,[0.50],0.001)[0]
				validated_res_count=condition(median,mini,maxi,hash_table)
			else:
				logger.error("Column {} is not a numerical column".format(ruleCol))	


		if validated_res_count!=0:
			return validated_res,validated_res_count
		else:
			validated_res=validated_res.where(col("ERR_CD")==0)
			return validated_res,validated_res_count

	def data_quality_unique_validation(hash_table, ruleCol, ruleID, logger):
		newdf = (hash_table.groupBy(ruleCol).count()).filter("count==1").filter(hash_table[ruleCol].isNotNull())
		list = newdf.select(ruleCol).rdd.flatMap(lambda x: x).collect()
		df = hash_table.filter(~hash_table[ruleCol].isin(list)|hash_table[ruleCol].isNull())
		return df.withColumn("ERR_CD",lit(ruleID)), hash_table.count()-newdf.count()
